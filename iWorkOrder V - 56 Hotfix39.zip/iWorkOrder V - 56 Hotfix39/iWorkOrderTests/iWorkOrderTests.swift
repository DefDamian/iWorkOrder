import XCTest
import UIKit
import PDFKit
@testable import iWorkOrder

final class LegalAcceptanceTests: XCTestCase {
    func testCurrentAcceptanceRequiresMatchingVersion() {
        var profile = UserProfile()
        profile.legalAccepted = true
        profile.legalAcceptedDate = Date()

        XCTAssertFalse(LegalContent.isCurrentAcceptance(profile))

        profile.legalAcceptedVersion = LegalContent.currentVersion
        XCTAssertTrue(LegalContent.isCurrentAcceptance(profile))
    }

    func testCurrentAcceptanceRequiresAcceptanceDate() {
        var profile = UserProfile()
        profile.legalAccepted = true
        profile.legalAcceptedVersion = LegalContent.currentVersion

        XCTAssertFalse(LegalContent.isCurrentAcceptance(profile))

        profile.legalAcceptedDate = Date()
        XCTAssertTrue(LegalContent.isCurrentAcceptance(profile))
    }

    func testPriorLegalVersionRequiresReacceptance() {
        var profile = UserProfile()
        profile.legalAccepted = true
        profile.legalAcceptedDate = Date()
        profile.legalAcceptedVersion = "2026.08.04.55"

        XCTAssertFalse(LegalContent.isCurrentAcceptance(profile))
        XCTAssertNotEqual(profile.legalAcceptedVersion, LegalContent.currentVersion)
    }

    func testLegacyProfileDecodesWithoutLegalVersion() throws {
        let encoded = try JSONEncoder.pretty.encode(UserProfile())
        var object = try XCTUnwrap(JSONSerialization.jsonObject(with: encoded) as? [String: Any])
        object.removeValue(forKey: "legalAcceptedVersion")
        let legacy = try JSONSerialization.data(withJSONObject: object, options: [.sortedKeys])

        let decoded = try JSONDecoder.iso8601.decode(UserProfile.self, from: legacy)
        XCTAssertNil(decoded.legalAcceptedVersion)
    }

    func testBundledLegalTextDescribesCurrentStorageAndAuditBehavior() {
        XCTAssertTrue(LegalContent.privacy.contains("stores operational data in the app's protected container on the device"))
        XCTAssertTrue(LegalContent.privacy.contains("private Apple CloudKit database"))
        XCTAssertTrue(LegalContent.privacy.contains("not guaranteed to be permanent, immutable, complete"))
        XCTAssertTrue(LegalContent.privacy.contains("material legal or privacy change"))
        XCTAssertTrue(LegalContent.terms.contains("require renewed in-app acceptance"))
        XCTAssertFalse(LegalContent.privacy.contains("All data is stored securely in your personal Apple iCloud account"))
        XCTAssertFalse(LegalContent.terms.contains("immutable audit logs"))
    }
}

final class WorkOrderModelTests: XCTestCase {
    func testSignedLockRequiresCompletedStatusAndSignatureAttachment() {
        var entry = WorkOrderEntry(issueDescription: "Leak")
        var order = WorkOrder(status: .inProgress, entries: [entry])
        XCTAssertFalse(order.isSignedAndLocked)

        entry.signatureFilename = "signature.png"
        order.entries = [entry]
        XCTAssertFalse(order.isSignedAndLocked)

        order.status = .completed
        XCTAssertTrue(order.isSignedAndLocked)
    }

    func testSignatureMetadataRoundTrips() throws {
        let captured = Date(timeIntervalSince1970: 1_725_000_000)
        var entry = WorkOrderEntry(issueDescription: "Boiler inspection")
        entry.signatureFilename = "signature.png"
        entry.signatureSignerName = "Alex Rivera"
        entry.signatureCapturedAt = captured
        entry.signatureConsentVersion = LegalContent.currentVersion

        let encoded = try JSONEncoder.pretty.encode(entry)
        let decoded = try JSONDecoder.iso8601.decode(WorkOrderEntry.self, from: encoded)

        XCTAssertEqual(decoded.signatureFilename, "signature.png")
        XCTAssertEqual(decoded.signatureSignerName, "Alex Rivera")
        XCTAssertEqual(decoded.signatureCapturedAt, captured)
        XCTAssertEqual(decoded.signatureConsentVersion, LegalContent.currentVersion)
    }

    func testSearchIncludesAuditContentAndFiltersStatus() {
        var matching = WorkOrder(status: .pending, entries: [WorkOrderEntry(area: "5A", issueDescription: "Sink leak")])
        matching.auditLog = [AuditEvent(message: "Vendor Acme Plumbing assigned")]
        let wrongStatus = WorkOrder(status: .completed, entries: [WorkOrderEntry(area: "5A", issueDescription: "Sink leak")])
        let filters = WorkOrderFilters(searchText: "Acme")

        let result = WorkOrderSearchEngine.filter([matching, wrongStatus], status: .pending, filters: filters)
        XCTAssertEqual(result.map(\.id), [matching.id])
    }

    func testRequiredFieldsRejectWhitespaceOnlyValues() {
        var entry = WorkOrderEntry(area: "   ", issueDescription: "\n")
        XCTAssertFalse(entry.hasRequiredFields)

        entry.area = "  4A  "
        entry.issueDescription = "  Sink leak  "
        XCTAssertTrue(entry.hasRequiredFields)
        entry.normalizeUserEnteredText()
        XCTAssertEqual(entry.area, "4A")
        XCTAssertEqual(entry.issueDescription, "Sink leak")
    }

    func testCategoryFilterUsesCanonicalIdentity() {
        var entry = WorkOrderEntry(area: "4A", issueDescription: "Outlet")
        entry.managedCategory = .electric
        let order = WorkOrder(status: .inProgress, entries: [entry])
        var filters = WorkOrderFilters()
        filters.category = WorkOrderCategory(rawValue: "  ÉLECTRICAL  ")

        let result = WorkOrderSearchEngine.filter([order], status: .inProgress, filters: filters)

        XCTAssertEqual(result.map(\.id), [order.id])
    }
}

final class AttachmentFilenamePolicyTests: XCTestCase {
    func testAttachmentFilenamePolicyRejectsTraversalAndDirectoryAliases() {
        XCTAssertTrue(AttachmentFilenamePolicy.isSafe("photo-123.jpg"))
        XCTAssertTrue(AttachmentFilenamePolicy.isSafe("signature-123.png"))
        XCTAssertFalse(AttachmentFilenamePolicy.isSafe(""))
        XCTAssertFalse(AttachmentFilenamePolicy.isSafe("."))
        XCTAssertFalse(AttachmentFilenamePolicy.isSafe(".."))
        XCTAssertFalse(AttachmentFilenamePolicy.isSafe("../photo.jpg"))
        XCTAssertFalse(AttachmentFilenamePolicy.isSafe("folder/photo.jpg"))
        XCTAssertFalse(AttachmentFilenamePolicy.isSafe("folder\\photo.jpg"))
        XCTAssertFalse(AttachmentFilenamePolicy.isSafe("photo..jpg"))
        XCTAssertFalse(AttachmentFilenamePolicy.isSafe("photo\u{0000}.jpg"))
        XCTAssertFalse(AttachmentFilenamePolicy.isSafe(String(repeating: "a", count: 256)))
    }

    func testAttachmentContentPolicyRejectsCorruptBytesAndAcceptsImageData() throws {
        XCTAssertFalse(AttachmentContentPolicy.isReadableImageData(Data("not-an-image".utf8)))

        let image = UIGraphicsImageRenderer(size: CGSize(width: 2, height: 2)).image { context in
            UIColor.white.setFill()
            context.fill(CGRect(x: 0, y: 0, width: 2, height: 2))
        }
        let png = try XCTUnwrap(image.pngData())
        XCTAssertTrue(AttachmentContentPolicy.isReadableImageData(png))
    }

    func testEvidenceThumbnailIsDownsampledAndReadable() throws {
        let original = UIGraphicsImageRenderer(size: CGSize(width: 900, height: 600)).image { context in
            UIColor.systemBlue.setFill()
            context.fill(CGRect(x: 0, y: 0, width: 900, height: 600))
        }
        let record = try XCTUnwrap(ImageStorageService.saveCompressed(image: original, kind: .before))
        defer { _ = ImageStorageService.delete(record) }

        let data = try XCTUnwrap(ImageStorageService.thumbnailData(record, maxPixelSize: 120))
        let thumbnail = try XCTUnwrap(UIImage(data: data))

        XCTAssertLessThanOrEqual(max(thumbnail.size.width, thumbnail.size.height), 120.5)
        XCTAssertTrue(AttachmentContentPolicy.isReadableImageData(data))
    }

    func testThumbnailCacheDoesNotReturnDeletedAttachment() async throws {
        let original = UIGraphicsImageRenderer(size: CGSize(width: 320, height: 240)).image { context in
            UIColor.systemGreen.setFill()
            context.fill(CGRect(x: 0, y: 0, width: 320, height: 240))
        }
        let record = try XCTUnwrap(ImageStorageService.saveCompressed(image: original, kind: .after))

        let first = await WorkOrderImageThumbnailCache.shared.data(for: record, maxPixelSize: 90)
        XCTAssertNotNil(first)
        XCTAssertTrue(ImageStorageService.delete(record))

        let afterDelete = await WorkOrderImageThumbnailCache.shared.data(for: record, maxPixelSize: 90)
        XCTAssertNil(afterDelete)
    }


    func testPickerDataCompressionWritesBoundedReadableJPEG() throws {
        let original = UIGraphicsImageRenderer(size: CGSize(width: 1600, height: 1200)).image { context in
            UIColor.systemOrange.setFill()
            context.fill(CGRect(x: 0, y: 0, width: 1600, height: 1200))
        }
        let sourceData = try XCTUnwrap(original.pngData())
        let record = try XCTUnwrap(
            ImageStorageService.saveCompressed(data: sourceData, kind: .before, maxPixelSize: 240)
        )
        defer { _ = ImageStorageService.delete(record) }

        XCTAssertEqual(URL(fileURLWithPath: record.filename).pathExtension.lowercased(), "jpg")
        let storedURL = try XCTUnwrap(ImageStorageService.safeURL(forFilename: record.filename))
        let storedData = try Data(contentsOf: storedURL)
        let storedImage = try XCTUnwrap(UIImage(data: storedData))
        XCTAssertLessThanOrEqual(max(storedImage.size.width, storedImage.size.height), 240.5)
        XCTAssertTrue(AttachmentContentPolicy.isReadableImageData(storedData))
    }
}

final class PresentationIdentityTests: XCTestCase {
    func testIdentifiableURLUsesStableURLIdentity() {
        let url = URL(fileURLWithPath: "/tmp/iworkorder-report.pdf")
        XCTAssertEqual(IdentifiableURL(url: url).id, IdentifiableURL(url: url).id)
        XCTAssertNotEqual(
            IdentifiableURL(url: url).id,
            IdentifiableURL(url: URL(fileURLWithPath: "/tmp/other-report.pdf")).id
        )
    }
}

final class MergeAndBackupTests: XCTestCase {
    func testConflictMergePreservesPrimaryProfileWhileImportingCurrentLegalAcceptance() throws {
        let orderID = UUID()
        let localOrder = WorkOrder(id: orderID, status: .inProgress, entries: [WorkOrderEntry(issueDescription: "Local")])
        let cloudOrder = WorkOrder(id: orderID, status: .pending, entries: [WorkOrderEntry(issueDescription: "Cloud")])

        var localProfile = UserProfile()
        localProfile.personName = "Local User"
        localProfile.buildingAddress = "100 Local Street"

        var cloudProfile = UserProfile()
        cloudProfile.personName = "Old Cloud User"
        cloudProfile.buildingAddress = "999 Cloud Street"
        cloudProfile.legalAccepted = true
        cloudProfile.legalAcceptedDate = Date(timeIntervalSince1970: 200)
        cloudProfile.legalAcceptedVersion = LegalContent.currentVersion

        let local = AppSnapshot(
            profile: localProfile,
            workOrders: [localOrder],
            snapshotSavedAt: Date(timeIntervalSince1970: 300),
            deviceID: "local"
        )
        let cloud = AppSnapshot(
            profile: cloudProfile,
            workOrders: [cloudOrder],
            snapshotSavedAt: Date(timeIntervalSince1970: 100),
            deviceID: "cloud"
        )

        let merged = try XCTUnwrap(ConflictMergeService.merge(local: local, cloud: cloud))
        XCTAssertEqual(merged.profile.personName, "Local User")
        XCTAssertEqual(merged.profile.buildingAddress, "100 Local Street")
        XCTAssertTrue(LegalContent.isCurrentAcceptance(merged.profile))
    }

    func testRecoveryEventWinsOverOlderDeletionDuringMerge() throws {
        let orderID = UUID()
        let deletedAt = Date(timeIntervalSince1970: 100)
        let recoveredAt = Date(timeIntervalSince1970: 200)
        var deleted = WorkOrder(id: orderID, status: .inProgress, entries: [WorkOrderEntry(area: "4A", issueDescription: "Leak")])
        deleted.isDeleted = true
        deleted.deletedAt = deletedAt
        deleted.statusEntries = [StatusEntry(kind: .deleted, date: deletedAt, detail: "Moved to trash")]
        deleted.auditLog = [AuditEvent(date: deletedAt, message: "Moved to trash")]

        var recovered = deleted
        recovered.isDeleted = false
        recovered.deletedAt = nil
        recovered.statusEntries?.append(StatusEntry(kind: .recovered, date: recoveredAt, detail: "Recovered from trash"))
        recovered.auditLog.append(AuditEvent(date: recoveredAt, message: "Recovered from trash"))

        let merged = try XCTUnwrap(ConflictMergeService.merge(
            local: AppSnapshot(profile: UserProfile(), workOrders: [recovered], snapshotSavedAt: Date(timeIntervalSince1970: 250), deviceID: "local"),
            cloud: AppSnapshot(profile: UserProfile(), workOrders: [deleted], snapshotSavedAt: Date(timeIntervalSince1970: 300), deviceID: "cloud")
        ))
        XCTAssertFalse(try XCTUnwrap(merged.workOrders.first).isDeleted)
        XCTAssertNil(merged.workOrders.first?.deletedAt)
    }

    func testNewerDeletionEventWinsOverOlderRecoveryDuringMerge() throws {
        let orderID = UUID()
        let recoveredAt = Date(timeIntervalSince1970: 200)
        let deletedAgainAt = Date(timeIntervalSince1970: 400)
        var recovered = WorkOrder(id: orderID, status: .inProgress, entries: [WorkOrderEntry(area: "4A", issueDescription: "Leak")])
        recovered.statusEntries = [StatusEntry(kind: .recovered, date: recoveredAt, detail: "Recovered from trash")]
        recovered.auditLog = [AuditEvent(date: recoveredAt, message: "Recovered from trash")]

        var deletedAgain = recovered
        deletedAgain.isDeleted = true
        deletedAgain.deletedAt = deletedAgainAt
        deletedAgain.statusEntries?.append(StatusEntry(kind: .deleted, date: deletedAgainAt, detail: "Moved to trash"))
        deletedAgain.auditLog.append(AuditEvent(date: deletedAgainAt, message: "Moved to trash"))

        let merged = try XCTUnwrap(ConflictMergeService.merge(
            local: AppSnapshot(profile: UserProfile(), workOrders: [recovered], snapshotSavedAt: Date(timeIntervalSince1970: 500), deviceID: "local"),
            cloud: AppSnapshot(profile: UserProfile(), workOrders: [deletedAgain], snapshotSavedAt: Date(timeIntervalSince1970: 450), deviceID: "cloud")
        ))
        XCTAssertTrue(try XCTUnwrap(merged.workOrders.first).isDeleted)
        XCTAssertEqual(merged.workOrders.first?.deletedAt, deletedAgainAt)
    }

    func testNewerRevisionTimestampWinsLegacyMergeWithoutAuditEvents() throws {
        let orderID = UUID()
        let orderCreatedAt = Date(timeIntervalSince1970: 50)
        let olderEntry = WorkOrderEntry(id: UUID(), createdAt: Date(timeIntervalSince1970: 100), area: "4A", issueDescription: "Older")
        let newerEntry = WorkOrderEntry(id: UUID(), createdAt: Date(timeIntervalSince1970: 500), area: "4A", issueDescription: "Newer")
        let localOrder = WorkOrder(id: orderID, createdAt: orderCreatedAt, status: .completed, entries: [olderEntry], auditLog: [], statusEntries: [])
        let cloudOrder = WorkOrder(id: orderID, createdAt: orderCreatedAt, status: .pending, entries: [newerEntry], auditLog: [], statusEntries: [])

        let merged = try XCTUnwrap(ConflictMergeService.merge(
            local: AppSnapshot(profile: UserProfile(), workOrders: [localOrder], snapshotSavedAt: Date(timeIntervalSince1970: 900), deviceID: "local"),
            cloud: AppSnapshot(profile: UserProfile(), workOrders: [cloudOrder], snapshotSavedAt: Date(timeIntervalSince1970: 800), deviceID: "cloud")
        ))

        XCTAssertEqual(try XCTUnwrap(merged.workOrders.first).status, .pending)
        XCTAssertEqual(merged.workOrders.first?.latestEntry.issueDescription, "Newer")
    }

    func testExplicitProfileFreshnessWinsOverNewerUnrelatedSnapshot() throws {
        var localProfile = UserProfile()
        localProfile.buildingAddress = "100 Correct Street"
        localProfile.notificationsEnabled = true
        localProfile.firstBuildingUnits = ["1A"]

        var cloudProfile = UserProfile()
        cloudProfile.buildingAddress = "999 Stale Street"
        cloudProfile.notificationsEnabled = false
        cloudProfile.firstBuildingUnits = ["2B"]

        let local = AppSnapshot(
            profile: localProfile,
            workOrders: [],
            profileConfigurationUpdatedAt: Date(timeIntervalSince1970: 500),
            snapshotSavedAt: Date(timeIntervalSince1970: 100),
            deviceID: "local"
        )
        let cloud = AppSnapshot(
            profile: cloudProfile,
            workOrders: [],
            profileConfigurationUpdatedAt: Date(timeIntervalSince1970: 400),
            snapshotSavedAt: Date(timeIntervalSince1970: 900),
            deviceID: "cloud"
        )

        let merged = try XCTUnwrap(ConflictMergeService.merge(local: local, cloud: cloud))
        XCTAssertEqual(merged.profile.buildingAddress, "100 Correct Street")
        XCTAssertTrue(merged.profile.notificationsEnabled)
        XCTAssertEqual(merged.profileConfigurationUpdatedAt, Date(timeIntervalSince1970: 500))
        XCTAssertEqual(Set(merged.profile.firstBuildingUnits), Set(["1A", "2B"]))
    }

    func testExplicitProfileFreshnessBeatsLegacySnapshotWithoutProfileTimestamp() throws {
        var localProfile = UserProfile()
        localProfile.personName = "Current Profile"
        localProfile.firstBuildingUnits = ["1A", "１Ａ"]

        var legacyProfile = UserProfile()
        legacyProfile.personName = "Legacy Stale Profile"
        legacyProfile.firstBuildingUnits = ["2B"]

        let local = AppSnapshot(
            profile: localProfile,
            workOrders: [],
            profileConfigurationUpdatedAt: Date(timeIntervalSince1970: 500),
            snapshotSavedAt: Date(timeIntervalSince1970: 100),
            deviceID: "local"
        )
        let legacyCloud = AppSnapshot(
            profile: legacyProfile,
            workOrders: [],
            snapshotSavedAt: Date(timeIntervalSince1970: 1000),
            deviceID: "cloud"
        )

        let merged = try XCTUnwrap(ConflictMergeService.merge(local: local, cloud: legacyCloud))
        XCTAssertEqual(merged.profile.personName, "Current Profile")
        XCTAssertEqual(Set(merged.profile.firstBuildingUnits), Set(["1A", "2B"]))
    }

    func testNewerExplicitLegalDeclineIsNotOverriddenByOlderAcceptance() throws {
        var declinedProfile = UserProfile()
        declinedProfile.personName = "Current Profile"
        declinedProfile.legalAccepted = false
        declinedProfile.legalAcceptedDate = nil
        declinedProfile.legalAcceptedVersion = nil

        var olderAcceptedProfile = UserProfile()
        olderAcceptedProfile.personName = "Older Profile"
        olderAcceptedProfile.legalAccepted = true
        olderAcceptedProfile.legalAcceptedDate = Date(timeIntervalSince1970: 150)
        olderAcceptedProfile.legalAcceptedVersion = LegalContent.currentVersion

        let merged = try XCTUnwrap(ConflictMergeService.merge(
            local: AppSnapshot(
                profile: declinedProfile,
                workOrders: [],
                profileConfigurationUpdatedAt: Date(timeIntervalSince1970: 300),
                snapshotSavedAt: Date(timeIntervalSince1970: 100),
                deviceID: "newer-decline"
            ),
            cloud: AppSnapshot(
                profile: olderAcceptedProfile,
                workOrders: [],
                profileConfigurationUpdatedAt: Date(timeIntervalSince1970: 200),
                snapshotSavedAt: Date(timeIntervalSince1970: 400),
                deviceID: "older-acceptance"
            )
        ))

        XCTAssertEqual(merged.profile.personName, "Current Profile")
        XCTAssertFalse(merged.profile.legalAccepted)
        XCTAssertNil(merged.profile.legalAcceptedVersion)
    }

    func testNewerExplicitLegalDeclineBeatsLegacyOlderAcceptanceDate() throws {
        var declinedProfile = UserProfile()
        declinedProfile.personName = "Current Profile"
        declinedProfile.legalAccepted = false
        declinedProfile.legalAcceptedDate = nil
        declinedProfile.legalAcceptedVersion = nil

        var legacyAcceptedProfile = UserProfile()
        legacyAcceptedProfile.personName = "Legacy Accepted Profile"
        legacyAcceptedProfile.legalAccepted = true
        legacyAcceptedProfile.legalAcceptedDate = Date(timeIntervalSince1970: 150)
        legacyAcceptedProfile.legalAcceptedVersion = LegalContent.currentVersion

        let merged = try XCTUnwrap(ConflictMergeService.merge(
            local: AppSnapshot(
                profile: declinedProfile,
                workOrders: [],
                profileConfigurationUpdatedAt: Date(timeIntervalSince1970: 300),
                snapshotSavedAt: Date(timeIntervalSince1970: 100),
                deviceID: "newer-decline"
            ),
            cloud: AppSnapshot(
                profile: legacyAcceptedProfile,
                workOrders: [],
                snapshotSavedAt: Date(timeIntervalSince1970: 400),
                deviceID: "legacy-older-acceptance"
            )
        ))

        XCTAssertEqual(merged.profile.personName, "Current Profile")
        XCTAssertFalse(merged.profile.legalAccepted)
        XCTAssertNil(merged.profile.legalAcceptedVersion)
    }

    func testSnapshotWithoutCommittedMutationDoesNotInventFreshness() {
        let snapshot = AppSnapshot(profile: UserProfile(), workOrders: [])
        XCTAssertNil(snapshot.snapshotSavedAt)
        XCTAssertNil(snapshot.profileConfigurationUpdatedAt)
    }

    func testUnrelatedNewerAuditCannotRollBackExplicitStatusTransition() throws {
        let orderID = UUID()
        let statusChangedAt = Date(timeIntervalSince1970: 100)
        let viewedAt = Date(timeIntervalSince1970: 200)

        var completed = WorkOrder(
            id: orderID,
            status: .completed,
            entries: [WorkOrderEntry(area: "7A", issueDescription: "Boiler repair")]
        )
        completed.statusEntries = [
            StatusEntry(kind: .statusChanged, date: statusChangedAt, detail: "Status changed to Completed")
        ]
        completed.auditLog = [AuditEvent(date: statusChangedAt, message: "Status changed to Completed")]

        var staleViewed = completed
        staleViewed.status = .inProgress
        staleViewed.statusEntries = []
        staleViewed.auditLog = [AuditEvent(date: viewedAt, message: "Work order opened")]

        let merged = try XCTUnwrap(ConflictMergeService.merge(
            local: AppSnapshot(
                profile: UserProfile(),
                workOrders: [staleViewed],
                snapshotSavedAt: viewedAt,
                deviceID: "stale-viewer"
            ),
            cloud: AppSnapshot(
                profile: UserProfile(),
                workOrders: [completed],
                snapshotSavedAt: statusChangedAt,
                deviceID: "status-writer"
            )
        ))

        XCTAssertEqual(merged.workOrders.first?.status, .completed)
    }

    func testDuplicateWorkOrderIDsCoalesceWithoutDroppingDistinctRevisions() {
        let orderID = UUID()
        var firstEntry = WorkOrderEntry(area: "1A", issueDescription: "First revision")
        var secondEntry = WorkOrderEntry(area: "1A", issueDescription: "Second revision")
        secondEntry.createdAt = firstEntry.createdAt.addingTimeInterval(1)

        let first = WorkOrder(id: orderID, status: .inProgress, entries: [firstEntry])
        let second = WorkOrder(id: orderID, status: .inProgress, entries: [secondEntry])
        let coalesced = ConflictMergeService.coalesceWorkOrders([first, second])

        XCTAssertEqual(coalesced.count, 1)
        XCTAssertEqual(coalesced[0].entries.count, 2)
        XCTAssertEqual(Set(coalesced[0].entries.map(\.issueDescription)), Set(["First revision", "Second revision"]))
    }

    func testAttachmentReferenceManifestIncludesPhotosAndSignatures() {
        var entry = WorkOrderEntry(issueDescription: "Window")
        entry.images = [
            WorkOrderImage(filename: "before.jpg", kind: .before),
            WorkOrderImage(filename: "after.jpg", kind: .after)
        ]
        entry.signatureFilename = "signature.png"
        let snapshot = AppSnapshot(profile: UserProfile(), workOrders: [WorkOrder(entries: [entry])])

        let references = BackupArchiveService.referencedAttachmentFilenames(in: snapshot)
        XCTAssertEqual(references.images, Set(["before.jpg", "after.jpg"]))
        XCTAssertEqual(references.signatures, Set(["signature.png"]))
    }
}


final class AccessibilityConfigurationTests: XCTestCase {
    func testMainTabsExposeUniqueStableIdentifiers() {
        let identifiers = MainTab.allCases.map(AccessibilityID.mainTab)
        XCTAssertEqual(Set(identifiers).count, MainTab.allCases.count)
        XCTAssertEqual(identifiers, [
            "main.tab.workOrders",
            "main.tab.calendar",
            "main.tab.hub",
            "main.tab.settings"
        ])
    }

    func testStatusFiltersExposeUniqueStableIdentifiers() {
        let identifiers = WorkOrderStatus.allCases.map(AccessibilityID.statusFilter)
        XCTAssertEqual(Set(identifiers).count, WorkOrderStatus.allCases.count)
    }

    func testMainTabKeyboardShortcutsAreUnique() {
        let shortcuts = MainTab.allCases.map(\.keyboardShortcutLabel)
        XCTAssertEqual(Set(shortcuts).count, MainTab.allCases.count)
        XCTAssertEqual(shortcuts, ["1", "2", "3", "4"])
    }
}

final class DiagnosticReportTests: XCTestCase {
    func testDiagnosticsExcludeOperationalAndPersonalContent() {
        let context = DiagnosticReportContext(
            generatedAt: Date(timeIntervalSince1970: 1_725_000_000),
            appVersion: "1.0 (56)",
            systemName: "iOS",
            systemVersion: "26.0",
            deviceFamily: "iPhone",
            localeIdentifier: "en_US",
            timeZoneIdentifier: "America/New_York",
            storageMode: "Local Only",
            iCloudEnabled: false,
            cloudState: "Off",
            networkAvailable: true,
            lastSuccessfulSync: nil,
            cloudReplacementPending: false,
            cloudErasePending: false,
            cloudSyncPausedForRecovery: false,
            possibleInterruptedSessionCount7Days: 0,
            memoryPressureCount7Days: 0,
            currentSessionMemoryWarningCount: 0,
            notificationsEnabled: true,
            emergencyNotificationsEnabled: true,
            appLockEnabled: true,
            activeWorkOrderCount: 12,
            deletedWorkOrderCount: 2,
            revisionCount: 19,
            photoReferenceCount: 8,
            signatureReferenceCount: 3,
            assetCount: 4,
            tenantCount: 10,
            localStorageUsage: "4.2 MB",
            legalVersion: LegalContent.currentVersion,
            legalAcceptanceCurrent: true,
            backupOperationActive: false,
            recentErrorPresent: true
        )

        let report = DiagnosticReportService.reportText(for: context)

        XCTAssertTrue(report.contains("Active Work Orders: 12"))
        XCTAssertTrue(report.contains("Recent Error Present: Yes"))
        XCTAssertTrue(report.contains("intentionally excludes names"))
        XCTAssertFalse(report.contains("100 Test Avenue"))
        XCTAssertFalse(report.contains("Leaking kitchen faucet"))
        XCTAssertFalse(report.contains("tenant@example.com"))
        XCTAssertFalse(report.contains("signature.png"))
        XCTAssertFalse(report.contains("iWorkOrder.deviceID"))
    }

    func testDiagnosticFilenameIsTimestampedTextFile() throws {
        let context = DiagnosticReportContext(
            generatedAt: Date(timeIntervalSince1970: 1_725_000_000),
            appVersion: "1.0 (56)",
            systemName: "iOS",
            systemVersion: "26.0",
            deviceFamily: "iPhone",
            localeIdentifier: "en_US",
            timeZoneIdentifier: "UTC",
            storageMode: "Local Only",
            iCloudEnabled: false,
            cloudState: "Off",
            networkAvailable: false,
            lastSuccessfulSync: nil,
            cloudReplacementPending: false,
            cloudErasePending: false,
            cloudSyncPausedForRecovery: false,
            possibleInterruptedSessionCount7Days: 0,
            memoryPressureCount7Days: 0,
            currentSessionMemoryWarningCount: 0,
            notificationsEnabled: false,
            emergencyNotificationsEnabled: false,
            appLockEnabled: false,
            activeWorkOrderCount: 0,
            deletedWorkOrderCount: 0,
            revisionCount: 0,
            photoReferenceCount: 0,
            signatureReferenceCount: 0,
            assetCount: 0,
            tenantCount: 0,
            localStorageUsage: "0 bytes",
            legalVersion: LegalContent.currentVersion,
            legalAcceptanceCurrent: true,
            backupOperationActive: false,
            recentErrorPresent: false
        )

        let url = try DiagnosticReportService.writeReport(context: context)
        defer { try? FileManager.default.removeItem(at: url) }

        XCTAssertEqual(url.pathExtension, "txt")
        XCTAssertTrue(url.lastPathComponent.hasPrefix("iWorkOrder-Diagnostics-"))
        XCTAssertTrue(FileManager.default.fileExists(atPath: url.path))

        let draft = EmailHelper.supportDraft(diagnosticsURL: url)
        XCTAssertEqual(draft.attachmentURLs, [url])
        XCTAssertEqual(draft.attachments.first?.filename, url.lastPathComponent)
    }
}

final class MaintenanceAndMigrationTests: XCTestCase {
    func testLegacySchemaMigratesWithoutInventingOperationalContent() throws {
        var order = WorkOrder(
            status: .pending,
            entries: [WorkOrderEntry(area: "5A", issueDescription: "Existing issue")]
        )
        order.statusEntries = nil
        let legacy = AppSnapshot(
            profile: UserProfile(),
            workOrders: [order],
            assets: nil,
            tenants: nil,
            dataSchemaVersion: 1
        )

        let result = try MaintenanceService.migrate(legacy)

        XCTAssertTrue(result.changed)
        XCTAssertEqual(result.sourceVersion, 1)
        XCTAssertEqual(result.targetVersion, AppDataSchema.currentVersion)
        XCTAssertEqual(result.snapshot.dataSchemaVersion, AppDataSchema.currentVersion)
        XCTAssertEqual(result.snapshot.workOrders.first?.latestEntry.issueDescription, "Existing issue")
        XCTAssertEqual(result.snapshot.workOrders.first?.statusEntries, [])
        XCTAssertEqual(result.snapshot.assets, [])
        XCTAssertEqual(result.snapshot.tenants, [])
        XCTAssertEqual(result.snapshot.categories, WorkOrderCategory.defaultCategories)
    }

    func testFutureSchemaIsBlockedInsteadOfDowngraded() {
        let future = AppSnapshot(
            profile: UserProfile(),
            workOrders: [],
            dataSchemaVersion: AppDataSchema.currentVersion + 1
        )

        XCTAssertThrowsError(try MaintenanceService.migrate(future)) { error in
            XCTAssertEqual(error as? DataMigrationError, .unsupportedFutureVersion(AppDataSchema.currentVersion + 1))
        }
    }

    func testMaintenanceReportContainsOnlyStructuredOperationalFields() {
        let health = MaintenanceHealthReport(
            generatedAt: Date(timeIntervalSince1970: 1_725_000_000),
            schemaVersion: 2,
            snapshotSchemaVersion: 2,
            primarySnapshotPresent: true,
            fallbackSnapshotPresent: true,
            migrationBackupCount: 1,
            safetyBackupCount: 2,
            missingPhotoCount: 0,
            missingSignatureCount: 0,
            orphanPhotoCount: 1,
            orphanSignatureCount: 0,
            duplicateRevisionIDCount: 0,
            emptyWorkOrderCount: 0,
            cloudReplacementPending: false,
            cloudErasePending: false,
            recentFailureCount: 0,
            possibleInterruptedSessionCount7Days: 1,
            memoryPressureCount7Days: 2,
            cloudSyncPausedForRecovery: true,
            lastKnownGoodBuild: "1.0 (56)"
        )
        let events = [
            MaintenanceEvent(
                date: Date(timeIntervalSince1970: 1_725_000_001),
                kind: .localSave,
                outcome: .success,
                durationMilliseconds: 12,
                itemCount: 3,
                schemaVersion: 2,
                buildVersion: "1.0 (56)"
            )
        ]

        let report = MaintenanceService.reportText(health: health, recentEvents: events)

        XCTAssertTrue(report.contains("kind=localSave outcome=success"))
        XCTAssertTrue(report.contains("durationMs=12"))
        XCTAssertTrue(report.contains("Possible Interrupted Sessions in Last 7 Days: 1"))
        XCTAssertTrue(report.contains("Memory-Pressure Warnings in Last 7 Days: 2"))
        XCTAssertTrue(report.contains("Cloud Sync Paused for Recovery: Yes"))
        XCTAssertTrue(report.contains("excludes names, addresses"))
        XCTAssertFalse(report.contains("5A"))
        XCTAssertFalse(report.contains("Existing issue"))
        XCTAssertFalse(report.contains("tenant@example.com"))
        XCTAssertFalse(report.contains("signature.png"))
    }
}


final class RuntimeReliabilityTests: XCTestCase {
    override func setUp() {
        super.setUp()
        MaintenanceService.deleteAll()
        RuntimeReliabilityService.deleteAll()
    }

    override func tearDown() {
        RuntimeReliabilityService.deleteAll()
        MaintenanceService.deleteAll()
        super.tearDown()
    }

    func testPossibleInterruptedSessionIsRecordedWithoutClaimingCrash() throws {
        let started = Date(timeIntervalSince1970: 1_725_100_000)
        let prior = RuntimeSessionCheckpoint(
            sessionStartedAt: started,
            lastUpdatedAt: started.addingTimeInterval(5),
            lifecycleState: .active,
            buildVersion: "1.0 (54)",
            schemaVersion: AppDataSchema.currentVersion,
            memoryWarningCount: 0
        )
        try FileManager.default.createDirectory(
            at: MaintenanceService.maintenanceDirectory,
            withIntermediateDirectories: true
        )
        try JSONEncoder.pretty.encode(prior).write(to: RuntimeReliabilityService.checkpointURL, options: .atomic)

        let summary = RuntimeReliabilityService.beginSession(at: started.addingTimeInterval(10))

        XCTAssertTrue(summary.previousSessionPossiblyInterrupted)
        XCTAssertEqual(summary.interruptedSessionCount7Days, 1)
        XCTAssertEqual(RuntimeReliabilityService.checkpoint()?.lifecycleState, .launching)
        XCTAssertEqual(MaintenanceService.events().last?.kind, .sessionInterrupted)
    }

    func testBackgroundCheckpointDoesNotCreateInterruptionWarning() throws {
        let started = Date()
        RuntimeReliabilityService.beginSession(at: started)
        RuntimeReliabilityService.transition(to: .background, at: started.addingTimeInterval(2))
        MaintenanceService.clearHistory()

        let summary = RuntimeReliabilityService.beginSession(at: started.addingTimeInterval(4))

        XCTAssertFalse(summary.previousSessionPossiblyInterrupted)
        XCTAssertEqual(MaintenanceService.events().filter { $0.kind == .sessionInterrupted }.count, 0)
    }

    func testMemoryWarningsAndRecoveryPauseAreAggregateOnly() {
        let now = Date()
        RuntimeReliabilityService.beginSession(at: now)
        RuntimeReliabilityService.noteMemoryWarning(at: now.addingTimeInterval(1))
        RuntimeReliabilityService.setCloudSyncPaused(true)

        let summary = RuntimeReliabilityService.summary(at: now.addingTimeInterval(2))

        XCTAssertEqual(summary.currentSessionMemoryWarningCount, 1)
        XCTAssertEqual(summary.memoryWarningCount7Days, 1)
        XCTAssertTrue(summary.cloudSyncPausedForRecovery)
        XCTAssertTrue(MaintenanceService.events().contains { $0.kind == .recoverySyncPauseChanged })
    }
}

final class SupportBundleTests: XCTestCase {
    func testSupportBundleChecksumDetectsTampering() throws {
        let generatedAt = Date(timeIntervalSince1970: 1_725_200_000)
        let content = SupportBundleContent(
            formatIdentifier: SupportBundleService.formatIdentifier,
            formatVersion: SupportBundleService.formatVersion,
            reportID: UUID(uuidString: "11111111-2222-3333-4444-555555555555")!,
            generatedAt: generatedAt,
            applicationVersion: "1.0 (56)",
            dataSchemaVersion: AppDataSchema.currentVersion,
            legalVersion: LegalContent.currentVersion,
            diagnosticReport: "Privacy-safe diagnostics only",
            maintenanceReport: "Structured maintenance only",
            reliabilitySummary: RuntimeReliabilitySummary(
                generatedAt: generatedAt,
                previousSessionPossiblyInterrupted: false,
                interruptedSessionCount7Days: 0,
                memoryWarningCount7Days: 0,
                currentSessionMemoryWarningCount: 0,
                currentLifecycleState: .active,
                currentSessionStartedAt: generatedAt,
                lastCheckpointAt: generatedAt,
                cloudSyncPausedForRecovery: false
            ),
            recentEvents: [
                MaintenanceEvent(
                    date: generatedAt,
                    kind: .healthCheck,
                    outcome: .success,
                    itemCount: 0,
                    schemaVersion: AppDataSchema.currentVersion,
                    buildVersion: "1.0 (56)"
                )
            ]
        )
        let envelope = try SupportBundleService.makeEnvelope(content: content)
        let url = FileManager.default.temporaryDirectory.appendingPathComponent("support-test.iworkordersupport")
        defer { try? FileManager.default.removeItem(at: url) }
        try JSONEncoder.pretty.encode(envelope).write(to: url, options: .atomic)

        XCTAssertEqual(try SupportBundleService.validateBundle(at: url), envelope)

        var object = try XCTUnwrap(JSONSerialization.jsonObject(with: Data(contentsOf: url)) as? [String: Any])
        var contentObject = try XCTUnwrap(object["content"] as? [String: Any])
        contentObject["diagnosticReport"] = "tampered"
        object["content"] = contentObject
        try JSONSerialization.data(withJSONObject: object, options: [.prettyPrinted, .sortedKeys]).write(to: url, options: .atomic)

        XCTAssertThrowsError(try SupportBundleService.validateBundle(at: url)) { error in
            XCTAssertEqual(error as? SupportBundleError, .checksumMismatch)
        }
    }

    func testSupportBundleContentContainsNoOperationalRecordText() throws {
        let generatedAt = Date(timeIntervalSince1970: 1_725_200_000)
        let content = SupportBundleContent(
            formatIdentifier: SupportBundleService.formatIdentifier,
            formatVersion: SupportBundleService.formatVersion,
            reportID: UUID(),
            generatedAt: generatedAt,
            applicationVersion: "1.0 (56)",
            dataSchemaVersion: AppDataSchema.currentVersion,
            legalVersion: LegalContent.currentVersion,
            diagnosticReport: "This report intentionally excludes names and work-order text.",
            maintenanceReport: "This local report excludes names, addresses, notes, and filenames.",
            reliabilitySummary: RuntimeReliabilitySummary(
                generatedAt: generatedAt,
                previousSessionPossiblyInterrupted: false,
                interruptedSessionCount7Days: 0,
                memoryWarningCount7Days: 0,
                currentSessionMemoryWarningCount: 0,
                currentLifecycleState: .background,
                currentSessionStartedAt: generatedAt,
                lastCheckpointAt: generatedAt,
                cloudSyncPausedForRecovery: false
            ),
            recentEvents: []
        )
        let encoded = String(decoding: try JSONEncoder.pretty.encode(content), as: UTF8.self)

        XCTAssertFalse(encoded.contains("100 Test Avenue"))
        XCTAssertFalse(encoded.contains("Leaking kitchen faucet"))
        XCTAssertFalse(encoded.contains("tenant@example.com"))
        XCTAssertFalse(encoded.contains("signature.png"))
        XCTAssertFalse(encoded.contains("iWorkOrder.deviceID"))
    }
}

final class CategoryConfigurationTests: XCTestCase {
    func testCategoryCodingRemainsCompatibleWithLegacyStringValues() throws {
        let legacyData = Data("\"Plumbing\"".utf8)
        let decoded = try JSONDecoder().decode(WorkOrderCategory.self, from: legacyData)
        XCTAssertEqual(decoded, .plumbing)

        let encoded = try JSONEncoder().encode(WorkOrderCategory(rawValue: "Elevators"))
        XCTAssertEqual(String(decoding: encoded, as: UTF8.self), "\"Elevators\"")
    }

    func testCategoryNamesNormalizeWhitespace() {
        XCTAssertEqual(WorkOrderCategory.normalizedName("  Fire   Safety\nInspection  "), "Fire Safety Inspection")
    }

    func testCategoryIdentityIsStableAcrossCaseDiacriticsAndWidth() {
        XCTAssertEqual(
            WorkOrderCategory.identityKey("  ÉLECTRICAL  "),
            WorkOrderCategory.identityKey("electrical")
        )
        XCTAssertEqual(
            WorkOrderCategory.identityKey("ＰＬＵＭＢＩＮＧ"),
            WorkOrderCategory.identityKey("plumbing")
        )
    }

    func testCategoryReorderingPreservesRequestedOrder() {
        let categories = [
            WorkOrderCategory(rawValue: "A"),
            WorkOrderCategory(rawValue: "B"),
            WorkOrderCategory(rawValue: "C"),
            WorkOrderCategory(rawValue: "D")
        ]

        let reordered = WorkOrderCategory.reordered(
            categories,
            moving: IndexSet(integer: 1),
            to: 4
        )

        XCTAssertEqual(reordered.map(\.rawValue), ["A", "C", "D", "B"])
    }

    func testCustomCategoryKeepsLegacyWireValueForForwardSchemaProtection() throws {
        var entry = WorkOrderEntry(area: "4A", issueDescription: "Elevator inspection")
        entry.managedCategory = WorkOrderCategory(rawValue: "Elevators")

        let encoded = try JSONEncoder().encode(entry)
        let object = try XCTUnwrap(JSONSerialization.jsonObject(with: encoded) as? [String: Any])
        XCTAssertEqual(object["category"] as? String, LegacyWorkOrderCategory.other.rawValue)
        XCTAssertEqual(object["customCategoryName"] as? String, "Elevators")

        let decoded = try JSONDecoder().decode(WorkOrderEntry.self, from: encoded)
        XCTAssertEqual(decoded.managedCategory, WorkOrderCategory(rawValue: "Elevators"))
    }

    func testNewestCategoryConfigurationWinsCloudMergeIndependentlyOfSnapshotDate() {
        let localCategoryDate = Date(timeIntervalSince1970: 500)
        let cloudCategoryDate = Date(timeIntervalSince1970: 400)
        let local = AppSnapshot(
            profile: UserProfile(),
            workOrders: [],
            categories: [WorkOrderCategory(rawValue: "Elevators"), .plumbing],
            categoryConfigurationUpdatedAt: localCategoryDate,
            snapshotSavedAt: Date(timeIntervalSince1970: 100),
            deviceID: "local"
        )
        let cloud = AppSnapshot(
            profile: UserProfile(),
            workOrders: [],
            categories: [.hvac, .other],
            categoryConfigurationUpdatedAt: cloudCategoryDate,
            snapshotSavedAt: Date(timeIntervalSince1970: 600),
            deviceID: "cloud"
        )

        let merged = ConflictMergeService.merge(local: local, cloud: cloud)

        XCTAssertEqual(merged?.categories, [WorkOrderCategory(rawValue: "Elevators"), .plumbing])
        XCTAssertEqual(merged?.categoryConfigurationUpdatedAt, localCategoryDate)
    }

    func testSchemaTwoMigrationAddsManagedCategoryConfiguration() throws {
        let legacy = AppSnapshot(
            profile: UserProfile(),
            workOrders: [],
            categories: nil,
            dataSchemaVersion: 2
        )

        let migrated = try MaintenanceService.migrate(legacy)

        XCTAssertEqual(migrated.targetVersion, 3)
        XCTAssertEqual(migrated.snapshot.categories, WorkOrderCategory.defaultCategories)
        XCTAssertEqual(migrated.snapshot.dataSchemaVersion, 3)
    }
}

final class NotificationSchedulingPolicyTests: XCTestCase {
    func testReminderAndEmergencyUseIndependentIdentifiers() {
        let orderID = UUID()
        let entryID = UUID()
        let reminder = WorkOrderNotificationIdentifier.reminder(orderID: orderID)
        let emergency = WorkOrderNotificationIdentifier.emergency(orderID: orderID, entryID: entryID)

        XCTAssertNotEqual(reminder, emergency)
        XCTAssertEqual(WorkOrderNotificationIdentifier.workOrderID(from: reminder), orderID)
        XCTAssertEqual(WorkOrderNotificationIdentifier.workOrderID(from: emergency), orderID)
        XCTAssertEqual(WorkOrderNotificationIdentifier.workOrderID(from: orderID.uuidString), orderID)
    }

    func testExpiredEmergencyFollowUpIsNotRecreatedFromCurrentTime() {
        let now = Date(timeIntervalSince1970: 2_000)
        var entry = WorkOrderEntry(area: "4A", issueDescription: "Leak", priority: .emergency)
        entry.createdAt = now.addingTimeInterval(-60)
        let order = WorkOrder(status: .inProgress, entries: [entry])

        XCTAssertNil(WorkOrderNotificationPolicy.emergencyFollowUpDate(for: order, enabled: true, now: now))
    }

    func testFreshEmergencyFollowUpUsesRevisionTimestamp() throws {
        let now = Date(timeIntervalSince1970: 2_000)
        var entry = WorkOrderEntry(area: "4A", issueDescription: "Leak", priority: .emergency)
        entry.createdAt = now.addingTimeInterval(-2)
        let order = WorkOrder(status: .inProgress, entries: [entry])

        let scheduled = try XCTUnwrap(WorkOrderNotificationPolicy.emergencyFollowUpDate(for: order, enabled: true, now: now))
        XCTAssertEqual(scheduled, entry.createdAt.addingTimeInterval(10), accuracy: 0.001)
    }

    func testExpiredExplicitReminderDoesNotResurrect() {
        let now = Date(timeIntervalSince1970: 2_000)
        var entry = WorkOrderEntry(area: "4A", issueDescription: "Leak")
        entry.reminderEnabled = true
        entry.reminderDate = now.addingTimeInterval(-5)
        let order = WorkOrder(status: .inProgress, entries: [entry])

        XCTAssertNil(WorkOrderNotificationPolicy.reminderDate(for: order, now: now))
    }
}


// These tests run against the actual Apple SDK through the existing Xcode target.
// The portable behavior harness is separate and cannot stand in for these tests.
final class ConsolidatedDataRegressionTests: XCTestCase {
    func testFractionalTimestampsSurviveSnapshotEncoding() throws {
        struct Stamp: Codable { let date: Date }
        let stamp = Stamp(date: Date(timeIntervalSince1970: 1_700_000_000.125))
        let decoded = try JSONDecoder.iso8601.decode(Stamp.self, from: JSONEncoder.pretty.encode(stamp))
        XCTAssertEqual(decoded.date.timeIntervalSince1970, stamp.date.timeIntervalSince1970, accuracy: 0.0011)
    }

    func testLegacyFingerprintEncodingRemainsCompatible() throws {
        let snapshot = AppSnapshot(profile: UserProfile(), workOrders: [], snapshotSavedAt: Date())
        let legacy = JSONEncoder()
        legacy.outputFormatting = [.prettyPrinted, .sortedKeys]
        legacy.dateEncodingStrategy = .iso8601
        XCTAssertEqual(try legacy.encode(snapshot), try SnapshotFingerprintEncoding.encode(snapshot, version: nil))
        XCTAssertEqual(try JSONEncoder.pretty.encode(snapshot), try SnapshotFingerprintEncoding.encode(snapshot, version: 2))
        XCTAssertThrowsError(try SnapshotFingerprintEncoding.encode(snapshot, version: 99))
    }

    func testMalformedBackupCollectionsAreRejectedBeforeMigration() {
        for text in ["{}", "{\"profile\":{},\"workOrders\":[42]}",
                     "{\"profile\":{},\"workOrders\":[],\"assets\":\"invalid\"}",
                     "{\"profile\":{},\"workOrders\":[{\"entries\":null}]}"] {
            XCTAssertThrowsError(try SnapshotFormatPolicy.validateLegacyStructure(in: Data(text.utf8)))
        }
    }

    func testSchemaValidationPrecedesVersionSpecificModelDecode() {
        let bytes = Data("{\"dataSchemaVersion\":99,\"workOrders\":[{\"status\":\"future\"}]}".utf8)
        XCTAssertThrowsError(try SnapshotFormatPolicy.validateSchema(in: bytes)) { error in
            guard case DataMigrationError.unsupportedFutureVersion(99) = error else {
                XCTFail("Expected future schema block, not a model decoding error")
                return
            }
        }
    }

    func testUnreadableOnlySnapshotRemainsProtectedAcrossLoads() throws {
        let directory = FileManager.default.temporaryDirectory.appendingPathComponent(UUID().uuidString)
        try FileManager.default.createDirectory(at: directory, withIntermediateDirectories: true)
        defer { try? FileManager.default.removeItem(at: directory) }
        let file = directory.appendingPathComponent("iworkorder-data.json")
        let bytes = Data("unreadable snapshot".utf8)
        try bytes.write(to: file)
        for _ in 0..<2 {
            let storage = StorageService(directory: directory)
            XCTAssertNil(storage.load())
            XCTAssertNotNil(storage.compatibilityBlockMessage)
            XCTAssertEqual(try Data(contentsOf: file), bytes)
        }
    }

    func testMissingSnapshotDoesNotDiscardSurvivingEvidence() throws {
        let directory = FileManager.default.temporaryDirectory.appendingPathComponent(UUID().uuidString)
        let images = directory.appendingPathComponent("WorkOrderImages", isDirectory: true)
        try FileManager.default.createDirectory(at: images, withIntermediateDirectories: true)
        defer { try? FileManager.default.removeItem(at: directory) }
        let file = images.appendingPathComponent("surviving.jpg")
        let bytes = Data([1, 2, 3, 4])
        try bytes.write(to: file)
        let storage = StorageService(directory: directory)
        XCTAssertNil(storage.load())
        XCTAssertNotNil(storage.compatibilityBlockMessage)
        XCTAssertEqual(try Data(contentsOf: file), bytes)
    }

    @MainActor
    func testLateAuthenticationCannotUnlockAfterBackgrounding() throws {
        let lock = AppLockState()
        XCTAssertTrue(lock.isLocked)
        let token = try XCTUnwrap(lock.beginAuthentication())
        XCTAssertNil(lock.beginAuthentication())
        lock.applicationDidEnterBackground(lockEnabled: true)
        lock.completeAuthentication(token: token, succeeded: true)
        XCTAssertTrue(lock.isLocked)
        let current = try XCTUnwrap(lock.beginAuthentication())
        lock.completeAuthentication(token: current, succeeded: true)
        XCTAssertFalse(lock.isLocked)
    }
}

final class PDFExportRegressionTests: XCTestCase {
    @MainActor
    func testLongNotesReachTheFinalPage() throws {
        let marker = "END_OF_LONG_NOTES_4729"
        var entry = WorkOrderEntry(area: "101", issueDescription: "Inspection")
        entry.notes = String(repeating: "Inspection notes with multiple wrapped lines and findings. ", count: 1200) + marker
        let url = try XCTUnwrap(PDFExportService.makeWorkOrderPDF(profile: UserProfile(), orders: [WorkOrder(entries: [entry])]))
        defer { try? FileManager.default.removeItem(at: url) }
        let document = try XCTUnwrap(PDFDocument(url: url))
        XCTAssertGreaterThan(document.pageCount, 2)
        XCTAssertTrue((document.string ?? "").contains(marker))
        for page in 0..<document.pageCount {
            XCTAssertEqual(document.page(at: page)?.bounds(for: .mediaBox).width, 612)
        }
    }

    @MainActor
    func testEveryMissingAttachmentIsDisclosedIncludingAfterSixPhotos() throws {
        var entry = WorkOrderEntry(area: "101", issueDescription: "Missing evidence test")
        entry.images = (0..<7).map { WorkOrderImage(filename: "missing-\($0)-\(UUID().uuidString).jpg", kind: .before) }
        entry.signatureFilename = "missing-\(UUID().uuidString).png"
        let url = try XCTUnwrap(PDFExportService.makeWorkOrderPDF(profile: UserProfile(), orders: [WorkOrder(entries: [entry])]))
        defer { try? FileManager.default.removeItem(at: url) }
        let text = try XCTUnwrap(PDFDocument(url: url)?.string)
        XCTAssertEqual(text.components(separatedBy: "Evidence unavailable:").count - 1, 8)
    }

    @MainActor
    func testRapidExportsHaveDistinctSafeFilenames() throws {
        let first = try XCTUnwrap(PDFExportService.makeWorkOrderPDF(profile: UserProfile(), orders: [], title: "../Reports/Now"))
        let second = try XCTUnwrap(PDFExportService.makeWorkOrderPDF(profile: UserProfile(), orders: [], title: "../Reports/Now"))
        defer { try? FileManager.default.removeItem(at: first); try? FileManager.default.removeItem(at: second) }
        XCTAssertNotEqual(first, second)
        XCTAssertEqual(first.deletingLastPathComponent().lastPathComponent, "iWorkOrderPDFExports")
        XCTAssertNotNil(PDFDocument(url: first))
        XCTAssertNotNil(PDFDocument(url: second))
    }
}
