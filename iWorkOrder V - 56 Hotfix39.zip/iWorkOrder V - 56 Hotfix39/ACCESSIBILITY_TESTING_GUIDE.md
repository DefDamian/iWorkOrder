# Phase 52 accessibility and iPad testing guide

Record the device, OS version, text size, orientation, result, and evidence for every check.

## Automated Xcode checks

Run:

```bash
./Scripts/run_xcode_ci.sh
```

Confirm both `iPhoneTests.xcresult` and `iPadTests.xcresult` pass and contain the UI-test target.

## Accessibility Inspector

Audit onboarding, Work Orders, Quick Add, New Work Order, detail/edit, signature, Calendar, Hub, Settings, Notifications, Export & Backup, and Legal screens.

No unresolved critical findings are acceptable. Do not suppress text clipping, missing labels, small hit targets, invalid traits, or element-order problems.

## VoiceOver

- Navigate every screen by swipe and rotor.
- Confirm headings, groups, status values, priority values, filter selection, and work-order actions are announced correctly.
- Confirm decorative images are skipped.
- Confirm swipe-to-delete and email functions are available as accessibility actions.
- Confirm signature controls announce drawing state and save requirements.

## Dynamic Type

Test all standard sizes and every accessibility size, including the largest size.

- No essential text may be clipped or hidden.
- Paired actions must stack when horizontal space is insufficient.
- Metrics and filters must reflow without overlap.
- Forms must remain scrollable and editable.

## Other assistive settings

Test Voice Control, Switch Control, Bold Text, Increase Contrast, Differentiate Without Color, Reduce Motion, Reduce Transparency, and Button Shapes.

## iPad adaptivity

Test portrait, both landscape orientations, Split View widths, Stage Manager resizing, external keyboard, and pointer input.

Confirm:

- Sidebar navigation appears at regular width.
- Compact tab navigation appears in narrow windows.
- Command-1 through Command-4 selects Work Orders, Calendar, Hub, and Settings.
- No content is cut off when resizing during forms, backup operations, or work-order detail views.

## Physical-device gate

Repeat the matrix on at least one current iPhone and one current iPad. Simulator-only accessibility qualification is not sufficient for release sign-off.
