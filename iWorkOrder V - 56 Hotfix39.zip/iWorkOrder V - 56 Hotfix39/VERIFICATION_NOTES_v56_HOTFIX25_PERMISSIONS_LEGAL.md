# iWorkOrder v56 Hotfix25 — First-Use Permissions and Legal Refresh

## Purpose

Hotfix25 adds an independent device-permission review for first use and restored users. The review is deliberately separate from onboarding completion and backup contents because iOS permission decisions are device-local. A backup restore can still skip onboarding, while the new device must review its own notification and camera authorization state before protected app access.

## Permission audit

The current feature set requires only these Info.plist protected-resource purpose strings:

- `NSCameraUsageDescription` for the optional rear torch. The app does not start an `AVCaptureSession` or capture camera photos/video.
- `NSFaceIDUsageDescription` for optional App Lock. Authentication is requested only when App Lock is enabled or restored as enabled.

Notifications use `UNUserNotificationCenter` authorization and do not use an Info.plist usage-description key. Photo attachments use Apple `PhotosPicker`, which grants access to user-selected items without broad Photo Library authorization. The app does not request device Contacts, Calendar, microphone, precise-location, or App Tracking Transparency authorization for the current feature set.

## First-use routing

Root routing now follows this order:

1. Data compatibility protection
2. Backup/iCloud recovery choice when needed
3. Fresh onboarding when needed
4. Current legal acceptance
5. Device-local permission review
6. App Lock authentication when enabled
7. Main app

The permission review asks for notification and camera authorization in a dedicated explanatory context. The user may allow or deny either permission. The review is considered complete once iOS has a decision for both permissions; denial limits only the related optional feature.

## Legal refresh

The Privacy Policy, Terms & Conditions, and Data & Liability Disclaimer are updated to legal version `2026.09.16.56`, effective September 16, 2026. The public privacy HTML, terms file, disclaimer file, support/current-version labels, App Store handoff material, and in-app legal source are aligned. Existing users who accepted an older legal revision must re-accept before the permission review and normal app access.

## Verification added

`Scripts/run_hotfix25_permissions_legal_harness.py` verifies the permission gate, device-local persistence, purpose strings, absence of unused privacy keys, legal version, PhotosPicker boundary, camera authorization path, and UI-test routing. The cross-platform and Mac Phase56 runners execute this harness. Swift parser, plist, public-legal parity, and the existing release regression suite remain part of qualification.

Native iOS runtime behavior still requires final Xcode/device or simulator qualification because this Linux environment cannot display or answer Apple system permission sheets.
