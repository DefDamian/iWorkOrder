# iWork v12 Verification Notes

## Changes added in v12

- Added required-reason API declarations to `iWorkOrder/PrivacyInfo.xcprivacy`:
  - UserDefaults: `CA92.1`
  - File Timestamp: `C617.1`
  - System Boot Time: `35F9.1`
  - Disk Space: `E174.1`
- Added `HapticManager` in `Services.swift`.
- Added success haptic when a completion signature is saved.
- Added heavy triple-pulse warning haptic when an emergency work order is created or priority is changed to Emergency.
- Added selection haptics for onboarding role and storage selection.
- Added selection haptics for Quick Fix actions and flashlight toggle.
- Preserved existing work order, onboarding, legal, iCloud/local persistence, PDF export, audit log, deep-link, filter, trash, retention purge, directory, asset, and signature logic.

## Validation performed

- `plutil -lint iWorkOrder/PrivacyInfo.xcprivacy`: passed.
- `swiftc -parse iWorkOrder/*.swift`: passed.
- Confirmed `PrivacyInfo.xcprivacy` is already referenced in `iWorkOrder.xcodeproj/project.pbxproj` resources.

## Notes

- `xcodebuild` is not available inside this container, so the validation used Swift parsing and plist linting.
