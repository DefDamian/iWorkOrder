# v25 Theme 2 Cleanup

- Reworked Theme 2 contrast so custom theme content no longer inherits dark-mode white foreground text.
- Forced custom themes to render in light appearance while leaving Default Theme system-controlled.
- Increased Theme 2 card opacity for readable white/tinted legacy cards.
- Applied explicit theme text colors to metric tiles, section headers, settings rows, work-order rows, and info rows.
- No SwiftData models, CloudKit/iCloud sync, audit log, PDF export, notification, or work-order persistence logic changed.
