# iWork v16 Production Build Notes

Baseline: iWork v13 locked, v14/v15 stabilization preserved.

Production hardening added in v16:
- Local/iCloud snapshot conflict merge keeps both devices' unique work orders, entries, images, audit events, status entries, assets, and tenant contacts.
- Save path now validates audit integrity before every save.
- Signed/completed work orders are treated as locked records. Direct status-only mutation is blocked and logged.
- Save failures are surfaced to the user instead of failing silently.
- PDF export now adds consistent page footers and separators for more reliable legal output.
- Existing v13 through v15 features preserved.

Manual production checks still required on real devices:
1. Create work order on Superintendent iPhone, sync to Handyman iPhone.
2. Edit different work orders on both phones, then Sync Now on both.
3. Complete and sign a work order, then confirm direct editing is blocked unless using Making Changes.
4. Export PDFs with and without photos/signatures.
5. Delete and restore from Trash.
