# iWork v6 verification notes

Applied to the existing iWork v5 project instead of rebuilding from scratch.

Verified in this package:
- SettingsRow exists in Components.swift and LegalAboutView references it correctly.
- Swift source files have balanced braces, parentheses, and brackets.
- AppStore now loads saved local or iCloud data during initialization before RootView decides whether onboarding is needed.
- Onboarding completion is still saved to local UserDefaults and iCloud key-value storage.
- App data is still saved when the scene moves inactive or background.
- Legal pages open through NavigationLink and now include the uploaded legal framework language.
- The signature screen includes the ESIGN disclaimer above the signature canvas.
- Hub export, Hub metric details, swipe-to-delete, backup export/restore, keyboard dismissal, Apple Maps address verification, notification permission prompt, Face ID prompt, and reset/erase flow remain in the project.

Tooling note:
- This environment does not include Xcode or iOS SDK, so a real `xcodebuild` compile is not available here. I performed file-level verification and zip integrity checks in the container.
