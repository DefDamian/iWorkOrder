# iWorkOrder v56 Hotfix 8 — Xcode 26 ScrollView Initializer

## Reported failure

Xcode 26 reported `Ambiguous use of init` at `WorkOrderViews.swift:22` on a shorthand `ScrollView { ... }` declaration.

## Cause

The shorthand vertical `ScrollView` call did not provide enough initializer context for the Xcode 26 SwiftUI overload set in that nested view-builder expression.

## Correction

All bare vertical scroll containers now use:

```swift
SwiftUI.ScrollView(.vertical, showsIndicators: true) {
    // content
}
```

This explicitly identifies the SwiftUI type, axis, and indicator behavior. Horizontal scroll containers retain their existing explicit horizontal configuration.

## Regression protection

The release verifier now fails if a bare `ScrollView {` declaration is reintroduced and confirms that the work-order screens contain the explicit initializer.

## Environment limitation

The package is parser- and regression-validated in this environment. Final SwiftUI type checking must be confirmed by rebuilding with Xcode 26 on macOS.
