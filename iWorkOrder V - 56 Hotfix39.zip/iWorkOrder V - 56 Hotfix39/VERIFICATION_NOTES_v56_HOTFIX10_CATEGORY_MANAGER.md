# iWorkOrder v56 Hotfix 10 — Category Manager

## Confirmed defect

The Settings > Category Manager screen rendered the fixed `WorkOrderCategory.allCases` enum as a read-only list. It had no add, delete, reorder, or persistence path. Work-order forms and filters also read directly from the enum, so even a UI-only manager could not affect the rest of the application.

## Corrections

- Added a string-backed managed category value type while retaining the legacy built-in category field in work-order JSON.
- Stores custom names separately so older builds can still decode the snapshot and enter forward-schema protection instead of treating the data as unreadable.
- Added an ordered category configuration to `AppSnapshot` and `AppStore`.
- Added transactional add, delete, and reorder operations with rollback when protected local persistence fails.
- Added duplicate-name, blank-name, length, and last-category validation.
- Added Category Manager controls for adding, swipe deletion, Edit-mode reordering, usage counts, and failure reporting.
- Updated new-work-order category pickers, dashboard filters, Theme 3 filters, and Quick Add to use the persisted category order.
- Preserved deleted category names on existing work orders instead of rewriting historical or signed evidence.
- Kept historical categories available in filters while they are still used by active records.
- Added category configuration timestamps so the newest category change wins CloudKit merges independently of unrelated snapshot dates.
- Advanced the data schema to version 3. Schema 1 and 2 snapshots migrate without changing existing work-order category values.
- Added unit tests for legacy category decoding, custom-category wire compatibility, normalization, schema migration, and CloudKit category conflict resolution.
- Added UI automation for adding and deleting a category through Settings.

## Legal review

The existing privacy and legal text already discloses that work-order categories may be stored and synchronized. No new data type, external transmission, or developer collection was introduced, so the legal acceptance version was not changed.

## Required Mac validation

Open the package in Xcode, select the authorized signing team, clean the build folder, and run the unit/UI test targets. Confirm add, reorder, delete, relaunch persistence, new-work-order selection, filtering, backup restore, and two-device CloudKit propagation.
