# iWorkOrder v56 Hotfix 15 — Xcode Access-Control Compile Fix

## Defect reproduced from physical Xcode build

Xcode reported:

`prepareSnapshotCommit is inaccessible due to fileprivate protection level`

`AppStore.swift` calls `transaction?.prepareSnapshotCommit(savedSnapshot)`, while the method was declared in `BackupArchiveService.swift`. Swift `fileprivate` limits access to the declaring source file, so the call could not compile.

## Fix

- Changed `BackupAttachmentTransaction.prepareSnapshotCommit(_:)` from `fileprivate` to the module-default `internal` access level.
- Kept the enclosing transaction type internal; no public API surface was introduced.
- Added dedicated release/core regression checks for the declaration and the cross-file call.
- Audited the remaining `fileprivate` transaction members; they are used only inside `BackupArchiveService.swift`.
- Audited private/fileprivate type declarations for cross-file references.

## Verification in this environment

- All Swift sources parse with Swift 6.2.1 available in the verification container.
- Full executable cross-platform harness suite passes.
- Core stability harness includes the new access-control regression.
- Source integrity hashes are regenerated only after the final tree is frozen.

## Environment limitation

This verification container does not provide Apple Xcode or iOS SDKs, so a true `xcodebuild` compile/archive cannot be executed here. The reported Xcode compiler error itself is directly addressed by restoring legal cross-file access. The separate development-team signing requirement must be resolved in Xcode with the authorized Apple Team on the developer Mac.
