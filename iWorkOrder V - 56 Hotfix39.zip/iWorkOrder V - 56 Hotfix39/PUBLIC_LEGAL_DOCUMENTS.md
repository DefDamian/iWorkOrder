# Public legal documents

These files match the authoritative legal text bundled in `iWorkOrder/LegalContent.swift` for legal version `2026.09.16.56`, effective September 16, 2026:

- `iworkorder-privacy-policy.html`
- `terms-of-service`
- `Data-Liability-Disclaimer`

Publish all three current files together whenever the in-app legal version changes. The in-app copies remain authoritative for acceptance, so stale network content cannot replace the text the user accepted.

The App Store privacy-policy URL must point to the current published privacy policy. The App Store Connect privacy questionnaire and any custom license agreement must be reviewed against the exact signed release binary before submission.
