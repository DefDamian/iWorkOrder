# v49 Runtime Security, Notifications, Erase, Email, and Deep Links

Scope: Phase 49 runtime hardening for app relocking, notification lifecycle cleanup, destructive reset behavior, email composition, theme/legal exit behavior, and custom deep links.

## Changes made

- Moved `AppLockState` to the application root so the same lock instance is shared by the app lifecycle and all screens.
- Added immediate relocking whenever iWorkOrder enters the background while app lock is enabled.
- Preserved device-owner authentication through Face ID, Touch ID, or device passcode.
- Added notification authorization reconciliation when the app becomes active, including cleanup if permission was revoked in iOS Settings.
- Added cancellation of pending and delivered notifications when reminders are disabled, a work order is completed, moved to Trash, or all data is erased.
- Added startup, cloud-sync, cloud-restore, backup-restore, rollback, and preference-change notification reconciliation.
- Enforced the global notification switch and the separate emergency follow-up switch.
- Added foreground banner, Notification Center list, and sound presentation for active-app reminders.
- Added a dedicated Notifications settings screen.
- Registered the `iworkorder` custom URL scheme in a checked-in `Info.plist`.
- Hardened deep-link parsing for path and query forms and prevented duplicate queued routing.
- Replaced manual `mailto:` work-order construction with `MFMailComposeViewController` and a share-sheet fallback when Mail is unavailable.
- Rebuilt the support-email URL with `URLComponents`.
- Removed every programmatic app-close path.
- Themes now apply immediately without terminating the app.
- Legal disagreement dismisses the agreement instead of making the app appear to crash.
- Reset returns directly to onboarding while retaining data.
- Erase All Data now clears pending and delivered notifications, deep-link state, local data, safety backups, restore journals, onboarding state, the device identifier, save revision, selected theme, filters, and in-memory errors while preserving the persistent CloudKit erase barrier until remote deletion completes.
- Corrected a duplicated `previousDate` local declaration in revision normalization that could prevent compilation.

## Verification performed

- Parsed all Swift files individually and as one combined Swift frontend invocation.
- Parsed the Xcode project file, Info.plist, privacy manifest, entitlements, shared scheme, and all asset-catalog JSON metadata.
- Executed a Swift behavioral harness covering app-lock transitions, notification eligibility, emergency preference enforcement, completed/deleted cancellation, deep-link parsing, foreign-scheme rejection, and special-character email content.
- Verified every Swift source is referenced by the Xcode project and Compile Sources phase.
- Verified the shared scheme points to target `42AEFBAE01D2DFD981F7DA7D`.
- Verified the `iworkorder` URL scheme exists in `CFBundleURLTypes`.
- Verified no `closeApp`, suspension selector, `exit(0)`, or equivalent programmatic termination path remains.
- Verified notification cancellation is integrated with Trash, completion/update, preference changes, authorization changes, restore paths, cloud paths, and Erase All Data.
- Verified Phase 47 CloudKit and Phase 48 backup source files were not modified.
- Recalculated the source SHA-256 manifest and verified the final archive after clean extraction.

## External verification required

The following still require macOS, Xcode, Apple signing, and real iOS services:

- full iOS compile and link
- Face ID, Touch ID, passcode, inactive/background, and relaunch behavior on a device
- notification permission changes through the iOS Settings app
- pending and delivered notification removal on a device
- foreground notification presentation
- Mail composer behavior with and without a configured Mail account
- external `iworkorder://` launch from Safari, Mail, Notes, and another app
- simulator and physical-device theme transition checks
- signed Release archive, TestFlight, and App Store review
