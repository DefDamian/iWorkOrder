# iWorkOrder support bundle format

Extension: `.iworkordersupport`

Media type used by the app: `application/json`

Format identifier: `com.damiancedeno.iworkorder.support`

Current format version: `1`

## Envelope

The file is UTF-8 JSON with these top-level fields:

- `content`
- `contentSHA256`

The `content` object carries `formatIdentifier`, `formatVersion`, `reportID`, `generatedAt`, app/schema/legal versions, the privacy-safe reports, the aggregate reliability summary, and bounded maintenance events.

`contentSHA256` is the lowercase hexadecimal SHA-256 digest of the canonically encoded `content` value using sorted JSON keys.

## Content

The content contains only privacy-safe technical and aggregate information:

- diagnostic report text;
- maintenance report text;
- runtime reliability summary; and
- up to 100 bounded maintenance events.

The support bundle does not contain work-order descriptions, notes, resident or tenant data, building addresses, company names, photos, signatures, attachment filenames, audit text, or the internal device identifier.

## Validation

A consumer must reject a bundle when:

- the format identifier is unknown;
- the format version is unsupported;
- JSON decoding fails; or
- the calculated content digest does not match `contentSHA256`.

Validation confirms file integrity, not the truth of user-entered operational information. The format contains no user-entered operational content.
