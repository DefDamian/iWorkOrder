# iWorkOrder v56 Hotfix 12 Core Stability Loop

Hotfix 12 is an iterative core-defect stabilization pass over Hotfix 11. The loop continued through persistence, cross-device merge, CloudKit attachments, backup/restore transactions, privacy cleanup, onboarding recovery, notifications, and erase behavior until a complete audit pass produced no new actionable core defect.

## Core corrections

### Persistence and conflict freshness

- `snapshotSavedAt` advances only for committed local content mutations, not serialization, lifecycle checkpoints, or cloud transport.
- The persisted save revision is reconciled into the monotonic revision counter at launch.
- Profile/configuration freshness is independent from work-order freshness, preventing unrelated work-order activity from overwriting newer building/profile settings.
- Category identity and imported building-unit identity use deterministic POSIX case/diacritic/width folding instead of device-locale-dependent comparison.
- Duplicate work-order identities are coalesced during normalization, and ambiguous duplicate tenant-unit identities do not silently grant entry permission.
- Workflow status merge follows explicit status transitions instead of unrelated audit recency.
- Newer explicit legal decline/profile state cannot be resurrected by older legal-acceptance evidence.

### Category and work-order integrity

- Category delete confirmation stores category identity instead of mutable row indexes, preventing the wrong category from being deleted after a reorder or cloud refresh.
- Category filtering, usage counts, selection, and legacy category values use the same canonical identity rules.
- Signed-record integrity validates readable signature image content rather than trusting filename metadata alone.
- Asynchronous photo import removes late-created files when SwiftUI cancels a draft task.

### Attachment safety and Data Protection

- Central attachment filename policy rejects traversal aliases, separators, control characters, oversized filenames, and unsafe persisted references.
- Backup and CloudKit attachment handling validates that transferred bytes decode as an image, not only that hashes match.
- Photos, signatures, imported attachment staging files, exported full backups, and restored attachments require complete-until-first-user-authentication Data Protection.
- Existing same-content attachments are also upgraded to the required Data Protection class instead of bypassing protection because no rewrite was necessary.
- Same-name readable local/cloud attachments with different bytes are treated as an immutable-identity conflict instead of silently overwriting one copy.
- A corrupt local attachment can no longer satisfy recovery when the corresponding cloud attachment is missing.

### CloudKit safety

- Authoritative cloud replacement fully stages and verifies the complete replacement snapshot and every attachment before deleting the existing CloudKit zone.
- Ordinary sync inventories actual attachment records in the private zone using the current paginated async CloudKit query API when available. This lets later syncs remove orphaned cloud attachment records left by a crash after snapshot upload.
- Attachment inventory failure falls back to snapshot-derived names so cleanup cannot block ordinary sync.
- Pre-onboarding cloud recovery cannot overwrite an existing local snapshot.
- Incomplete onboarding remains download-only and cannot upload partial/default profile state.

### Backup and restore transaction integrity

- Restore installs verified attachment bytes before signed-record integrity validation so valid incoming signatures are not falsely reported missing.
- Restore journals store the exact expected snapshot SHA-256 fingerprint before the protected snapshot commit.
- Attachment rollback failures retain recovery copies and the journal instead of discarding the only rollback evidence.
- Restore finalization verifies unreferenced attachment cleanup and transaction-directory deletion; failed cleanup is retained and retried instead of being reported as complete.
- A durable `snapshotCommitted` journal remains authoritative after later valid saves, while same-revision recovery still requires the exact snapshot fingerprint.
- Failure to persist the post-save restore commit marker is observable. If cleanup also cannot finish, local writes and CloudKit sync enter a safe temporary recovery block so later revisions cannot destroy the evidence needed to distinguish commit from rollback.
- Startup recovery marks unreadable or unresolved rollback journals as write-blocking instead of permitting potentially corrupting later mutations.
- A verified backup can still restore over an already-damaged current dataset by creating an explicit degraded safety backup of all recoverable current attachments and recording the omissions.

### Retention and erase privacy

- Retention purge commits database redaction before physical deletion, removes only unreferenced files, verifies actual deletion, retries prior orphan files, and reports the number physically removed instead of the number merely selected.
- Repeated retention purge no longer appends duplicate redaction audit events when nothing changed.
- Erase All Data verifies deletion of the primary/fallback snapshot, photos, signatures, safety backups, restore journals, maintenance data, backup import/export staging, CloudKit staging, generated PDFs, diagnostics, and support-bundle temporary data before CloudKit erase is allowed to clear its pending state.
- Startup with a pending erase does not reload stale local data, preventing deleted data from reappearing after a partial erase.

### Packaging and verification integrity

- Distributed source packages contain no Apple Team ID or per-user Xcode workspace state.
- Release verification ignores user-specific workspace state and correctly supports an unsigned GitHub-ready source package.
- Hotfix 12 regression assertions are integrated into the Phase 56 qualification flow.

## Cross-platform verification

The final Hotfix 12 cross-platform gate includes:

- Phase 56 executable logic harness
- Accessibility harness
- Submission harness
- Migration and maintenance harness
- Runtime reliability harness
- Hotfix 6 defect harness
- Hotfix 7 transactional harness
- Hotfix 12 core stability harness: 124 checks
- App Store metadata validation
- Phase 56 evidence-template validation
- Swift parser validation across the application, unit tests, and UI tests
- Python script compilation and shell-script syntax validation
- Full source SHA-256 manifest verification

A real Apple-platform compile, simulator run, device run, archive, signing validation, and TestFlight qualification still require macOS with Xcode. Cross-platform verification is not represented as a substitute for that Apple toolchain gate.
