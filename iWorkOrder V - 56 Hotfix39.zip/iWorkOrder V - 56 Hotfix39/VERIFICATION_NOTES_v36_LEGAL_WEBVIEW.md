# VERIFICATION NOTES v36 - Legal Web Viewer

Changes made:
- Added an in-app WKWebView-based legal document viewer.
- Wired Settings > Legal & About > Privacy Policy to:
  https://defdamian.github.io/iWorkOrder/iworkorder-privacy-policy.html
- Wired Settings > Legal & About > Terms of Service to:
  https://defdamian.github.io/iWorkOrder/Terms%20of%20Service
- Kept Data & Liability Disclaimer as the existing in-app offline document.
- Added offline fallback to the existing embedded legal text if a web document fails to load.

Scope:
- UI/navigation only.
- No SwiftData models touched.
- No iCloud persistence touched.
- No audit log logic touched.
- No PDF export generation logic touched.
- No theme files or theme switching logic touched.

Notes:
- The web viewer opens inside the app. It does not call Safari for Privacy Policy or Terms of Service.
- JavaScript is disabled in the web viewer configuration for simpler legal document display.
