# iWorkOrder V - 56 Hotfix22
## Consolidated stability, evidence, and validation pass

Status: source changes complete for this pass. Native Apple build and release qualification remain open. This package is not certified bug-free or ready for public distribution.

Baseline: Hotfix21, archive SHA-256 `be64bdd6f537e1af29b467c4d7b6484144b33a86a57ec51d456360e2d202235b`.

## What changed

### Data and recovery

* Snapshot timestamps now preserve milliseconds. The earlier encoder discarded fractional seconds, so rapid changes could lose their ordering after a save/load.
* Restore journals record the fingerprint encoding version. Existing journals retain their original second-precision fingerprint rules; an unknown newer encoding blocks recovery rather than triggering an unsafe rollback.
* Schema versions are checked before version-specific model decoding. A newer snapshot containing an unknown enum cannot trigger a downgrade to an older fallback file.
* Unreadable snapshots are preserved. A corrupt sole snapshot, two unusable snapshots, quarantined snapshots, or surviving evidence with no snapshot no longer looks like a fresh installation that can sweep the attachments away.
* A known-good fallback can still rebuild a corrupt primary, with a visible recovery notice.
* Legacy backup migration requires recognized data structures. Malformed profiles, work-order arrays, revisions, photos, audits, assets, and tenant arrays are rejected rather than silently converted to empty collections. Recognized flat legacy records and genuinely empty legacy datasets remain supported.
* Save, lifecycle checkpoint, and cloud preparation boundaries block writes while an earlier cloud erase is pending. A stale detail screen also cannot edit an order already moved to Trash.

### Asynchronous interactions and privacy

* Editing an address during verification invalidates the outstanding request; a late geocoder response cannot overwrite the replacement address.
* Notification permission requests capture rollback state after the prompt returns. Denial does not restore an obsolete whole profile over changes made during the prompt.
* Setup completion is guarded against repeated taps and revalidates its prerequisites after awaiting permission.
* Notification additions are awaited and serialized with later reconciliation/cancellation. A late system add is cleaned up after completion instead of reviving a canceled request.
* Notification callbacks capture immutable identifier sets, avoiding mutable captures in concurrent callbacks. Pending and already-delivered notifications have separate eligibility rules, so merely passing a reminder's due time does not erase a valid delivered reminder.
* Authorization refresh rechecks current preferences and restores scheduling after permission is enabled in device Settings.
* App locking starts closed until the saved policy is applied. Authentication attempts use tokens: overlapping attempts are refused and a late success cannot unlock a session that has since backgrounded/relocked.
* Both new and edited orders wait for photo imports before allowing Save or Sign and Save. Every import outcome releases the busy state; a reused thumbnail clears its prior image while loading.
* Backup-operation and inactive-app overlays now hide the covered content from the accessibility tree as well as covering it visually.

### PDF source corrections

* Long text is paginated using the actual Core Text visible character range instead of a fixed-height rectangle that could clip notes.
* The six-photo-per-revision cap is removed. Unreadable referenced photos/signatures are disclosed instead of silently omitted.
* PDF filenames are sanitized and use the export UUID, preventing same-second exports from overwriting each other.
* PDF text uses explicit dark colors suitable for white pages. Image placement checks available space after its caption.
* Incomplete layout is treated as export failure; partial output is removed. Finished PDFs receive file protection.

These are source corrections, not a claim that native PDF layout was rendered here. The existing XCTest target now includes long-note, missing-evidence, and rapid-export regressions. They must run with Apple's frameworks and the PDFs must be visually checked on the Mac/device.

### Build and verification

* `verify_release.sh` no longer depends on Bash 4 `mapfile` or GNU `sort -z`, which are absent from the standard macOS command-line environment.
* The verifier parses both Release and Debug conditional branches.
* Xcode qualification output preparation validates its cleanup paths. Environment overrides cannot point recursive cleanup at project source, a filesystem root, or an escaping symbolic link. Custom output must be a dedicated child of this project's `Artifacts` or `build` directory. Manual evidence must be outside the disposable destinations.
* The integrated verifier runs the new executable behavioral harness and source-wiring/build-path safety harness.
* Existing source assertions were updated for awaited notification additions, time-zone-aware date components, and safe permission-denial behavior; these assertions were not substituted for functional tests.

## Evidence and limits

`Scripts/run_hotfix22_behavior_harness.py` compiles extracted application models, JSON codecs, migration validation, snapshot I/O, address state, app-lock state, and notification coordination with Swift 6 strict concurrency and warnings treated as errors. It runs 80 checks, including 250 chronological round-trips and 512 fingerprint-stability trials.

The unavailable Apple notification/geocoding/UI types are test-only stand-ins in `Scripts/BehaviorTests/PlatformFakes.swift`. The tests exercise application control flow with held additions, late responses, cancellations, errors, and real temporary-file I/O. They do not exercise the iOS notification server, biometrics, SwiftUI layout, Core Text rendering, signing, or production iCloud.

`Scripts/run_hotfix22_integration_harness.py` performs 36 source-wiring checks and executes 12 build-directory safety checks. Source-wiring checks are static, not UI execution.

Ten additional native XCTest methods are included for data validation, fingerprint compatibility, data preservation, app locking, and PDF exports. They were not run in this Linux environment.

Baseline regressions were reproduced for fractional timestamp loss, malformed backup acceptance, and missing-snapshot evidence protection. The corrected behavior harness passes. Final integrated and fresh-archive results are recorded separately in `ReleaseEvidence/hotfix22_portable_results.json`.

## Preserved compatibility and product behavior

The bundle identifier, iCloud container, deep-link scheme, user data locations, and existing legal version `2026.09.13.56` are unchanged. No legal text change or additional re-acceptance was introduced. Developer tools and test fixtures remain excluded from the public app target.

This pass does not perform a broad architecture/file split or replace the app's design. That refactor should be separate from these fixes and should follow a passing native build, rather than introducing another large uncompiled change.

## Remaining release stages

The existing 22-gate qualification template is still pending. It was not filled with fabricated passes. Native Debug/Release builds, XCTest/UI tests, static analysis, signed archive validation, iPhone/iPad operation, notification permissions, biometrics, PDF rendering, two-device production iCloud, privacy-report review, public URL publication, App Store account fields, and TestFlight validation require their actual platforms or owner input.

On a Mac with Xcode and the iOS simulator runtimes, from the extracted project directory:

```bash
./Scripts/run_xcode_ci.sh
```

This runs the existing native qualification pipeline and saves results under `Artifacts/Phase56`. It does not publish the application. Signed/device/final-gate steps remain documented in `PHASE56_MAC_EXECUTION_GUIDE.md`; choosing a signing team is still the owner's responsibility.

Before installing over important data, retain a full backup. Do not delete the installed app as a troubleshooting step for a protected-data warning.
