# v20 Themes

Added a Settings > Themes section with three UI choices:

1. Default Theme
2. Design 2
3. Design 3

Implementation notes:
- Theme choice is stored with AppStorage/UserDefaults using the key selectedVisualTheme.
- Only visual theme styling was added. SwiftData models, iCloud sync, work order logic, audit logs, PDF export, onboarding persistence, and backup flows were not changed.
- Design 2 uses the darker electric-blue look from the older UI.
- Design 3 uses a cleaner light blue and white look from the older UI.
- Selecting a theme shows a relaunch prompt and closes the app after Apply and Close so the selected design loads cleanly on next launch.
