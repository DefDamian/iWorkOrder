# v22 Distinct Legacy Themes

Changes are UI-only.

- Reworked Design 2 and Design 3 so they no longer share the same layout language.
- Design 2 now follows the older command-center direction: navy hero card, glass metric grid, Dashboard tab naming, and darker command style.
- Design 3 now follows the workflow/control-room direction: blue-purple hero, pill filters, Command tab naming, and softer white cards.
- Theme selection still uses AppStorage only.
- No SwiftData models, CloudKit/iCloud sync, audit log, PDF export, onboarding state, or work order persistence logic changed.
