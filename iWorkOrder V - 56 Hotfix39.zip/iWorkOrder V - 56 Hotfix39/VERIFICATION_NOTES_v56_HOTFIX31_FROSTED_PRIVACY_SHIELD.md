# iWorkOrder v56 Hotfix 31 — Frosted Privacy Shield

## Problem corrected

When iOS moved iWorkOrder out of the active scene state, including while Notification Center or Control Center was presented, the app replaced its interface with the full startup splash. The protection hid work-order content, but it looked like a second launch screen and was visually heavy.

## Changes

- Replaced the full splash privacy cover with a dedicated frosted privacy shield.
- Blurs the live app content by 24 points and reduces saturation before the privacy layer is drawn so work-order text is no longer readable through the cover.
- Uses a system regular-material frost with a restrained light/dark tint instead of an opaque gray replacement screen.
- Uses only a compact 58-point adaptive iWorkOrder mark in a small circular glass badge; the large product title and splash-sized logo are not shown.
- Honors Reduce Transparency by falling back to the adaptive solid `LaunchBackground` instead of relying on translucency.
- The cover remains noninteractive and hidden from accessibility navigation while the underlying app is removed from accessibility focus.
- Added a first-activation guard so the privacy shield cannot appear during the native-launch-to-SwiftUI handoff. This preserves Hotfix30 startup continuity while still arming privacy protection as soon as the app is active.
- Existing inactive/background lifecycle checkpoints, app-lock behavior, persistence, notification refresh, legal version, work-order data, iCloud data, and backup format are unchanged.

## Automated verification

`Scripts/run_hotfix31_privacy_blur_harness.py` checks the frosted material, strong blur, desaturation, compact adaptive mark, Reduce Transparency fallback, lifecycle preservation, accessibility behavior, launch guard, and removal of the full splash from the inactive privacy path.

The harness is included in both the cross-platform release verifier and the Phase 56 Xcode qualification script.

## Native Apple validation still required

Notification Center and Control Center presentation are rendered by iOS. A simulator or physical-device check should therefore still verify the final visual result in Light and Dark Mode by opening Notification Center, opening Control Center, entering the app switcher, returning to the app, and confirming that sensitive work-order text is not readable through the cover.
