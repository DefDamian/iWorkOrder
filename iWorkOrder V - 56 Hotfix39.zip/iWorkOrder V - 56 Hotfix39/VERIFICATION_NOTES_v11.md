# iWork v11 Verification Notes

Applied to v10 without removing existing files or screens.

## Implemented
- Added UIApplicationDelegate notification setup in `iWorkOrderApp.swift`.
- Notification taps now route `workOrderID` into the existing `RootView`/`WorkOrderHomeView` deep-link path.
- Added pending deep-link storage so a notification tapped at cold launch is not lost before `AppStore` finishes initializing.
- Kept the legal-receipt model fields: status entries, audit log, tenant permission, entry method, and asset ID.
- Added a metadata search engine in `Services.swift` used by `AppStore.filteredWorkOrders`.
- Preserved image compression through `ImageStorageService.saveCompressed` before persistence.
- Preserved high-contrast priority theming, quick-fix buttons, flashlight toggle, role onboarding, legal hard stop, storage setup, signature ESIGN banner, and read-only signed work orders.
- Added `PrivacyInfo.xcprivacy` to the Xcode project resources.
- Expanded iCloud entitlements with the app-specific container identifier.
- Added accessibility labels and hints for shared component buttons and settings rows.

## Static Checks Run
- XML lint passed for `iWorkOrder.entitlements`.
- XML lint passed for `PrivacyInfo.xcprivacy`.
- Bracket/brace balance check passed for every Swift source file.
- Verified `PrivacyInfo.xcprivacy` is referenced in the Xcode project resource phase.

## Manual Xcode Note
This environment does not include `xcodebuild`, so the final device/simulator compile still has to be run in Xcode on macOS.
