# iWorkOrder V - 56 Hotfix38: iOS 26 minimum baseline

## Scope

Hotfix38 intentionally raises the minimum supported iPhone and iPad OS version from iOS/iPadOS 17.0 to 26.0. The project remains on Swift 6 language mode with complete strict concurrency and is qualified for Apple's stable Xcode 27 / Swift 6.4 toolchain.

## Source changes

- Set every app, unit-test, UI-test, Debug, and Release `IPHONEOS_DEPLOYMENT_TARGET` entry to `26.0`.
- Removed the iOS 17-25 `MKLocalSearch` address-verification fallback and its matching/tokenization helpers.
- Address verification now uses `MKGeocodingRequest` and `MKAddressRepresentations` directly while preserving cancellation and stale-response generation guards.
- Removed the legacy MapKit fake/test path from the portable behavior harness.
- Retained the iOS 26-only rounded text-field compatibility helper because the newer bordered input-shape presentation is guarded for iOS 27.
- Updated current release and device-validation guidance to the supported iOS 26-27 matrix.

## Compatibility consequence

Devices that cannot run iOS/iPadOS 26 can no longer install or update to this build. Existing older builds already installed on those devices are not modified by this source change.

## Verification boundary

Portable static, parser, executable behavior, metadata, and integrity checks can be run in this environment. Native Xcode 27 compilation, iOS 26/27 simulator/device execution, signing, archive validation, CloudKit production checks, and TestFlight/App Store verification still require macOS with stable Xcode 27 build 27A266a and the iOS 27 SDK.

## Completed portable regression loop

The post-change regression loop completed successfully in this environment.

- Hotfix38 iOS 26 baseline audit: 40/40 checks passed.
- Hotfix37 Xcode 27 / Swift 6.4 compatibility audit: 48/48 checks passed.
- Executable Hotfix22 behavior suite: 83/83 checks passed.
- Transactional harness: 39/39 checks passed after removing its obsolete requirement for the deleted pre-iOS-26 MapKit path.
- Master Phase 56 release verifier: 549 checks passed.
- Swift parser validation passed in Release and DEBUG configurations.
- Python verification scripts compile and shell scripts pass syntax validation.
- App Store metadata validation passed.
- Phase 56 evidence template validation passed with 22 native/device/service gates correctly remaining pending.
- Shipping-source risk scan found no TODO/FIXME/HACK markers, forced tries, forced casts, or `fatalError` shortcuts.
- Package branding scan found no assistant-generation or vendor-attribution markers.

The only issue found during this Hotfix38 loop was a stale verification assertion that still expected cancellation across both modern and legacy MapKit implementations. Because the legacy implementation was intentionally removed with the iOS 26 minimum, the harness was corrected to require cancellation of the supported `MKGeocodingRequest` path. The corrected transactional harness then passed completely.
