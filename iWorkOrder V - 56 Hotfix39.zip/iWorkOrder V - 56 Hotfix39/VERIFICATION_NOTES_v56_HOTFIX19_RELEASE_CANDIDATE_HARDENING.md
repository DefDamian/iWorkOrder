# Phase 56 Hotfix 19 — Release candidate hardening

## Scope

This phase is a no-feature release-candidate pass over Hotfix 18. It focuses on privacy exposure, permission minimization, public wording, and low-risk hardware handling while preserving the existing work-order, backup, Cloud sync, legal, and public-release behavior.

## Changes

- Added an opaque `AppPrivacyShieldView` over the application whenever the SwiftUI scene is inactive or backgrounded. This is intended to keep tenant/work-order content, photos, signatures, and other operational data out of the app-switcher snapshot.
- Marked the root application content `privacySensitive()` as an additional semantic privacy signal.
- Removed `NSPhotoLibraryUsageDescription`. Work-order evidence uses SwiftUI `PhotosPicker`, which gives the app access only to items the user explicitly selects and does not require Photo Library authorization. No direct `PHPhotoLibrary` authorization path is used.
- Retained `NSCameraUsageDescription` because the optional flashlight accesses camera hardware through `AVCaptureDevice`.
- Hardened the flashlight path by checking `isTorchAvailable` and `.on` mode support before activating the torch and by guaranteeing `unlockForConfiguration()` through `defer`.
- Reworded public sync/recovery status from implementation-specific “CloudKit” terminology to the user-facing “iCloud” terminology. Engineering/legal documentation may still name CloudKit where technical precision matters.
- Removed two stale localization entries, `Sync ready` and `Sync failed - tap to retry`, that were no longer backed by real actions/state.
- Added a dedicated Hotfix 19 release-candidate harness and wired it into both cross-platform verification and the macOS/Xcode qualification runner.

## Current Apple release environment

As of September 13, 2026, App Store Connect requires iOS apps to be built with Xcode 26 or later using an iOS 26 SDK or later. Apple has also opened submissions built with Xcode 27 RC / iOS 27 RC. The project deliberately remains compatible with the Xcode 26 minimum while the final release candidate should also be exercised on the current Xcode 27 RC / iOS 27 path when available.

## Verification limitation

Cross-platform verification cannot replace Xcode type checking, simulator/device execution, archive validation, signing, production CloudKit testing, Xcode privacy-report review, or TestFlight processing. Those gates remain pending until run on macOS with Apple tooling.

## Legal version

The legal package remains `2026.09.13.56`. These privacy/permission/UI wording changes do not materially change the legal terms and therefore do not trigger another legal re-acceptance.
