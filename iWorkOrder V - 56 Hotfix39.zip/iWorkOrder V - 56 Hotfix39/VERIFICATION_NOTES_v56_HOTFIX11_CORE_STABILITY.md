# iWorkOrder v56 Hotfix 11 Core Stability Verification

This hotfix is limited to core correctness, data safety, synchronization consistency, and release-package integrity. It does not add product features.

## Corrected defects

1. Category identity is now deterministic across devices. Canonical comparison uses a fixed POSIX locale and normalizes case, diacritics, and Unicode width instead of depending on `Locale.current`.
2. Category deletion confirmation now retains the selected category identities. A list reorder or CloudKit refresh between the swipe action and the confirmation can no longer redirect the deletion to a different row index.
3. Category usage counts and dashboard filters use the same canonical category identity as the Category Manager, preserving expected behavior for legacy spelling variants.
4. Persisted image and signature filenames are validated through one shared policy before local file loading or deletion. Empty names, directory aliases, traversal syntax, separators, control characters, and overlong names are rejected.
5. Backup and CloudKit attachment validation now use the same filename policy as local attachment storage.
6. Cloud conflict freshness now includes work-order revision creation timestamps. Legacy records missing audit or status events no longer ignore a newer revision when choosing the winning top-level work-order state.
7. The distributed Xcode project no longer contains a private Apple Team ID. Signing remains supplied by the secure build environment.
8. Per-user Xcode workspace state is excluded from the package and from source-manifest verification.
9. Local fallback recovery no longer risks rotating an unreadable primary file over the known-good fallback. If quarantine fails, the unreadable primary is preserved, and recovery atomically rebuilds the primary while retaining the fallback.
10. Ordinary local saves now stage the previous primary snapshot before replacing the fallback copy, so a failed backup rotation cannot delete the last known recovery snapshot first.
11. Unreadable-snapshot quarantine names include a UUID, preventing same-second quarantine collisions from replacing earlier forensic recovery copies.
12. A manual CloudKit resync no longer schedules a follow-up upload with an uncommitted save-revision number; the uploaded metadata now matches the revision actually persisted on the device.
13. Startup no longer trusts a stale cross-install onboarding-complete flag when no local or legacy persisted snapshot was recovered. A reinstall with missing app data returns to full setup instead of opening a blank operational profile.
14. Notification toggles in onboarding and Settings no longer persist through reentrant `onChange` callbacks. Permission denial and save rollback now pass through one explicit transaction, avoiding duplicate saves or a rollback that could re-enable a denied setting.
15. Source integrity verification is regenerated after this hotfix and covers the complete deliverable.

## Regression coverage

Hotfix 11 adds unit coverage for canonical category identity, canonical category filtering, attachment filename traversal protection, and merge freshness based on revision timestamps. It also adds `Scripts/run_core_stability_harness.py` and wires that harness into the Phase 56 Xcode qualification flow.

## Verification boundary

All Swift sources and tests are syntax-parsed in the available environment, and all portable Python verification harnesses are executed. A real Xcode iOS build, simulator run, archive, and device test require Apple Xcode and the iOS SDK and cannot be substituted by the Linux Swift toolchain.
