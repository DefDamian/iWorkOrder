# iWorkOrder v56 Hotfix 20 — Final Release Candidate

Date: September 13, 2026

Scope: non-feature release-candidate hardening after Hotfix 19.

## Changes

1. Evidence import now converts picker-provided bytes through ImageIO on a detached user-initiated task. The saved evidence remains a protected JPEG with a maximum dimension of 1080 pixels.
2. The flashlight checks `AVCaptureDevice.authorizationStatus(for: .video)` and requests access only when the user explicitly turns the flashlight on. Denied/restricted/cancelled authorization cannot activate the torch.
3. Evidence-form lifecycle handling forces the torch off outside the active foreground and prevents a late permission result from enabling hardware after dismissal.
4. The Support screen no longer recursively calculates local-storage usage inside SwiftUI body rendering; the scan runs on a utility task and updates cached display state.
5. Export & Backup now caches total local storage, safety-backup size, and latest-safety-backup availability from utility work instead of scanning protected directories during SwiftUI body updates.
6. Signed-record integrity now verifies signature pixels through a tiny ImageIO decode instead of fully decoding every signature image on the main actor.
7. `CFBundleURLName` now uses the iWorkOrder product identity while the existing `iworkorder` URL scheme and production bundle/iCloud identifiers remain unchanged.
8. Added a dedicated Hotfix 20 final-RC regression harness and a unit regression for picker-data image conversion.

## Required Apple/Xcode validation

This environment does not include Xcode or the iOS SDK. A real Xcode 26+ build with warnings treated as errors, physical-device permission tests, signed archive validation, and TestFlight processing remain required before public release.
