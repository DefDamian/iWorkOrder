# iWork v4 verification notes

Patched from iWork_v3.

## Compile issue fixed
- Added missing `SettingsRow` component used by Legal and About.
- Removed duplicate `case .total` branch in `HubDetailKind.id`.
- Ran static checks for Swift brace balance across all Swift files.
- Checked for empty placeholder action buttons; backup export and restore now have real file actions.

## User reported bugs fixed
- Hub export:
  - Files uses native `fileExporter` and writes a report text file.
  - Google Drive uses the iOS share sheet with a generated report file.
  - OneDrive uses the iOS share sheet with a generated report file.
- Hub metric boxes:
  - Total Work Orders opens all active work orders.
  - Units / Areas opens grouped area view.
  - Completed opens completed work orders.
  - Recurring Issues opens grouped recurring issue view.
- Work Order delete:
  - Swipe gesture upgraded with high priority drag handling.
  - Delete remains available through the row context menu as a fallback.
- Legal section:
  - Privacy Policy, Terms & Conditions, and Data & Liability Disclaimer open detail pages.

## Historical export note superseded by Phase 48

The earlier raw JSON backup implementation has been replaced. Settings > Export & Backup now creates and restores a verified `.iworkorderbackup` archive containing data, photos, and signatures. Legacy JSON files remain migration-only inputs.
