# iWorkOrder v56 — Hotfix 33 Distinct Theme Identity

Hotfix33 corrects the three-theme presentation after the user reported that Default Theme, Design 2, and Design 3 appeared duplicated or too similar in-app.

## Root cause

The persisted theme values were different and the Work Order home already had separate custom-theme branches, but too much of the remaining visible app reused the same shared card, header, settings-row, metric, Calendar, Hub, and Settings presentation. The Themes picker also wrapped every choice in the currently active `ModernCard`, so the three options could visually inherit the same card language even though their small preview thumbnails differed. This made the theme system feel duplicated despite the stored selection changing correctly.

## Corrections

- Preserved the existing `selectedVisualTheme` persistence key and all three raw values.
- Re-separated the visual systems:
  - **Default Theme:** current system-oriented iWorkOrder styling and system light/dark behavior.
  - **Design 2:** command-console styling with compact geometry, monospaced operational typography, navy/electric-blue treatment, squared metric/icon surfaces, and denser cards.
  - **Design 3:** workflow styling with blue-purple gradients, rounded typography, softer large-radius cards, circular accents, and lavender/blue background treatment.
- `ModernCard`, `SectionHeader`, `MetricTile`, `SettingsRow`, `InfoLine`, and global backgrounds now render materially different geometry and ornamentation for Design 2 and Design 3 instead of relying mainly on color changes.
- Calendar now uses a **Schedule Grid** identity in Design 2 and a **Workflow Timeline** identity in Design 3.
- Hub now distinguishes **Operations Console / Dashboard** from **Control Room / Command**.
- Settings gives Design 2 its own **Settings Console** treatment while Design 3 keeps the workflow/control-room language.
- Design 2 Work Orders now use more compact command geometry and monospaced typography; Design 3 keeps the softer rounded workflow layout.
- The Themes screen now renders every option from the theme it represents, not from the currently selected theme. Its previews are larger and structurally different: System, Command, and Workflow.
- Added stable UI identities for the actual Default, Design 2, and Design 3 Work Order surfaces.
- Added Xcode UI coverage that switches all three themes and verifies that the actual Work Order surface changes to the corresponding distinct layout.

## Compatibility

- Legal version remains `2026.09.16.56`.
- Marketing version remains `1.0` and build remains `56`.
- Work-order schema and backup format are unchanged.
- Bundle identifier and iCloud/CloudKit container identity are unchanged.
- Existing saved theme preferences continue to use `selectedVisualTheme`.
- No work-order, attachment, notification, backup, restore, legal-acceptance, or sync behavior was intentionally changed.

## Verification

`Scripts/run_hotfix33_theme_identity_harness.py` checks that the three themes remain separate at the persisted identity, shared component, theme picker, Work Order, Calendar, Hub, and Settings levels. It also verifies that Xcode UI coverage checks the actual theme-specific Work Order surfaces rather than only the tab labels.

The complete release chain must pass after the final source hash manifest is regenerated. Native Xcode/iOS rendering remains a separate qualification layer and cannot be replaced by portable source inspection.

## Final portable verification

After the Hotfix33 identity corrections and native-test checklist updates, the complete portable regression chain was restarted from the beginning. The main release verifier passed 512 checks, the Hotfix33 theme-identity harness passed 43 checks, App Store metadata validation passed 44 checks, and Swift parser validation passed for both Release and Debug source paths. The evidence gate remains 0 failed / 22 pending because those gates require Xcode, signing, a simulator or physical Apple device, and/or production iCloud services.
