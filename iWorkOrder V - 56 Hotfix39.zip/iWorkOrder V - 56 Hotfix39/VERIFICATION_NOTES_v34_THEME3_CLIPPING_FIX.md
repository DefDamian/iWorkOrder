# v34 Theme 3 clipping and data binding fix

Scope: Theme 3 UI only.

Changes:
- Increased Theme 3 top content offset so the navigation bar no longer overlaps or cuts off the workflow card.
- Reworked Theme 3 workflow card to use live onboarding profile fields only:
  - `profile.buildingName`
  - `profile.personName`
- Removed duplicated address text from the Theme 3 workflow card.
- Made Theme 3 workflow title support up to three lines with scaling so long building names do not clip.
- Reduced Theme 3 work-order card vertical spacing and padding.
- Updated Theme 3 work-order rows so unit, title, category, priority, and status avoid truncation where possible.
- Updated Theme 3 overdue filter/count to use reminder date logic instead of treating every pending order as overdue.

Not changed:
- SwiftData/local persistence
- iCloud persistence logic
- audit log behavior
- PDF export behavior
- default theme behavior
- Theme 2 behavior
