# iWorkOrder v56 Hotfix28 — Full Bug Loop Integrity Hardening

## Scope

Hotfix28 starts from the packaged Hotfix27 source and performs a complete portable regression pass plus an independent source audit. The pass specifically reviews persistence, migration, backup/restore, iCloud merge/restore, attachment lifecycle, work-order revision identity, concurrency-risk shortcuts, unsafe indexing/forced operations, release packaging, and existing regression coverage.

## Defects found and fixed

### 1. Zero-revision work-order records were not rejected

`WorkOrder.originalEntry` and `latestEntry` have defensive model fallbacks. A damaged or malformed snapshot containing a work order with `entries: []` could therefore be treated as if it had a temporary blank entry instead of being stopped as corrupt data. This could produce misleading temporary dates/status-derived behavior.

Hotfix28 adds `DataMigrationError.invalidWorkOrderRevisionHistory` and rejects this state before the snapshot can be used. Local source bytes remain untouched in protection mode.

### 2. Restore code retained raw-snapshot fallbacks after normalization

The iCloud restore path and portable backup restore path previously contained `?? outcome.snapshot` / `?? candidate.snapshot` fallbacks after revision normalization. Those fallbacks were unnecessary for valid data and could undermine future integrity checks by accepting raw data if normalization returned `nil`. Hotfix28 removes both fallbacks and requires normalized data before applying a restore.

### 3. Persistence/export boundaries needed defense in depth

Hotfix28 adds a shared AppStore persistence guard and backup-archive validation so invalid zero-revision records cannot be saved, lifecycle-checkpointed, exported, or queued back to iCloud. Backup archive creation rejects the invalid structure before creating work files.

### 4. Failed backup restore could leave iCloud sync canceled

Backup restore intentionally cancels pending cloud work while it has exclusive access to local data. The failure and candidate-rejection paths released that exclusive access but did not restart the prior cloud operation after a clean rollback. Hotfix28 now resumes the appropriate pending replacement/sync only when local rollback is safe. If attachment recovery is incomplete, sync remains paused as required.

## Regression coverage

- `Scripts/run_maintenance_harness.py` compiles and executes the migration invariant.
- `Scripts/run_hotfix22_behavior_harness.py` now verifies backup rejection, local protection mode, and byte-for-byte preservation of an invalid source snapshot.
- `Scripts/run_hotfix28_full_bug_loop_harness.py` verifies 30 Hotfix28-specific source/integrity conditions.
- `Scripts/verify_release.sh` runs Hotfix28 together with the complete prior Phase56 regression chain.
- `Scripts/phase56_xcode_qualification.sh` records the same Hotfix28 harness before native Xcode qualification.

## Important test boundary

Portable verification can parse Swift and execute extracted Swift 6 core behavior, but this Linux environment cannot run Apple SDK type-checking, Xcode build/analyze, iOS simulators, CloudKit, PhotosPicker, UserNotifications, LocalAuthentication, or a physical-device UI session. The final native gate therefore remains the included Xcode qualification script on macOS.

## Final portable loop result

After the Hotfix28 fixes were applied, the complete portable verification chain was restarted from the beginning twice. The second complete pass reported `PHASE 56 RELEASE VERIFICATION: PASS` with 466 release checks, `HOTFIX 28 FULL BUG LOOP: PASS (30 checks)`, `HOTFIX 22 EXECUTABLE BEHAVIOR HARNESS: PASS (83 checks)`, App Store metadata validation PASS, evidence validation PASS with no failed portable gates, Swift parser validation PASS for Release and Debug source paths, and `PHASE 56 CROSS-PLATFORM VERIFICATION: PASS`.

A separate post-fix source audit also found no remaining explicit forced-try/forced-cast/fatal shortcuts, no TODO/FIXME/HACK placeholders, no production construction of zero-revision work orders, no unguarded shipping collection-removal sites, and no remaining raw backup/iCloud normalization fallback.
