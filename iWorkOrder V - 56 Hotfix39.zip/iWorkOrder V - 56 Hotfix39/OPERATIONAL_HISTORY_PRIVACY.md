# Privacy-safe operational history

Phase 54 stores a limited maintenance history locally on the device to support release troubleshooting.

## Recorded fields

- Fixed event category
- Success, warning, failure, or blocked outcome
- Timestamp
- Optional duration in milliseconds
- Optional aggregate item count
- Data schema version
- App version and build

## Never recorded

- User, company, building, tenant, contractor, or signer names
- Addresses, units, phone numbers, or email addresses
- Work-order descriptions, notes, audit messages, or search text
- Photo, signature, backup, or attachment filenames
- Photo or signature contents
- Internal device identifier
- CloudKit record identifiers or free-form CloudKit error messages

## Retention and control

- Maximum 250 events
- Maximum age 30 days
- Stored only in the app container
- Protected by iOS file protection
- Deleted by Erase All Data
- Is removed by Erase All Data; separate maintenance-history controls are available only in internal Debug builds
- Export requires an explicit user action

The app does not send this history to a developer-operated server and does not include third-party analytics or advertising SDKs.

## Phase 55 runtime and support evidence

Phase 55 adds one replaceable runtime lifecycle checkpoint, aggregate memory-pressure events, a local recovery-sync pause preference, and an explicitly exported support bundle. These additions use fixed technical fields only and remain subject to the same prohibition on names, addresses, work-order text, tenant data, audit text, images, signatures, filenames, and device identifiers.

A possible interrupted session means the previous checkpoint was not cleanly marked as backgrounded. It is not labeled or represented as a confirmed crash. The support bundle leaves the device only through an explicit user export or support-email action and is protected by a content SHA-256 checksum.
