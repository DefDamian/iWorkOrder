# v37 Legal URL Fix

- Updated Settings > Legal privacy link to the exact GitHub URL provided by the user.
- Updated Settings > Legal terms link to the exact GitHub URL provided by the user.
- Kept both links opening inside the existing in-app WKWebView.
- Removed duplicate WKWebView navigationDelegate assignment.
- No model, persistence, iCloud, audit log, PDF generation, onboarding reset, Theme 2, or Theme 3 logic was changed.
