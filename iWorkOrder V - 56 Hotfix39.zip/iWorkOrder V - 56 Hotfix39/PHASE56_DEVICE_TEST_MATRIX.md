# Phase 56 physical-device test matrix

Record device model, OS version, date, tester, build, result, and evidence path for every scenario. Use synthetic or authorized data only.

## iPhone

- Fresh install and upgrade from the latest supported production dataset
- Onboarding and legal acceptance
- Face ID, Touch ID, or passcode relock
- Photos picker, notification, Mail, Files, and denial paths
- Optional flashlight/torch from a fresh install, including camera-purpose-string behavior and confirmation that no photo/video capture occurs
- Work-order create, edit, complete, sign, trash, restore, search, and filters
- Evidence Gallery with many photos, including delete/restore/sync replacement and thumbnail correctness
- Monthly report Share or Save Report through Files and installed share extensions
- Notification scheduling and cleanup
- Backup Merge, Replace, safety restore, corruption rejection, and interruption recovery
- Local-only and CloudKit modes, with live status wording verified in every visual theme
- Offline edit and reconnect conflict
- Low-storage behavior
- Deep links
- App-switcher privacy snapshot while work-order/tenant/photo content is visible
- Photos picker from a fresh install with confirmation that no full Photo Library permission prompt is requested
- VoiceOver, Voice Control, Dynamic Type, Reduce Motion, Reduce Transparency, Increased Contrast, and Differentiate Without Color

## iPad

Repeat all applicable iPhone scenarios and include:

- Portrait and landscape
- Split View
- Stage Manager or resizable window behavior
- Hardware-keyboard navigation
- Sidebar and compact navigation transitions
- Large Dynamic Type in narrow windows

## Two-device CloudKit production

- Separate physical devices signed into authorized test iCloud accounts
- Initial upload and complete attachment download
- Concurrent offline edits followed by reconnect
- Revision and audit preservation
- Attachment deletion and cleanup
- Backup replacement transaction
- Cloud erase with interruption and recovery
- Recovery sync pause
- Verification that deleted or replaced data does not return

## Current-platform compatibility

- Run the final native qualification with stable Xcode 27 build `27A266a`, iOS 27 SDK, and Swift 6.4 compiler.
- Retain the iOS 26.0 deployment target and exercise supported iOS 26–27 devices/simulators for navigation, sheets, keyboard, share sheet, Photos picker, app-switcher privacy, and iPad resizing.
- Verify address lookup on both iOS 26 and iOS 27 through `MKGeocodingRequest` / `MKAddressRepresentations`.
- Treat hosted Xcode 26 results as compatibility evidence only, not the final native Xcode 27 release gate.


### Hotfix 20 device checks

- Flashlight permission: fresh install -> explicit Flashlight tap -> accurate camera-purpose prompt -> deny and grant paths.
- Flashlight lifecycle: turn on -> background/lock/dismiss evidence form -> verify torch is off on return.
- Evidence import performance: select at least one large HEIC/JPEG and verify the editor remains responsive while the stored evidence is bounded to 1080p.
- Support performance: open Support with a large local dataset and verify storage-size calculation does not block initial screen presentation.
- Deep link regression: verify `iworkorder://` still opens the app after the descriptive URL identifier cleanup.


### Hotfix 21 device checks

- Notification durability: simulate/induce a local-save failure before creating/editing a reminder and confirm no request for uncommitted state survives.
- Independent channels: an emergency revision with a future explicit reminder can have one emergency follow-up plus one user reminder without identifier collision.
- No resurrection: after an emergency follow-up expires, reopen/resync and confirm no new 10-second follow-up is generated.
- Delayed deep link: trigger a work-order route before the matching synced record is present; confirm the route resolves after data arrives.
- Local-only notification surface: confirm local notification taps route correctly and the build does not request remote-push registration.
- Device-local permission isolation: deny/revoke notification permission on one of two synced devices and confirm the other device is not globally disabled.

## Hotfix 30 launch continuity

- [ ] Cold-launch in iOS Light appearance and confirm the native launch screen, SwiftUI splash, and first app screen do not show a low-contrast/ghost logo or white-to-dark flash.
- [ ] Cold-launch in iOS Dark appearance and confirm the native launch screen and SwiftUI splash use the coordinated dark artwork without a size jump.
- [ ] Launch iWorkOrder from another app such as Messages and confirm the startup handoff remains visually continuous while the system back-to-app indicator is present.


## Hotfix 34 Field Deck Theme 3 rebuild

- [ ] Select Design 3 from Default Theme and confirm the app immediately enters the dark graphite/mint Field Deck appearance without relaunching.
- [ ] Verify Work Orders shows the Field Deck queue header, search, status rail, field filters, priority rails, and no purple/blue workflow cards from the prior Theme 3.
- [ ] Verify Calendar uses the Field Deck schedule/timeline cards and every reminder still opens the correct work order.
- [ ] Verify Hub uses the Field Deck overview, metrics, monthly report export, Asset Tags & QR, and Unit / Tenant Directory.
- [ ] Verify Settings uses Profile/System/Workflow/Support groups and every navigation destination still opens correctly.
- [ ] Switch Design 3 -> Design 2 -> Default -> Design 3 repeatedly while each tab has already been visited; confirm no stale theme chrome remains.
- [ ] Test Design 3 with Dynamic Type, VoiceOver, Reduce Motion, Reduce Transparency, Increased Contrast, and iPad split/Stage Manager layouts.

## Hotfix 31 frosted privacy shield

- [ ] With a work order containing readable tenant/unit/photo information on screen, pull down Notification Center and confirm the app underneath is strongly blurred and the text is not readable.
- [ ] Open Control Center and the app switcher and confirm the same compact frosted privacy presentation is used rather than the full startup splash.
- [ ] Repeat in iOS Light and Dark appearances and confirm the small adaptive iWorkOrder mark has appropriate contrast.
- [ ] Enable Reduce Transparency and confirm the privacy cover switches to the solid adaptive fallback while still hiding sensitive content.
- [ ] Cold-launch the app and confirm the privacy shield does not flash before the normal Hotfix30 startup handoff completes.

## Hotfix 32 full bug loop

- [ ] With **Reduce Transparency** enabled, open Notification Center, Control Center, and the app switcher; confirm the full cover and compact logo badge are both opaque with no material/glass patch remaining.
- [ ] With Reduce Transparency disabled, confirm the privacy treatment remains frosted and the underlying work-order text cannot be read.
- [ ] From Settings > Themes, switch Default -> Design 2 -> Design 3 -> Default while Work Orders are populated; confirm rows, date labels, filter chips, priority cards, and hero colors all change in the same frame with no stale styling.
- [ ] Open legal/setup-gated surfaces where applicable and confirm their layout uses the active theme without requiring relaunch.
- [ ] Hotfix33 identity check: on Work Orders, verify Default uses the native/system layout, Design 2 uses the compact command-console layout, and Design 3 uses the rounded blue-purple workflow layout; the three must be structurally distinguishable, not just recolored.
- [ ] In Settings > Themes, verify each theme preview keeps its own visual identity even while a different theme is currently selected (Default = system, Design 2 = command, Design 3 = workflow).
- [ ] Repeat the three-theme identity check in Calendar, Hub, and Settings; verify Design 2 uses compact command styling while Design 3 uses the softer workflow/control-room styling.

