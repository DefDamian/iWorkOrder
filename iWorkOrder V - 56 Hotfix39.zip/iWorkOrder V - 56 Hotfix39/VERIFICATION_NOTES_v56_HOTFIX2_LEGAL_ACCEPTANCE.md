# iWorkOrder v56 Hotfix 2 - Legal Acceptance Action Fix

## Defect

On the onboarding legal-agreement sheet, the unlabeled trailing closure was bound to `LegalDocumentView.decline` because `decline` was the final closure parameter. The **I Understand and Agree** button therefore had a `nil` accept action and silently did nothing.

## Correction

- Passed the onboarding acceptance closure with the explicit `accept:` label.
- Dismisses the sheet only after `AppStore` reports current legal acceptance.
- Disables the agreement button if an accept callback is ever omitted.
- Added stable accessibility identifiers for agree and decline actions.
- Added a UI regression test that opens the onboarding legal sheet, taps Agree, verifies dismissal, and confirms the onboarding card changes to **Agreement Accepted**.

## Scope

No legal wording, storage schema, CloudKit schema, backup format, or application data model was changed.
