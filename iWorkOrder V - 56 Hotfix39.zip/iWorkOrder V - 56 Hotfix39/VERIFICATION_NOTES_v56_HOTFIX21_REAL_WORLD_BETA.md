# Phase 56 Hotfix 21 — Real-World Beta Hardening

Date: September 13, 2026

## Scope

This phase is a non-feature beta hardening pass. It preserves legal version `2026.09.13.56` and focuses on notification durability, notification identity, delayed deep-link routing, and removal of dead public-facing legacy code.

## Corrections

- Notification Center mutations now reconcile from successfully committed work-order state rather than being scheduled before local persistence succeeds.
- Explicit reminders and emergency follow-ups use independent identifiers. Emergency identifiers also include the current revision ID.
- Emergency follow-ups are anchored to the committed revision timestamp instead of being recreated relative to the current time after a reopen/resync.
- Stale asynchronous notification cleanup is generation-guarded so an older callback cannot remove requests belonging to a newer reconciliation.
- Removed the now-unused per-order notification cancellation API and a duplicate pending-notification removal call.
- Pending deep links now retry when work-order data changes, so a notification/deep link received before local/iCloud data finishes loading can open after the matching record arrives.
- Removed dormant remote-push launch handling; this build uses local notifications and does not register for APNs.
- iOS notification authorization is treated as device-local. A denial/revocation on one iPhone/iPad no longer persists `notificationsEnabled = false` into the synced profile and therefore cannot disable another device by accident; the affected device cancels its local requests and surfaces a permission warning instead.
- Removed unreachable legacy-theme helper views that contained fake `$0.00`, `Late 0`, and inert filter metrics. Public theme descriptions no longer describe designs as old/legacy project UI.
- Initial sync wording remains user-facing `iCloud` terminology.

## Regression coverage

`Scripts/run_hotfix21_real_world_beta_harness.py` verifies notification identifier separation, revision-time scheduling, save-before-notification ordering, generation-safe reconciliation, local-only notification routing, delayed deep-link retry, removal of fake/dead UI, and compiler-risk hygiene.

The existing XCTest suite also includes notification-policy tests for independent identifiers and non-resurrection of expired reminders/follow-ups.

## Apple execution boundary

Cross-platform verification cannot replace an Xcode/iOS SDK build. The final beta gate still requires Xcode compilation, simulator/device tests, archive validation, signing, and TestFlight/production-iCloud evidence on macOS.
