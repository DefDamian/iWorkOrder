# iWorkOrder v56 Hotfix 17 — Public Release Surface Cleanup

## Scope

This hotfix separates public App Store behavior from internal Debug-only qualification and troubleshooting tools.

## Release-only changes

- `-ui-testing`, onboarding test launch flags, seeded work-order data, and legal-update test launch behavior are confined to `#if DEBUG` code paths.
- `AppStore.loadUITestingState()` is not compiled into Release-active source.
- The public Settings screen no longer exposes **Maintenance & Recovery**, **Release Health**, raw maintenance reports, operational-history clearing, or the manual **Pause Cloud Sync for Recovery** control.
- The manual recovery-pause API is DEBUG-only. A public Release launch clears a legacy persisted manual pause so users cannot become stranded behind a control that is no longer exposed.
- Public **Support** contains only app status, **Create Support Package**, and **Email Support**.
- The standalone raw diagnostics export action was removed from the public UI. The privacy-safe diagnostic model remains an internal component of the user-initiated support package.
- The public data-compatibility screen no longer exposes the internal data-schema number.
- Release build settings explicitly set `ENABLE_PREVIEWS = NO` and `ENABLE_TESTABILITY = NO`.
- The app Resources phase contains only `Assets.xcassets`, `PrivacyInfo.xcprivacy`, and `Localizable.xcstrings`; source verification notes, scripts, phase reports, test targets, and handoff documents are not bundled into the app.

## Verification

`Scripts/run_public_release_harness.py` verifies the Release-active source after resolving `#if DEBUG` blocks. It rejects UI-test hooks, internal maintenance/release-health UI, raw diagnostic export controls, manual recovery-pause UI, stale internal localization strings, DEBUG in the Release target, and unexpected source/verification artifacts in the app Resources phase.

The harness also confirms that the public Support surface remains available and that developer-only resources are not included in the Release app surface.

## Legal behavior

Legal version remains `2026.09.13.56`, effective September 13, 2026. No new re-acceptance is triggered because Hotfix 17 changes release exposure and build hygiene, not the legal text.

## Xcode limitation

Cross-platform verification can validate conditional-compilation structure, Swift parsing, source integrity, and the full harness suite, but an actual Release archive still requires Xcode on macOS. The signed archive must be checked to confirm Debug-only strings and UI are absent from the processed app binary.
