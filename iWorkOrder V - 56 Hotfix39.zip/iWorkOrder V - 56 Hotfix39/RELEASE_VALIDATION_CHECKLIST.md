# Phase 56 release validation checklist

## Hotfix39 iPadOS 26 resizable-scene cleanup: native checks still required

- [ ] Run `python3 Scripts/run_hotfix39_fullscreen_deprecation_harness.py` and confirm every check passes.
- [ ] In Xcode 27, confirm the `UIRequiresFullScreen` deprecation warning is gone in both Debug and Release builds.
- [ ] On iPadOS 26 and 27, resize the app through narrow, medium, and wide window sizes and rotate through all four supported orientations.
- [ ] Verify Work Orders, Calendar, Hub, Settings, onboarding, legal screens, sheets, photo/evidence flows, and keyboard navigation do not clip, overlap, or become unreachable while resizing.
- [ ] Confirm the configured launch screen remains present and the app opens normally in full-screen and windowed modes.

## Hotfix38 iOS 26 minimum baseline: native checks still required

- [ ] Run `python3 Scripts/run_hotfix38_ios26_baseline_harness.py` and confirm every check passes.
- [ ] Confirm Debug and Release build settings for app, unit-test, and UI-test targets all resolve to `IPHONEOS_DEPLOYMENT_TARGET = 26.0`.
- [ ] Build and test on both iOS 26 and iOS 27 simulators/devices; confirm onboarding, address verification, notifications, photos, backup/restore, CloudKit, themes, accessibility, and iPad layouts remain correct.
- [ ] Verify address lookup uses `MKGeocodingRequest` / `MKAddressRepresentations` with cancellation and stale-response protection.
- [ ] Confirm devices below iOS 26 are intentionally unsupported and App Store Connect shows the expected minimum OS before release.

## Hotfix37 Xcode 27 / Swift 6.4 audit: native checks still required

- [ ] Run `python3 Scripts/run_hotfix37_xcode27_swift64_harness.py` and confirm every check passes.
- [ ] Use stable Xcode 27 build `27A266a` on macOS Tahoe 26.6 or later; confirm the iOS 27 SDK and Swift 6.4 compiler are selected.
- [ ] Open the project in native Xcode 27, review any recommended project-setting migration, and apply only changes that preserve the iOS 26.0 minimum deployment target and app behavior.
- [ ] Build Debug and Release with warnings treated as errors, run all unit/UI tests, static analysis, repeated stability tests, and the archive validation path.
- [ ] Exercise address verification on both iOS 26 and iOS 27 so the supported `MKGeocodingRequest` / `MKAddressRepresentations` path is covered on Apple SDKs.
- [ ] Do not treat the hosted macOS 26 workflow as final Xcode 27 qualification; it is a compatibility gate only.

## Hotfix34 Theme 3 Field Deck rebuild: native checks still required

- [ ] Run `python3 Scripts/run_hotfix34_theme3_rebuild_harness.py` and confirm every check passes.
- [ ] On a simulator and physical iPhone, select Design 3 and confirm its Work Orders, Calendar, Hub, and Settings surfaces match the new dark graphite/mint Field Deck identity.
- [ ] Confirm there is no residual purple/blue workflow styling from the previous Design 3.
- [ ] Verify Field Deck Quick Capture, New Work Order, search, status filters, unit/worker/category filters, deep links, reminder navigation, report export, assets, directory, and Settings destinations.
- [ ] Repeat live switches Design 3 -> Design 2 -> Default -> Design 3 with all four main tabs already retained in memory.
- [ ] Run all Xcode unit/UI tests, including `testTheme3FieldDeckSurfacesAreDistinct()`.
- [ ] Re-run launch continuity, privacy shield, backup/restore, iCloud/CloudKit, permission, legal, accessibility, Dynamic Type, iPad resizing, and app-switcher/Notification Center checks.

## Hotfix33 distinct-theme identity: native checks still required

- [ ] Run `python3 Scripts/run_hotfix33_theme_identity_harness.py` and confirm every check passes.
- [ ] On a real iPhone or simulator, select Default, Design 2, and Design 3 in sequence without relaunching; verify each Work Orders surface has a visibly different structure, typography, corner geometry, and hero treatment.
- [ ] Confirm the Themes chooser previews the represented theme itself rather than inheriting the currently selected theme.
- [ ] Verify Calendar, Hub, and Settings preserve the same identity split: Default = native/system, Design 2 = compact command console, Design 3 = soft blue-purple workflow/control room.
- [ ] Switch themes repeatedly while each main tab is already retained in memory; confirm no stale cards, headers, navigation bars, or accent colors remain from the previous theme.
- [ ] Re-run the existing Hotfix29 live-switch, Hotfix30 launch, Hotfix31 privacy-shield, and Hotfix32 full-loop native checks after the theme identity changes.

## Hotfix22 consolidated pass: native checks still required

- [ ] Run the portable verifier, including the 80-check executable behavior harness and source/build-path harness.
- [ ] Build Debug and Release in Xcode with warnings investigated; run all XCTest and UI tests.
- [ ] Verify upgrading from an older restore journal preserves the matching committed snapshot and attachments.
- [ ] Verify corrupt/newer/missing snapshots preserve existing evidence without restarting onboarding or deleting files.
- [ ] Verify a denied notification prompt cannot replace profile changes received while it was visible.
- [ ] Import a large photo, immediately try Save/Sign and Save, and verify saving waits and succeeds after import.
- [ ] Background during biometric authentication and verify the prior success does not unlock the newly locked session.
- [ ] Open long-note PDFs, inspect every page for clipping and legibility, and verify the final text marker is present.
- [ ] Export more than six photos plus a missing attachment; verify every available image and missing-evidence notice.
- [ ] Generate two PDFs in quick succession and verify both files survive independently.
- [ ] Verify VoiceOver cannot reach data covered by the backup or inactive-app shield, including modal sheets.
- [ ] Run the unchanged signed/device/production-iCloud/TestFlight gates; do not mark them complete from portable results.

## 1. Cross-platform source verification

```bash
./Scripts/verify_release.sh
```

- [ ] All static and executable harnesses pass.
- [ ] Swift parser validation passes.
- [ ] Python and shell validation passes.
- [ ] Source SHA-256 manifest passes.
- [ ] No credential or private signing material is included.

## 1B. Public release surface

- [ ] `python3 Scripts/run_public_release_harness.py` passes.
- [ ] Release Settings shows **Support**, not **Support & Diagnostics**.
- [ ] Release Settings does not show **Maintenance & Recovery**, **Release Health**, raw diagnostics export, operational-history controls, or **Pause Cloud Sync for Recovery**.
- [ ] Release launch arguments cannot activate UI-test onboarding, seeded data, or legal-update test state.
- [ ] Release string catalog contains no stale developer-only labels from those hidden surfaces.
- [ ] Release target has previews and testability disabled.
- [ ] Archive Resources contain no verification notes, scripts, phase reports, or test artifacts.

## 1C. Hotfix 18 public-beta qualification

- [ ] `python3 Scripts/run_public_beta_harness.py` passes.
- [ ] Scroll an order with many evidence photos and confirm thumbnails appear correctly without repeated full-size decode stalls.
- [ ] Delete, restore, replace, and sync photo attachments and confirm stale thumbnails never survive the underlying file change.
- [ ] Enable **Reduce Motion** and confirm custom filter/trash transitions no longer animate.
- [ ] Enable **Reduce Transparency** and confirm custom cards, fields, and blocking overlays become legible opaque surfaces.
- [ ] Verify Default, Design 2, and Design 3 on iOS 26 or later with the standard tab/navigation appearance.
- [ ] Exercise local-only, syncing, synced, offline, paused, no-account, restricted, and failed cloud states and confirm legacy-theme status text matches reality.
- [ ] Use **Share or Save Report** and confirm the system share sheet exposes only destinations actually installed/available on the device.
- [ ] Generate Xcode's privacy report from the exact signed archive and compare it with App Store Connect privacy answers and the published privacy policy.

## 1D. Hotfix 19 release-candidate hardening

- [ ] `python3 Scripts/run_release_candidate_harness.py` passes.
- [ ] Background the app while a work order containing tenant details/photos is visible and confirm the app switcher makes the underlying content unreadable behind the compact privacy shield; with Reduce Transparency enabled, confirm both cover and logo badge are opaque.
- [ ] Return to the app and confirm content immediately restores without losing editor state.
- [ ] Confirm selecting Before/After Photo uses the system Photos picker without a full Photo Library permission prompt.
- [ ] Confirm the optional flashlight still behaves correctly on a physical iPhone and reports unavailable hardware cleanly.
- [ ] Confirm public sync/recovery status uses iCloud wording and does not expose internal CloudKit terminology.
- [ ] Run the final signed archive through Xcode Organizer privacy-report review.
- [ ] Exercise stable Xcode 27 / iOS 27 before public beta, plus the supported iOS 26–27 regression matrix.


## 1E. Hotfix 20 final release candidate

- [ ] `python3 Scripts/run_final_rc_harness.py` passes.
- [ ] Large HEIC/JPEG evidence import remains responsive and stores bounded protected evidence.
- [ ] Flashlight permission/deny/background/dismissal paths leave the torch off when the form is inactive.
- [ ] Support and Export & Backup open without synchronous recursive filesystem scans.
- [ ] `iworkorder://workorder/<UUID>` routes correctly.

## 1F. Hotfix 21 real-world beta hardening

- [ ] `python3 Scripts/run_hotfix21_real_world_beta_harness.py` passes.
- [ ] Create a work order with a future explicit reminder and verify exactly one reminder request is scheduled after the save succeeds.
- [ ] Create an emergency work order with a future explicit reminder and verify the emergency follow-up and user reminder behave independently.
- [ ] Reopen/resync after the emergency follow-up deadline and verify the expired follow-up is not recreated relative to the current time.
- [ ] Complete/trash an order and verify pending requests for that order are reconciled away only after the state change is saved.
- [ ] Open an `iworkorder://` link before the matching record finishes loading/syncing and confirm it opens when the record arrives.
- [ ] Confirm the app requests no APNs/remote-push registration and local notification routing still works from terminated/background/foreground states.
- [ ] With two devices, deny/revoke notification permission on only one device and verify the other device retains its synced app preference and existing valid notification capability.

## 1A. Hotfix 6 defect stabilization

- [ ] Whitespace-only area or description cannot be saved.
- [ ] Cancelling a draft removes uncommitted photo files.
- [ ] A work order changed by another device cannot be overwritten by a stale open editor.
- [ ] A failed local save leaves the previous work-order state intact.
- [ ] Signature Save cannot be double-submitted and does not retain a signature when completion persistence fails.
- [ ] Near-term reminders retain seconds instead of being truncated into the past.
- [ ] Onboarding storage picker and iCloud toggle always agree.
- [ ] Theme 2 overdue and worker counts match actual data.
- [ ] Photo, flashlight, and PDF failures show an error instead of silently doing nothing.
- [ ] The full UI test signs, saves, dismisses the signature sheet, and shows Making Changes.

## 2. Xcode automated qualification (stable Xcode 27 final gate; hosted Xcode 26 compatibility gate)

```bash
# Hosted compatibility only
./Scripts/run_xcode_ci.sh

# Final native gate on stable Xcode 27 (27A266a)
PHASE56_MODE=ci ./Scripts/phase56_xcode_qualification.sh
```

- [ ] Native Xcode 27 environment reports build `27A266a`, iOS 27 SDK, and Swift 6.4 compiler.
- [ ] iPhone simulator tests pass.
- [ ] iPad simulator tests pass.
- [ ] Five repeated unit-test iterations pass.
- [ ] Screenshot UI tests pass on both device families.
- [ ] Swift and Clang warnings are treated as errors.
- [ ] Static analysis passes.
- [ ] Unsigned archive validates.

## 3. Signed archive and IPA

```bash
APPLE_TEAM_ID=YOUR_TEAM_ID \
PHASE56_MODE=signed \
./Scripts/phase56_xcode_qualification.sh
```

- [ ] Automatic provisioning succeeds.
- [ ] Signed archive validates as version `1.0`, build `56`.
- [ ] Application identifier and CloudKit entitlements are correct.
- [ ] Deep code-signature verification passes.
- [ ] App Store Connect IPA export succeeds.
- [ ] IPA payload validation passes.
- [ ] dSYM and symbol evidence are retained.

## 4. Privacy and legal

- [ ] Confirm the installed legal version is `2026.09.16.56` and the effective date is September 16, 2026.
- [ ] Upgrade a profile that accepted an older legal version and confirm the Legal Terms Updated splash appears before normal app access.
- [ ] Decline the updated agreement and confirm normal app access remains blocked.
- [ ] Accept the updated agreement, relaunch, and confirm normal app access resumes without another legal prompt for the same version.
- [ ] Confirm bundled Privacy Policy, Terms & Conditions, and Data & Liability Disclaimer exactly match the published copies.
- [ ] On a physical iPhone, toggle the optional flashlight from a fresh install and confirm any camera-purpose prompt is accurate, the app does not crash, and no photo/video capture UI or media recording occurs.
- [ ] Generate Xcode’s privacy report from the exact signed archive.
- [ ] Review every included SDK and required-reason declaration.
- [ ] Confirm App Privacy answers against the processed binary and network behavior.
- [ ] Publish and compare all legal and support pages.
- [ ] Confirm export-compliance answers for the signed build.

## 5. CloudKit production

- [ ] Deploy the development schema for `iCloud.com.damiancedeno.SedgwickWorkOrders` to production.
- [ ] Verify record types, zone, indexes, snapshot asset, photo assets, and signature assets.
- [ ] Test two physical devices, offline edits, reconnects, conflicts, replacement restore, cloud erase, and recovery pause.
- [ ] Confirm deleted or replaced data cannot return.

## 6. Physical-device matrix

- [ ] Complete `PHASE56_DEVICE_TEST_MATRIX.md` on physical iPhone and iPad.
- [ ] Test fresh install and upgrade.
- [ ] Test permissions, notifications, biometrics, the Photos picker, Mail, Files, and deep links.
- [ ] Test backup Merge, Replace, safety restore, interruption recovery, corruption rejection, and low storage.
- [ ] Test large datasets, long histories, many photos, and offline conflicts.
- [ ] Test VoiceOver, Voice Control, Switch Control, Dynamic Type, Bold Text, Reduce Motion, Increased Contrast, and Differentiate Without Color.
- [ ] Test iPad portrait, landscape, Split View, Stage Manager, resizing, and keyboard navigation.

## 7. Screenshots and metadata

- [ ] Export and review synthetic screenshot attachments.
- [ ] Install approved screenshots in the required App Store folders.
- [ ] Run `python3 Scripts/validate_app_store_metadata.py --require-screenshots`.
- [ ] Confirm public URLs and account-holder declarations.

## 8. TestFlight stabilization

- [ ] Upload build 56.
- [ ] Wait for successful Apple processing.
- [ ] Complete internal group 1 exit criteria.
- [ ] Complete operational workflow testing.
- [ ] Close all critical and high-severity defects.
- [ ] Repeat affected scenarios after every correction.

## 9. Final machine-readable evidence gate

- [ ] Every required item in `phase56_evidence.json` is marked `pass`.
- [ ] Every passing item has an existing evidence path.
- [ ] `EVIDENCE_INDEX.json` records SHA-256 hashes for the qualification artifacts.
- [ ] The following command passes:

```bash
python3 Scripts/validate_phase56_evidence.py \
  Artifacts/Phase56/phase56_evidence.json \
  --root . \
  --require-complete
```

Do not submit while any required gate is pending, blocked, failed, unsupported, or missing evidence.

## Hotfix 7 transactional-integrity checks

- [ ] Recover an order on one device, merge an older deleted snapshot from another device, and confirm the order remains recovered.
- [ ] Delete an order after recovery and confirm the newer deletion wins on the second device.
- [ ] Simulate a local-save failure and confirm trash, recovery, directory, unit import, and integrity-repair state roll back.
- [ ] Confirm signed completed work orders do not gain an audit event merely by being opened.
- [ ] Run retention cleanup with a shared legacy image reference and confirm the still-referenced file remains available.
- [ ] Start two address verifications quickly and confirm the older callback cannot replace the newer result.
- [ ] Export a backup with pending integrity repairs and confirm the local snapshot is committed before archive creation.


## Hotfix 20 final release-candidate checks

- [ ] On a fresh install, tap Flashlight and confirm iOS requests camera access only after that explicit action.
- [ ] Deny camera access and confirm the flashlight remains off and iWorkOrder stays usable.
- [ ] Grant camera access, turn the flashlight on, background the app, and confirm the torch turns off before returning to iWorkOrder.
- [ ] Start flashlight authorization and immediately dismiss/background the form; confirm the torch cannot turn on after the form is gone.
- [ ] Import a large HEIC/JPEG evidence photo and confirm the form remains responsive while a protected 1080p-or-smaller JPEG is created.
- [ ] Open Support with a large evidence/backup dataset and confirm the screen appears immediately while Local Storage changes from `Calculating...` to the computed value.
- [ ] Open Export & Backup with a large backup directory and confirm storage totals and latest-backup availability populate without blocking the initial screen.
- [ ] Open a dataset with many completed signed work orders and confirm load/repair does not visibly stall while signature integrity is checked.
- [ ] Open an `iworkorder://` deep link and confirm the existing scheme still routes correctly.
- [ ] Run `python3 Scripts/run_final_rc_harness.py`.
