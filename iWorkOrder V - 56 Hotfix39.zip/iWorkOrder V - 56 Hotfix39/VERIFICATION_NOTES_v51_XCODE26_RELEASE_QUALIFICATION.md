# Verification Notes v51: Xcode 26 Release Qualification

Date: August 4, 2026

## Scope

Phase 51 prepares and enforces the build, test, analysis, archive, signing, and evidence workflow required for current Apple distribution. Apple requires App Store Connect uploads to use Xcode 26 or later and the iOS 26 SDK or later as of April 28, 2026.

## Changes

### Release configuration

- Build number advanced from 50 to 51 for the app and unit-test targets.
- `SWIFT_STRICT_CONCURRENCY = complete` enables full concurrency diagnostics while preserving Swift 5 language mode.
- `ENABLE_USER_SCRIPT_SANDBOXING = YES` is enabled at project level.
- Release app builds enable `DEAD_CODE_STRIPPING` and `VALIDATE_PRODUCT`.
- The distributed project retains an empty `DEVELOPMENT_TEAM`; signing identity is supplied only in the secure build environment.

### App icon qualification

Every AppIcon PNG was converted from RGBA to RGB. The release verifier now checks:

- PNG signature and IHDR structure
- Exact pixel dimensions derived from each asset-catalog size and scale
- 8-bit encoding
- Absence of grayscale-alpha or RGBA PNG color types

### Xcode qualification automation

`Scripts/phase51_xcode_qualification.sh`:

- Selects the newest installed Xcode 26 unless `DEVELOPER_DIR` is explicitly supplied.
- Rejects Xcode or iOS SDK versions below 26.
- Captures environment and build-setting evidence.
- Dynamically selects current iPhone and iPad simulators.
- Runs tests with Swift, Clang, and GCC warnings treated as errors.
- Runs Xcode static analysis.
- Creates an unsigned or signed Release archive.
- Validates the archive contents.
- Verifies CloudKit entitlements and the code signature for signed archives.

`Scripts/validate_xcode_archive.py` verifies the archived bundle identifier, version, build, executable, privacy manifest, compiled assets, dSYM, source-file exclusion, Finder-metadata exclusion, and signed entitlements.

### Continuous integration

The GitHub Actions workflow now:

- Uses `macos-26`.
- Runs the complete unsigned Phase 51 qualification.
- Cancels superseded runs for the same branch.
- Uploads qualification logs, result bundles, and archive evidence for review.

## Verification completed in this environment

- Phase 51 static verifier passed.
- Executable Swift logic harness passed.
- All Swift source files passed parser validation with Swift 6.2.1.
- Xcode project, scheme, plists, privacy manifest, entitlements, and asset catalogs parsed successfully.
- App icon dimensions and RGB encoding passed.
- Python qualification tools compiled successfully.
- Shell qualification scripts passed `bash -n` validation.
- Archive validator passed against a synthetic archive fixture.
- Source-manifest coverage and SHA-256 verification passed after packaging.

## Verification requiring macOS and owner credentials

The following cannot be truthfully completed in this Linux environment:

- iOS SDK type-check and link
- Xcode warning and concurrency diagnostics
- iPhone and iPad simulator execution
- Xcode static analyzer execution
- Real `.xcarchive` generation
- Provisioning and code signing
- Xcode Organizer validation
- Xcode privacy report generation
- CloudKit production deployment
- TestFlight upload and installation
- Physical-device and two-device CloudKit testing

Run the supplied unsigned and signed qualification commands on macOS before distribution.
