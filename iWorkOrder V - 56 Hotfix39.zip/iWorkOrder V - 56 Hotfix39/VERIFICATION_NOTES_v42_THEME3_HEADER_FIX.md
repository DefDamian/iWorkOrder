# iWorkOrder v42 Theme 3 Header Fix

## Changes made
- Theme 3 Calendar now hides the large NavigationStack title, leaving only the in-page Calendar header.
- Theme 3 Command now hides the large NavigationStack Hub title so the Command hero card starts higher.
- Default Theme and Design 2 navigation titles are unchanged.

## Files changed
- iWorkOrder/CalendarHubSettingsViews.swift

## Notes
- This environment does not include xcodebuild, so the project could not be compiled here.
