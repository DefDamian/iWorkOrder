# iWorkOrder v56 — Hotfix 35 Onboarding Theme-Scope Compile Correction

## Defect found from native Xcode

Xcode correctly reported `Cannot find 'selectedTheme' in scope` in `OnboardingView.swift`. The onboarding screen observed `selectedThemeRaw` with `@AppStorage`, then used `AppTheme.horizontalPadding(for: selectedTheme)` without defining the derived `selectedTheme` value inside `OnboardingView`.

## Correction

`OnboardingView` now defines its own reactive derived theme value:

```swift
private var selectedTheme: VisualTheme {
    VisualTheme(rawValue: selectedThemeRaw) ?? .defaultTheme
}
```

This preserves the live-theme behavior and adaptive onboarding spacing without changing the persisted theme key, user data, legal version, backup format, CloudKit identity, or the rebuilt Theme 3 Field Deck design.

## Regression hardening

Hotfix35 adds a dedicated source-scope regression harness. In addition to asserting the onboarding fix, the harness scans shipping Swift view structs that reference `selectedTheme` and rejects any struct that uses that symbol without a local declaration. The harness is wired into both portable release verification and the Mac/Xcode qualification workflow.

## Verification boundary

The package is parsed and regression-tested with the available Swift 6 compiler in this environment. Native SwiftUI type checking and an iOS build still require Xcode on macOS, so the exact Apple build remains a native qualification gate.
