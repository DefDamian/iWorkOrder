# v17 UI Polish Notes

Changes made:
- Quick Add and New Work Order now use the same shared action button label layout.
- Both top action buttons now share the same height and flexible equal-width behavior.
- Button control size was reduced from large to regular to shrink the visual footprint slightly while keeping the tap target usable.
- Search field now uses a custom inline search treatment with a magnifying glass, thin material background, and subtle stroke instead of the default roundedBorder TextField.

Risk notes:
- No data model, persistence, iCloud, audit log, PDF export, onboarding, or navigation logic was changed.
- Changes are limited to WorkOrderViews.swift and Components.swift, plus this note file.

Recommended Xcode check:
- Build the iWorkOrder scheme.
- Open Work Order home screen on iPhone preview/device.
- Confirm the two buttons are the same size and the search box blends into the card.
