# App Store privacy audit

Phase 50 audited the app source against Apple's required-reason API categories.

## Declared categories

- `NSPrivacyAccessedAPICategoryUserDefaults` with `CA92.1`: app-only preferences, onboarding state, theme, device identity, save revision, and CloudKit transaction flags.
- `NSPrivacyAccessedAPICategoryFileTimestamp` with `C617.1`: timestamps, sizes, and metadata for files inside the app container, including backup safety copies and CloudKit attachment staging.
- `NSPrivacyAccessedAPICategoryDiskSpace` with `E174.1`: user-visible free-space preflight before backup creation, import staging, and restore attachment installation.

`NSPrivacyAccessedAPICategorySystemBootTime` was removed because the app source does not use `systemUptime` or `mach_absolute_time`.

## Data collection declaration

The privacy manifest declares no developer-collected data and no tracking. The app has no advertising, analytics, telemetry, or developer-operated work-order backend. User content is kept in the app container and, when enabled, the user's private CloudKit database. This source review does not replace the App Store Connect privacy questionnaire or Xcode's generated privacy report from the final archive.

## Final submission checks

Before App Store submission:

1. Generate the privacy report from the final signed archive in Xcode Organizer.
2. Confirm no added package or SDK introduces another privacy manifest, tracking domain, collected data type, or required-reason API.
3. Match the App Store Connect privacy questionnaire to the final binary and user-facing legal text.
4. Publish the included `iworkorder-privacy-policy.html` and use its public HTTPS location for the App Store privacy-policy URL.
5. Re-run `Scripts/run_xcode_ci.sh` after any dependency, storage, analytics, advertising, authentication, or networking change.

Official Apple references:

- https://developer.apple.com/documentation/bundleresources/privacy-manifest-files
- https://developer.apple.com/documentation/bundleresources/describing-use-of-required-reason-api
- https://developer.apple.com/documentation/technotes/tn3183-adding-required-reason-api-entries-to-your-privacy-manifest

## Phase 54 operational history assessment

Phase 54 adds a local maintenance event history used for migration, save, sync, backup, restore, and health-check troubleshooting. The history stores only fixed event categories, outcome states, durations, aggregate counts, schema/build numbers, and bounded error categories. It does not store work-order descriptions, tenant or building details, names, addresses, photos, signatures, filenames, audit text, or the app's internal device identifier.

The history remains inside the app container, is limited to 250 events and 30 days, and is deleted by Erase All Data. It leaves the device only when the user explicitly exports the privacy-safe maintenance report. This does not introduce developer collection or tracking, so the proposed App Store Connect answer remains "Data Not Collected" provided the final archive and network inspection confirm that no analytics or telemetry SDK has been added.

## Phase 55 field reliability assessment

Phase 55 adds one replaceable local lifecycle checkpoint, aggregate memory-pressure evidence, a local recovery-sync pause preference, and an explicitly exported checksum-verified support bundle. These records contain lifecycle state, dates, build/schema values, fixed technical categories, outcomes, durations, and aggregate counts only. They do not contain names, addresses, tenant or building details, work-order text, notes, audit text, attachment filenames, photos, signatures, or device identifiers.

No record is sent to the developer automatically. The support bundle leaves the app container only through an explicit user export or support-email action. The proposed App Store Connect answer remains “Data Not Collected” provided final archive inspection and network testing confirm that no third-party analytics, telemetry, advertising, or developer-operated collection endpoint has been added.
## Hotfix 25 legal and permission alignment

The September 16, 2026 legal refresh documents Apple geocoding for a user-entered address, private CloudKit sync, user-controlled support/export flows, retention/deletion behavior, and renewed acceptance after a material legal update. Source review found no camera capture session or camera photo/video recording. The app does use `AVCaptureDevice` to control the optional rear torch, so `NSCameraUsageDescription` is retained with a flashlight-only purpose string. Photo attachment selection continues through Apple `PhotosPicker`, which does not require broad Photo Library authorization. Hotfix25 adds a device-local first-use permission review for notification authorization and torch-only camera authorization; it does not add Contacts, Calendar, microphone, precise-location, or tracking authorization requests. The proposed App Store Connect answer remains “Data Not Collected,” subject to final signed-archive privacy-report and network verification.



## Hotfix 19 release-candidate privacy hardening

- The app uses SwiftUI `PhotosPicker` for user-selected work-order evidence. Apple documents that this picker grants access only to items the user chooses and does not require photo-library authorization. The unused `NSPhotoLibraryUsageDescription` entry was therefore removed from the public app `Info.plist`; no PhotoKit authorization API is used.
- `NSCameraUsageDescription` remains because the optional flashlight uses `AVCaptureDevice` camera hardware for the torch. Hotfix 20 now checks camera authorization and requests it only when the user explicitly tries to turn the flashlight on. The app does not start a photo/video capture session or record media.
- The app strongly blurs/desaturates operational content and places a frosted privacy shield over it whenever the scene is inactive or backgrounded, so work orders, tenant information, photos, signatures, and other operational content are not intentionally readable in Notification Center, Control Center, or task-switcher snapshots. When Reduce Transparency is enabled, both the cover and compact logo badge use opaque semantic surfaces.
- Public sync status uses the user-facing term “iCloud.” CloudKit remains an implementation detail in engineering documentation and legal disclosures where technical specificity is appropriate.
