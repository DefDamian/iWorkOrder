# iWorkOrder v56 Hotfix 4 — Ineffective @preconcurrency Warning

## Issue

Xcode 26 reported:

`@preconcurrency on conformance to UNUserNotificationCenterDelegate has no effect`

Because the project treats warnings as errors, this warning blocked the build.

## Root cause

`NotificationService` already satisfies the notification delegate requirements with `nonisolated` async methods. The additional `@preconcurrency` annotation on the protocol conformance was therefore unnecessary and produced an ineffective-attribute diagnostic.

## Correction

The conformance is now declared as:

```swift
@MainActor
final class NotificationService: NSObject, UNUserNotificationCenterDelegate
```

The delegate callbacks remain `nonisolated`, and any mutation of main-actor state continues to cross back through `MainActor.run`.

## Regression protection

The release verifier now requires the native conformance form and rejects any return of `@preconcurrency UNUserNotificationCenterDelegate`.
