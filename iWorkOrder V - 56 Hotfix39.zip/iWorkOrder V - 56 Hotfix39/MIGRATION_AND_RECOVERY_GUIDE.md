# iWorkOrder data migration and recovery guide

Phase 54 introduces an explicit local data schema and a non-destructive migration path.

## Current schema

- Current schema: `3`
- Oldest supported schema: `1`
- Snapshot field: `dataSchemaVersion`

A schema 1 snapshot is migrated through schema 2 by normalizing optional collections and legacy status-history storage. Schema 2 snapshots are then migrated to schema 3 by adding the ordered, user-managed category configuration. Existing work-order category values are preserved and user-entered work-order content is not rewritten.

## Migration transaction

Before a schema-changing migration, iWorkOrder:

1. Reads and decodes the existing snapshot.
2. Verifies that the stored schema is supported.
3. Creates a protected pre-migration recovery copy.
4. Applies the migration in memory.
5. Saves the migrated snapshot atomically.
6. Retains no more than five migration recovery copies.
7. Records only the structured migration outcome in the local operational history.

If the recovery copy cannot be created or the migrated snapshot cannot be saved, migration stops. The app does not continue into normal editing.

## Forward-schema protection

If an older app build encounters data created by a newer unsupported schema, the app enters Data Protection Mode. Saving, editing, synchronization, and restore activity remain blocked so the older build cannot overwrite newer data.

Do not delete the app in this state. Install the newer compatible build or contact support.

## Primary snapshot recovery

If the primary JSON snapshot is unreadable but the fallback snapshot is valid, iWorkOrder quarantines the unreadable primary file, loads the fallback, and rebuilds protected primary storage. The user receives a recovery notice.

## Required migration test matrix

Before increasing `AppDataSchema.currentVersion`:

- Decode every retained historical fixture.
- Verify migration is deterministic and idempotent.
- Verify work-order text, audit records, photos, signatures, tenants, assets, preferences, and revision IDs remain correct.
- Verify insufficient-storage failure leaves the original recovery copy intact.
- Verify interruption before commit leaves the old snapshot usable.
- Verify an unsupported future schema enters Data Protection Mode and never saves an empty snapshot.
- Verify CloudKit and portable backups carry the new schema field.
- Verify restore from the previous public version into the candidate version.
- Verify upgrade on both local-only and CloudKit-enabled devices.

## Recovery evidence

The Xcode qualification package must retain:

- Unit-test results
- Debug-only UI-test result for internal Maintenance & Recovery tooling
- Archive validation
- Migration harness output
- Source hash verification
- Signed IPA validation when signed mode is used
