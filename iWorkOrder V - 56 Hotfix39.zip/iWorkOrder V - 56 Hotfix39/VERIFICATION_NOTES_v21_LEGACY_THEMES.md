# iWorkOrder v21 Legacy Theme Pass

Changes included:
- Strengthened Settings > Themes so Design 2 and Design 3 are actual legacy-inspired UI skins instead of simple color swaps.
- Design 2 now uses the old command-center style: navy/blue hero cards, rounded glass panels, compact metric chips, and light app background.
- Design 3 now uses the old control-room/workflow style: blue-purple hero cards, rounded soft cards, blue accent controls, and light app background.
- Theme choice is still stored only in AppStorage using the existing selectedVisualTheme key.
- Relaunch prompt behavior remains in place.

Safety notes:
- No model types were changed.
- No persistence, iCloud, audit log, PDF export, onboarding completion, notification, or backup logic was changed.
- Changes are confined to SwiftUI visual presentation files: RootView.swift, Components.swift, WorkOrderViews.swift, and CalendarHubSettingsViews.swift.
