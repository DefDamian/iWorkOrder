# iWorkOrder V - 56 Hotfix29 Live Theme Switching

## Reported issue

Changing among Default Theme, Design 2, and Design 3 from Settings could leave parts of the visible SwiftUI hierarchy on the previous theme. The result could look like a mixed or glitching theme until navigation changed or the affected view was rebuilt.

## Root cause

The theme value was persisted in `UserDefaults`, but most theme-dependent views read it through the plain `AppTheme.selected` helper. SwiftUI does not treat an arbitrary `UserDefaults` read as a view dependency. Only a few shell views used `@AppStorage`, so a live change could invalidate the picker and parts of the shell while retained cards, navigation state, backgrounds, or an inactive tab remained stale.

Theme selection also performed two writes for one tap: the `@AppStorage` property was assigned and `AppTheme.selected` wrote the same `UserDefaults` key again. Design 2 additionally hides the Settings root navigation bar; while changing themes inside the nested Themes screen that visibility could interfere with the active navigation controls.

## Corrections

- Added direct `@AppStorage(AppTheme.storageKey)` observation to the main Work Order, Calendar, Hub, and Settings surfaces.
- Added direct theme observation to shared visual chrome including screen backgrounds, modern cards, section headers, metric tiles, settings rows, info rows, and themed Form/List backgrounds.
- Added explicit theme-parameter versions of shared `AppTheme` styling helpers so a render pass uses one resolved theme value instead of mixing independently-read defaults.
- Made `AppTheme.selected` writes idempotent.
- Removed the duplicate theme write from `ThemeSettingsView`.
- Theme selection now changes through one `applyTheme(_:)` function with animations disabled for the cross-layout switch, preventing interpolation between unrelated layouts.
- The Themes screen explicitly keeps its navigation bar visible and inline while a live switch occurs, including when Design 2 is selected.
- Added deterministic accessibility/UI-test identifiers and selected-state values for all three theme choices.
- Added Xcode UI automation that switches Default -> Design 2 -> Design 3 -> Default in-app without relaunching and verifies the Themes screen and navigation bar remain present while the tab-shell title updates.

## Scope intentionally unchanged

- Work-order model and revision schema
- Local persistence format
- Portable backup format
- iCloud/CloudKit container identity and sync semantics
- Notification behavior
- Legal version `2026.09.16.56`
- Existing user theme preference key `selectedVisualTheme`

## Portable verification

`Scripts/run_hotfix29_theme_switch_harness.py` validates the reactive theme dependencies, one-write selection path, non-animated switch, navigation-bar protection, and UI regression coverage.

The complete cross-platform verification must also pass after the final source hash manifest is regenerated.

## Native Apple test still required

The portable environment cannot render UIKit/SwiftUI navigation and tab bars on an actual iPhone/iPad. Final qualification should run the new `testThemeSwitchingStaysLiveAndNavigable()` UI test on Xcode/iOS and manually switch all three themes on at least one compact iPhone and one iPad configuration.

## Final portable verification result

After the theme corrections and test additions, `Scripts/verify_release.sh` completed successfully in the portable environment:

- Phase 56 release verification: **475 checks passed**
- Hotfix29 live-theme harness: **61 checks passed**
- All existing regression harnesses: **passed**
- App Store metadata validation: **passed**
- Swift parser validation for Release and Debug: **passed**
- Phase 56 cross-platform verification: **passed**

These portable checks verify source structure and executable non-UI logic. They do not substitute for running the new Xcode UI test on iOS.
