# iWorkOrder v56 Hotfix39 — iPadOS 26 Resizable-Scene Cleanup

## Change

- Removed `UIRequiresFullScreen` from `iWorkOrder/Info.plist`.
- Kept the iOS/iPadOS 26.0 minimum deployment target unchanged.
- Updated portable accessibility and release gates to require the deprecated key to be absent rather than present with a false value.
- Added a dedicated Hotfix39 audit covering launch-screen configuration, all iPad orientations, SwiftUI scene lifecycle, adaptive navigation/layout signals, and absence of fixed `UIScreen.main` sizing.
- Added the Hotfix39 audit to both portable release verification and native Xcode qualification.

## Reason

Starting in iPadOS 26, Apple deprecates `UIRequiresFullScreen` and recommends removing it for apps that support resizable scenes. Keeping the key, even as `false`, causes the Xcode warning seen in Hotfix38. Because iWorkOrder now has iOS/iPadOS 26.0 as its minimum and already supports the modern adaptive scene requirements, the compatibility key is unnecessary.

## Native verification still required

A macOS/Xcode 27 run must confirm the warning is gone and exercise dynamic iPad resizing/orientation behavior on Apple simulators or devices. Portable checks cannot replace that UI/runtime validation.

## Portable regression results

- Hotfix39 resizable-scene audit: 17/17 checks passed.
- Hotfix38 iOS 26 baseline audit: 40/40 checks passed.
- Hotfix37 Xcode 27 / Swift 6.4 audit: 48/48 checks passed.
- Consolidated executable behavior harness: 83/83 checks passed.
- Transactional, core-stability, public-release, public-beta, release-candidate, final-RC, theme, accessibility, reliability, maintenance, and submission harnesses passed.
- Master release verifier: 557 checks passed.
- Swift parser validation passed for Release and DEBUG configurations.
- Python and shell syntax validation passed.
- App Store metadata validation passed.
- Phase 56 evidence template validation passed with 22 native Apple/Xcode/device gates intentionally pending.

The portable checks found no production-code regression from removing `UIRequiresFullScreen`.
