# Phase 56 App Store submission handoff

## Automated content

`AppStoreConnect/` contains draft English metadata, review notes, TestFlight information, proposed privacy responses, screenshot instructions, and account-holder decision records.

```bash
python3 Scripts/validate_app_store_metadata.py
```

After approved screenshots are installed:

```bash
python3 Scripts/validate_app_store_metadata.py --require-screenshots
```

## Signed build

```bash
APPLE_TEAM_ID=YOUR_TEAM_ID \
PHASE56_MODE=signed \
./Scripts/phase56_xcode_qualification.sh
```

Review `Artifacts/Phase56/QUALIFICATION_STATUS.txt`, the archive, IPA, `.xcresult` bundles, analyzer output, code-signature evidence, signed entitlements, archive validation, IPA validation, and `EVIDENCE_INDEX.json`.

## Evidence record

Use `ReleaseEvidence/phase56_evidence.template.json`. Mark a gate `pass` only after its evidence exists and has been reviewed. The final validator rejects missing evidence and evidence paths outside the controlled qualification root.

```bash
python3 Scripts/validate_phase56_evidence.py \
  Artifacts/Phase56/phase56_evidence.json \
  --root . \
  --require-complete
```

## Account-holder decisions

The account holder must confirm seller identity, copyright, SKU, availability, price, tax category, review contacts, Digital Services Act status, age rating, export compliance, final privacy answers, accessibility declarations, and release controls.

## Hotfix 25 permission and legal package

Current in-app legal version: `2026.09.16.56`, effective September 16, 2026. Existing users who accepted an older revision see the Legal Terms Updated splash and cannot resume normal app access until they accept the current Privacy Policy, Terms & Conditions, and Data & Liability Disclaimer.

Before submission, publish all three legal copies together and confirm the App Store privacy questionnaire still matches the exact signed binary. The build retains `NSCameraUsageDescription` because the optional flashlight uses rear camera hardware only for the torch; photo attachments use the system PhotosPicker and the flashlight path does not capture media. Hotfix25 adds a device-local first-use permission review for notifications and torch-only camera authorization, including after a restore to a new install/device. Apple provides the Standard EULA unless a custom EULA is configured in App Store Connect.

## Website publication

Before submission, verify these public HTTPS pages:

- Marketing: `index.html`
- Support: `support.html`
- Privacy: `iworkorder-privacy-policy.html`
- Terms: `terms-of-service`
- Disclaimer: `Data-Liability-Disclaimer`

## TestFlight and submission

1. Upload only the validated build 56 IPA through an authorized Apple workflow.
2. Wait for processing and resolve every warning or invalid-binary status.
3. Complete internal TestFlight stabilization.
4. Use external testing only after required beta review.
5. Submit to App Review only after every required Phase 56 evidence gate passes.
