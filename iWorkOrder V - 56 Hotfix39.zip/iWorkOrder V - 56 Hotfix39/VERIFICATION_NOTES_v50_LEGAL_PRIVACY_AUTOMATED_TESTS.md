# Verification Notes v50: Legal, Privacy, and Automated Tests

Date: August 4, 2026

## Legal source of truth

- Added `iWorkOrder/LegalContent.swift` as the authoritative legal baseline.
- Removed network-loaded legal views and stale GitHub document URLs from application source.
- Added legal version `2026.08.04.50` and effective date August 4, 2026.
- Added matching publish-ready Privacy Policy, Terms & Conditions, and Data & Liability Disclaimer files at the package root.
- Added automated equality checks between bundled and public legal copies.
- Corrected obsolete claims that all app data is stored in iCloud or that audit records are immutable or permanent.

## Upgrade and onboarding behavior

- Added `legalAcceptedVersion` to the user profile using backward-compatible optional decoding.
- Kept onboarding completion separate from legal acceptance.
- Existing configured users remain configured but are blocked by the legal-update screen until they accept the current version.
- First-run users cannot complete setup without accepting the current legal version.
- Conflict merge imports a current legal acceptance without replacing the primary device's building or user profile.

## Signature hardening

- Blank drawings cannot be saved.
- A signer name is required.
- The signature stores signer name, capture date, and legal consent version.
- New work-order revisions clear inherited signature data.
- PDF exports display the signer and consent metadata.
- Legal text states that the app does not verify identity, authority, consent, enforceability, or admissibility.

## Privacy manifest audit

The manifest now declares only source-supported categories:

- User Defaults: `CA92.1`
- File Timestamp: `C617.1`
- Disk Space: `E174.1`

The prior System Boot Time declaration was removed because no corresponding source usage was found. The manifest declares no tracking and no developer-collected data. Final App Store privacy declarations must still be checked against the signed archive and all linked SDK manifests.

## Automated test and CI additions

- Added `iWorkOrderTests` to the Xcode project.
- Added the test target to the shared scheme.
- Added unit tests for legal-version gating, legacy decoding, legal text, signed-record locking, signature metadata, search, merge behavior, and backup attachment references.
- Added `Scripts/verify_release.py` for structured project, source, legal, privacy, and target validation.
- Added `Scripts/run_logic_harness.py` for executable platform-neutral behavior checks.
- Added `Scripts/run_xcode_ci.sh` to run static verification, simulator tests, and an unsigned Release archive on macOS.
- Added `.github/workflows/ios-ci.yml` for macOS CI.

## Verification completed in this environment

- All Swift source files passed parser validation individually.
- All application Swift files passed combined parser validation.
- Xcode project, shared scheme, property lists, entitlements, privacy manifest, and asset catalogs passed structural validation.
- The executable Phase 50 logic harness passed.
- Public legal copies matched the bundled source exactly.
- Required-reason API declarations matched source evidence.
- No duplicate Xcode object identifiers were detected.
- The source SHA-256 manifest and final ZIP were validated after clean extraction.

## Verification requiring macOS and owner credentials

- Full iOS SDK compile
- Xcode unit-test execution on an iPhone simulator
- Release archive with the owner's signing configuration
- Xcode Organizer privacy report
- Physical-device upgrade, biometric, notification, signature, backup, deep-link, and CloudKit tests
- TestFlight and App Store review
