# iWorkOrder v56 Hotfix 30 — Launch Continuity

## Problem corrected

The startup experience used three visually different states in sequence: the native iOS launch screen displayed a white transparent logo on the default light background, the inactive-scene privacy shield could also use a light system background, and the SwiftUI splash then changed to a dark gradient with a smaller logo and an extra title. On a light-mode device this produced a low-contrast “ghost” logo followed by an obvious dark flash before the app opened.

## Changes

- Added `LaunchBackground`, an adaptive asset color with coordinated light and dark appearances.
- Rebuilt `LaunchLogo` as adaptive light/dark image variants using the existing production iWorkOrder artwork.
- Set `UILaunchScreen.UIColorName` to `LaunchBackground` while retaining `LaunchLogo` as the native launch image.
- Matched the launch image intrinsic size to the SwiftUI splash at 170 points for 1x, 2x, and 3x assets.
- Made `SplashScreenView` use the exact same `LaunchBackground` and `LaunchLogo` assets as the native screen.
- Removed the second-stage gradient and splash title so there is no visual jump between native launch and SwiftUI launch state.
- Reused `SplashScreenView` for the inactive/background privacy shield so scene activation cannot introduce a white flash between launch stages.
- Reduced the artificial splash hold from 850 ms to 320 ms with a 0.18-second fade. Reduce Motion uses a short nonanimated path.
- Legal version, work-order data, backup format, iCloud identity, and theme selection are unchanged.

## Automated verification

`Scripts/run_hotfix30_launch_continuity_harness.py` verifies the launch plist, adaptive color and image assets, PNG scale dimensions, removal of obsolete low-contrast launch artwork, shared native/SwiftUI styling, privacy-shield reuse, shorter timing, and Reduce Motion behavior.

The harness is included in `Scripts/verify_release.sh` and in the Phase 56 Xcode qualification evidence path.

## Native Apple validation still required

The actual iOS launch-screen handoff is rendered by the operating system before normal app UI automation can inspect it. A physical-device or simulator launch should therefore still be checked in both iOS Light and Dark appearances, including a cold launch from the Home Screen and a launch from another app such as Messages.

## Portable verification result

The final source pass completed successfully with 484 release-verification checks, all 36 Hotfix30 launch-continuity checks, the complete existing Hotfix regression chain, App Store metadata validation, Phase 56 evidence-template validation, and Swift parser validation for Release and Debug source paths. The remaining launch-handoff check is native iOS rendering on Xcode/simulator or physical hardware.

## Hotfix31 follow-up

Hotfix31 intentionally replaces the Hotfix30 full-splash inactive-scene privacy cover with a dedicated frosted privacy shield. The Hotfix30 native launch assets, matched startup splash, and shortened startup timing remain unchanged.
