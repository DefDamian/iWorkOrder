# CloudKit Production Setup for iWorkOrder v48

## Container

Use this existing container in the app target's Signing & Capabilities settings:

`iCloud.com.damiancedeno.SedgwickWorkOrders`

The target must have:

- iCloud capability enabled
- CloudKit selected
- The container above checked
- `iWorkOrder/iWorkOrder.entitlements` assigned to the target
- A valid Apple Developer team and provisioning profile

## Database design

The app uses the signed-in user's private CloudKit database and automatically creates a custom record zone named:

`iWorkOrderZone`

The zone contains one current snapshot record and zero or more attachment records.

### Record type: IWorkOrderSnapshot

Fields created by the development build:

- `payload`: Asset
- `savedAt`: Date/Time
- `schemaVersion`: Int64
- `deviceID`: String
- `saveRevision`: Int64

The `payload` asset contains the complete versioned JSON snapshot. Attachment references are derived from that payload instead of being duplicated in a large record field.

### Record type: IWorkOrderAttachment

Fields created by the development build:

- `file`: Asset
- `filename`: String
- `kind`: String
- `sha256`: String
- `byteCount`: Int64
- `modifiedAt`: Date/Time

`kind` is either `image` or `signature`.

## Development initialization

1. In Xcode, select the correct Apple Developer team.
2. Confirm the iCloud container is available to the bundle identifier.
3. Run the app in a development-signed simulator or device signed into iCloud.
4. Finish onboarding with iCloud Sync enabled.
5. Create a work order containing a photo and signature.
6. Open Settings > Cloud and run Sync Now.
7. In CloudKit Console, confirm the two record types and the private database records exist in the development environment.

## Production deployment

Before TestFlight or App Store release:

1. Open CloudKit Console for `iCloud.com.damiancedeno.SedgwickWorkOrders`.
2. Review the development schema and record types listed above.
3. Deploy the schema from Development to Production.
4. Archive a Release build using the intended distribution team and profile.
5. Install through TestFlight and test with a separate Apple ID.

CloudKit production schema deployment is not performed by the source package or by a normal app upload. It must be completed in CloudKit Console.

## Required device test

Use two devices signed into the same iCloud account:

1. Create a work order with before and after photos and a signature on device A.
2. Run Sync Now and confirm a successful timestamp.
3. Install or launch the app on device B and run Re-sync from iCloud.
4. Confirm work-order revisions, audit history, photos, and the signature all appear.
5. Edit the work order independently on both devices, then run Sync Now on each and verify the merged revision history.
6. Disable the network and confirm local saves continue while CloudKit shows an offline state.
7. Restore the network and confirm sync resumes.
8. Use Erase All Data only with disposable test data and confirm the custom zone is removed.

## Phase 48 backup replacement test

A Replace Current Data restore may delete and recreate `iWorkOrderZone` before uploading the verified backup. Test this with disposable development data while offline and online. Confirm the pending replacement survives relaunch, ordinary Re-sync from iCloud remains blocked, and the replacement flag clears only after the restored snapshot and all attachments appear in CloudKit.

## Release warning

Do not ship the production build until the production schema is deployed. A development container can appear functional during local testing while a TestFlight or App Store build fails because the production record types do not yet exist.
