# iWork v7 Verification Notes

Implemented from the uploaded legal and technical blueprint:

- Role-based onboarding: Superintendent vs Handyman.
- Data storage choice: iCloud Sync or Local Only.
- Apple Maps address verification stays required before onboarding completion.
- Permission priming language for camera/photos and notifications.
- Initial building quick start with CSV-style unit import.
- Categories and priority levels on work orders.
- Entry permitted toggle on work orders.
- Asset tag / QR value field plus asset manager in Hub.
- Unit / tenant directory in Hub.
- Before / after photos through PhotosPicker.
- Image compression to 1080px JPEG before local/iCloud persistence.
- Audit log on every work order for created, status, revision, photos, signature, trash, and recovery events.
- Search and filters for unit, handyman, emergency, text, and category.
- PDF export through the iOS share sheet for Files, Google Drive, and OneDrive.
- Notification userInfo deep-link handling to open the selected work order.
- Data privacy purge setting for 3-year or 7-year retention redaction.
- Legal documents appended and available under Legal & About.
- ESIGN language remains above the signature pad.
- Swipe delete preserved on Work Order rows.
- Reset onboarding and Erase All Data flows preserved in Trash.

Static checks performed:

- Verified Swift file brace balance.
- Checked for duplicate global type definitions.
- Removed placeholder/TODO markers from app Swift files.
- Repacked project as a full Xcode project.

Notes:

- Real iCloud sync requires the developer account capability to be enabled in Xcode for this bundle identifier.
- Google Drive and OneDrive export use the standard iOS share sheet. The apps must be installed on the device for those destinations to appear.
- Voice-to-text uses the iOS keyboard dictation microphone in notes fields to avoid adding a fragile speech entitlement requirement.
