# v45 Theme 2 Navigation Cleanup

Scope: Theme 2 only.

Changes made:
- Calendar: hidden the large navigation title for legacy themes so Theme 2 no longer shows duplicate Calendar text.
- Dashboard: hidden the large navigation title so the Hub label is removed and the dashboard content shifts up.
- Settings: hidden the large Settings navigation title only for Theme 2 so the settings hero shifts up without changing Theme 3 settings behavior.

Verification:
- Searched all modified navigation title logic in CalendarHubSettingsViews.swift.
- No model, persistence, iCloud, PDF, audit log, onboarding, or work order data logic was changed.
