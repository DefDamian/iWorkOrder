# Phase 56 signing handoff

The distributed project contains no Apple Team ID, certificate, private key, password, provisioning profile, or App Store Connect credential.

## Signed qualification

1. Install stable Xcode 27 build `27A266a` on macOS Tahoe 26.6 or later. This supplies the iOS 27 SDK and Swift 6.4 compiler.
2. Sign in to the authorized Apple Developer account.
3. Confirm the App ID `com.damiancedeno.SedgwickWorkOrders` supports iCloud and CloudKit.
4. Confirm `iCloud.com.damiancedeno.SedgwickWorkOrders` is assigned to the App ID.
5. Run:

```bash
APPLE_TEAM_ID=YOUR_TEAM_ID \
PHASE56_MODE=signed \
./Scripts/phase56_xcode_qualification.sh
```

The runner first verifies the exact stable Xcode 27 build and iOS 27 SDK, then performs simulator tests, five repeated unit-test iterations, static analysis, signed archive creation, archive validation, entitlement capture, code-signature verification, App Store Connect IPA export, IPA validation, and evidence indexing.

## Connected devices

Optional automated unit-test evidence:

```bash
APPLE_TEAM_ID=YOUR_TEAM_ID \
PHASE56_MODE=signed \
PHASE56_IPHONE_DEVICE_ID=IPHONE_UDID \
PHASE56_IPAD_DEVICE_ID=IPAD_UDID \
./Scripts/phase56_xcode_qualification.sh
```

These automated tests do not replace the manual device matrix.

## Security

Use Xcode-managed signing locally or protected CI secrets. Do not commit credentials or copy them into the ZIP package.
