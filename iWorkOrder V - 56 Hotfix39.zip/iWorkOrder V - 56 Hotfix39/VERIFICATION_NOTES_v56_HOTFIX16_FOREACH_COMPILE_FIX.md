# iWorkOrder v56 Hotfix 16 — Swift 6 `forEach` Compile Fix

## Defect reproduced

Xcode reported a compile error in `WorkOrderViews.swift` because `cleanupUncommittedImages()` passed `ImageStorageService.delete` directly to `Array.forEach`. The delete function returns `Bool`, while Swift `forEach` requires a callback returning `Void`.

## Fix

The cleanup now iterates explicitly:

```swift
for image in entry.images {
    _ = ImageStorageService.delete(image)
}
entry.images.removeAll()
```

The deletion result remains intentionally observed/discarded because this view-disappearance cleanup is best-effort; startup orphan cleanup remains the recovery path for any filesystem deletion that cannot complete immediately.

## Regression protection

- Core stability harness rejects the original invalid direct method reference.
- Core stability harness scans app source for direct qualified function references passed to `forEach`.
- Release verification rejects the known broken expression.
- All Swift source files are reparsed after the change.

## Legal behavior

Legal revision remains `2026.09.13.56`. This compile-only correction does not create a new legal revision or force users who already accepted that exact revision to accept it again.
