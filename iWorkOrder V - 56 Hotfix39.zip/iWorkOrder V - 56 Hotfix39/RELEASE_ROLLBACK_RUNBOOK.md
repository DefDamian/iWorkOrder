# iWorkOrder release rollback runbook

This runbook is for a production issue discovered after TestFlight or App Store release.

## Immediate triage

1. Stop further release promotion.
2. Preserve the failing build, Xcode archive, dSYM, privacy report, test results, and CloudKit evidence.
3. Ask affected users to avoid deleting the app or erasing data.
4. Obtain the privacy-safe diagnostics and maintenance report only through a deliberate user export.
5. Determine whether the issue affects data integrity, CloudKit, backup restore, authentication, notifications, or presentation only.

## TestFlight

- Remove or expire the affected beta build when appropriate.
- Stop adding testers to the affected build.
- Upload a corrected build with a higher build number.
- Re-run internal stabilization before external testing resumes.

## App Store phased release

For an update using phased release:

- Pause the phased release while investigating.
- If the build is safe after correction or mitigation, resume the release.
- If the build must be replaced, make the affected version unavailable when appropriate and submit a new version. Reinstating an unavailable version makes it available broadly rather than restarting the prior percentage progression.

Phased release is for version updates and is not available for an app's first public version.

## Data-schema rule

Never distribute an older binary that cannot read the newest production schema. Phase 54 blocks writes when it sees a future schema, but release management must still preserve compatibility.

A rollback candidate must satisfy one of these conditions:

- It uses the same schema and is fully read/write compatible.
- It contains an explicit backward migration that has been tested against production-shaped fixtures.
- It is intentionally read-only and cannot overwrite newer data.

## CloudKit rule

Do not delete, rename, or destructively alter production CloudKit record types or fields during emergency rollback. Prefer additive schema changes and corrected clients. Confirm production schema deployment state before promoting the replacement build.

## Replacement build gates

- Reproduce the defect.
- Add a regression test.
- Run `Scripts/verify_release.sh`.
- Run Phase 54 Xcode qualification on iPhone and iPad simulators.
- Validate a signed archive and IPA.
- Test local-only upgrade, CloudKit upgrade, backup export, backup restore, app lock, notifications, and low-storage behavior.
- Confirm the public legal and privacy documents match the bundled version.
- Record the replacement build as last known good only after health checks pass.

## User communication

Use factual wording. State the affected version, symptoms, whether data is at risk, the safe action users should take, and the corrected build number. Do not instruct users to delete the app unless a verified backup and restore procedure has been tested for the exact incident.

## Phase 55 issue-containment procedure

When an incident may involve CloudKit propagation, do not expose internal recovery toggles to public users. The **Pause Cloud Sync for Recovery** control is compiled only into internal Debug builds. For public Release builds, first have the user disable iCloud Sync through the normal Cloud settings when appropriate, preserve a verified backup, and collect a privacy-safe support package before additional troubleshooting.

Ask the user to export a verified `.iworkordersupport` bundle. Validate its SHA-256 checksum before review. Treat a possible interrupted-session event as evidence of an incomplete prior lifecycle checkpoint, not proof of a crash.

Do not ask users to disable the pause until the data state, pending cloud transaction, compatible app version, and rollback decision are understood. Resume sync only after a verified safety backup exists when operational data is at risk.
