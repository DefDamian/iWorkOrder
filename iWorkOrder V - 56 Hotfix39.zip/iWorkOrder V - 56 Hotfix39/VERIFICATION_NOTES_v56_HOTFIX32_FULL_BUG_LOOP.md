# iWorkOrder v56 — Hotfix 32 Full Bug Loop

Hotfix32 is a full portable regression and independent source-audit pass over Hotfix31. The loop starts from a clean extraction, runs the entire existing verification chain, audits code paths not covered by those harnesses, fixes every actionable defect found, restarts the complete verification chain after each fix set, and stops only after a subsequent independent audit finds no additional actionable portable defect.

## Defects found and corrected

1. **Reduce Transparency privacy badge remained translucent.** Hotfix31 correctly made the full-screen privacy fallback opaque, but the compact logo badge still unconditionally used `thinMaterial`. With Reduce Transparency enabled, Apple expects window/background surfaces to be opaque. Hotfix32 makes the badge use an opaque semantic system background and a non-translucent border treatment while preserving the frosted material only when transparency is allowed.
2. **Residual hidden theme dependencies remained in retained work-order leaf views.** Several leaf views still read `AppTheme.selected` indirectly through static computed styling properties instead of observing the persisted theme themselves. During live theme switching, retained SwiftUI identity could therefore keep stale geometry or text styling until another state change invalidated the leaf. `PriorityQueueCard`, `StatusFilterChip`, `WorkOrderDateLabel`, and `WorkOrderRow` now observe the theme with `@AppStorage` and render from explicit theme values.
3. **Design 2 hero could transiently read the newly selected theme while leaving the old layout.** The Design 2 orders hero used the global selected-theme gradient even though the view itself represents Design 2. It now renders the Design 2 gradient explicitly, preventing cross-theme color leakage during layout replacement.
4. **Setup/legal surfaces still contained hidden selected-theme styling reads.** Recovery, onboarding, permission review, legal-update, and legal-document screens now observe the persisted theme explicitly and use `horizontalPadding(for:)`, eliminating the remaining selected-theme style reads that bypass SwiftUI dependency tracking.
5. **Evidence-photo delete controls ignored Reduce Transparency.** The trash button added in Hotfix27 still used an unconditional `thinMaterial` circle. It now uses the same opaque semantic fallback when Reduce Transparency is enabled.
6. **Current release documentation still led with Hotfix30/older privacy wording.** Current-package notes are moved to the top and privacy validation wording is aligned with the frosted normal mode plus opaque Reduce Transparency fallback.
7. **Current summary files omitted Hotfix31 from the visible release sequence.** The package had the Hotfix31 verification note and code, but `README.md` and `ALL_FIXES_INCLUDED.md` jumped directly from Hotfix32 to Hotfix30. The current summaries now restore the Hotfix31 frosted-privacy entry so the release history matches the shipped source.

## Compatibility

- Legal version remains `2026.09.16.56`.
- Marketing version remains `1.0` and build remains `56`.
- Work-order schema and backup format are unchanged.
- CloudKit container and bundle identifiers are unchanged.
- Existing user data, attachment filenames, work-order status raw values, and theme storage key are unchanged.

## Verification scope

The Hotfix32 harness specifically guards the Reduce Transparency badge fallback, direct reactive theme observation in retained leaf views, Design 2 transition isolation, elimination of hidden selected-theme style reads, and integration into both cross-platform and Xcode qualification runners.

Native Xcode/iOS execution is still a separate qualification layer and cannot be replaced by portable source analysis.
