# iWork v9 Verification Notes

This version fixes the v8 Xcode build failure reported on `WorkOrderViews.swift`.

## Build-risk fix
- `WorkOrder` now conforms to `Hashable`.
- Supporting model types used inside `WorkOrder` also conform to `Hashable`.
- This clears the SwiftUI `navigationDestination(item:destination:)` requirement shown in the screenshot.

## Static checks run before packaging
- Swift parser check was run against every `.swift` source file.
- No syntax errors were returned by the parser.
- Project files were preserved from v8.

## Preserved features
- Onboarding persistence with local and iCloud key-value snapshot support.
- Apple Maps address verification and formatting.
- Notification permission prompt and deep-link handling.
- Face ID / passcode app lock prompt.
- Work orders, quick add, full add, reminders, photos, notes, signatures.
- Swipe-to-delete work orders.
- Hub metric drill-down views.
- Hub export actions.
- Legal pages with appended legal framework language.
- Role pathing, priority queue, categories, filters, audit log, image compression, asset records, directory, and retention purge.
