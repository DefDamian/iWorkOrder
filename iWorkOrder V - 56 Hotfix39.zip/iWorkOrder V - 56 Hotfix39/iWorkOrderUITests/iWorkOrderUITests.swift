import XCTest

final class iWorkOrderUITests: XCTestCase {
    override func setUpWithError() throws {
        continueAfterFailure = false
    }

    @MainActor
    func testFirstLaunchOffersBackupRecoveryBeforeOnboarding() {
        let app = launch(arguments: ["-ui-testing", "-ui-testing-backup-recovery"])

        XCTAssertTrue(app.otherElements["screen.backupRecovery"].waitForExistence(timeout: 5))
        XCTAssertFalse(app.otherElements["screen.onboarding"].exists)
        XCTAssertTrue(app.buttons["recovery.restoreFile"].exists)
        XCTAssertTrue(app.buttons["recovery.restoreICloud"].exists)

        let startNew = app.buttons["recovery.startNew"]
        XCTAssertTrue(startNew.exists)
        startNew.tap()

        XCTAssertTrue(app.otherElements["screen.onboarding"].waitForExistence(timeout: 5))
        XCTAssertFalse(app.otherElements["screen.backupRecovery"].exists)
    }

    @MainActor
    func testFirstUsePermissionReviewAppearsBeforeMainApp() {
        let app = launch(arguments: ["-ui-testing", "-ui-testing-permission-setup"])

        XCTAssertTrue(app.otherElements["screen.permissionSetup"].waitForExistence(timeout: 5))
        XCTAssertFalse(app.otherElements["screen.workOrders"].exists)
        XCTAssertTrue(app.buttons["permissions.requestAll"].exists)
        XCTAssertTrue(app.staticTexts["Notifications"].exists)
        XCTAssertTrue(app.staticTexts["Camera Hardware"].exists)
        XCTAssertTrue(app.staticTexts["Photos"].exists)
        XCTAssertTrue(app.staticTexts["Location"].exists)
    }

    @MainActor
    func testOnboardingFieldsRemainAccessible() throws {
        let app = launch(arguments: ["-ui-testing", "-ui-testing-onboarding"])

        XCTAssertTrue(app.otherElements["screen.onboarding"].waitForExistence(timeout: 5))
        XCTAssertTrue(app.textFields["Your name"].exists)
        XCTAssertTrue(app.textFields["Property Manager Company Name"].exists)
        XCTAssertTrue(app.textFields["Building address"].exists)

        try app.performAccessibilityAudit { issue in
            issue.auditType == .contrast
        }
    }


    @MainActor
    func testOnboardingLegalAgreementAcceptsAndDismisses() {
        let app = launch(arguments: ["-ui-testing", "-ui-testing-onboarding"])

        XCTAssertTrue(app.otherElements["screen.onboarding"].waitForExistence(timeout: 5))
        let review = app.buttons["Review and Accept"]
        XCTAssertTrue(review.waitForExistence(timeout: 5))
        review.tap()

        let agree = app.buttons["legal.accept"]
        XCTAssertTrue(agree.waitForExistence(timeout: 5))
        XCTAssertTrue(agree.isEnabled)
        agree.tap()

        XCTAssertTrue(app.buttons["Agreement Accepted"].waitForExistence(timeout: 5))
        XCTAssertFalse(app.buttons["legal.accept"].exists)
    }

    @MainActor
    func testUpdatedLegalVersionShowsSplashAndRequiresReacceptance() {
        let app = launch(arguments: ["-ui-testing", "-ui-testing-seeded", "-ui-testing-legal-update"])

        XCTAssertTrue(app.otherElements["screen.legalUpdate"].waitForExistence(timeout: 5))
        XCTAssertFalse(app.otherElements["screen.workOrders"].exists)

        let review = app.buttons["legal.update.review"]
        XCTAssertTrue(review.waitForExistence(timeout: 5))
        review.tap()

        let decline = app.buttons["legal.decline"]
        XCTAssertTrue(decline.waitForExistence(timeout: 5))
        decline.tap()
        XCTAssertTrue(app.staticTexts["Normal app access remains disabled until the current legal version is accepted."].waitForExistence(timeout: 5))
        XCTAssertFalse(app.otherElements["screen.workOrders"].exists)

        let agree = app.buttons["legal.accept"]
        XCTAssertTrue(agree.exists)
        XCTAssertTrue(agree.isEnabled)
        agree.tap()

        XCTAssertTrue(app.otherElements["screen.workOrders"].waitForExistence(timeout: 5))
        XCTAssertFalse(app.otherElements["screen.legalUpdate"].exists)
    }

    @MainActor
    func testSeededWorkOrderCanBeOpened() throws {
        let app = launch(arguments: ["-ui-testing", "-ui-testing-seeded"])

        XCTAssertTrue(app.otherElements["screen.workOrders"].waitForExistence(timeout: 5))
        try app.performAccessibilityAudit { issue in
            issue.auditType == .contrast
        }
        let seededOrder = app.staticTexts["Leaking kitchen faucet"]
        XCTAssertTrue(seededOrder.waitForExistence(timeout: 5))
        seededOrder.tap()
        XCTAssertTrue(app.navigationBars["Work Order"].waitForExistence(timeout: 5))
    }

    @MainActor
    func testSignatureDrawingEnablesCompletionButtons() {
        let app = launch(arguments: ["-ui-testing", "-ui-testing-seeded"])

        let seededOrder = app.staticTexts["Leaking kitchen faucet"]
        XCTAssertTrue(seededOrder.waitForExistence(timeout: 5))
        seededOrder.tap()
        XCTAssertTrue(app.navigationBars["Work Order"].waitForExistence(timeout: 5))

        let statusPicker = app.descendants(matching: .any)["workOrder.status"]
        XCTAssertTrue(statusPicker.waitForExistence(timeout: 5))
        statusPicker.tap()
        let completed = app.buttons["Completed"]
        XCTAssertTrue(completed.waitForExistence(timeout: 5))
        completed.tap()

        let signAndSave = app.buttons["workOrder.signAndSave"]
        XCTAssertTrue(signAndSave.waitForExistence(timeout: 5))
        signAndSave.tap()

        let canvas = app.otherElements["signature.canvas"]
        XCTAssertTrue(canvas.waitForExistence(timeout: 5))
        let start = canvas.coordinate(withNormalizedOffset: CGVector(dx: 0.2, dy: 0.5))
        let end = canvas.coordinate(withNormalizedOffset: CGVector(dx: 0.8, dy: 0.5))
        start.press(forDuration: 0.1, thenDragTo: end)

        XCTAssertTrue(app.buttons["signature.clear"].isEnabled)
        let saveSignature = app.buttons["signature.save"]
        XCTAssertTrue(saveSignature.isEnabled)
        saveSignature.tap()

        XCTAssertTrue(app.buttons["Making Changes"].waitForExistence(timeout: 5))
        XCTAssertFalse(app.buttons["signature.save"].exists)
    }

    @MainActor
    func testQuickAddCreatesAWorkOrder() {
        let app = launch(arguments: ["-ui-testing", "-ui-testing-seeded"])

        let quickAdd = app.buttons["workOrders.quickAdd"]
        XCTAssertTrue(quickAdd.waitForExistence(timeout: 5))
        quickAdd.tap()

        let area = app.textFields["quickAdd.area"]
        XCTAssertTrue(area.waitForExistence(timeout: 5))
        area.tap()
        area.typeText("12B")

        let description = app.textFields["quickAdd.description"]
        description.tap()
        description.typeText("Bathroom sink is dripping")

        app.buttons["quickAdd.save"].tap()
        XCTAssertTrue(app.staticTexts["Bathroom sink is dripping"].waitForExistence(timeout: 5))
    }

    @MainActor
    func testRegularWidthSidebarNavigation() throws {
        let app = launch(arguments: ["-ui-testing", "-ui-testing-seeded"])

        let settings = app.buttons["main.tab.settings"]
        guard settings.waitForExistence(timeout: 3) else {
            throw XCTSkip("Regular-width sidebar is not present on this destination")
        }
        settings.tap()
        XCTAssertTrue(app.otherElements["screen.settings"].waitForExistence(timeout: 5))
    }


    @MainActor
    func testSupportDiagnosticsCanBeOpened() throws {
        let app = launch(arguments: ["-ui-testing", "-ui-testing-seeded"])

        let settings = app.buttons["main.tab.settings"]
        XCTAssertTrue(settings.waitForExistence(timeout: 5))
        settings.tap()
        XCTAssertTrue(app.otherElements["screen.settings"].waitForExistence(timeout: 5))

        let support = app.staticTexts["Support"]
        XCTAssertTrue(support.waitForExistence(timeout: 5))
        support.tap()

        XCTAssertTrue(app.otherElements["screen.support"].waitForExistence(timeout: 5))
        XCTAssertTrue(app.buttons["support.exportPackage"].exists)
        XCTAssertTrue(app.buttons["support.email"].exists)
    }

    @MainActor
    func testMaintenanceRecoveryCanRunHealthCheck() {
        let app = launch(arguments: ["-ui-testing", "-ui-testing-seeded"])

        let settings = app.buttons["main.tab.settings"]
        XCTAssertTrue(settings.waitForExistence(timeout: 5))
        settings.tap()
        XCTAssertTrue(app.otherElements["screen.settings"].waitForExistence(timeout: 5))

        let maintenance = app.staticTexts["Maintenance & Recovery"]
        XCTAssertTrue(maintenance.waitForExistence(timeout: 5))
        maintenance.tap()

        XCTAssertTrue(app.otherElements["screen.maintenanceRecovery"].waitForExistence(timeout: 5))
        let check = app.buttons["maintenance.runHealthCheck"]
        XCTAssertTrue(check.waitForExistence(timeout: 5))
        check.tap()
        XCTAssertTrue(app.staticTexts["Health check passed. Review any warnings shown above."].waitForExistence(timeout: 5))
        XCTAssertTrue(app.switches["maintenance.cloudRecoveryPause"].exists)
    }



    @MainActor
    func testRecoveryCloudPauseCanBeEnabledAndDisabled() {
        let app = launch(arguments: ["-ui-testing", "-ui-testing-seeded"])

        let settings = app.buttons["main.tab.settings"]
        XCTAssertTrue(settings.waitForExistence(timeout: 5))
        settings.tap()
        XCTAssertTrue(app.otherElements["screen.settings"].waitForExistence(timeout: 5))

        let maintenance = app.staticTexts["Maintenance & Recovery"]
        XCTAssertTrue(maintenance.waitForExistence(timeout: 5))
        maintenance.tap()

        let pause = app.switches["maintenance.cloudRecoveryPause"]
        XCTAssertTrue(pause.waitForExistence(timeout: 5))
        XCTAssertEqual(pause.value as? String, "0")
        pause.tap()
        XCTAssertEqual(pause.value as? String, "1")
        pause.tap()
        XCTAssertEqual(pause.value as? String, "0")
    }

    @MainActor
    func testCategoryManagerAddsAndDeletesCategory() {
        let app = launch(arguments: ["-ui-testing", "-ui-testing-seeded"])

        let settings = app.buttons["main.tab.settings"]
        XCTAssertTrue(settings.waitForExistence(timeout: 5))
        settings.tap()
        XCTAssertTrue(app.otherElements["screen.settings"].waitForExistence(timeout: 5))

        let categoryManager = app.staticTexts["Category Manager"]
        XCTAssertTrue(categoryManager.waitForExistence(timeout: 5))
        categoryManager.tap()
        XCTAssertTrue(app.navigationBars["Categories"].waitForExistence(timeout: 5))

        let addCategory = app.buttons["category.add"]
        XCTAssertTrue(addCategory.waitForExistence(timeout: 5))
        addCategory.tap()

        let alert = app.alerts["Add Category"]
        XCTAssertTrue(alert.waitForExistence(timeout: 5))
        let nameField = alert.textFields["Category name"]
        XCTAssertTrue(nameField.exists)
        nameField.tap()
        nameField.typeText("Elevators")
        alert.buttons["Add"].tap()

        let addedCategory = app.descendants(matching: .any)["category.row.Elevators"]
        XCTAssertTrue(addedCategory.waitForExistence(timeout: 5))
        addedCategory.swipeLeft()

        let swipeDelete = app.buttons["Delete"].firstMatch
        XCTAssertTrue(swipeDelete.waitForExistence(timeout: 5))
        swipeDelete.tap()

        let confirmDelete = app.buttons["Delete"].firstMatch
        XCTAssertTrue(confirmDelete.waitForExistence(timeout: 5))
        confirmDelete.tap()
        XCTAssertFalse(app.descendants(matching: .any)["category.row.Elevators"].waitForExistence(timeout: 1))
    }

    @MainActor
    func testThemeSwitchingStaysLiveAndNavigable() {
        let app = launch(arguments: ["-ui-testing", "-ui-testing-seeded"])

        let settings = app.buttons["main.tab.settings"]
        XCTAssertTrue(settings.waitForExistence(timeout: 5))
        settings.tap()
        XCTAssertTrue(app.otherElements["screen.settings"].waitForExistence(timeout: 5))

        let themes = app.staticTexts["Themes"]
        XCTAssertTrue(themes.waitForExistence(timeout: 5))
        themes.tap()
        XCTAssertTrue(app.otherElements["screen.themes"].waitForExistence(timeout: 5))
        XCTAssertTrue(app.navigationBars["Themes"].waitForExistence(timeout: 5))

        let design2 = app.buttons["theme.design2"]
        XCTAssertTrue(design2.waitForExistence(timeout: 5))
        design2.tap()
        XCTAssertEqual(design2.value as? String, "Selected")
        XCTAssertTrue(app.otherElements["screen.themes"].exists)
        XCTAssertTrue(app.navigationBars["Themes"].exists)
        XCTAssertTrue(app.buttons["main.tab.hub"].label.contains("Dashboard"))

        let design3 = app.buttons["theme.design3"]
        XCTAssertTrue(design3.waitForExistence(timeout: 5))
        design3.tap()
        XCTAssertEqual(design3.value as? String, "Selected")
        XCTAssertTrue(app.otherElements["screen.themes"].exists)
        XCTAssertTrue(app.navigationBars["Themes"].exists)
        XCTAssertTrue(app.buttons["main.tab.hub"].label.contains("Field Deck"))

        let defaultTheme = app.buttons["theme.defaultTheme"]
        XCTAssertTrue(defaultTheme.waitForExistence(timeout: 5))
        defaultTheme.tap()
        XCTAssertEqual(defaultTheme.value as? String, "Selected")
        XCTAssertTrue(app.otherElements["screen.themes"].exists)
        XCTAssertTrue(app.navigationBars["Themes"].exists)
        XCTAssertTrue(app.buttons["main.tab.hub"].label.contains("Hub"))
    }


    @MainActor
    func testTheme3FieldDeckSurfacesAreDistinct() {
        let app = launch(arguments: ["-ui-testing", "-ui-testing-seeded"])

        let settings = app.buttons["main.tab.settings"]
        XCTAssertTrue(settings.waitForExistence(timeout: 5))
        settings.tap()
        XCTAssertTrue(app.otherElements["screen.settings"].waitForExistence(timeout: 5))

        let themes = app.staticTexts["Themes"]
        XCTAssertTrue(themes.waitForExistence(timeout: 5))
        themes.tap()
        XCTAssertTrue(app.otherElements["screen.themes"].waitForExistence(timeout: 5))

        let design3 = app.buttons["theme.design3"]
        XCTAssertTrue(design3.waitForExistence(timeout: 5))
        design3.tap()
        XCTAssertEqual(design3.value as? String, "Selected")
        XCTAssertTrue(app.buttons["main.tab.hub"].label.contains("Field Deck"))

        let themesBar = app.navigationBars["Themes"]
        XCTAssertTrue(themesBar.exists)
        let backButton = themesBar.buttons.firstMatch
        XCTAssertTrue(backButton.exists)
        backButton.tap()
        XCTAssertTrue(app.descendants(matching: .any)["theme.design3.settings"].waitForExistence(timeout: 5))

        let workOrders = app.buttons["main.tab.workOrders"]
        workOrders.tap()
        XCTAssertTrue(app.descendants(matching: .any)["theme.surface.design3"].waitForExistence(timeout: 5))

        let calendar = app.buttons["main.tab.calendar"]
        calendar.tap()
        XCTAssertTrue(app.descendants(matching: .any)["theme.design3.calendar"].waitForExistence(timeout: 5))

        let hub = app.buttons["main.tab.hub"]
        hub.tap()
        XCTAssertTrue(app.descendants(matching: .any)["theme.design3.hub"].waitForExistence(timeout: 5))
    }

    @MainActor
    func testThemeWorkOrderSurfacesAreDistinct() {
        let app = launch(arguments: ["-ui-testing", "-ui-testing-seeded"])

        let settings = app.buttons["main.tab.settings"]
        let workOrders = app.buttons["main.tab.workOrders"]
        XCTAssertTrue(settings.waitForExistence(timeout: 5))
        XCTAssertTrue(workOrders.waitForExistence(timeout: 5))

        func openThemes() {
            settings.tap()
            if !app.otherElements["screen.themes"].waitForExistence(timeout: 1) {
                let themes = app.staticTexts["Themes"]
                XCTAssertTrue(themes.waitForExistence(timeout: 5))
                themes.tap()
            }
            XCTAssertTrue(app.otherElements["screen.themes"].waitForExistence(timeout: 5))
        }

        func selectTheme(_ identifier: String, surface: String) {
            openThemes()
            let choice = app.buttons[identifier]
            XCTAssertTrue(choice.waitForExistence(timeout: 5))
            choice.tap()
            XCTAssertEqual(choice.value as? String, "Selected")
            workOrders.tap()
            XCTAssertTrue(app.descendants(matching: .any)[surface].waitForExistence(timeout: 5))
        }

        selectTheme("theme.design2", surface: "theme.surface.design2")
        selectTheme("theme.design3", surface: "theme.surface.design3")
        selectTheme("theme.defaultTheme", surface: "theme.surface.default")
    }

    @MainActor
    func testCaptureSubmissionScreenshots() {
        let app = launch(arguments: ["-ui-testing", "-ui-testing-seeded"])

        XCTAssertTrue(app.otherElements["screen.workOrders"].waitForExistence(timeout: 5))
        capture("01-work-orders")

        let hub = app.buttons["main.tab.hub"]
        XCTAssertTrue(hub.waitForExistence(timeout: 5))
        hub.tap()
        XCTAssertTrue(app.otherElements["screen.hub"].waitForExistence(timeout: 5))
        capture("02-hub")

        let settings = app.buttons["main.tab.settings"]
        XCTAssertTrue(settings.waitForExistence(timeout: 5))
        settings.tap()
        XCTAssertTrue(app.otherElements["screen.settings"].waitForExistence(timeout: 5))
        capture("03-settings")
    }

    @MainActor
    private func capture(_ name: String) {
        let attachment = XCTAttachment(screenshot: XCUIScreen.main.screenshot())
        attachment.name = name
        attachment.lifetime = .keepAlways
        add(attachment)
    }

    @MainActor
    private func launch(arguments: [String]) -> XCUIApplication {
        let app = XCUIApplication()
        app.launchArguments = arguments
        app.launch()
        return app
    }
}
