#!/usr/bin/env python3
from pathlib import Path
import re
import sys

ROOT = Path(__file__).resolve().parents[1]
APP = ROOT / "iWorkOrder"
components = (APP / "Components.swift").read_text(encoding="utf-8")
work_orders = (APP / "WorkOrderViews.swift").read_text(encoding="utf-8")
settings = (APP / "CalendarHubSettingsViews.swift").read_text(encoding="utf-8")
root_view = (APP / "RootView.swift").read_text(encoding="utf-8")
ui_tests = (ROOT / "iWorkOrderUITests/iWorkOrderUITests.swift").read_text(encoding="utf-8")

checks = []
errors = []

def require(condition: bool, message: str) -> None:
    if condition:
        checks.append(message)
    else:
        errors.append(message)

def struct_block(source: str, name: str) -> str:
    match = re.search(rf"\bstruct\s+{re.escape(name)}\b[^{{]*\{{", source)
    if not match:
        return ""
    start = match.start()
    brace = source.find("{", match.start())
    depth = 0
    for idx in range(brace, len(source)):
        if source[idx] == "{":
            depth += 1
        elif source[idx] == "}":
            depth -= 1
            if depth == 0:
                return source[start:idx + 1]
    return ""

# Core source-of-truth / duplicate-write protection.
require('static let storageKey = "selectedVisualTheme"' in components, "theme selection keeps the existing persisted key")
require('guard UserDefaults.standard.string(forKey: storageKey) != newValue.rawValue else { return }' in components, "theme UserDefaults writes are idempotent")
for symbol in [
    "corner(for theme: VisualTheme)",
    "horizontalPadding(for theme: VisualTheme)",
    "accent(for theme: VisualTheme)",
    "textPrimary(for theme: VisualTheme)",
    "textSecondary(for theme: VisualTheme)",
    "background(for theme: VisualTheme)",
    "cardFill(for theme: VisualTheme)",
    "cardStroke(for theme: VisualTheme)",
    "cardShadow(for theme: VisualTheme)",
    "heroGradient(for theme: VisualTheme)",
    "usesLegacyHero(for theme: VisualTheme)",
    "legacyTitleFont(for theme: VisualTheme)",
]:
    require(symbol in components, f"theme styling supports explicit reactive selection: {symbol}")

# The main tab surfaces must observe the stored theme directly so a live change invalidates them.
for name, source in [
    ("WorkOrderHomeView", work_orders),
    ("CalendarWorkOrderView", settings),
    ("HubView", settings),
    ("SettingsView", settings),
]:
    block = struct_block(source, name)
    require(bool(block), f"{name} exists")
    require('@AppStorage(AppTheme.storageKey)' in block, f"{name} observes the persisted theme")
    require('private var selectedTheme: VisualTheme' in block, f"{name} resolves a local reactive theme value")

work_home = struct_block(work_orders, "WorkOrderHomeView")
require('if selectedTheme == .design2' in work_home and 'else if selectedTheme == .design3' in work_home, "work-order home switches all three layouts from reactive state")
require('AppTheme.selected == .design2' not in work_home and 'AppTheme.selected == .design3' not in work_home, "work-order home no longer branches on unobserved UserDefaults reads")

calendar = struct_block(settings, "CalendarWorkOrderView")
hub = struct_block(settings, "HubView")
settings_view = struct_block(settings, "SettingsView")
require('AppTheme.usesLegacyHero(for: selectedTheme)' in calendar, "calendar navigation responds live to theme changes")
require('AppTheme.usesLegacyHero(for: selectedTheme)' in hub, "hub navigation responds live to theme changes")
require('selectedTheme == .design2 ? .hidden : .visible' in settings_view, "settings root navigation state is driven by reactive theme state")
require('Theme3SettingsHeader()' in settings_view and 'struct Theme3SettingsHeader' in settings, "settings root switches to the dedicated Design 3 field-deck surface")

# Shared visual chrome observes theme changes itself so retained subviews do not stay half-themed.
for name in ["ScreenBackground", "ModernCard", "SectionHeader", "MetricTile", "SettingsRow", "InfoLine"]:
    block = struct_block(components, name)
    require('@AppStorage(AppTheme.storageKey)' in block, f"{name} independently invalidates on theme changes")
require('struct ThemedScrollableBackgroundModifier: ViewModifier' in components and '@AppStorage(AppTheme.storageKey)' in struct_block(components, "ThemedScrollableBackgroundModifier"), "Form/List themed backgrounds react without a relaunch")
require('AppTheme.background(for: selectedTheme)' in struct_block(components, "ScreenBackground"), "screen background renders from the same reactive theme value")
require('AppTheme.cardFill(reduceTransparency: reduceTransparency, theme: selectedTheme)' in struct_block(components, "ModernCard"), "card fill renders from the same reactive theme value")

# Theme picker must perform exactly one persisted change and avoid animated layout interpolation.
theme_settings = struct_block(settings, "ThemeSettingsView")
require('applyTheme(theme)' in theme_settings, "theme buttons route through one apply function")
require('AppTheme.selected = theme' not in theme_settings, "theme picker no longer performs a duplicate UserDefaults write")
require('guard theme != selectedTheme else { return }' in theme_settings, "reselecting the current theme is a no-op")
require('transaction.disablesAnimations = true' in theme_settings and 'withTransaction(transaction)' in theme_settings, "live theme switches disable cross-layout interpolation")
require('.toolbar(.visible, for: .navigationBar)' in theme_settings, "Themes screen keeps navigation controls visible while Design 2 is applied")
require('.navigationBarTitleDisplayMode(.inline)' in theme_settings, "Themes screen uses stable inline navigation geometry")
require('.accessibilityIdentifier("theme.\\(theme.rawValue)")' in theme_settings, "each theme choice has a stable UI-test identifier")
require('.accessibilityValue(theme == selectedTheme ? "Selected" : "Not selected")' in theme_settings, "theme selection exposes deterministic state to accessibility and UI tests")
require('.accessibilityIdentifier("screen.themes")' in theme_settings, "Themes screen has a stable UI-test identifier")

# The app shell itself remains reactive and uses the same explicit theme value for tint.
require(root_view.count('@AppStorage(AppTheme.storageKey)') >= 2, "root and tab shell both observe live theme selection")
require(root_view.count('AppTheme.accent(for: theme)') >= 3, "tab/sidebar tint is rendered from the current observed theme")

# Xcode UI regression: switch all three themes without losing the Themes screen or navigation bar.
require('func testThemeSwitchingStaysLiveAndNavigable()' in ui_tests, "UI automation covers live switching across all three themes")
for identifier in ['theme.design2', 'theme.design3', 'theme.defaultTheme']:
    require(identifier in ui_tests, f"UI automation selects {identifier}")
require('app.otherElements["screen.themes"].exists' in ui_tests, "UI automation verifies the Themes screen survives each live switch")
require('app.navigationBars["Themes"].exists' in ui_tests, "UI automation verifies the back/navigation bar survives live switching")
for title in ['Dashboard', 'Field Deck', 'Hub']:
    require(f'.label.contains("{title}")' in ui_tests, f"UI automation verifies tab-shell title updates to {title}")

if errors:
    print("HOTFIX 29 LIVE THEME SWITCHING: FAIL")
    for error in errors:
        print(f"FAIL: {error}")
    print(f"Checks passed before failure: {len(checks)}")
    sys.exit(1)

print("HOTFIX 29 LIVE THEME SWITCHING: PASS")
print(f"Checks passed: {len(checks)}")
for check in checks:
    print(f"PASS: {check}")
