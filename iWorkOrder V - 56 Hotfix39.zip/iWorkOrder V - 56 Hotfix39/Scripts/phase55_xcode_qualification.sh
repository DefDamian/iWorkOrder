#!/bin/bash
set -euo pipefail

ROOT="$(cd "$(dirname "$0")/.." && pwd)"
cd "$ROOT"

PROJECT="iWorkOrder.xcodeproj"
SCHEME="iWorkOrder"
BUNDLE_ID="com.damiancedeno.SedgwickWorkOrders"
ICLOUD_CONTAINER="iCloud.com.damiancedeno.SedgwickWorkOrders"
MARKETING_VERSION="1.0"
BUILD_NUMBER="55"
MODE="${PHASE55_MODE:-unsigned}"
ARTIFACTS_DIR="${PHASE55_ARTIFACTS_DIR:-$ROOT/Artifacts/Phase55}"
DERIVED_DATA="${PHASE55_DERIVED_DATA:-$ROOT/build/Phase55DerivedData}"
ARCHIVE_PATH="$ARTIFACTS_DIR/iWorkOrder.xcarchive"
EXPORT_PATH="$ARTIFACTS_DIR/TestFlightExport"

rm -rf "$ARTIFACTS_DIR" "$DERIVED_DATA"
mkdir -p "$ARTIFACTS_DIR"

if [[ "$(uname -s)" != "Darwin" ]]; then
  echo "Phase 55 Xcode qualification requires macOS." >&2
  exit 2
fi

select_xcode() {
  if [[ -n "${DEVELOPER_DIR:-}" && -x "$DEVELOPER_DIR/usr/bin/xcodebuild" ]]; then
    return
  fi
  local selected
  selected="$(python3 - <<'PY'
from pathlib import Path
import plistlib

candidates = []
for app in Path('/Applications').glob('Xcode*.app'):
    plist = app / 'Contents' / 'Info.plist'
    if not plist.is_file():
        continue
    try:
        version = plistlib.loads(plist.read_bytes()).get('CFBundleShortVersionString', '')
        parts = tuple(int(part) for part in version.split('.') if part.isdigit())
    except Exception:
        continue
    if parts and parts[0] >= 26:
        candidates.append((parts, app.name, app))
if candidates:
    _, _, selected = max(candidates)
    print(selected / 'Contents' / 'Developer')
PY
)"
  if [[ -n "$selected" ]]; then
    export DEVELOPER_DIR="$selected"
  fi
}

select_xcode

{
  echo "Phase 55 environment"
  echo "Date: $(date -u +%Y-%m-%dT%H:%M:%SZ)"
  echo "Mode: $MODE"
  echo "Developer directory: ${DEVELOPER_DIR:-$(xcode-select -p)}"
  xcodebuild -version
  echo "iOS SDK: $(xcrun --sdk iphoneos --show-sdk-version)"
  echo "Simulator SDK: $(xcrun --sdk iphonesimulator --show-sdk-version)"
  sw_vers
} | tee "$ARTIFACTS_DIR/environment.txt"

XCODE_MAJOR="$(xcodebuild -version | awk '/Xcode/{split($2,a,"."); print a[1]; exit}')"
SDK_MAJOR="$(xcrun --sdk iphoneos --show-sdk-version | cut -d. -f1)"
if [[ -z "$XCODE_MAJOR" || "$XCODE_MAJOR" -lt 26 ]]; then
  echo "Xcode 26 or later is required. Found: $(xcodebuild -version | head -1)" >&2
  exit 1
fi
if [[ -z "$SDK_MAJOR" || "$SDK_MAJOR" -lt 26 ]]; then
  echo "iOS 26 SDK or later is required. Found: $(xcrun --sdk iphoneos --show-sdk-version)" >&2
  exit 1
fi

./Scripts/verify_release.sh | tee "$ARTIFACTS_DIR/static-verification.txt"
./Scripts/run_reliability_harness.py | tee "$ARTIFACTS_DIR/runtime-reliability.txt"
./Scripts/validate_app_store_metadata.py | tee "$ARTIFACTS_DIR/app-store-metadata.txt"
xcodebuild -project "$PROJECT" -list -json > "$ARTIFACTS_DIR/project-list.json"
xcodebuild -project "$PROJECT" -scheme "$SCHEME" -configuration Debug -showBuildSettings > "$ARTIFACTS_DIR/debug-build-settings.txt"
xcodebuild -project "$PROJECT" -scheme "$SCHEME" -configuration Release -showBuildSettings > "$ARTIFACTS_DIR/release-build-settings.txt"

IPHONE_ID="$(./Scripts/select_simulator.py --family iphone)"
IPAD_ID="$(./Scripts/select_simulator.py --family ipad)"
COMMON=(
  -project "$PROJECT"
  -scheme "$SCHEME"
  -derivedDataPath "$DERIVED_DATA"
  SWIFT_TREAT_WARNINGS_AS_ERRORS=YES
  GCC_TREAT_WARNINGS_AS_ERRORS=YES
  CLANG_TREAT_WARNINGS_AS_ERRORS=YES
  COMPILER_INDEX_STORE_ENABLE=NO
)

xcodebuild "${COMMON[@]}" \
  -configuration Debug \
  -destination "platform=iOS Simulator,id=$IPHONE_ID" \
  -resultBundlePath "$ARTIFACTS_DIR/iPhoneTests.xcresult" \
  clean test | tee "$ARTIFACTS_DIR/iphone-tests.log"

xcodebuild "${COMMON[@]}" \
  -configuration Debug \
  -destination "platform=iOS Simulator,id=$IPAD_ID" \
  -resultBundlePath "$ARTIFACTS_DIR/iPadTests.xcresult" \
  test | tee "$ARTIFACTS_DIR/ipad-tests.log"

xcodebuild "${COMMON[@]}" \
  -configuration Debug \
  -destination "platform=iOS Simulator,id=$IPHONE_ID" \
  -only-testing:iWorkOrderTests \
  -test-iterations 3 \
  -resultBundlePath "$ARTIFACTS_DIR/StabilityTests.xcresult" \
  test | tee "$ARTIFACTS_DIR/stability-tests.log"

xcodebuild "${COMMON[@]}" \
  -configuration Debug \
  -destination "platform=iOS Simulator,id=$IPHONE_ID" \
  -only-testing:iWorkOrderUITests/iWorkOrderUITests/testMaintenanceRecoveryCanRunHealthCheck \
  -resultBundlePath "$ARTIFACTS_DIR/MaintenanceRecoveryUI.xcresult" \
  test | tee "$ARTIFACTS_DIR/maintenance-recovery-ui.log"

xcodebuild "${COMMON[@]}" \
  -configuration Debug \
  -destination "platform=iOS Simulator,id=$IPHONE_ID" \
  -only-testing:iWorkOrderUITests/iWorkOrderUITests/testRecoveryCloudPauseCanBeEnabledAndDisabled \
  -resultBundlePath "$ARTIFACTS_DIR/RecoveryPauseUI.xcresult" \
  test | tee "$ARTIFACTS_DIR/recovery-pause-ui.log"

xcodebuild "${COMMON[@]}" \
  -configuration Debug \
  -destination "platform=iOS Simulator,id=$IPHONE_ID" \
  -only-testing:iWorkOrderUITests/iWorkOrderUITests/testCaptureSubmissionScreenshots \
  -resultBundlePath "$ARTIFACTS_DIR/iPhoneSubmissionScreenshots.xcresult" \
  test | tee "$ARTIFACTS_DIR/iphone-screenshots.log"

xcodebuild "${COMMON[@]}" \
  -configuration Debug \
  -destination "platform=iOS Simulator,id=$IPAD_ID" \
  -only-testing:iWorkOrderUITests/iWorkOrderUITests/testCaptureSubmissionScreenshots \
  -resultBundlePath "$ARTIFACTS_DIR/iPadSubmissionScreenshots.xcresult" \
  test | tee "$ARTIFACTS_DIR/ipad-screenshots.log"

xcodebuild "${COMMON[@]}" \
  -configuration Debug \
  -destination "platform=iOS Simulator,id=$IPHONE_ID" \
  -resultBundlePath "$ARTIFACTS_DIR/Analyze.xcresult" \
  analyze | tee "$ARTIFACTS_DIR/analyze.log"

ARCHIVE_ARGS=(
  -project "$PROJECT"
  -scheme "$SCHEME"
  -configuration Release
  -destination "generic/platform=iOS"
  -archivePath "$ARCHIVE_PATH"
  -derivedDataPath "$DERIVED_DATA"
  SWIFT_TREAT_WARNINGS_AS_ERRORS=YES
  GCC_TREAT_WARNINGS_AS_ERRORS=YES
  CLANG_TREAT_WARNINGS_AS_ERRORS=YES
  COMPILER_INDEX_STORE_ENABLE=NO
)

case "$MODE" in
  unsigned)
    ARCHIVE_ARGS+=(CODE_SIGNING_ALLOWED=NO CODE_SIGNING_REQUIRED=NO)
    ;;
  signed)
    if [[ -z "${APPLE_TEAM_ID:-}" ]]; then
      echo "APPLE_TEAM_ID is required for PHASE55_MODE=signed." >&2
      exit 1
    fi
    ARCHIVE_ARGS+=(DEVELOPMENT_TEAM="$APPLE_TEAM_ID" CODE_SIGN_STYLE=Automatic CODE_SIGNING_ALLOWED=YES CODE_SIGNING_REQUIRED=YES -allowProvisioningUpdates)
    ;;
  *)
    echo "PHASE55_MODE must be unsigned or signed." >&2
    exit 1
    ;;
esac

xcodebuild "${ARCHIVE_ARGS[@]}" archive | tee "$ARTIFACTS_DIR/archive.log"

./Scripts/validate_xcode_archive.py "$ARCHIVE_PATH" \
  --bundle-id "$BUNDLE_ID" \
  --version "$MARKETING_VERSION" \
  --build "$BUILD_NUMBER" \
  --icloud-container "$ICLOUD_CONTAINER" \
  | tee "$ARTIFACTS_DIR/archive-validation.txt"

if [[ "$MODE" == "signed" ]]; then
  codesign --verify --deep --strict --verbose=2 "$ARCHIVE_PATH/Products/Applications/iWorkOrder.app" 2>&1 \
    | tee "$ARTIFACTS_DIR/codesign-verification.txt"

  cat > "$ARTIFACTS_DIR/ExportOptions.plist" <<EOF
<?xml version="1.0" encoding="UTF-8"?>
<!DOCTYPE plist PUBLIC "-//Apple//DTD PLIST 1.0//EN" "http://www.apple.com/DTDs/PropertyList-1.0.dtd">
<plist version="1.0"><dict>
<key>method</key><string>app-store-connect</string>
<key>destination</key><string>export</string>
<key>signingStyle</key><string>automatic</string>
<key>teamID</key><string>$APPLE_TEAM_ID</string>
<key>uploadSymbols</key><true/>
<key>manageAppVersionAndBuildNumber</key><false/>
</dict></plist>
EOF

  xcodebuild -exportArchive \
    -archivePath "$ARCHIVE_PATH" \
    -exportPath "$EXPORT_PATH" \
    -exportOptionsPlist "$ARTIFACTS_DIR/ExportOptions.plist" \
    -allowProvisioningUpdates \
    | tee "$ARTIFACTS_DIR/export.log"

  IPA_PATH="$(find "$EXPORT_PATH" -maxdepth 1 -name '*.ipa' -print -quit)"
  if [[ -z "$IPA_PATH" ]]; then
    echo "Signed App Store Connect export did not produce an IPA." >&2
    exit 1
  fi
  ./Scripts/validate_testflight_ipa.py "$IPA_PATH" \
    --bundle-id "$BUNDLE_ID" \
    --version "$MARKETING_VERSION" \
    --build "$BUILD_NUMBER" \
    | tee "$ARTIFACTS_DIR/ipa-validation.txt"
fi

cat > "$ARTIFACTS_DIR/QUALIFICATION_STATUS.txt" <<EOF
PHASE 55 XCODE QUALIFICATION: PASS
Mode: $MODE
Xcode major: $XCODE_MAJOR
iOS SDK major: $SDK_MAJOR
iPhone simulator: $IPHONE_ID
iPad simulator: $IPAD_ID
Archive: $ARCHIVE_PATH
TestFlight export: $([[ "$MODE" == "signed" ]] && echo "$EXPORT_PATH" || echo "Not created in unsigned mode")
Upload: Not performed; explicit App Store Connect account-holder action required
EOF

cat "$ARTIFACTS_DIR/QUALIFICATION_STATUS.txt"
