#!/usr/bin/env python3
from pathlib import Path
import re
import sys

ROOT = Path(__file__).resolve().parents[1]
APP = ROOT / "iWorkOrder"
components = (APP / "Components.swift").read_text(encoding="utf-8")
root = (APP / "RootView.swift").read_text(encoding="utf-8")
orders = (APP / "WorkOrderViews.swift").read_text(encoding="utf-8")
settings = (APP / "CalendarHubSettingsViews.swift").read_text(encoding="utf-8")
ui_tests = (ROOT / "iWorkOrderUITests/iWorkOrderUITests.swift").read_text(encoding="utf-8")
verify_sh = (ROOT / "Scripts/verify_release.sh").read_text(encoding="utf-8")
phase56 = (ROOT / "Scripts/phase56_xcode_qualification.sh").read_text(encoding="utf-8")

passed: list[str] = []
failed: list[str] = []


def require(condition: bool, message: str) -> None:
    (passed if condition else failed).append(message)


def struct_block(source: str, name: str) -> str:
    match = re.search(rf"\bstruct\s+{re.escape(name)}\b[^{{]*\{{", source)
    if not match:
        return ""
    start = match.start()
    brace = source.find("{", match.start())
    depth = 0
    for idx in range(brace, len(source)):
        if source[idx] == "{": depth += 1
        elif source[idx] == "}":
            depth -= 1
            if depth == 0:
                return source[start:idx + 1]
    return ""

# Persistence / compatibility: rebuild visuals without migrating user data or theme selection.
require('case design3' in components, "Design 3 persisted enum identity is preserved")
require('static let storageKey = "selectedVisualTheme"' in components, "theme storage key is unchanged")
require('case .design3: return "Design 3"' in components, "public Design 3 title remains compatible")
require('case .design3: return .dark' in root, "rebuilt Design 3 owns a dark appearance")
require('case .design3: return 10' in components, "rebuilt Design 3 uses compact panel geometry")
require('case .design3: return 8' in components, "rebuilt Design 3 uses compact control geometry")
require('case .design3: return 16' in components, "rebuilt Design 3 uses its own horizontal rhythm")
require('case .design3: return Color(red: 0.34, green: 0.94, blue: 0.72)' in components, "rebuilt Design 3 uses a mint field accent")
require('graphite panels' in components and 'mint status rails' in components, "Design 3 description documents the new visual system")

# Old Theme 3 identity is removed from live Design 3 implementation.
field_section = orders[orders.find('// MARK: - Design 3 field-deck theme'):] if '// MARK: - Design 3 field-deck theme' in orders else ""
require(bool(field_section), "Design 3 is implemented as a standalone field-deck section")
for legacy in ['WORKFLOW', 'Color.purple', 'blue-purple', 'RoundedRectangle(cornerRadius: 34']:
    require(legacy not in field_section, f"old Theme 3 workflow artifact removed: {legacy}")
require('FIELD DECK / ACTIVE' in field_section, "work-order surface uses Field Deck identity")
require('theme.surface.design3' in field_section, "rebuilt work-order surface keeps stable UI-test identity")

# Work-order functionality is preserved while visual hierarchy is rebuilt.
home = struct_block(orders, 'Theme3OrdersHomeView')
hero = struct_block(orders, 'Theme3OrdersHero')
search = struct_block(orders, 'Theme3SearchBar')
filters = struct_block(orders, 'Theme3FilterCard')
row = struct_block(orders, 'Theme3OrderRow')
require('store.activeWorkOrders' in home, "Field Deck reads real active work orders")
require('case .open:' in home and 'case .completed:' in home and 'case .overdue:' in home and 'case .all:' in home, "Field Deck preserves queue status filtering")
require('filters.emergencyOnly' in home, "Field Deck preserves emergency-only filtering")
require('filters.category' in home, "Field Deck preserves category filtering")
require('filters.unit' in home and 'filters.handyman' in home, "Field Deck preserves unit and worker filtering")
require('filters.searchText' in home and 'localizedCaseInsensitiveContains' in home, "Field Deck preserves search filtering")
require('priority == .emergency' in home, "Field Deck prioritizes emergency work orders")
require('.sheet(isPresented: $quickAdd)' in home and '.sheet(isPresented: $newOrder)' in home, "Quick Add and detailed work-order creation remain connected")
require('deepLinkedOrderID' in home and 'navigationDestination(item: $selectedDeepLink)' in home, "deep-linked work-order navigation remains connected")
require('Button(action: addAction)' in hero and '.frame(width: 44, height: 44)' in hero, "Field Deck hero has an accessible new-order action")
require('TextField("Search unit, worker, issue"' in search, "Field Deck search remains bound to work-order search")
require('ForEach(Theme3StatusFilter.allCases)' in filters, "Field Deck status rail exposes every queue state")
require('Menu {' in filters and 'All Units' in filters and 'All Workers' in filters and 'All Categories' in filters, "Field Deck field filters remain interactive")
require('store.filters.emergencyOnly.toggle()' in filters and 'Emergency work orders only' in filters, "Field Deck exposes inherited emergency-only filter state instead of hiding it")
require('trailingIcon: store.filters.emergencyOnly ? "checkmark" : "circle"' in filters, "Emergency filter uses toggle feedback instead of a misleading menu chevron")
require('order.latestEntry.managedCategory.rawValue' in row and 'order.latestEntry.priority.rawValue' in row, "Field Deck rows retain category and priority context")

# Calendar, Hub, and Settings are rebuilt instead of recolored copies.
calendar = struct_block(settings, 'CalendarWorkOrderView')
calendar_content = struct_block(settings, 'Theme3CalendarContent')
calendar_row = struct_block(settings, 'Theme3CalendarRow')
hub = struct_block(settings, 'HubView')
hub_header = struct_block(settings, 'Theme3HubHeader')
settings_view = struct_block(settings, 'SettingsView')
settings_header = struct_block(settings, 'Theme3SettingsHeader')
settings_group = struct_block(settings, 'Theme3SettingsGroup')
require('Theme3CalendarContent(orders: store.reminderWorkOrders)' in calendar, "Calendar switches to a dedicated Field Deck surface")
require('FIELD DECK / SCHEDULE' in calendar_content, "Calendar uses new Field Deck language")
require('theme.design3.calendar' in calendar_content, "Calendar exposes dedicated Field Deck UI identity")
require('NavigationLink { WorkOrderDetailView(order: order) }' in calendar_content, "Calendar rows still navigate to work-order details")
require('Theme3HubHeader' in hub, "Hub switches to a dedicated Field Deck header")
require('FIELD DECK / OVERVIEW' in hub_header and 'theme.design3.hub' in hub_header, "Hub exposes new Field Deck identity")
require('reportPDFURL' in hub and 'ShareSheet' in hub, "Hub report export remains connected")
require('AssetManagerView()' in hub and 'DirectoryView()' in hub, "Hub asset and directory tools remain connected")
require('Theme3SettingsHeader()' in settings_view and settings_view.count('Theme3SettingsGroup') >= 4, "Settings uses grouped Field Deck sections")
require('FIELD DECK / CONFIG' in settings_header and 'theme.design3.settings' in settings_header, "Settings exposes new Field Deck identity")
require('Color(red: 0.052, green: 0.080, blue: 0.084)' in settings_group, "Settings groups use independent graphite panels")

# Shared components follow the new design system.
modern = struct_block(components, 'ModernCard')
section = struct_block(components, 'SectionHeader')
metric = struct_block(components, 'MetricTile')
settings_row = struct_block(components, 'SettingsRow')
require('if selectedTheme == .design3' in modern and 'Rectangle()' in modern, "Design 3 shared cards use a top field rail")
require('FIELD / \\(title.uppercased())' in section, "Design 3 section headers use field labels")
require('RoundedRectangle(cornerRadius: 7' in metric and 'AppTheme.accent(for: .design3)' in metric, "Design 3 metric tiles use solid square markers")
require('selectedTheme == .design3 ? "arrow.up.right"' in settings_row, "Design 3 settings navigation uses field-deck affordances")

# Theme picker preview and tab shell clearly identify the rebuild.
preview = struct_block(settings, 'ThemePreview')
option = struct_block(settings, 'ThemeOptionCard')
require('case .design3: return "FIELD"' in option, "theme picker labels Design 3 as FIELD")
require('Color.purple' not in preview, "Design 3 preview contains no old purple workflow styling")
require('AppTheme.accent(for: .design3)' in preview, "Design 3 preview uses the new mint accent")
require('.environment(\\.colorScheme, theme == .design3 ? .dark : .light)' in struct_block(settings, 'ThemeSettingsView'), "theme chooser renders Field Deck preview in dark appearance without contaminating light-theme previews")
require('case .design3: return "Field Deck"' in root, "main tab shell names the new Design 3 Field Deck")
require('case .workOrders: return theme == .design3 ? "wrench.and.screwdriver.fill"' in root, "Field Deck uses a dedicated work-order tab icon")

# Native UI coverage added for main rebuilt surfaces.
require('func testTheme3FieldDeckSurfacesAreDistinct()' in ui_tests, "Xcode UI test covers rebuilt Design 3")
for identity in ['theme.surface.design3', 'theme.design3.calendar', 'theme.design3.hub', 'theme.design3.settings']:
    require(identity in ui_tests, f"Xcode UI test asserts {identity}")
require('.label.contains("Field Deck")' in ui_tests, "Xcode UI test verifies live Field Deck tab identity")

# Release integration.
require('run_hotfix34_theme3_rebuild_harness.py' in verify_sh, "cross-platform verification executes Hotfix34 harness")
require('run_hotfix34_theme3_rebuild_harness.py' in phase56, "Xcode qualification executes Hotfix34 harness")
require((ROOT / 'VERIFICATION_NOTES_v56_HOTFIX34_THEME3_REBUILD.md').is_file(), "Hotfix34 verification notes are included")

if failed:
    print('HOTFIX 34 THEME 3 REBUILD: FAIL')
    for item in failed:
        print('FAIL:', item)
    print(f'Checks passed before failure: {len(passed)}')
    sys.exit(1)

print('HOTFIX 34 THEME 3 REBUILD: PASS')
print(f'Checks passed: {len(passed)}')
for item in passed:
    print('PASS:', item)
