#!/usr/bin/env python3
from __future__ import annotations

import hashlib
import html
import json
import plistlib
import re
import struct
import sys
import xml.etree.ElementTree as ET
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
APP = ROOT / "iWorkOrder"
PROJECT = ROOT / "iWorkOrder.xcodeproj" / "project.pbxproj"
SCHEME = ROOT / "iWorkOrder.xcodeproj" / "xcshareddata" / "xcschemes" / "iWorkOrder.xcscheme"

errors: list[str] = []
checks: list[str] = []


def require(condition: bool, message: str) -> None:
    if condition:
        checks.append(message)
    else:
        errors.append(message)


def extract_swift_multiline(name: str) -> str:
    source = (APP / "LegalContent.swift").read_text(encoding="utf-8")
    match = re.search(rf"static let {re.escape(name)} = \"\"\"\n(.*?)\n\"\"\"", source, re.S)
    if not match:
        errors.append(f"LegalContent.{name} could not be extracted")
        return ""
    return match.group(1).strip() + "\n"


# Structured files.
for relative in [
    "iWorkOrder/Info.plist",
    "iWorkOrder/PrivacyInfo.xcprivacy",
    "iWorkOrder/iWorkOrder.entitlements",
]:
    try:
        plistlib.loads((ROOT / relative).read_bytes())
        checks.append(f"valid plist: {relative}")
    except Exception as exc:
        errors.append(f"invalid plist {relative}: {exc}")

try:
    ET.parse(SCHEME)
    checks.append("valid shared Xcode scheme XML")
except Exception as exc:
    errors.append(f"invalid shared scheme XML: {exc}")

for contents in APP.glob("Assets.xcassets/**/Contents.json"):
    try:
        json.loads(contents.read_text(encoding="utf-8"))
    except Exception as exc:
        errors.append(f"invalid asset catalog JSON {contents.relative_to(ROOT)}: {exc}")
checks.append("asset catalog JSON scanned")

# App Store icon integrity. App icons must have exact pixel dimensions and no alpha channel.
app_icon_contents = json.loads((APP / "Assets.xcassets/AppIcon.appiconset/Contents.json").read_text(encoding="utf-8"))
for image in app_icon_contents.get("images", []):
    filename = image.get("filename")
    if not filename:
        continue
    icon_path = APP / "Assets.xcassets/AppIcon.appiconset" / filename
    require(icon_path.is_file(), f"app icon file exists: {filename}")
    payload = icon_path.read_bytes()
    require(payload.startswith(b"\x89PNG\r\n\x1a\n") and payload[12:16] == b"IHDR", f"app icon is a valid PNG: {filename}")
    if len(payload) >= 29:
        width, height, bit_depth, color_type, _, _, _ = struct.unpack(">IIBBBBB", payload[16:29])
        size = float(str(image["size"]).split("x", 1)[0])
        scale = int(str(image["scale"]).removesuffix("x"))
        expected_pixels = round(size * scale)
        require((width, height) == (expected_pixels, expected_pixels), f"app icon dimensions match catalog: {filename}")
        require(color_type not in {4, 6}, f"app icon has no alpha channel: {filename}")
        require(bit_depth == 8, f"app icon uses 8-bit PNG encoding: {filename}")


# Privacy-manifest source audit.
manifest = plistlib.loads((APP / "PrivacyInfo.xcprivacy").read_bytes())
entries = {
    item["NSPrivacyAccessedAPIType"]: set(item["NSPrivacyAccessedAPITypeReasons"])
    for item in manifest.get("NSPrivacyAccessedAPITypes", [])
}
expected = {
    "NSPrivacyAccessedAPICategoryUserDefaults": {"CA92.1"},
    "NSPrivacyAccessedAPICategoryFileTimestamp": {"C617.1"},
    "NSPrivacyAccessedAPICategoryDiskSpace": {"E174.1"},
}
require(entries == expected, "privacy manifest contains only source-supported required-reason categories")
require(manifest.get("NSPrivacyTracking") is False, "privacy tracking is disabled")
require(manifest.get("NSPrivacyCollectedDataTypes") == [], "developer-collected data list is empty")

swift_source = "\n".join(path.read_text(encoding="utf-8") for path in APP.glob("*.swift"))
require("UserDefaults" in swift_source, "UserDefaults usage supports CA92.1")
require(any(token in swift_source for token in ["contentModificationDateKey", "attributesOfItem"]), "file metadata usage supports C617.1")
require("systemFreeSize" in swift_source, "disk-capacity preflight supports E174.1")
require("systemUptime" not in swift_source and "mach_absolute_time" not in swift_source, "no system-boot-time API usage is present")
require("WKWebView" not in swift_source and "LegalWebView" not in swift_source, "stale network legal pages cannot replace bundled legal text")

# Cross-file restore API access-control regression. Swift parser-only checks do not
# diagnose this; AppStore and BackupArchiveService are separate source files.
backup_source_for_access = (APP / "BackupArchiveService.swift").read_text(encoding="utf-8")
app_store_source_for_access = (APP / "AppStore.swift").read_text(encoding="utf-8")
require("fileprivate func prepareSnapshotCommit" not in backup_source_for_access and "func prepareSnapshotCommit(_ snapshot: AppSnapshot) throws" in backup_source_for_access, "restore snapshot-commit API is visible across Swift files")
require("transaction?.prepareSnapshotCommit(savedSnapshot)" in app_store_source_for_access, "AppStore uses the validated restore snapshot-commit API")

# Legal source-of-truth and public copies.
privacy = extract_swift_multiline("privacy")
terms = extract_swift_multiline("terms")
liability = extract_swift_multiline("liability")
public_privacy = (ROOT / "iworkorder-privacy-policy.html").read_text(encoding="utf-8")
pre = re.search(r"<pre>(.*?)</pre>", public_privacy, re.S)
public_privacy_text = html.unescape(pre.group(1)).strip() + "\n" if pre else ""
require(public_privacy_text == privacy, "public privacy HTML matches bundled privacy text")
require((ROOT / "terms-of-service").read_text(encoding="utf-8") == terms, "public terms match bundled terms")
require((ROOT / "Data-Liability-Disclaimer").read_text(encoding="utf-8") == liability, "public disclaimer matches bundled disclaimer")
require("Legal Version: 2026.09.16.56" in privacy, "legal documents carry the Hotfix25 legal version")
require("profile.legalAcceptedDate != nil" in (APP / "LegalContent.swift").read_text(encoding="utf-8"), "current legal acceptance requires a persisted acceptance date")
require("Effective Date: September 16, 2026" in privacy and "Effective Date: September 16, 2026" in terms and "Effective Date: September 16, 2026" in liability, "all authoritative legal documents carry the same Hotfix25 effective date")
require("third-party advertising, attribution, or analytics providers" in privacy, "privacy policy discloses third-party advertising and analytics posture")
require("retention and deletion" in privacy.lower() and "Erase All Data" in privacy, "privacy policy explains retention and deletion controls")
require("require renewed in-app acceptance" in terms, "terms require renewed acceptance after material legal changes")
require("Material changes to this disclaimer" in liability, "liability disclaimer participates in renewed legal acceptance")
settings_source_for_legal = (APP / "CalendarHubSettingsViews.swift").read_text(encoding="utf-8")
root_source_for_legal = (APP / "RootView.swift").read_text(encoding="utf-8")
accessibility_source_for_legal = (APP / "AccessibilitySupport.swift").read_text(encoding="utf-8")
require("LegalUpdateSplashView" in settings_source_for_legal and "stage: Stage = .splash" in settings_source_for_legal, "stale legal acceptance presents an update splash before the agreement")
require("Review Updated Legal Terms" in settings_source_for_legal and "legalUpdateReview" in settings_source_for_legal, "legal update splash has a review action")
require("else if !store.hasCurrentLegalAcceptance" in root_source_for_legal and "LegalUpdateRequiredView()" in root_source_for_legal, "normal app access remains gated on current-version legal acceptance")
require(".task(id: store.isOnboardingComplete && store.hasCurrentLegalAcceptance && store.hasCompletedPermissionSetup)" in root_source_for_legal, "biometric unlock waits until onboarding, current legal acceptance, and device permission review are satisfied")
require("startsLegalUpdate" in accessibility_source_for_legal and "-ui-testing-legal-update" in accessibility_source_for_legal, "UI testing can exercise a stale legal-version upgrade")
require("testUpdatedLegalVersionShowsSplashAndRequiresReacceptance" in (ROOT / "iWorkOrderUITests/iWorkOrderUITests.swift").read_text(encoding="utf-8"), "UI automation covers legal update splash, decline block, and re-acceptance")
info_plist_text = (APP / "Info.plist").read_text(encoding="utf-8")
require("NSCameraUsageDescription" in info_plist_text and "optional rear flashlight" in info_plist_text and "does not capture or record photos or video" in info_plist_text, "camera purpose string matches torch-only AVCaptureDevice use")
require("AVCaptureDevice.default(for: .video)" in swift_source and "AVCaptureSession" not in swift_source, "camera hardware use is limited to torch control rather than media capture")
for obsolete in [
    "All data is stored securely in your personal Apple iCloud account",
    "The app maintains immutable audit logs",
    "Work orders and related actions are recorded in permanent audit logs",
]:
    require(obsolete not in privacy + terms + liability, f"obsolete legal claim removed: {obsolete}")

# Project and test-target integrity.
pbx = PROJECT.read_text(encoding="utf-8")
scheme = SCHEME.read_text(encoding="utf-8")
require("LegalContent.swift in Sources" in pbx, "LegalContent.swift is compiled by the app target")
require("iWorkOrderTests.xctest" in pbx, "unit-test target exists")
require("iWorkOrderUITests.xctest" in pbx, "UI-test target exists")
require("B50000000000000000000008" in scheme and "<TestAction" in scheme, "shared scheme runs the unit-test target")
require("C52000000000000000000017" in scheme, "shared scheme runs the UI-test target")
require("CURRENT_PROJECT_VERSION = 56;" in pbx, "Phase 56 build number is configured")
require("42AEFBAE01D2DFD981F7DA7D" in scheme, "shared scheme references the app target")
require(pbx.count("SWIFT_STRICT_CONCURRENCY = complete;") >= 8, "strict-concurrency diagnostics are enabled for project and targets")
require(pbx.count("SWIFT_VERSION = 6.0;") >= 8, "project and test targets explicitly use Swift 6 language mode")
require("LastUpgradeCheck = 2600" in pbx and "CreatedOnToolsVersion = 26.0" in pbx, "project truthfully records Xcode 26 as its last native recommended-settings migration")
require(pbx.count("ENABLE_USER_SCRIPT_SANDBOXING = YES;") >= 2, "user-script sandboxing is enabled")
require("VALIDATE_PRODUCT = YES;" in pbx and "DEAD_CODE_STRIPPING = YES;" in pbx, "Release product validation and dead-code stripping are enabled")
require(pbx.count('DEVELOPMENT_TEAM = "";') == 2, "distribution package contains no embedded Apple Team ID")

workflow = (ROOT / ".github/workflows/ios-ci.yml").read_text(encoding="utf-8")
qualification_script = (ROOT / "Scripts/phase56_xcode_qualification.sh").read_text(encoding="utf-8")
archive_validator = (ROOT / "Scripts/validate_xcode_archive.py").read_text(encoding="utf-8")
require("runs-on: macos-26" in workflow, "hosted compatibility CI is pinned to the macOS 26 runner family")
require("phase56_xcode_qualification.sh" in workflow or "run_xcode_ci.sh" in workflow, "CI invokes Phase 56 qualification")
require("PHASE56_ALLOW_XCODE26_COMPATIBILITY" in workflow, "hosted CI explicitly declares Xcode 26 compatibility-only mode")
require("27A266a" in qualification_script and "REQUIRED_IOS_SDK_MAJOR" in qualification_script, "native qualification pins stable Xcode 27 and the iOS 27 SDK")
require("Artifacts/Phase56" in workflow, "CI retains Phase 56 qualification evidence")
require("SWIFT_TREAT_WARNINGS_AS_ERRORS=YES" in qualification_script, "Xcode qualification treats Swift warnings as errors")
require("--family iphone" in qualification_script and "--family ipad" in qualification_script, "Xcode qualification covers iPhone and iPad simulators")
require("analyze" in qualification_script and "archive" in qualification_script, "Xcode qualification performs analysis and archive steps")
require("PrivacyInfo.xcprivacy" in archive_validator and "Assets.car" in archive_validator, "archive validator checks privacy and asset payloads")
require("CODE_SIGNING_ALLOWED=YES" in qualification_script and "CODE_SIGNING_REQUIRED=YES" in qualification_script, "signed qualification explicitly enables code signing")
require((ROOT / "Config/README_SIGNING.md").is_file() and (ROOT / "Config/Signing.xcconfig.example").is_file(), "secure signing handoff documentation is included")

# Phase 53 TestFlight and App Store handoff assertions.
require("DiagnosticReportService.swift in Sources" in pbx, "privacy-safe diagnostic service is compiled by the app target")
require((APP / "DiagnosticReportService.swift").is_file(), "diagnostic report source is included")
require((ROOT / "Scripts/validate_app_store_metadata.py").is_file(), "App Store metadata validator is included")
require((ROOT / "Scripts/validate_testflight_ipa.py").is_file(), "TestFlight IPA validator is included")
require((ROOT / "Scripts/run_submission_harness.py").is_file(), "Phase 56 submission harness is included")
require("-test-iterations 5" in qualification_script, "Xcode qualification repeats unit tests for stabilization")
require(qualification_script.count("testCaptureSubmissionScreenshots") >= 2, "Xcode qualification captures iPhone and iPad screenshot evidence")
require("-exportArchive" in qualification_script and "app-store-connect" in qualification_script, "signed qualification exports an App Store Connect IPA")
require("Upload: Not performed" in qualification_script, "release tooling requires an explicit account-holder upload action")
for relative in [
    "AppStoreConnect/metadata/en-US/name.txt",
    "AppStoreConnect/metadata/en-US/description.txt",
    "AppStoreConnect/review/app_review_notes.txt",
    "AppStoreConnect/review/APP_PRIVACY_RESPONSES.md",
    "AppStoreConnect/review/ACCOUNT_HOLDER_CONFIRMATION.md",
    "AppStoreConnect/testflight/beta_app_description.txt",
    "AppStoreConnect/testflight/what_to_test.txt",
    "AppStoreConnect/screenshots/README.md",
    "support.html",
    "index.html",
]:
    require((ROOT / relative).is_file(), f"submission handoff file exists: {relative}")

# Validate file references for source files and assets.
for match in re.finditer(r"path = ([^;]+); sourceTree = \"<group>\";", pbx):
    raw = match.group(1).strip().strip('"')
    if raw in {"iWorkOrder", "iWorkOrderTests", "iWorkOrderUITests"}:
        continue
    candidates = [APP / raw, ROOT / "iWorkOrderTests" / raw, ROOT / "iWorkOrderUITests" / raw]
    require(any(candidate.exists() for candidate in candidates), f"project reference exists: {raw}")

# Retained Phase 52 accessibility, localization, and iPad adaptivity assertions.
info = plistlib.loads((APP / "Info.plist").read_bytes())
ipad_orientations = set(info.get("UISupportedInterfaceOrientations~ipad", []))
require("UIInterfaceOrientationLandscapeLeft" in ipad_orientations and "UIInterfaceOrientationLandscapeRight" in ipad_orientations, "iPad supports both landscape orientations")
require("UIRequiresFullScreen" not in info, "deprecated UIRequiresFullScreen key is absent so iPad resizing uses the modern scene model")
require((APP / "AccessibilitySupport.swift").is_file(), "shared accessibility support is included")
require((APP / "Localizable.xcstrings").is_file(), "string catalog is included")
try:
    catalog = json.loads((APP / "Localizable.xcstrings").read_text(encoding="utf-8"))
    require(catalog.get("sourceLanguage") == "en" and len(catalog.get("strings", {})) >= 100, "string catalog contains the managed English UI baseline")
except Exception as exc:
    errors.append(f"invalid string catalog: {exc}")
accessibility_modifier_count = len(re.findall(r"\.accessibility(?:Label|Hint|Value|Identifier|Element|AddTraits|Action|Hidden)", swift_source))
require(accessibility_modifier_count >= 35, "accessibility labels, values, identifiers, traits, actions, and hidden decorations are broadly applied")
require("NavigationSplitView" in (APP / "RootView.swift").read_text(encoding="utf-8"), "regular-width iPad navigation uses an adaptive split view")
require("ViewThatFits" in swift_source and "GridItem(.adaptive" in swift_source, "narrow windows and large text use adaptive layouts")
ui_test_source = (ROOT / "iWorkOrderUITests/iWorkOrderUITests.swift").read_text(encoding="utf-8")
require("performAccessibilityAudit" in ui_test_source, "UI automation includes an accessibility audit")
require(ui_test_source.count("@MainActor") >= 5 and "@MainActor\nfinal class iWorkOrderUITests" not in ui_test_source, "UI-test methods use safe main-actor isolation")
require(".textClipped" not in ui_test_source, "UI automation does not suppress text-clipping findings")
require(".font(.system(size:" not in swift_source, "interface source uses semantic Dynamic Type fonts")
require("testQuickAddCreatesAWorkOrder" in ui_test_source and "testSeededWorkOrderCanBeOpened" in ui_test_source, "UI automation covers work-order creation and navigation")
require("-ui-testing-seeded" in ui_test_source and "UITestingConfiguration" in swift_source, "UI tests launch with deterministic local-only data")
require("Localizable.xcstrings in Resources" in pbx, "string catalog is copied by the app target")
require("AccessibilitySupport.swift in Sources" in pbx, "accessibility support is compiled by the app target")
require("testSupportDiagnosticsCanBeOpened" in ui_test_source, "UI automation covers support diagnostics")
require("testCaptureSubmissionScreenshots" in ui_test_source, "UI automation captures submission screenshots")
unit_test_source = (ROOT / "iWorkOrderTests/iWorkOrderTests.swift").read_text(encoding="utf-8")
require("DiagnosticReportTests" in unit_test_source, "unit tests cover diagnostic report privacy and file creation")
require("SupportDiagnosticsView" in swift_source, "privacy-safe support diagnostics screen is included")
require("recentErrorPresent" in (APP / "DiagnosticReportService.swift").read_text(encoding="utf-8"), "diagnostics expose error presence without exporting error content")

# Phase 54 maintenance, migration, and rollback assertions.
maintenance_source = (APP / "MaintenanceService.swift").read_text(encoding="utf-8")
require((APP / "MaintenanceService.swift").is_file(), "maintenance service source is included")
require("MaintenanceService.swift in Sources" in pbx, "maintenance service is compiled by the app target")
require("dataSchemaVersion" in (APP / "AppStore.swift").read_text(encoding="utf-8"), "app snapshots persist an explicit data schema")
require("currentVersion = 3" in maintenance_source and "oldestSupportedVersion = 1" in maintenance_source, "schema support range is explicit")
require("createMigrationBackup" in maintenance_source and "maximumMigrationBackupCount = 5" in maintenance_source, "migrations create retained recovery copies")
require("unsupportedFutureVersion" in maintenance_source and "DataCompatibilityBlockedView" in (APP / "RootView.swift").read_text(encoding="utf-8"), "future schemas enter protected compatibility mode")
require("guard !isDataCompatibilityBlocked else { return false }" in (APP / "AppStore.swift").read_text(encoding="utf-8"), "compatibility mode blocks local saves")
require("maximumEventCount = 250" in maintenance_source and "eventRetentionDays = 30" in maintenance_source, "operational history has fixed count and age limits")
for forbidden in ["profile.personName", "profile.buildingAddress", "issueDescription", "auditLog", "DeviceIdentity.current"]:
    require(forbidden not in maintenance_source, f"maintenance history does not access personal field: {forbidden}")
require("MaintenanceRecoveryView" in swift_source and "Maintenance & Recovery" in swift_source, "maintenance and recovery screen is included")
require("testMaintenanceRecoveryCanRunHealthCheck" in ui_test_source, "UI automation covers maintenance health checks")
require("MaintenanceAndMigrationTests" in unit_test_source, "unit tests cover migration and maintenance privacy")
for relative in ["MIGRATION_AND_RECOVERY_GUIDE.md", "RELEASE_ROLLBACK_RUNBOOK.md", "OPERATIONAL_HISTORY_PRIVACY.md", "VERIFICATION_NOTES_v54_MAINTENANCE_MIGRATION_ROLLBACK.md"]:
    require((ROOT / relative).is_file(), f"Phase 54 handoff file exists: {relative}")
require("2026.09.16.56" in (APP / "LegalContent.swift").read_text(encoding="utf-8"), "current legal version retains Phase 54 maintenance disclosure")
require("phase56_xcode_qualification.sh" in workflow or "run_xcode_ci.sh" in workflow, "CI invokes Phase 56 qualification")
require("Artifacts/Phase56" in workflow, "CI retains Phase 56 qualification evidence")
require((ROOT / "Scripts/run_maintenance_harness.py").is_file(), "migration and maintenance executable harness is included")
cloud_sync_source = (APP / "CloudSyncService.swift").read_text(encoding="utf-8")
backup_archive_source = (APP / "BackupArchiveService.swift").read_text(encoding="utf-8")
app_store_source = (APP / "AppStore.swift").read_text(encoding="utf-8")
require("MaintenanceService.migrate(snapshot).snapshot" in cloud_sync_source, "CloudKit snapshots are schema-validated before restore or merge")
require("unsupportedFutureVersion" in cloud_sync_source and "incompatibleDataSchema" in cloud_sync_source, "CloudKit rejects unsupported future schemas")
require("snapshotSchemaVersion = AppDataSchema.currentVersion" in backup_archive_source, "portable backups use the current application schema")
require("migrateDecodedSnapshot" in backup_archive_source and "MaintenanceService.migrate(snapshot)" in backup_archive_source, "imported backups are migrated before installation")
require("MaintenanceService.migrate(sourceSnapshot)" in app_store_source, "all AppStore snapshot ingress passes through schema migration")

# Phase 55 field reliability and issue-containment assertions.
runtime_source = (APP / "RuntimeReliabilityService.swift").read_text(encoding="utf-8")
support_bundle_source = (APP / "SupportBundleService.swift").read_text(encoding="utf-8")
app_source = (APP / "iWorkOrderApp.swift").read_text(encoding="utf-8")
settings_source = (APP / "CalendarHubSettingsViews.swift").read_text(encoding="utf-8")
require((APP / "RuntimeReliabilityService.swift").is_file(), "runtime reliability service is included")
require((APP / "SupportBundleService.swift").is_file(), "support bundle service is included")
require("RuntimeReliabilityService.swift in Sources" in pbx and "SupportBundleService.swift in Sources" in pbx, "Phase 55 services are compiled by the app target")
require("RuntimeReliabilityService.beginSession()" in app_source, "app launch begins a runtime reliability session")
require("applicationDidReceiveMemoryWarning" in app_source and "noteMemoryWarning" in app_source, "memory warnings are captured as aggregate reliability evidence")
require("transition(to: .background)" in app_source and "lifecycleState != .background" in runtime_source, "clean background sessions are distinguished from possible interruptions")
require("does not claim that a crash occurred" in runtime_source.lower(), "runtime evidence explicitly avoids claiming a crash")
require("maximumEventCount = 250" in maintenance_source and "eventRetentionDays = 30" in maintenance_source, "Phase 55 reliability events retain existing bounded history limits")
require("case sessionInterrupted" in maintenance_source and "case memoryPressure" in maintenance_source, "maintenance history includes fixed reliability event categories")
require("case recoverySyncPauseChanged" in maintenance_source and "case supportBundleExport" in maintenance_source, "maintenance history includes fixed containment and export categories")
require("cloudSyncPausedForRecovery" in app_store_source and "setCloudSyncPausedForRecovery" in app_store_source, "AppStore exposes a user-controlled recovery sync pause")
require(app_store_source.count("guard !cloudSyncPausedForRecovery") >= 5, "ordinary CloudKit paths are blocked while recovery pause is enabled")
require("isCloudErasePending" in app_store_source and "isCloudReplacementPending" in app_store_source, "pending cloud erase and replacement transactions remain explicitly tracked")
require("Pause Cloud Sync for Recovery" in settings_source and "maintenance.cloudRecoveryPause" in (APP / "AccessibilitySupport.swift").read_text(encoding="utf-8"), "recovery pause is visible in Cloud and Maintenance settings")
require("com.damiancedeno.iworkorder.support" in support_bundle_source and "formatVersion = 1" in support_bundle_source, "support bundle has a versioned format identifier")
require("contentSHA256" in support_bundle_source and "SHA256.hash" in support_bundle_source, "support bundle content is protected by SHA-256")
require("checksumMismatch" in support_bundle_source and "validateBundle" in support_bundle_source, "support bundle tampering is rejected")
require("maximumRecentEventCount = 100" in support_bundle_source, "support bundle event evidence is bounded")
for forbidden in ["personName", "buildingAddress", "issueDescription", "auditLog", "DeviceIdentity.current", "photoFilenames", "signatureFilename"]:
    require(forbidden not in support_bundle_source, f"support bundle does not access operational field: {forbidden}")
require("UTExportedTypeDeclarations" in str(info) and "iworkordersupport" in str(info), "support bundle file type is declared in Info.plist")
require("RuntimeReliabilityTests" in unit_test_source and "SupportBundleTests" in unit_test_source, "unit tests cover runtime reliability and support bundle integrity")
require("testRecoveryCloudPauseCanBeEnabledAndDisabled" in ui_test_source, "UI automation covers the recovery sync pause")
require((ROOT / "Scripts/run_reliability_harness.py").is_file(), "runtime reliability executable harness is included")
for relative in ["FIELD_RELIABILITY_AND_ISSUE_CONTAINMENT.md", "SUPPORT_BUNDLE_FORMAT.md", "VERIFICATION_NOTES_v55_FIELD_RELIABILITY_ISSUE_CONTAINMENT.md"]:
    require((ROOT / relative).is_file(), f"Phase 55 handoff file exists: {relative}")
require("2026.09.16.56" in (APP / "LegalContent.swift").read_text(encoding="utf-8"), "current legal version retains Phase 55 reliability disclosure")
require("run_reliability_harness.py" in qualification_script, "Xcode qualification executes the runtime reliability harness")
require("testRecoveryCloudPauseCanBeEnabledAndDisabled" in qualification_script, "Xcode qualification runs focused recovery-pause UI coverage")
require("phase56-hosted-xcode-compatibility" in workflow, "CI publishes hosted Xcode compatibility evidence")

# Phase 56 Apple release qualification assertions.
phase56_evidence_validator = (ROOT / "Scripts/validate_phase56_evidence.py").read_text(encoding="utf-8")
phase56_indexer = (ROOT / "Scripts/index_phase56_artifacts.py").read_text(encoding="utf-8")
require((ROOT / "PHASE56_MAC_EXECUTION_GUIDE.md").is_file(), "Phase 56 Mac execution guide is included")
require((ROOT / "PHASE56_DEVICE_TEST_MATRIX.md").is_file(), "Phase 56 physical-device matrix is included")
require((ROOT / "VERIFICATION_NOTES_v56_APPLE_RELEASE_QUALIFICATION.md").is_file(), "Phase 56 verification notes are included")
require((ROOT / "ReleaseEvidence/phase56_evidence.template.json").is_file(), "Phase 56 evidence template is included")
require((ROOT / "Scripts/validate_phase56_evidence.py").is_file(), "Phase 56 evidence validator is included")
require((ROOT / "Scripts/index_phase56_artifacts.py").is_file(), "Phase 56 artifact indexer is included")
require('BUILD_NUMBER="56"' in qualification_script, "Phase 56 Xcode runner validates build 56")
require('PHASE56_FINAL_GATE' in qualification_script and '--require-complete' in qualification_script, "Phase 56 runner has a strict final evidence gate")
require('PHASE56_IPHONE_DEVICE_ID' in qualification_script and 'PHASE56_IPAD_DEVICE_ID' in qualification_script, "Phase 56 runner supports connected iPhone and iPad evidence")
require('codesign --verify --deep --strict' in qualification_script and 'signed-entitlements.plist' in qualification_script, "Phase 56 runner captures signature and entitlement evidence")
require('EVIDENCE_INDEX.json' in phase56_indexer and 'sha256' in phase56_indexer, "Phase 56 evidence files receive a SHA-256 index")
require('required passing gate' in phase56_evidence_validator and 'evidence escapes qualification root' in phase56_evidence_validator, "Phase 56 validator rejects incomplete or unsafe evidence")
require('phase56-hosted-xcode-compatibility' in workflow, "CI publishes hosted Xcode compatibility evidence")

# Security and signature assertions.
require("UIApplication.closeApp" not in swift_source, "no programmatic app termination remains")
require("drawing.strokes.isEmpty" in (APP / "SignatureCaptureView.swift").read_text(), "blank signatures are blocked")
require("signatureConsentVersion" in swift_source, "signature consent metadata is persisted")
require("EmailHelper.email(" not in swift_source, "obsolete EmailHelper.email compile references are removed")
work_order_views = (APP / "WorkOrderViews.swift").read_text()
require("private func presentEmail()" in work_order_views and "mailDraft = EmailHelper.draft(order: order)" in work_order_views, "row email actions use the native MailDraft presentation flow")
require("let attachmentDescription: String" in work_order_views and "if let diagnosticsURL" in work_order_views, "support email safely unwraps the optional diagnostics URL")
require((ROOT / "VERIFICATION_NOTES_v56_HOTFIX1_XCODE_COMPILE.md").is_file(), "Phase 56 Xcode compile hotfix notes are included")
onboarding_source = (APP / "OnboardingView.swift").read_text(encoding="utf-8")
legal_view_source = (APP / "CalendarHubSettingsViews.swift").read_text(encoding="utf-8")
require('showAccept: true,\n                accept: {' in onboarding_source, "onboarding legal sheet wires the Agree action explicitly")
require('LegalDocumentView(title: "Legal Agreement", document: .agreement, showAccept: true) {' not in onboarding_source, "ambiguous onboarding legal trailing closure is absent")
require('.disabled(accept == nil)' in legal_view_source and '.accessibilityIdentifier("legal.accept")' in legal_view_source, "legal Agree action cannot silently run without a callback")
require('testOnboardingLegalAgreementAcceptsAndDismisses' in ui_test_source, "UI automation verifies legal acceptance and sheet dismissal")
require((ROOT / "VERIFICATION_NOTES_v56_HOTFIX2_LEGAL_ACCEPTANCE.md").is_file(), "Phase 56 legal acceptance hotfix notes are included")
services_source = (APP / "Services.swift").read_text(encoding="utf-8")
cloud_source = (APP / "CloudSyncService.swift").read_text(encoding="utf-8")
root_source = (APP / "RootView.swift").read_text(encoding="utf-8")
onboarding_source = (APP / "OnboardingView.swift").read_text(encoding="utf-8")
calendar_source = (APP / "CalendarHubSettingsViews.swift").read_text(encoding="utf-8")
app_entry_source = (APP / "iWorkOrderApp.swift").read_text(encoding="utf-8")
require("@MainActor\nfinal class NotificationService" in services_source, "notification routing state is main-actor isolated")
require("final class NotificationService: NSObject, UNUserNotificationCenterDelegate" in services_source, "notification delegate conformance uses the native Swift 6 form")
require("@preconcurrency UNUserNotificationCenterDelegate" not in services_source, "ineffective @preconcurrency notification conformance is absent")
require("(@MainActor @Sendable (UUID) -> Void)?" in services_source, "notification route callback is actor-isolated and Sendable")
require("private enum AddressVerificationResult: Sendable" in services_source and "(@MainActor @Sendable (String) -> Void)?" in services_source, "address verification transfers only Sendable results to UI state")
require("DispatchQueue.main.async { self.openWorkOrder" not in services_source and "DispatchQueue.main.async { handler" not in services_source, "unsafe notification dispatch captures are absent")
require("struct SecurityService: Sendable" in services_source, "stateless authentication service is Sendable")
require("let callback = statusChanged" in cloud_source and "pathUpdateHandler = { path in" in cloud_source and "[weak self] path" not in cloud_source, "network monitor callback does not capture a non-Sendable service")
require("@MainActor\nstruct RootView" in root_source and "@MainActor\nstruct OnboardingView" in onboarding_source, "primary SwiftUI roots are explicitly main-actor isolated")
require("@MainActor\nstruct SecurityView" in calendar_source and "@MainActor\nstruct NotificationSettingsView" in calendar_source, "settings views that own UI services are main-actor isolated")
require("@MainActor\nfinal class AppDelegate" in app_entry_source and "@MainActor\nstruct iWorkOrderApp" in app_entry_source, "application lifecycle access to UI services is main-actor isolated")
require("private let dismissAction: @MainActor @Sendable () -> Void" in work_order_views and "nonisolated func mailComposeController" in work_order_views, "Mail composer dismissal crosses the delegate boundary safely")
require("@MainActor\n    static func openSupportEmail" in work_order_views, "UIKit URL opening is main-actor isolated")
require((ROOT / "VERIFICATION_NOTES_v56_HOTFIX3_SWIFT6_CONCURRENCY.md").is_file(), "Phase 56 Swift 6 concurrency hotfix notes are included")
require((ROOT / "VERIFICATION_NOTES_v56_HOTFIX4_PRECONCURRENCY_WARNING.md").is_file(), "Phase 56 ineffective preconcurrency warning hotfix notes are included")
signature_source = (APP / "SignatureCaptureView.swift").read_text(encoding="utf-8")
require("func makeCoordinator() -> Coordinator" in signature_source, "signature canvas creates a PencilKit delegate coordinator")
require("view.delegate = context.coordinator" in signature_source, "signature canvas connects the PencilKit delegate")
require("func canvasViewDrawingDidChange(_ canvasView: PKCanvasView)" in signature_source and "drawing.wrappedValue = canvasView.drawing" in signature_source, "signature strokes update the SwiftUI binding")
require('testSignatureDrawingEnablesCompletionButtons' in ui_test_source, "UI automation verifies signature strokes enable completion controls")
require('workOrder.signAndSave' in work_order_views and 'workOrder.status' in work_order_views, "completion flow exposes stable UI automation identifiers")
require((ROOT / "VERIFICATION_NOTES_v56_HOTFIX5_SIGNATURE_COMPLETION.md").is_file(), "Phase 56 signature completion hotfix notes are included")

# Phase 56 Hotfix 6 defect-only stabilization assertions.
models_source = (APP / "Models.swift").read_text(encoding="utf-8")
require("var hasRequiredFields: Bool" in models_source and "func normalizeUserEnteredText()" in models_source, "required work-order fields are validated and normalized")
require("expectedLatestEntryID" in app_store_source and "latestEntry.id != expectedLatestEntryID" in app_store_source, "stale revisions cannot overwrite newer synchronized data")
require("func save() -> Bool" in app_store_source and app_store_source.count("workOrders = originalWorkOrders") >= 3, "core work-order mutations roll back after local persistence failure")
require("guard onDone() else" in signature_source and "SignatureStorageService.delete(filename: filename)" in signature_source, "signature completion is committed transactionally")
require("@State private var isSaving = false" in signature_source, "signature save rejects rapid duplicate submission")
require("[.calendar, .timeZone, .year, .month, .day, .hour, .minute, .second]" in services_source, "near-term reminders preserve seconds")
require("var id: String { url.absoluteString }" in work_order_views, "share-sheet URL identity is stable")
require("cleanupUncommittedImages" in work_order_views and "cleanupUncommittedAttachments" in work_order_views, "cancelled drafts clean unreferenced attachments")
require("setStorageChoice(choice)" in onboarding_source and "store.setICloudEnabled(enabled)" in onboarding_source, "onboarding iCloud controls cannot diverge")
require(r'Theme2MiniStat(title: "Overdue", value: "\(overdue)"' in work_order_views, "Theme 2 overdue count is live")
require(r'Theme2MiniStat(title: "Workers", value: "\(workers)"' in work_order_views, "Theme 2 worker count is live")
require("Theme2FilterRow()" not in work_order_views, "nonfunctional Theme 2 filter controls are not displayed")
require("saveSignature.tap()" in ui_test_source and 'app.buttons["Making Changes"]' in ui_test_source, "UI automation verifies successful signed completion")
require((ROOT / "Scripts/run_defect_harness.py").is_file(), "Hotfix 6 defect harness is included")
require("run_defect_harness.py" in qualification_script, "Xcode qualification executes the Hotfix 6 defect harness")
require((ROOT / "VERIFICATION_NOTES_v56_HOTFIX6_DEFECT_STABILIZATION.md").is_file(), "Phase 56 defect stabilization notes are included")
require("isOnboardingComplete" in (APP / "RootView.swift").read_text(), "onboarding completion is gated independently")
require("hasCurrentLegalAcceptance" in (APP / "RootView.swift").read_text(), "current legal version is enforced")

# Phase 56 Hotfix 7 transactional-integrity assertions.
transactional_harness = (ROOT / "Scripts/run_transactional_harness.py").read_text(encoding="utf-8")
require("deletionTransition(for:" in services_source and "merged.isDeleted = a.isDeleted || b.isDeleted" not in services_source, "recovery can override an older cloud deletion")
require("nextSaveRevisionCandidate" in services_source and "commitSaveRevision" in services_source, "save revisions commit only after persistence")
require("workOrdersBeforeIntegrityRepair" in app_store_source, "failed saves roll back in-memory integrity repairs")
require("guard !workOrders[index].isSignedAndLocked else { return }" in app_store_source, "viewing signed legal evidence does not mutate its audit trail")
require("retainedFilenames" in app_store_source and app_store_source.index("guard save() else", app_store_source.index("func purgeOldData")) < app_store_source.index("ImageStorageService.deleteUnreferenced", app_store_source.index("func purgeOldData")), "retention cleanup saves before deleting unreferenced attachments")
require("deleteUnreferenced(keeping: retainedFilenames)" in app_store_source and "cleanup.failedFilenames" in app_store_source, "retention cleanup verifies physical deletion and retries orphaned files")
require("verificationGeneration" in services_source and "generation == verificationGeneration" in services_source, "stale address verification callbacks are rejected")
require("captureInMemorySnapshotContents" in app_store_source and app_store_source.count("guard repairAndPersistLoadedState() else") >= 3, "cloud-applied state rolls back when local persistence fails")
require("if store.addAsset(asset)" in settings_source and "if store.addTenant(tenant)" in settings_source, "directory forms clear only after successful persistence")
require("run_transactional_harness.py" in qualification_script, "Xcode qualification executes the Hotfix 7 transactional harness")
require((ROOT / "Scripts/run_transactional_harness.py").is_file(), "Hotfix 7 transactional harness is included")
require((ROOT / "VERIFICATION_NOTES_v56_HOTFIX7_TRANSACTIONAL_INTEGRITY.md").is_file(), "Phase 56 transactional-integrity notes are included")
require("HOTFIX 7 TRANSACTIONAL HARNESS: PASS" in transactional_harness, "Hotfix 7 harness has a strict pass marker")

# Phase 56 Hotfix 8 Xcode 26 ScrollView initializer disambiguation.
all_swift_source = "\n".join(
    path.read_text(encoding="utf-8")
    for path in APP.rglob("*.swift")
)
require("ScrollView {" not in all_swift_source, "vertical ScrollView initializers are explicit under Xcode 26")
require("SwiftUI.ScrollView(.vertical, showsIndicators: true)" in work_order_views, "work-order screens use the unambiguous SwiftUI ScrollView initializer")
require((ROOT / "VERIFICATION_NOTES_v56_HOTFIX8_SCROLLVIEW_INITIALIZER.md").is_file(), "Phase 56 ScrollView initializer hotfix notes are included")

# Phase 56 Hotfix 9 SwiftUI action return-type disambiguation.
require("_ = store.moveToTrash(order)" in work_order_views, "trash row action explicitly discards the Boolean persistence result")
require("withAnimation { store.moveToTrash(order) }" not in work_order_views, "SwiftUI action closures do not leak Bool results through withAnimation")
require((ROOT / "VERIFICATION_NOTES_v56_HOTFIX9_ACTION_RESULT_AMBIGUITY.md").is_file(), "Phase 56 action-result ambiguity hotfix notes are included")

# Phase 56 Hotfix 10 persisted Category Manager.
models_source = (APP / "Models.swift").read_text(encoding="utf-8")
require("struct WorkOrderCategory: RawRepresentable" in models_source, "categories use a dynamic string-backed value type")
require("defaultCategories" in models_source and "singleValueContainer" in models_source, "category defaults preserve legacy string coding")
require("enum LegacyWorkOrderCategory" in models_source and "customCategoryName" in models_source and "var managedCategory" in models_source, "custom categories retain a legacy-decodable work-order wire format")
require("@Published private(set) var categories" in app_store_source, "managed categories are observable application state")
require("func addCategory(named" in app_store_source and "func deleteCategories(at" in app_store_source and "func moveCategories(from" in app_store_source, "category add, delete, and reorder operations are implemented")
require("persistCategoryConfiguration" in app_store_source and "categories = originalCategories" in app_store_source, "category changes roll back when persistence fails")
require("categoryConfigurationUpdatedAt" in app_store_source and "categoryConfigurationUpdatedAt" in services_source, "category ordering participates in CloudKit conflict resolution")
require("ForEach(store.categories)" in settings_source and ".onMove" in settings_source and ".onDelete" in settings_source, "Category Manager exposes reorder and delete controls")
require("showAddCategory" in settings_source and "store.addCategory" in settings_source, "Category Manager exposes category creation")
require("WorkOrderCategory.allCases" not in all_swift_source, "no screen bypasses the managed category source")
require(work_order_views.count("store.filterCategories") >= 2, "all dashboard category filters use managed categories")
require("store.categoryOptions" in work_order_views and "preserveCurrentCategory" in work_order_views, "work-order forms use managed categories while preserving historical values")
require("entry.managedCategory = defaultCategory" in app_store_source, "Quick Add uses the first managed category")
require("currentVersion = 3" in maintenance_source and "if version == 2" in maintenance_source, "schema 3 migration persists category configuration")
require("testCategoryManagerAddsAndDeletesCategory" in ui_test_source, "UI automation covers Category Manager add and delete")
require("CategoryConfigurationTests" in unit_test_source and "testCategoryReorderingPreservesRequestedOrder" in unit_test_source and "testNewestCategoryConfigurationWinsCloudMergeIndependentlyOfSnapshotDate" in unit_test_source and "testCustomCategoryKeepsLegacyWireValueForForwardSchemaProtection" in unit_test_source, "unit tests cover category coding, reordering, migration, downgrade safety, and cloud conflict resolution")
require((ROOT / "VERIFICATION_NOTES_v56_HOTFIX10_CATEGORY_MANAGER.md").is_file(), "Phase 56 Category Manager hotfix notes are included")

# Phase 56 Hotfix 12 iterative core-stability hardening.
core_stability_harness = (ROOT / "Scripts/run_core_stability_harness.py").read_text(encoding="utf-8")
require("static func identityKey" in models_source and 'Locale(identifier: "en_US_POSIX")' in models_source, "category identity is deterministic across device locales")
require("pendingDeleteCategories" in settings_source and "pendingDeleteOffsets" not in settings_source, "category delete confirmation retains stable identities instead of row indexes")
require("enum AttachmentFilenamePolicy" in services_source and "safeURL(forFilename" in services_source, "persisted attachment filenames are constrained to attachment directories")
require("AttachmentFilenamePolicy.isSafe(filename)" in (APP / "BackupArchiveService.swift").read_text(encoding="utf-8"), "backup attachment validation uses the shared filename policy")
require("AttachmentFilenamePolicy.isSafe(filename)" in (APP / "CloudSyncService.swift").read_text(encoding="utf-8"), "CloudKit attachment validation uses the shared filename policy")
require("order.entries.map(\\.createdAt).max()" in services_source, "cloud conflict freshness includes work-order revision timestamps")
require("scheduleCloudSync(currentSnapshot(incrementSaveRevision: true))" not in app_store_source, "post-resync CloudKit upload uses the committed local save revision")
require("recoveredPersistedSnapshot && onboardingPersistence.hasCompletedOnboarding" in app_store_source, "onboarding completion requires recovered persisted app data")
require("$store.profile.notificationsEnabled" not in settings_source and "updateNotificationsEnabled" in settings_source, "notification settings avoid recursive direct-binding persistence")
require("$store.profile.notificationsEnabled" not in (APP / "OnboardingView.swift").read_text(encoding="utf-8") and "updateNotificationPreference" in (APP / "OnboardingView.swift").read_text(encoding="utf-8"), "onboarding notification permission avoids recursive direct-binding persistence")
require("save(migrated, rotatePrimaryIntoFallback: false)" in services_source and "rotatePrimaryIntoFallback: !recoveringFromFallback" in services_source, "fallback recovery cannot rotate a corrupt primary over the known-good fallback")
require("rotatePrimarySnapshotIntoFallback" in services_source and "replaceItemAt(backupURL, withItemAt: stagedBackup)" in services_source, "ordinary saves stage fallback replacement before discarding the previous recovery copy")
require("run_core_stability_harness.py" in qualification_script, "Xcode qualification executes the current core-stability harness")
require((ROOT / "Scripts/run_core_stability_harness.py").is_file(), "current core-stability harness is included")
require("HOTFIX 16 CORE STABILITY HARNESS: PASS" in core_stability_harness, "Hotfix 16 harness has a strict pass marker")
require("entry.images.forEach(ImageStorageService.delete)" not in (APP / "WorkOrderViews.swift").read_text(encoding="utf-8"), "draft-image cleanup does not pass a Bool-returning delete function directly to forEach")
require((ROOT / "VERIFICATION_NOTES_v56_HOTFIX11_CORE_STABILITY.md").is_file(), "Phase 56 Hotfix 11 core-stability notes are retained")
require((ROOT / "VERIFICATION_NOTES_v56_HOTFIX12_CORE_STABILITY_LOOP.md").is_file(), "Phase 56 Hotfix 12 iterative core-stability notes are included")
require((ROOT / "VERIFICATION_NOTES_v56_HOTFIX15_XCODE_ACCESS_CONTROL.md").is_file(), "Phase 56 Hotfix 15 Xcode access-control notes are included")
require((ROOT / "VERIFICATION_NOTES_v56_HOTFIX16_FOREACH_COMPILE_FIX.md").is_file(), "Phase 56 Hotfix 16 Swift 6 forEach compile-fix notes are included")
public_release_harness = (ROOT / "Scripts/run_public_release_harness.py").read_text(encoding="utf-8")
require((ROOT / "Scripts/run_public_release_harness.py").is_file(), "Hotfix 17 public-release harness is included")
require("PUBLIC RELEASE HARNESS: PASS" in public_release_harness, "Hotfix 17 public-release harness has a strict pass marker")
require("run_public_release_harness.py" in (ROOT / "Scripts/verify_release.sh").read_text(encoding="utf-8"), "cross-platform verification executes the public-release harness")
require("run_public_release_harness.py" in qualification_script, "Xcode qualification records the public-release surface harness")
require((ROOT / "VERIFICATION_NOTES_v56_HOTFIX17_PUBLIC_RELEASE_CLEANUP.md").is_file(), "Phase 56 Hotfix 17 public-release cleanup notes are included")

# Phase 56 Hotfix 18 entire-app public-beta qualification.
public_beta_harness_path = ROOT / "Scripts/run_public_beta_harness.py"
require(public_beta_harness_path.is_file(), "Hotfix 18 public-beta harness is included")
if public_beta_harness_path.is_file():
    public_beta_harness = public_beta_harness_path.read_text(encoding="utf-8")
    require("HOTFIX 18 PUBLIC BETA HARNESS: PASS" in public_beta_harness, "Hotfix 18 public-beta harness has a strict pass marker")
require("run_public_beta_harness.py" in (ROOT / "Scripts/verify_release.sh").read_text(encoding="utf-8"), "cross-platform verification executes the Hotfix 18 public-beta harness")
require("run_public_beta_harness.py" in qualification_script, "Xcode qualification records the Hotfix 18 public-beta harness")
require("CGImageSourceCreateThumbnailAtIndex" in services_source and "WorkOrderImageThumbnailCache" in services_source, "evidence gallery uses bounded background thumbnail generation instead of repeated full-size UI decoding")
require("ImageStorageService.load(image)" not in work_order_views, "work-order views do not synchronously decode full-size evidence attachments")
require("accessibilityReduceMotion" in work_order_views and "accessibilityReduceTransparency" in (APP / "Components.swift").read_text(encoding="utf-8"), "custom work-order surfaces honor Reduce Motion and Reduce Transparency")
require("toolbarBackground(.ultraThinMaterial, for: .tabBar)" not in (APP / "RootView.swift").read_text(encoding="utf-8"), "system tab bar appearance is not overridden with custom material")
require('Sync failed - tap to retry' not in work_order_views and 'Label("Sync ready"' not in work_order_views, "legacy themes do not present hard-coded cloud status")
require('Button("Google Drive")' not in settings_source_for_legal and 'Button("OneDrive")' not in settings_source_for_legal, "report export does not claim provider-specific integrations it does not perform")
require((ROOT / "VERIFICATION_NOTES_v56_HOTFIX18_PUBLIC_BETA_QUALIFICATION.md").is_file(), "Phase 56 Hotfix 18 public-beta qualification notes are included")

# Phase 56 Hotfix 19 release-candidate hardening.
release_candidate_harness_path = ROOT / "Scripts/run_release_candidate_harness.py"
require(release_candidate_harness_path.is_file(), "Hotfix 19 release-candidate harness is included")
if release_candidate_harness_path.is_file():
    release_candidate_harness = release_candidate_harness_path.read_text(encoding="utf-8")
    require("HOTFIX 19 RELEASE CANDIDATE HARNESS: PASS" in release_candidate_harness, "Hotfix 19 release-candidate harness has a strict pass marker")
require("run_release_candidate_harness.py" in (ROOT / "Scripts/verify_release.sh").read_text(encoding="utf-8"), "cross-platform verification executes the Hotfix 19 release-candidate harness")
require("run_release_candidate_harness.py" in qualification_script, "Xcode qualification records the Hotfix 19 release-candidate harness")
require("AppPrivacyShieldView" in (APP / "iWorkOrderApp.swift").read_text(encoding="utf-8") and "scenePhase != .active" in (APP / "iWorkOrderApp.swift").read_text(encoding="utf-8"), "inactive/background scenes obscure operational content before task-switcher snapshots")
require("NSPhotoLibraryUsageDescription" not in (APP / "Info.plist").read_text(encoding="utf-8"), "public Info.plist does not request unnecessary full photo-library access")
permission_usage_keys = {key for key in info.keys() if key.startswith("NS") and key.endswith("UsageDescription")}
require(permission_usage_keys == {"NSCameraUsageDescription", "NSFaceIDUsageDescription"}, "Info.plist declares only protected-resource purpose strings used by current features")
require("PermissionSetupView" in onboarding_source and "Request iOS Permissions" in onboarding_source, "first-use permission review UI is present")
require("requestPermission()" in onboarding_source and "FlashlightService.requestCameraPermission()" in onboarding_source, "first-use review requests notification and torch-only camera authorization")
require("Full Photo Library permission is not requested" in onboarding_source and "Location" in onboarding_source and "Contacts & Calendar" in onboarding_source and "Microphone" in onboarding_source, "permission review explains protected resources the app intentionally does not request")
require("else if !store.hasCompletedPermissionSetup" in root_source, "normal app access is gated on completion of the device-local permission review")
require("PermissionSetupPersistenceService" in swift_source and "NSUbiquitousKeyValueStore" not in swift_source[swift_source.find("final class PermissionSetupPersistenceService"):swift_source.find("extension JSONEncoder")], "permission-review completion stays device-local rather than syncing through backup/iCloud state")
require("device.isTorchAvailable" in services_source and "device.isTorchModeSupported(.on)" in services_source, "optional flashlight validates live torch hardware availability")
require("CloudKit" not in app_store_source, "public cloud status strings use iCloud wording")
require((ROOT / "VERIFICATION_NOTES_v56_HOTFIX19_RELEASE_CANDIDATE_HARDENING.md").is_file(), "Phase 56 Hotfix 19 release-candidate notes are included")

# Phase 56 Hotfix 20 final release-candidate audit.
final_rc_harness_path = ROOT / "Scripts/run_final_rc_harness.py"
require(final_rc_harness_path.is_file(), "Hotfix 20 final release-candidate harness is included")
if final_rc_harness_path.is_file():
    final_rc_harness = final_rc_harness_path.read_text(encoding="utf-8")
    require("HOTFIX 20 FINAL RELEASE CANDIDATE HARNESS: PASS" in final_rc_harness, "Hotfix 20 final-RC harness has a strict pass marker")
require("run_final_rc_harness.py" in (ROOT / "Scripts/verify_release.sh").read_text(encoding="utf-8"), "cross-platform verification executes the Hotfix 20 final-RC harness")
require("run_final_rc_harness.py" in qualification_script, "Xcode qualification records the Hotfix 20 final-RC harness")
require("static func saveCompressed(data sourceData: Data" in services_source and "CGImageSourceCreateWithData(sourceData as CFData" in services_source, "picker evidence uses bounded ImageIO conversion")
require("AVCaptureDevice.authorizationStatus(for: .video)" in services_source and "await AVCaptureDevice.requestAccess(for: .video)" in services_source, "optional flashlight is camera-authorization aware")
require("phase != .active, torchOn" in work_order_views, "evidence-form lifecycle turns off the flashlight outside the active foreground")
require('InfoLine(title: "Local Storage", value: StorageService().localDataSizeText())' not in settings_source_for_legal, "Support view does not recursively scan local storage during body rendering")
require((ROOT / "VERIFICATION_NOTES_v56_HOTFIX20_FINAL_RELEASE_CANDIDATE.md").is_file(), "Phase 56 Hotfix 20 final release-candidate notes are included")

# Phase 56 Hotfix 21 real-world beta hardening.
hotfix21_harness_path = ROOT / "Scripts/run_hotfix21_real_world_beta_harness.py"
require(hotfix21_harness_path.is_file(), "Hotfix 21 real-world beta harness is included")
if hotfix21_harness_path.is_file():
    hotfix21_harness = hotfix21_harness_path.read_text(encoding="utf-8")
    require("HOTFIX 21 REAL-WORLD BETA HARNESS: PASS" in hotfix21_harness, "Hotfix 21 real-world beta harness has a strict pass marker")
require("run_hotfix21_real_world_beta_harness.py" in (ROOT / "Scripts/verify_release.sh").read_text(encoding="utf-8"), "cross-platform verification executes the Hotfix 21 real-world beta harness")
require("run_hotfix21_real_world_beta_harness.py" in qualification_script, "Xcode qualification records the Hotfix 21 real-world beta harness")
require('static let reminderPrefix = "iworkorder.reminder."' in services_source and 'static let emergencyPrefix = "iworkorder.emergency."' in services_source, "reminders and emergency follow-ups have independent notification identifiers")
require("order.latestEntry.createdAt.addingTimeInterval(10)" in services_source, "emergency follow-ups are anchored to the committed revision time")
require("reconciliationGeneration" in services_source, "notification reconciliation rejects stale asynchronous cleanup")
require(".remoteNotification" not in (APP / "iWorkOrderApp.swift").read_text(encoding="utf-8"), "Release app has no dormant remote-push launch path")
require(work_order_views.count('.onChange(of: store.activeWorkOrders.map(\\.id)) { _, _ in openDeepLinkedOrderIfNeeded() }') == 3, "all work-order themes retry a pending deep link when data arrives")
require((ROOT / "VERIFICATION_NOTES_v56_HOTFIX21_REAL_WORLD_BETA.md").is_file(), "Phase 56 Hotfix 21 real-world beta notes are included")

# Phase 56 Hotfix 23 Xcode runtime-warning cleanup.
hotfix23_harness_path = ROOT / "Scripts/run_hotfix23_xcode_runtime_harness.py"
require(hotfix23_harness_path.is_file(), "Hotfix 23 Xcode runtime cleanup harness is included")
if hotfix23_harness_path.is_file():
    hotfix23_harness = hotfix23_harness_path.read_text(encoding="utf-8")
    require("HOTFIX 23 XCODE RUNTIME CLEANUP HARNESS: PASS" in hotfix23_harness, "Hotfix 23 runtime cleanup harness has a strict pass marker")
require("run_hotfix23_xcode_runtime_harness.py" in (ROOT / "Scripts/verify_release.sh").read_text(encoding="utf-8"), "cross-platform verification executes the Hotfix 23 runtime cleanup harness")
require("run_hotfix23_xcode_runtime_harness.py" in qualification_script, "Xcode qualification records the Hotfix 23 runtime cleanup harness")
require("await self.center.pendingNotificationRequests()" in services_source and "await self.center.deliveredNotifications()" in services_source, "notification cleanup uses native async UserNotifications APIs")
require("getPendingNotificationRequests {" not in services_source and "getDeliveredNotifications {" not in services_source, "legacy notification completion-handler cleanup is removed")
require("VERIFICATION_NOTES_v56_HOTFIX23_XCODE_RUNTIME_CLEANUP.md" in [p.name for p in ROOT.glob("VERIFICATION_NOTES_v56_HOTFIX23_XCODE_RUNTIME_CLEANUP.md")], "Hotfix 23 Xcode runtime cleanup notes are included")

# Phase 56 Hotfix 24 first-launch backup recovery.
hotfix24_harness_path = ROOT / "Scripts/run_hotfix24_first_launch_recovery_harness.py"
require(hotfix24_harness_path.is_file(), "Hotfix 24 first-launch recovery harness is included")
if hotfix24_harness_path.is_file():
    hotfix24_harness = hotfix24_harness_path.read_text(encoding="utf-8")
    require("HOTFIX 24 FIRST-LAUNCH RECOVERY HARNESS: PASS" in hotfix24_harness, "Hotfix 24 first-launch recovery harness has a strict pass marker")
require("run_hotfix24_first_launch_recovery_harness.py" in (ROOT / "Scripts/verify_release.sh").read_text(encoding="utf-8"), "cross-platform verification executes the Hotfix 24 recovery harness")
require("run_hotfix24_first_launch_recovery_harness.py" in qualification_script, "Xcode qualification records the Hotfix 24 recovery harness")
require("shouldOfferInitialDataRecovery" in app_store_source, "AppStore exposes first-launch recovery routing state")
require("InitialDataRecoveryView()" in root_source, "RootView routes fresh installs through backup recovery before onboarding")
require("restoreBackup(candidate, mode: .replace)" in onboarding_source, "first-launch portable recovery restores the saved profile instead of merging into an empty profile")
require("restoreFromICloudBeforeOnboarding()" in app_store_source, "first-launch iCloud recovery is implemented")
require((ROOT / "VERIFICATION_NOTES_v56_HOTFIX24_FIRST_LAUNCH_RECOVERY.md").is_file(), "Hotfix 24 first-launch recovery notes are included")

# Phase 56 Hotfix 26 work-order badge layout.
work_order_source = (APP / "WorkOrderViews.swift").read_text(encoding="utf-8")
hotfix26_harness_path = ROOT / "Scripts/run_hotfix26_work_order_badge_layout_harness.py"
require(hotfix26_harness_path.is_file(), "Hotfix 26 work-order badge layout harness is included")
if hotfix26_harness_path.is_file():
    hotfix26_harness = hotfix26_harness_path.read_text(encoding="utf-8")
    require("HOTFIX 26 WORK-ORDER BADGE LAYOUT: PASS" in hotfix26_harness, "Hotfix 26 badge layout harness has a strict pass marker")
require("run_hotfix26_work_order_badge_layout_harness.py" in (ROOT / "Scripts/verify_release.sh").read_text(encoding="utf-8"), "cross-platform verification executes the Hotfix 26 badge layout harness")
require("run_hotfix26_work_order_badge_layout_harness.py" in qualification_script, "Xcode qualification records the Hotfix 26 badge layout harness")
require("ViewThatFits(in: .horizontal)" in work_order_source, "work-order rows use adaptive horizontal layout selection")
require("WorkOrderBadgeCluster" in work_order_source, "work-order rows use the responsive priority/status badge cluster")
require((ROOT / "VERIFICATION_NOTES_v56_HOTFIX26_WORK_ORDER_BADGE_LAYOUT.md").is_file(), "Hotfix 26 work-order badge layout notes are included")

# Phase 56 Hotfix 27 evidence-photo deletion.
hotfix27_harness_path = ROOT / "Scripts/run_hotfix27_photo_delete_harness.py"
require(hotfix27_harness_path.is_file(), "Hotfix 27 photo-delete harness is included")
if hotfix27_harness_path.is_file():
    hotfix27_harness = hotfix27_harness_path.read_text(encoding="utf-8")
    require("HOTFIX 27 PHOTO DELETE: PASS" in hotfix27_harness, "Hotfix 27 photo-delete harness has a strict pass marker")
require("run_hotfix27_photo_delete_harness.py" in (ROOT / "Scripts/verify_release.sh").read_text(encoding="utf-8"), "cross-platform verification executes the Hotfix 27 photo-delete harness")
require("run_hotfix27_photo_delete_harness.py" in qualification_script, "Xcode qualification records the Hotfix 27 photo-delete harness")
require("pendingPhotoDeletion" in work_order_source and 'Image(systemName: "trash.fill")' in work_order_source, "evidence gallery exposes confirmed per-photo deletion")
require("isPhotoAlreadySaved" in work_order_source and "isStillReferencedByDraft" in work_order_source, "photo deletion preserves saved history and duplicate draft references")
require((ROOT / "VERIFICATION_NOTES_v56_HOTFIX27_PHOTO_DELETE.md").is_file(), "Hotfix 27 photo-delete notes are included")

# Phase 56 Hotfix 28 full bug-loop integrity hardening.
hotfix28_harness_path = ROOT / "Scripts/run_hotfix28_full_bug_loop_harness.py"
require(hotfix28_harness_path.is_file(), "Hotfix 28 full bug-loop harness is included")
if hotfix28_harness_path.is_file():
    hotfix28_harness = hotfix28_harness_path.read_text(encoding="utf-8")
    require("HOTFIX 28 FULL BUG LOOP: PASS" in hotfix28_harness, "Hotfix 28 full bug-loop harness has a strict pass marker")
require("run_hotfix28_full_bug_loop_harness.py" in (ROOT / "Scripts/verify_release.sh").read_text(encoding="utf-8"), "cross-platform verification executes the Hotfix 28 full bug-loop harness")
require("run_hotfix28_full_bug_loop_harness.py" in qualification_script, "Xcode qualification records the Hotfix 28 full bug-loop harness")
require("invalidWorkOrderRevisionHistory" in maintenance_source, "data migration rejects work orders with missing revision history")
require("validateCurrentRevisionHistoryForPersistence" in app_store_source, "persistence boundaries reject missing revision history")
require("normalizedRevisionSnapshot(candidate.snapshot) ?? candidate.snapshot" not in app_store_source, "backup restore never falls back to unnormalized backup data")
require("normalizedRevisionSnapshot(outcome.snapshot)) ?? outcome.snapshot" not in app_store_source, "iCloud restore never falls back to unnormalized cloud data")
require(app_store_source.count("resumeCloudAfterBackupOperation()") >= 6, "backup failure/rejection paths resume cloud work after safe rollback")
require("if restoreRecoveryWriteBlocked" in app_store_source and "} else {\n                resumeCloudAfterBackupOperation()" in app_store_source, "restore failure keeps cloud paused only when recovery is incomplete")
require((ROOT / "VERIFICATION_NOTES_v56_HOTFIX28_FULL_BUG_LOOP.md").is_file(), "Hotfix 28 full bug-loop notes are included")

# Phase 56 Hotfix 29 live theme switching stabilization.
hotfix29_harness_path = ROOT / "Scripts/run_hotfix29_theme_switch_harness.py"
require(hotfix29_harness_path.is_file(), "Hotfix 29 live-theme harness is included")
if hotfix29_harness_path.is_file():
    hotfix29_harness = hotfix29_harness_path.read_text(encoding="utf-8")
    require("HOTFIX 29 LIVE THEME SWITCHING: PASS" in hotfix29_harness, "Hotfix 29 live-theme harness has a strict pass marker")
require("run_hotfix29_theme_switch_harness.py" in (ROOT / "Scripts/verify_release.sh").read_text(encoding="utf-8"), "cross-platform verification executes the Hotfix 29 live-theme harness")
require("run_hotfix29_theme_switch_harness.py" in qualification_script, "Xcode qualification records the Hotfix 29 live-theme harness")
require(work_order_source.count("@AppStorage(AppTheme.storageKey)") >= 4, "work-order theme-dependent views observe persisted theme changes")
require((APP / "CalendarHubSettingsViews.swift").read_text(encoding="utf-8").count("@AppStorage(AppTheme.storageKey)") >= 5, "calendar, hub, settings, and theme picker observe persisted theme changes")
require("transaction.disablesAnimations = true" in (APP / "CalendarHubSettingsViews.swift").read_text(encoding="utf-8"), "theme switching avoids cross-layout animation artifacts")
require("AppTheme.selected = theme" not in (APP / "CalendarHubSettingsViews.swift").read_text(encoding="utf-8"), "theme picker avoids duplicate persisted writes")
require((ROOT / "VERIFICATION_NOTES_v56_HOTFIX29_LIVE_THEME_SWITCHING.md").is_file(), "Hotfix 29 live-theme notes are included")

# Phase 56 Hotfix 30 launch-screen continuity and startup polish.
hotfix30_harness_path = ROOT / "Scripts/run_hotfix30_launch_continuity_harness.py"
require(hotfix30_harness_path.is_file(), "Hotfix 30 launch-continuity harness is included")
if hotfix30_harness_path.is_file():
    hotfix30_harness = hotfix30_harness_path.read_text(encoding="utf-8")
    require("HOTFIX 30 LAUNCH CONTINUITY: PASS" in hotfix30_harness, "Hotfix 30 launch-continuity harness has a strict pass marker")
require("run_hotfix30_launch_continuity_harness.py" in (ROOT / "Scripts/verify_release.sh").read_text(encoding="utf-8"), "cross-platform verification executes the Hotfix 30 launch-continuity harness")
require("run_hotfix30_launch_continuity_harness.py" in qualification_script, "Xcode qualification records the Hotfix 30 launch-continuity harness")
launch_info = info.get("UILaunchScreen", {})
require(launch_info.get("UIImageName") == "LaunchLogo" and launch_info.get("UIColorName") == "LaunchBackground", "native launch screen uses shared adaptive launch assets")
require('Color("LaunchBackground")' in (APP / "SplashScreenView.swift").read_text(encoding="utf-8"), "SwiftUI splash uses the same launch background asset")
require('Image("LaunchLogo")' in (APP / "SplashScreenView.swift").read_text(encoding="utf-8"), "SwiftUI splash uses the same launch logo asset")
require("@State private var hasBeenActive = false" in (APP / "iWorkOrderApp.swift").read_text(encoding="utf-8"), "privacy protection cannot interrupt the initial launch handoff before first activation")
require((ROOT / "VERIFICATION_NOTES_v56_HOTFIX30_LAUNCH_CONTINUITY.md").is_file(), "Hotfix 30 launch-continuity notes are included")

# Phase 56 Hotfix 31 frosted privacy shield and Notification Center polish.
hotfix31_harness_path = ROOT / "Scripts/run_hotfix31_privacy_blur_harness.py"
require(hotfix31_harness_path.is_file(), "Hotfix 31 frosted-privacy harness is included")
if hotfix31_harness_path.is_file():
    hotfix31_harness = hotfix31_harness_path.read_text(encoding="utf-8")
    require("HOTFIX 31 FROSTED PRIVACY SHIELD: PASS" in hotfix31_harness, "Hotfix 31 frosted-privacy harness has a strict pass marker")
require("run_hotfix31_privacy_blur_harness.py" in (ROOT / "Scripts/verify_release.sh").read_text(encoding="utf-8"), "cross-platform verification executes the Hotfix 31 privacy harness")
require("run_hotfix31_privacy_blur_harness.py" in qualification_script, "Xcode qualification records the Hotfix 31 privacy harness")
privacy_app_source = (APP / "iWorkOrderApp.swift").read_text(encoding="utf-8")
require(".fill(.regularMaterial)" in privacy_app_source, "inactive privacy cover uses a frosted material layer")
require("hasBeenActive && scenePhase != .active ? 24 : 0" in privacy_app_source, "inactive content is blurred beneath the privacy cover")
require("hasBeenActive && scenePhase != .active ? 0.20 : 1" in privacy_app_source, "inactive content is desaturated beneath the privacy cover")
require("@Environment(\\.accessibilityReduceTransparency)" in privacy_app_source, "privacy cover honors Reduce Transparency")
require(".frame(width: 58, height: 58)" in privacy_app_source, "privacy cover uses a compact logo rather than the full splash")
require("SplashScreenView()" not in privacy_app_source.split("private struct AppPrivacyShieldView: View", 1)[1].split("@main", 1)[0], "privacy cover is visually independent from the startup splash")
require((ROOT / "VERIFICATION_NOTES_v56_HOTFIX31_FROSTED_PRIVACY_SHIELD.md").is_file(), "Hotfix 31 frosted-privacy notes are included")

# Phase 56 Hotfix 32 full bug-loop hardening.
hotfix32_harness_path = ROOT / "Scripts/run_hotfix32_full_bug_loop_harness.py"
require(hotfix32_harness_path.is_file(), "Hotfix 32 full-bug-loop harness is included")
if hotfix32_harness_path.is_file():
    hotfix32_harness = hotfix32_harness_path.read_text(encoding="utf-8")
    require("HOTFIX 32 FULL BUG LOOP: PASS" in hotfix32_harness, "Hotfix 32 full-bug-loop harness has a strict pass marker")
require("run_hotfix32_full_bug_loop_harness.py" in (ROOT / "Scripts/verify_release.sh").read_text(encoding="utf-8"), "cross-platform verification executes the Hotfix 32 full-bug-loop harness")
require("run_hotfix32_full_bug_loop_harness.py" in qualification_script, "Xcode qualification records the Hotfix 32 full-bug-loop harness")
require("AnyShapeStyle(Color(.secondarySystemBackground))" in privacy_app_source, "Reduce Transparency privacy badge uses an opaque semantic background")
require(".background(.thinMaterial, in: Circle())" not in privacy_app_source, "privacy badge has no unconditional translucent material background")
work_order_source = (APP / "WorkOrderViews.swift").read_text(encoding="utf-8")
require(work_order_source.count('@AppStorage(AppTheme.storageKey)') >= 10, "retained work-order leaf views observe live theme changes")
require("AppTheme.heroGradient(for: .design2)" in work_order_source, "Design 2 hero uses a fixed Design 2 gradient during theme transitions")
require((ROOT / "VERIFICATION_NOTES_v56_HOTFIX32_FULL_BUG_LOOP.md").is_file(), "Hotfix 32 full-bug-loop notes are included")

# Phase 56 Hotfix 33 distinct theme identity correction.
hotfix33_harness_path = ROOT / "Scripts/run_hotfix33_theme_identity_harness.py"
require(hotfix33_harness_path.is_file(), "Hotfix 33 theme-identity harness is included")
if hotfix33_harness_path.is_file():
    hotfix33_harness = hotfix33_harness_path.read_text(encoding="utf-8")
    require("HOTFIX 33 THEME IDENTITY: PASS" in hotfix33_harness, "Hotfix 33 theme-identity harness has a strict pass marker")
require("run_hotfix33_theme_identity_harness.py" in (ROOT / "Scripts/verify_release.sh").read_text(encoding="utf-8"), "cross-platform verification executes the Hotfix 33 theme-identity harness")
require("run_hotfix33_theme_identity_harness.py" in qualification_script, "Xcode qualification records the Hotfix 33 theme-identity harness")
theme_components = (APP / "Components.swift").read_text(encoding="utf-8")
theme_settings_source = (APP / "CalendarHubSettingsViews.swift").read_text(encoding="utf-8")
require("struct ThemeOptionCard: View" in theme_settings_source, "theme picker renders each represented theme independently")
require("theme.surface.default" in work_order_source and "theme.surface.design2" in work_order_source and "theme.surface.design3" in work_order_source, "all three work-order themes expose distinct surface identities")
require("case .design2: return 16" in theme_components and "case .design3: return 10" in theme_components, "custom themes use intentionally different card geometry")
require((ROOT / "VERIFICATION_NOTES_v56_HOTFIX33_THEME_IDENTITY.md").is_file(), "Hotfix 33 theme-identity notes are included")


# Phase 56 Hotfix 34 Theme 3 rebuild and full regression loop.
hotfix34_harness_path = ROOT / "Scripts/run_hotfix34_theme3_rebuild_harness.py"
require(hotfix34_harness_path.is_file(), "Hotfix 34 Theme 3 rebuild harness is included")
if hotfix34_harness_path.is_file():
    hotfix34_harness = hotfix34_harness_path.read_text(encoding="utf-8")
    require("HOTFIX 34 THEME 3 REBUILD: PASS" in hotfix34_harness, "Hotfix 34 Theme 3 rebuild harness has a strict pass marker")
require("run_hotfix34_theme3_rebuild_harness.py" in (ROOT / "Scripts/verify_release.sh").read_text(encoding="utf-8"), "cross-platform verification executes the Hotfix 34 Theme 3 rebuild harness")
require("run_hotfix34_theme3_rebuild_harness.py" in qualification_script, "Xcode qualification records the Hotfix 34 Theme 3 rebuild harness")
require("FIELD DECK / ACTIVE" in work_order_source, "Design 3 Work Orders uses the rebuilt Field Deck surface")
require("Theme3CalendarContent" in theme_settings_source and "Theme3HubHeader" in theme_settings_source and "Theme3SettingsHeader" in theme_settings_source, "Design 3 Calendar, Hub, and Settings use dedicated rebuilt surfaces")
require("case .design3: return .dark" in (APP / "RootView.swift").read_text(encoding="utf-8"), "Design 3 uses its dedicated dark appearance")
require((ROOT / "VERIFICATION_NOTES_v56_HOTFIX34_THEME3_REBUILD.md").is_file(), "Hotfix 34 Theme 3 rebuild notes are included")

# Phase 56 Hotfix 35 onboarding theme-scope compile correction.
hotfix35_harness_path = ROOT / "Scripts/run_hotfix35_onboarding_theme_scope_harness.py"
require(hotfix35_harness_path.is_file(), "Hotfix 35 onboarding theme-scope harness is included")
if hotfix35_harness_path.is_file():
    hotfix35_harness = hotfix35_harness_path.read_text(encoding="utf-8")
    require("HOTFIX 35 ONBOARDING THEME SCOPE: PASS" in hotfix35_harness, "Hotfix 35 onboarding theme-scope harness has a strict pass marker")
require("run_hotfix35_onboarding_theme_scope_harness.py" in (ROOT / "Scripts/verify_release.sh").read_text(encoding="utf-8"), "cross-platform verification executes the Hotfix 35 onboarding theme-scope harness")
require("run_hotfix35_onboarding_theme_scope_harness.py" in qualification_script, "Xcode qualification records the Hotfix 35 onboarding theme-scope harness")
onboarding_source = (APP / "OnboardingView.swift").read_text(encoding="utf-8")
require("private var selectedTheme: VisualTheme { VisualTheme(rawValue: selectedThemeRaw) ?? .defaultTheme }" in onboarding_source, "OnboardingView defines a locally resolvable selected theme")
require((ROOT / "VERIFICATION_NOTES_v56_HOTFIX35_ONBOARDING_THEME_SCOPE.md").is_file(), "Hotfix 35 onboarding theme-scope notes are included")

# Phase 56 Hotfix 36 SwiftUI semantic type-check guard.
hotfix36_harness_path = ROOT / "Scripts/run_hotfix36_swiftui_semantic_lint_harness.py"
require(hotfix36_harness_path.is_file(), "Hotfix 36 SwiftUI semantic lint harness is included")
if hotfix36_harness_path.is_file():
    hotfix36_harness = hotfix36_harness_path.read_text(encoding="utf-8")
    require("HOTFIX 36 SWIFTUI SEMANTIC LINT: PASS" in hotfix36_harness, "Hotfix 36 SwiftUI semantic lint harness has a strict pass marker")
require("run_hotfix36_swiftui_semantic_lint_harness.py" in (ROOT / "Scripts/verify_release.sh").read_text(encoding="utf-8"), "cross-platform verification executes the Hotfix 36 SwiftUI semantic lint harness")
require("run_hotfix36_swiftui_semantic_lint_harness.py" in qualification_script, "Xcode qualification records the Hotfix 36 SwiftUI semantic lint harness")
require(".stretch" not in swift_source, "shipping Swift contains no nonexistent .stretch alignment member")
require(".overlay(alignment: .leading)" in work_order_source, "Theme 3 work-order priority rail uses a valid overlay alignment")
require((ROOT / "VERIFICATION_NOTES_v56_HOTFIX36_SWIFTUI_TYPECHECK_GUARD.md").is_file(), "Hotfix 36 SwiftUI semantic type-check notes are included")


# Phase 56 Hotfix 37 current Xcode/Swift audit and geocoding modernization.
hotfix37_harness_path = ROOT / "Scripts/run_hotfix37_xcode27_swift64_harness.py"
require(hotfix37_harness_path.is_file(), "Hotfix 37 Xcode 27 / Swift 6.4 audit harness is included")
if hotfix37_harness_path.is_file():
    hotfix37_harness = hotfix37_harness_path.read_text(encoding="utf-8")
    require("HOTFIX 37 XCODE27 SWIFT64 AUDIT: PASS" in hotfix37_harness, "Hotfix 37 toolchain audit harness has a strict pass marker")
require("run_hotfix37_xcode27_swift64_harness.py" in (ROOT / "Scripts/verify_release.sh").read_text(encoding="utf-8"), "cross-platform verification executes the Hotfix 37 toolchain audit")
require("run_hotfix37_xcode27_swift64_harness.py" in qualification_script, "Xcode qualification records the Hotfix 37 toolchain audit")
services_hotfix37 = (APP / "Services.swift").read_text(encoding="utf-8")
require("MKGeocodingRequest(addressString:" in services_hotfix37 and "addressRepresentations" in services_hotfix37, "address verification uses the modern MapKit geocoding/address representation path")
require("CLGeocoder" not in swift_source and "CLPlacemark" not in swift_source and "CNPostalAddressFormatter" not in swift_source, "shipping Swift no longer uses superseded address-geocoding APIs")
require((ROOT / "VERIFICATION_NOTES_v56_HOTFIX37_XCODE27_SWIFT64_AUDIT.md").is_file(), "Hotfix 37 Xcode 27 / Swift 6.4 audit notes are included")

# Phase 56 Hotfix 38 iOS 26 minimum-baseline qualification.
hotfix38_harness_path = ROOT / "Scripts/run_hotfix38_ios26_baseline_harness.py"
require(hotfix38_harness_path.is_file(), "Hotfix 38 iOS 26 baseline audit harness is included")
if hotfix38_harness_path.is_file():
    hotfix38_harness = hotfix38_harness_path.read_text(encoding="utf-8")
    require("HOTFIX 38 IOS26 BASELINE AUDIT: PASS" in hotfix38_harness, "Hotfix 38 iOS 26 baseline harness has a strict pass marker")
require("run_hotfix38_ios26_baseline_harness.py" in (ROOT / "Scripts/verify_release.sh").read_text(encoding="utf-8"), "cross-platform verification executes the Hotfix 38 iOS 26 baseline audit")
require("run_hotfix38_ios26_baseline_harness.py" in qualification_script, "Xcode qualification records the Hotfix 38 iOS 26 baseline audit")
require(pbx.count("IPHONEOS_DEPLOYMENT_TARGET = 26.0;") == 8, "all project and test configurations use the iOS 26.0 deployment target")
require("MKLocalSearch" not in (APP / "Services.swift").read_text(encoding="utf-8"), "pre-iOS-26 MapKit address fallback is removed from shipping source")
require((ROOT / "VERIFICATION_NOTES_v56_HOTFIX38_IOS26_BASELINE.md").is_file(), "Hotfix 38 iOS 26 baseline audit notes are included")

# Phase 56 Hotfix 39 iPadOS 26 UIRequiresFullScreen deprecation cleanup.
hotfix39_harness_path = ROOT / "Scripts/run_hotfix39_fullscreen_deprecation_harness.py"
require(hotfix39_harness_path.is_file(), "Hotfix 39 fullscreen deprecation audit harness is included")
if hotfix39_harness_path.is_file():
    hotfix39_harness = hotfix39_harness_path.read_text(encoding="utf-8")
    require("HOTFIX 39 FULLSCREEN DEPRECATION AUDIT: PASS" in hotfix39_harness, "Hotfix 39 fullscreen deprecation harness has a strict pass marker")
require("run_hotfix39_fullscreen_deprecation_harness.py" in (ROOT / "Scripts/verify_release.sh").read_text(encoding="utf-8"), "cross-platform verification executes the Hotfix 39 fullscreen deprecation audit")
require("run_hotfix39_fullscreen_deprecation_harness.py" in qualification_script, "Xcode qualification records the Hotfix 39 fullscreen deprecation audit")
require("UIRequiresFullScreen" not in info, "deprecated UIRequiresFullScreen key is absent from Info.plist")
require("INFOPLIST_KEY_UIRequiresFullScreen" not in pbx, "Xcode settings do not regenerate deprecated UIRequiresFullScreen")
require("UIScreen.main" not in swift_source and "UIScreen(" not in swift_source, "shipping Swift avoids fixed physical-screen sizing for resizable scenes")
require((ROOT / "VERIFICATION_NOTES_v56_HOTFIX39_FULLSCREEN_DEPRECATION.md").is_file(), "Hotfix 39 fullscreen deprecation notes are included")

# Source-package integrity manifest.
manifest_path = ROOT / "SOURCE_SHA256SUMS.txt"
require(manifest_path.is_file(), "source SHA-256 manifest is included")
recorded: dict[str, str] = {}
if manifest_path.is_file():
    for line_number, line in enumerate(manifest_path.read_text(encoding="utf-8").splitlines(), start=1):
        match = re.fullmatch(r"([0-9a-f]{64})  (.+)", line)
        if not match:
            errors.append(f"invalid source manifest line {line_number}")
            continue
        digest, relative = match.groups()
        if relative in recorded:
            errors.append(f"duplicate source manifest path: {relative}")
        recorded[relative] = digest

excluded_parts = {".git", "build", "Artifacts", "__MACOSX", "__pycache__", ".pytest_cache", "xcuserdata"}
actual_files = {
    path.relative_to(ROOT).as_posix(): path
    for path in ROOT.rglob("*")
    if path.is_file()
    and path.name not in {"SOURCE_SHA256SUMS.txt", ".DS_Store"}
    and not any(part in excluded_parts for part in path.relative_to(ROOT).parts)
}
missing_from_manifest = sorted(set(actual_files) - set(recorded))
unrecorded_manifest_paths = sorted(set(recorded) - set(actual_files))
require(not missing_from_manifest, f"no source files are missing from the hash manifest{': ' + ', '.join(missing_from_manifest[:5]) if missing_from_manifest else ''}")
require(not unrecorded_manifest_paths, f"hash manifest contains no nonexistent files{': ' + ', '.join(unrecorded_manifest_paths[:5]) if unrecorded_manifest_paths else ''}")
hash_mismatches = []
for relative, path in actual_files.items():
    expected_digest = recorded.get(relative)
    if expected_digest is None:
        continue
    actual_digest = hashlib.sha256(path.read_bytes()).hexdigest()
    if actual_digest != expected_digest:
        hash_mismatches.append(relative)
require(not hash_mismatches, f"all source files match the SHA-256 manifest{': ' + ', '.join(hash_mismatches[:5]) if hash_mismatches else ''}")
require(len(actual_files) >= 120, "source manifest covers the complete Phase 56 package")

# Duplicate object IDs in the pbxproj are a high-risk corruption signal.
object_ids = re.findall(r"^\s*([A-F0-9]{24}) /\*.*?\*/ = \{", pbx, re.M)
duplicates = sorted({item for item in object_ids if object_ids.count(item) > 1})
require(not duplicates, f"no duplicate Xcode object IDs{': ' + ', '.join(duplicates) if duplicates else ''}")

if errors:
    print("PHASE 56 RELEASE VERIFICATION: FAIL")
    for item in errors:
        print(f"FAIL: {item}")
    print(f"Passed checks before failure: {len(checks)}")
    sys.exit(1)

print("PHASE 56 RELEASE VERIFICATION: PASS")
print(f"Checks passed: {len(checks)}")
for item in checks:
    print(f"PASS: {item}")
