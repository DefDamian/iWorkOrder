#!/usr/bin/env python3
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
APP = ROOT / "iWorkOrder"
source = (APP / "iWorkOrderApp.swift").read_text(encoding="utf-8")
splash = (APP / "SplashScreenView.swift").read_text(encoding="utf-8")

checks: list[str] = []
errors: list[str] = []

def require(condition: bool, message: str) -> None:
    (checks if condition else errors).append(message)

require("private struct AppPrivacyShieldView: View" in source, "dedicated privacy shield remains present")
require("@Environment(\\.colorScheme) private var colorScheme" in source, "privacy shield adapts to light and dark appearance")
require("@Environment(\\.accessibilityReduceTransparency) private var reduceTransparency" in source, "privacy shield honors Reduce Transparency")
require('Color("LaunchBackground")' in source, "Reduce Transparency fallback uses the adaptive launch background")
require(".fill(.regularMaterial)" in source, "normal privacy cover uses a frosted material layer")
require("Color.black" in source and "colorScheme == .dark ? 0.20 : 0.05" in source, "frosted cover has a restrained appearance-aware tint")
require('Image("LaunchLogo")' in source, "privacy cover retains the adaptive iWorkOrder mark")
require(".frame(width: 58, height: 58)" in source, "privacy mark is compact rather than splash-sized")
require("AnyShapeStyle(.thinMaterial)" in source and "AnyShapeStyle(Color(.secondarySystemBackground))" in source, "privacy mark uses a compact frosted badge normally and an opaque badge with Reduce Transparency")
require("strokeBorder" in source and "lineWidth: 0.75" in source, "privacy badge has a subtle edge treatment")
require(".shadow(color: .black.opacity" in source, "privacy badge uses restrained depth")
require(".allowsHitTesting(false)" in source, "privacy cover cannot intercept app controls")
require(".accessibilityHidden(true)" in source, "decorative privacy cover is hidden from accessibility navigation")
require("@State private var hasBeenActive = false" in source, "privacy cover tracks whether the app has reached an active state")
require("if scenePhase == .active" in source and "hasBeenActive = true" in source, "already-active first presentation arms privacy protection")
require("case .active:" in source and source.count("hasBeenActive = true") >= 2, "later active transitions keep privacy protection armed")
require("hasBeenActive && scenePhase != .active ? 24 : 0" in source, "inactive app content is strongly blurred")
require("hasBeenActive && scenePhase != .active ? 0.20 : 1" in source, "inactive app content is desaturated beneath the frost")
require("if hasBeenActive && scenePhase != .active" in source, "privacy cover is shown only after the app has been active")
require(".accessibilityHidden(hasBeenActive && scenePhase != .active)" in source, "underlying sensitive controls leave accessibility focus while covered")
require(".privacySensitive()" in source, "root content remains marked privacy-sensitive")
require("SplashScreenView()" not in source.split("private struct AppPrivacyShieldView: View", 1)[1].split("@main", 1)[0], "privacy cover no longer reuses the full startup splash")
require('Text("iWorkOrder")' not in source, "privacy cover has no oversized duplicate product title")
require(".frame(width: 170, height: 170)" in splash, "startup splash remains independent at its 170-point launch size")
require("320_000_000" in splash, "Hotfix30 fast startup timing remains intact")
require("case .inactive:" in source and "RuntimeReliabilityService.transition(to: .inactive)" in source, "inactive lifecycle reliability handling is preserved")
require("case .background:" in source and "store.persistLifecycleCheckpoint()" in source, "background persistence checkpoint is preserved")
require("applicationDidEnterBackground" in source, "background app-lock behavior is preserved")
require("Task { await store.refreshNotificationAuthorization() }" in source, "active notification authorization refresh is preserved")

for item in checks:
    print(f"PASS: {item}")
if errors:
    for item in errors:
        print(f"FAIL: {item}")
    raise SystemExit(1)
print(f"HOTFIX 31 FROSTED PRIVACY SHIELD: PASS ({len(checks)} checks)")
