#!/usr/bin/env python3
from pathlib import Path
import re
import sys

ROOT = Path(__file__).resolve().parents[1]
APP = ROOT / "iWorkOrder"
services = (APP / "Services.swift").read_text(encoding="utf-8")
settings = (APP / "CalendarHubSettingsViews.swift").read_text(encoding="utf-8")
onboarding = (APP / "OnboardingView.swift").read_text(encoding="utf-8")
root_view = (APP / "RootView.swift").read_text(encoding="utf-8")

checks=[]; errors=[]
def require(condition,message):
    (checks if condition else errors).append(message)

require("getPendingNotificationRequests {" not in services, "legacy pending-notification completion callback is removed")
require("getDeliveredNotifications {" not in services, "legacy delivered-notification completion callback is removed")
require("await self.center.pendingNotificationRequests()" in services, "pending notifications use the async API")
require("await self.center.deliveredNotifications()" in services, "delivered notifications use the async API")
require("let pendingRequests = await self.center.pendingNotificationRequests()" in services, "pending cleanup stays inside serialized reconciliation")
require("let deliveredNotifications = await self.center.deliveredNotifications()" in services, "delivered cleanup stays inside serialized reconciliation")
require(services.count("guard self.reconciliationGeneration == generation else { return }") >= 3, "async notification cleanup preserves generation cancellation")

require("store.setICloudEnabled($0)" not in settings, "settings iCloud Binding does not synchronously publish AppStore changes")
require("store.setCloudSyncPausedForRecovery($0)" not in settings, "settings recovery Binding does not synchronously publish AppStore changes")
require("set: { updateSecuritySetting($0) }" not in settings, "security Binding does not synchronously publish AppStore changes")
require("set: { updateNotificationsEnabled($0) }" not in settings, "notification Binding does not synchronously publish AppStore changes")
require("set: { updateEmergencyNotificationsEnabled($0) }" not in settings, "emergency notification Binding does not synchronously publish AppStore changes")
require("store.setICloudEnabled($0)" not in onboarding, "onboarding iCloud Binding does not synchronously publish AppStore changes")
require("set: { updateNotificationPreference($0) }" not in onboarding, "onboarding notification Binding does not synchronously publish AppStore changes")
require(settings.count("await Task.yield()") >= 6, "settings custom bindings defer published mutations beyond the current view update")
require(onboarding.count("await Task.yield()") >= 3, "onboarding custom bindings defer published mutations beyond the current view update")
require("await Task.yield()" in root_view and "store.lastErrorMessage = nil" in root_view, "root alert dismissal defers published mutation beyond the current view update")

# Debug-only maintenance controls matter in the Xcode run that exposed the warning.
maint = re.findall(r'set: \{ enabled in\s+Task \{ @MainActor in\s+await Task\.yield\(\)\s+store\.setCloudSyncPausedForRecovery\(enabled\)', settings, re.S)
require(len(maint) >= 1, "Debug recovery toggle defers ObservableObject publication")

if errors:
    print("HOTFIX 23 XCODE RUNTIME CLEANUP HARNESS: FAIL")
    for item in errors: print("FAIL:", item)
    print(f"Passed before failure: {len(checks)}")
    sys.exit(1)
print("HOTFIX 23 XCODE RUNTIME CLEANUP HARNESS: PASS")
print(f"Checks passed: {len(checks)}")
for item in checks: print("PASS:", item)
