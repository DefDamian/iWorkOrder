#!/usr/bin/env python3
from pathlib import Path
import subprocess
import tempfile

ROOT = Path(__file__).resolve().parents[1]
SOURCE = (ROOT / "iWorkOrder/MaintenanceService.swift").read_text(encoding="utf-8")


def swift_block(text: str, marker: str) -> str:
    start = text.index(marker)
    brace = text.index("{", start)
    depth = 0
    for index in range(brace, len(text)):
        if text[index] == "{":
            depth += 1
        elif text[index] == "}":
            depth -= 1
            if depth == 0:
                return text[start:index + 1]
    raise RuntimeError(f"Unterminated Swift block: {marker}")


def swift_function(text: str, marker: str) -> str:
    return swift_block(text, marker)

app_schema = swift_block(SOURCE, "enum AppDataSchema")
migration_result = swift_block(SOURCE, "struct DataMigrationResult")
migration_error = swift_block(SOURCE, "enum DataMigrationError")
migrate_function = swift_function(SOURCE, "static func migrate")

models = r'''
import Foundation

struct UserProfile: Codable, Sendable {}
struct WorkOrderCategory: RawRepresentable, Codable, Equatable, Sendable {
    let rawValue: String
    init(rawValue: String) { self.rawValue = rawValue }
    static let plumbing = WorkOrderCategory(rawValue: "Plumbing")
    static let electric = WorkOrderCategory(rawValue: "Electrical")
    static let hvac = WorkOrderCategory(rawValue: "HVAC")
    static let appliances = WorkOrderCategory(rawValue: "Appliances")
    static let locks = WorkOrderCategory(rawValue: "Locks / Doors")
    static let pest = WorkOrderCategory(rawValue: "Pest Control")
    static let paint = WorkOrderCategory(rawValue: "Paint / Walls")
    static let roof = WorkOrderCategory(rawValue: "Roof")
    static let landscaping = WorkOrderCategory(rawValue: "Landscaping")
    static let pool = WorkOrderCategory(rawValue: "Pool")
    static let other = WorkOrderCategory(rawValue: "Other")
    static let defaultCategories: [WorkOrderCategory] = [.plumbing, .electric, .hvac, .appliances, .locks, .pest, .paint, .roof, .landscaping, .pool, .other]
}
struct AssetRecord: Codable, Sendable, Equatable { var id = UUID() }
struct TenantContact: Codable, Sendable, Equatable { var id = UUID() }
struct StatusEntry: Codable, Sendable, Equatable { var id = UUID() }
struct WorkOrderEntry: Codable, Sendable, Equatable {
    var id = UUID()
    var issueDescription = ""
}
struct WorkOrder: Codable, Sendable, Equatable {
    var id = UUID()
    var entries: [WorkOrderEntry]
    var statusEntries: [StatusEntry]? = nil
}
struct AppSnapshot: Codable, Sendable {
    var profile: UserProfile
    var workOrders: [WorkOrder]
    var assets: [AssetRecord]? = []
    var tenants: [TenantContact]? = []
    var categories: [WorkOrderCategory]?
    var categoryConfigurationUpdatedAt: Date?
    var dataSchemaVersion: Int? = AppDataSchema.currentVersion
}
'''

harness = r'''
enum MaintenanceService {
MIGRATE_FUNCTION
}

@main
struct Phase54MaintenanceHarness {
    static func require(_ condition: @autoclosure () -> Bool, _ message: String) {
        if !condition() {
            FileHandle.standardError.write(Data(("FAIL: " + message + "\n").utf8))
            exit(1)
        }
    }

    static func main() throws {
        let legacyOrder = WorkOrder(entries: [WorkOrderEntry(issueDescription: "preserve-me")], statusEntries: nil)
        let legacy = AppSnapshot(profile: UserProfile(), workOrders: [legacyOrder], assets: nil, tenants: nil, dataSchemaVersion: 1)
        let migrated = try MaintenanceService.migrate(legacy)
        require(migrated.changed, "schema 1 must migrate")
        require(migrated.sourceVersion == 1, "source schema")
        require(migrated.targetVersion == AppDataSchema.currentVersion, "target schema")
        require(migrated.snapshot.dataSchemaVersion == AppDataSchema.currentVersion, "stored schema")
        require(migrated.snapshot.assets == [], "assets default")
        require(migrated.snapshot.tenants == [], "tenants default")
        require(migrated.snapshot.categories == WorkOrderCategory.defaultCategories, "category configuration default")
        require(migrated.snapshot.workOrders[0].statusEntries == [], "status entries default")
        require(migrated.snapshot.workOrders[0].entries[0].issueDescription == "preserve-me", "operational content preserved")

        let current = AppSnapshot(profile: UserProfile(), workOrders: [], dataSchemaVersion: AppDataSchema.currentVersion)
        let currentResult = try MaintenanceService.migrate(current)
        require(!currentResult.changed, "current schema must be idempotent")

        let invalidOrder = AppSnapshot(
            profile: UserProfile(),
            workOrders: [WorkOrder(entries: [])],
            dataSchemaVersion: AppDataSchema.currentVersion
        )
        do {
            _ = try MaintenanceService.migrate(invalidOrder)
            require(false, "empty work-order revision history must be blocked")
        } catch DataMigrationError.invalidWorkOrderRevisionHistory(let count) {
            require(count == 1, "empty work-order revision count")
        }

        let future = AppSnapshot(profile: UserProfile(), workOrders: [], dataSchemaVersion: AppDataSchema.currentVersion + 1)
        do {
            _ = try MaintenanceService.migrate(future)
            require(false, "future schema must be blocked")
        } catch DataMigrationError.unsupportedFutureVersion(let version) {
            require(version == AppDataSchema.currentVersion + 1, "future schema number")
        }

        print("PHASE 56 MIGRATION AND MAINTENANCE HARNESS: PASS")
    }
}
'''.replace("MIGRATE_FUNCTION", migrate_function)

with tempfile.TemporaryDirectory(prefix="iworkorder-phase55-maintenance-") as temporary:
    temporary_path = Path(temporary)
    source = temporary_path / "Phase54MaintenanceHarness.swift"
    binary = temporary_path / "Phase54MaintenanceHarness"
    source.write_text("\n\n".join([models, app_schema, migration_result, migration_error, harness]), encoding="utf-8")
    subprocess.run(["swiftc", "-parse-as-library", str(source), "-o", str(binary)], check=True)
    subprocess.run([str(binary)], check=True)
