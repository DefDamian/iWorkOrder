#!/usr/bin/env python3
"""Prepare disposable build output without allowing an override to erase source."""
from __future__ import annotations
import argparse
from pathlib import Path
import shutil


def validate_destination(root: Path, destination: Path, category: str) -> Path:
    root = root.resolve(strict=True)
    base = root / category
    lexical = destination if destination.is_absolute() else root / destination
    resolved = lexical.resolve()
    if not resolved.is_relative_to(base) or resolved == base:
        raise ValueError(f"Output must be a dedicated subdirectory below {base}; refused {destination}")
    for item in [lexical, *lexical.parents]:
        if item == root:
            break
        if item.is_symlink():
            raise ValueError(f"Output path must not use a symbolic link: {item}")
    if resolved.exists() and not resolved.is_dir():
        raise ValueError(f"Output must be a directory: {resolved}")
    return resolved


def prepare(root: Path, artifacts: Path, derived_data: Path, evidence: Path) -> None:
    root = root.resolve(strict=True)
    artifacts = validate_destination(root, artifacts, "Artifacts")
    derived_data = validate_destination(root, derived_data, "build")
    evidence = evidence if evidence.is_absolute() else root / evidence
    evidence = evidence.resolve(strict=True)
    if evidence.is_relative_to(artifacts) or evidence.is_relative_to(derived_data):
        raise ValueError("Manual evidence must be stored outside disposable build output.")
    contents = evidence.read_bytes()  # Verify readability before deleting anything.
    for path in [artifacts, derived_data]:
        if path.exists():
            shutil.rmtree(path)
    artifacts.mkdir(parents=True, exist_ok=True)
    (artifacts / "phase56_evidence.json").write_bytes(contents)


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--root", type=Path, required=True)
    parser.add_argument("--artifacts", type=Path, required=True)
    parser.add_argument("--derived-data", type=Path, required=True)
    parser.add_argument("--evidence", type=Path, required=True)
    args = parser.parse_args()
    try:
        prepare(args.root, args.artifacts, args.derived_data, args.evidence)
    except (ValueError, OSError) as error:
        parser.exit(1, f"Build output preparation refused: {error}\n")


if __name__ == "__main__":
    main()
