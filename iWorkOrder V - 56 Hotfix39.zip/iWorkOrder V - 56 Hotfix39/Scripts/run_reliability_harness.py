#!/usr/bin/env python3
from __future__ import annotations

import hashlib
import json
import tempfile
from dataclasses import asdict, dataclass
from datetime import datetime, timedelta, timezone
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
APP = ROOT / "iWorkOrder"
checks: list[str] = []
errors: list[str] = []


def require(condition: bool, message: str) -> None:
    (checks if condition else errors).append(message)


@dataclass
class Checkpoint:
    started: str
    updated: str
    state: str
    build: str
    schema: int
    memory_warnings: int


@dataclass
class Event:
    date: str
    kind: str
    outcome: str
    count: int | None = None


def canonical(value: object) -> bytes:
    return json.dumps(value, sort_keys=True, separators=(",", ":"), ensure_ascii=False).encode("utf-8")


runtime_source = (APP / "RuntimeReliabilityService.swift").read_text(encoding="utf-8")
support_source = (APP / "SupportBundleService.swift").read_text(encoding="utf-8")
app_store = (APP / "AppStore.swift").read_text(encoding="utf-8")
app_lifecycle = (APP / "iWorkOrderApp.swift").read_text(encoding="utf-8")
maintenance = (APP / "MaintenanceService.swift").read_text(encoding="utf-8")
settings = (APP / "CalendarHubSettingsViews.swift").read_text(encoding="utf-8")

require("previousSessionPossiblyInterrupted" in runtime_source, "runtime summary distinguishes a possible interruption")
require("checkpoint.lifecycleState != .background" in runtime_source, "background checkpoint is treated as a normal prior session")
require("does not guarantee a termination callback" in runtime_source, "source does not claim that every interrupted session is a crash")
require("applicationDidReceiveMemoryWarning" in app_lifecycle, "memory-pressure warnings are captured from UIApplicationDelegate")
require("RuntimeReliabilityService.transition(to: .background)" in app_lifecycle, "background lifecycle checkpoints are persisted")
require("cloudSyncPausedForRecovery" in app_store and "case paused" in (APP / "CloudSyncService.swift").read_text(encoding="utf-8"), "cloud recovery pause is a first-class state")
require("guard !cloudSyncPausedForRecovery" in app_store, "ordinary cloud synchronization is blocked during recovery pause")
require("cloud.isCloudReplacementPending()" in app_store and "cloud.isCloudErasePending()" in app_store, "pending replacement and deletion transactions retain dedicated handling")
require("SupportBundleEnvelope" in support_source and "contentSHA256" in support_source, "support bundles contain a content checksum")
require("validateBundle" in support_source and "checksumMismatch" in support_source, "support bundles are verified before sharing")
require("Create Support Package" in settings, "support package export is available in the public UI")
require("Pause Cloud Sync for Recovery" in settings and "#if DEBUG" in settings, "internal recovery pause remains available to Debug troubleshooting builds")
require("maximumRecentEventCount = 100" in support_source, "support bundle event history is bounded")
require("maximumEventCount = 250" in maintenance and "eventRetentionDays = 30" in maintenance, "local operational history remains bounded")

for forbidden in [
    "profile.personName",
    "profile.buildingAddress",
    "issueDescription",
    "tenant.email",
    "DeviceIdentity.current",
    "signatureFilename",
]:
    require(forbidden not in runtime_source + support_source, f"field reliability services exclude personal field: {forbidden}")

now = datetime(2026, 8, 5, 0, 0, tzinfo=timezone.utc)
with tempfile.TemporaryDirectory(prefix="iworkorder-phase55-reliability-") as temp:
    root = Path(temp)
    checkpoint_file = root / "runtime-session.json"
    event_file = root / "events.json"

    prior_active = Checkpoint(
        started=(now - timedelta(minutes=2)).isoformat(),
        updated=(now - timedelta(seconds=30)).isoformat(),
        state="active",
        build="1.0 (54)",
        schema=2,
        memory_warnings=0,
    )
    checkpoint_file.write_text(json.dumps(asdict(prior_active), sort_keys=True), encoding="utf-8")
    prior = json.loads(checkpoint_file.read_text(encoding="utf-8"))
    events: list[Event] = []
    interrupted = prior["state"] != "background"
    if interrupted:
        events.append(Event(now.isoformat(), "sessionInterrupted", "warning"))
    current = Checkpoint(now.isoformat(), now.isoformat(), "launching", "1.0 (56)", 2, 0)
    checkpoint_file.write_text(json.dumps(asdict(current), sort_keys=True), encoding="utf-8")
    event_file.write_text(json.dumps([asdict(item) for item in events], sort_keys=True), encoding="utf-8")
    require(interrupted and len(events) == 1, "active prior checkpoint produces one possible-interruption warning")

    current.state = "background"
    current.updated = (now + timedelta(seconds=5)).isoformat()
    checkpoint_file.write_text(json.dumps(asdict(current), sort_keys=True), encoding="utf-8")
    prior = json.loads(checkpoint_file.read_text(encoding="utf-8"))
    require(prior["state"] == "background", "background checkpoint survives persistence")
    require(not (prior["state"] != "background"), "background prior checkpoint does not create a false interruption")

    current.state = "active"
    current.memory_warnings += 1
    current.updated = (now + timedelta(seconds=10)).isoformat()
    events.append(Event(current.updated, "memoryPressure", "warning", current.memory_warnings))
    require(current.memory_warnings == 1, "memory warning count is aggregate-only")

    content = {
        "formatIdentifier": "com.damiancedeno.iworkorder.support",
        "formatVersion": 1,
        "reportID": "11111111-2222-3333-4444-555555555555",
        "generatedAt": now.isoformat(),
        "applicationVersion": "1.0 (56)",
        "dataSchemaVersion": 2,
        "legalVersion": "2026.09.16.56",
        "diagnosticReport": "Privacy-safe diagnostics only",
        "maintenanceReport": "Structured maintenance only",
        "reliabilitySummary": {
            "previousSessionPossiblyInterrupted": True,
            "interruptedSessionCount7Days": 1,
            "memoryWarningCount7Days": 1,
            "cloudSyncPausedForRecovery": True,
        },
        "recentEvents": [asdict(item) for item in events],
    }
    digest = hashlib.sha256(canonical(content)).hexdigest()
    envelope = {"content": content, "contentSHA256": digest}
    bundle = root / "test.iworkordersupport"
    bundle.write_bytes(canonical(envelope))
    loaded = json.loads(bundle.read_text(encoding="utf-8"))
    require(hashlib.sha256(canonical(loaded["content"])).hexdigest() == loaded["contentSHA256"], "support bundle checksum validates")

    loaded["content"]["diagnosticReport"] = "tampered"
    require(hashlib.sha256(canonical(loaded["content"])).hexdigest() != loaded["contentSHA256"], "support bundle tampering is detected")

    encoded = canonical(content).decode("utf-8")
    for forbidden_value in ["100 Test Avenue", "Leaking kitchen faucet", "tenant@example.com", "signature.png", "iWorkOrder.deviceID"]:
        require(forbidden_value not in encoded, f"support bundle excludes operational value: {forbidden_value}")

if errors:
    print("PHASE 56 RUNTIME RELIABILITY HARNESS: FAIL")
    for item in errors:
        print(f"FAIL: {item}")
    print(f"Passed checks before failure: {len(checks)}")
    raise SystemExit(1)

print("PHASE 56 RUNTIME RELIABILITY HARNESS: PASS")
print(f"Checks passed: {len(checks)}")
for item in checks:
    print(f"PASS: {item}")
