#!/usr/bin/env python3
from __future__ import annotations

import argparse
import plistlib
import shutil
import subprocess
import sys
from pathlib import Path


def fail(message: str) -> None:
    print(f"FAIL: {message}", file=sys.stderr)
    raise SystemExit(1)


def require(condition: bool, message: str) -> None:
    if not condition:
        fail(message)
    print(f"PASS: {message}")


def load_plist(path: Path) -> dict:
    try:
        return plistlib.loads(path.read_bytes())
    except Exception as exc:
        fail(f"could not read plist {path}: {exc}")


def signed_entitlements(app: Path) -> dict | None:
    if shutil.which("codesign") is None:
        return None
    completed = subprocess.run(
        ["codesign", "-d", "--entitlements", ":-", str(app)],
        capture_output=True,
    )
    if completed.returncode != 0:
        return None
    payload = completed.stdout or completed.stderr
    start = payload.find(b"<?xml")
    if start < 0:
        start = payload.find(b"<plist")
    if start < 0:
        return None
    try:
        return plistlib.loads(payload[start:])
    except Exception:
        return None


def main() -> int:
    parser = argparse.ArgumentParser(description="Validate a Phase 56 Xcode archive.")
    parser.add_argument("archive", type=Path)
    parser.add_argument("--bundle-id", required=True)
    parser.add_argument("--version", required=True)
    parser.add_argument("--build", required=True)
    parser.add_argument("--icloud-container", required=True)
    args = parser.parse_args()

    archive = args.archive.resolve()
    app = archive / "Products" / "Applications" / "iWorkOrder.app"
    require(archive.is_dir(), "archive directory exists")
    require(app.is_dir(), "archived iWorkOrder.app exists")

    archive_info = load_plist(archive / "Info.plist")
    app_info = load_plist(app / "Info.plist")
    application_properties = archive_info.get("ApplicationProperties", {})

    require(app_info.get("CFBundleIdentifier") == args.bundle_id, "app bundle identifier matches")
    require(app_info.get("CFBundleShortVersionString") == args.version, "marketing version matches")
    require(str(app_info.get("CFBundleVersion")) == args.build, "build number matches")
    require(application_properties.get("CFBundleIdentifier") == args.bundle_id, "archive application identifier matches")

    executable_name = app_info.get("CFBundleExecutable")
    executable = app / str(executable_name)
    require(executable_name and executable.is_file(), "app executable is present")
    require((app / "PrivacyInfo.xcprivacy").is_file(), "privacy manifest is embedded in the app bundle")
    require((app / "Assets.car").is_file(), "compiled asset catalog is embedded")
    require(not list(app.rglob("*.swift")), "source files are not embedded in the app bundle")
    require(not list(app.rglob(".DS_Store")), "Finder metadata is not embedded")

    dsym = archive / "dSYMs" / "iWorkOrder.app.dSYM"
    require(dsym.is_dir(), "release dSYM is present")

    entitlements = signed_entitlements(app)
    if entitlements is None:
        print("INFO: archive is unsigned; signed entitlement validation was skipped")
    else:
        containers = entitlements.get("com.apple.developer.icloud-container-identifiers", [])
        require(args.icloud_container in containers, "signed archive contains the expected iCloud container entitlement")
        services = entitlements.get("com.apple.developer.icloud-services", [])
        require("CloudKit" in services, "signed archive contains the CloudKit entitlement")
        application_identifier = str(entitlements.get("application-identifier", ""))
        require(application_identifier.endswith("." + args.bundle_id), "signed application identifier matches bundle ID")

    print("PHASE 53 ARCHIVE VALIDATION: PASS")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
