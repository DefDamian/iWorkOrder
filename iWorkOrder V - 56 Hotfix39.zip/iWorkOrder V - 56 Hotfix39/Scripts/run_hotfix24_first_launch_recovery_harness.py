#!/usr/bin/env python3
from pathlib import Path
import sys

ROOT = Path(__file__).resolve().parents[1]
APP = ROOT / "iWorkOrder"
app_store = (APP / "AppStore.swift").read_text(encoding="utf-8")
root_view = (APP / "RootView.swift").read_text(encoding="utf-8")
onboarding = (APP / "OnboardingView.swift").read_text(encoding="utf-8")
accessibility = (APP / "AccessibilitySupport.swift").read_text(encoding="utf-8")
ui_tests = (ROOT / "iWorkOrderUITests" / "iWorkOrderUITests.swift").read_text(encoding="utf-8")

checks = []
errors = []

def require(condition: bool, message: str) -> None:
    (checks if condition else errors).append(message)

require(
    "@Published private(set) var shouldOfferInitialDataRecovery = false" in app_store,
    "first-launch recovery has explicit observable routing state",
)
require(
    "shouldOfferInitialDataRecovery = !recoveredPersistedSnapshot && !isOnboardingComplete" in app_store,
    "recovery choice is offered only when no persisted snapshot was recovered",
)
require(
    "if shouldOfferInitialDataRecovery {\n                cloudSyncDetail = \"Choose whether to restore existing data or start a new setup.\"" in app_store,
    "startup cloud work waits for the user's recovery decision",
)
require(
    "if shouldOfferInitialDataRecovery {\n                cloudSyncDetail = online" in app_store,
    "network changes cannot silently start pre-onboarding cloud recovery while the recovery gate is visible",
)
require(
    "func beginFreshOnboarding()" in app_store and "shouldOfferInitialDataRecovery = false" in app_store,
    "explicit no-backup choice enters normal onboarding",
)
require(
    "func restoreFromICloudBeforeOnboarding() async -> Bool" in app_store,
    "first-launch iCloud recovery has a dedicated controlled path",
)
require(
    "guard shouldOfferInitialDataRecovery, !isOnboardingComplete, !hasPersistedLocalState" in app_store,
    "iCloud first-launch recovery cannot replace an already-started local setup",
)
require(
    "isOnboardingComplete = true\n            shouldOfferInitialDataRecovery = false\n            onboardingPersistence.markCompleted(" in app_store,
    "successful recovery skips onboarding and persists completion",
)
require(
    "let currentSavedStateUsesICloud = originalHasPersistedLocalState &&" in app_store,
    "fresh-install default iCloud preferences are not treated as saved cloud authority",
)
require(
    "mode == .replace && (currentSavedStateUsesICloud || restoredStateUsesICloud)" in app_store,
    "cloud replacement is based on real saved/restored state",
)
require(
    "else if !store.isOnboardingComplete && store.shouldOfferInitialDataRecovery" in root_view
    and "InitialDataRecoveryView()" in root_view,
    "root routing places recovery before onboarding",
)
require(
    root_view.find("InitialDataRecoveryView()") < root_view.find("OnboardingView()") < root_view.find("LegalUpdateRequiredView()"),
    "restored users bypass onboarding while stale legal acceptance still reaches the legal gate",
)
require(
    "struct InitialDataRecoveryView: View" in onboarding,
    "first-launch recovery screen exists",
)
require(
    'Text("Do you already have an iWorkOrder backup?")' in onboarding,
    "recovery screen directly asks whether a backup exists",
)
require(
    'Label("Restore Backup File", systemImage:' in onboarding
    and 'Label("Restore from iCloud", systemImage:' in onboarding
    and 'Label("I Don\'t Have a Backup", systemImage:' in onboarding,
    "recovery screen provides file, iCloud, and no-backup paths",
)
require(
    "if let result = await store.restoreBackup(candidate, mode: .replace)" in onboarding,
    "first-launch portable restore uses full replacement so the saved profile is recovered",
)
require(
    "if await store.restoreFromICloudBeforeOnboarding()" in onboarding,
    "recovery screen is wired to the controlled iCloud restore path",
)
require(
    'static let startsBackupRecovery = arguments.contains("-ui-testing-backup-recovery")' in accessibility,
    "UI tests can deterministically start at the first-launch recovery gate",
)
require(
    "func testFirstLaunchOffersBackupRecoveryBeforeOnboarding()" in ui_tests,
    "UI regression covers recovery before onboarding",
)
require(
    'XCTAssertFalse(app.otherElements["screen.onboarding"].exists)' in ui_tests
    and 'app.buttons["recovery.startNew"]' in ui_tests
    and 'XCTAssertTrue(app.otherElements["screen.onboarding"].waitForExistence(timeout: 5))' in ui_tests,
    "UI regression verifies onboarding appears only after the no-backup choice",
)

if errors:
    print("HOTFIX 24 FIRST-LAUNCH RECOVERY HARNESS: FAIL")
    for item in errors:
        print("FAIL:", item)
    print(f"Passed before failure: {len(checks)}")
    sys.exit(1)

print("HOTFIX 24 FIRST-LAUNCH RECOVERY HARNESS: PASS")
print(f"Checks passed: {len(checks)}")
for item in checks:
    print("PASS:", item)
