#!/usr/bin/env python3
from pathlib import Path
import re

ROOT = Path(__file__).resolve().parents[1]
APP = ROOT / "iWorkOrder"
TESTS = ROOT / "iWorkOrderTests" / "iWorkOrderTests.swift"
checks: list[str] = []
errors: list[str] = []


def require(condition: bool, message: str) -> None:
    (checks if condition else errors).append(message)


def block(text: str, start: str, end: str) -> str:
    try:
        i = text.index(start)
        j = text.index(end, i + len(start))
        return text[i:j]
    except ValueError:
        return ""

services = (APP / "Services.swift").read_text(encoding="utf-8")
store = (APP / "AppStore.swift").read_text(encoding="utf-8")
views = (APP / "WorkOrderViews.swift").read_text(encoding="utf-8")
app = (APP / "iWorkOrderApp.swift").read_text(encoding="utf-8")
components = (APP / "Components.swift").read_text(encoding="utf-8")
tests = TESTS.read_text(encoding="utf-8")
settings = (APP / "CalendarHubSettingsViews.swift").read_text(encoding="utf-8")
onboarding = (APP / "OnboardingView.swift").read_text(encoding="utf-8")

# Notification identity and policy must separate user reminders from emergency follow-ups.
require('static let reminderPrefix = "iworkorder.reminder."' in services, "explicit reminders have a dedicated identifier namespace")
require('static let emergencyPrefix = "iworkorder.emergency."' in services, "emergency follow-ups have a dedicated identifier namespace")
require('emergencyPrefix + orderID.uuidString + "." + entryID.uuidString' in services, "emergency identifiers are revision-specific")
require('if let legacy = UUID(uuidString: identifier)' in services, "legacy bare-UUID notification identifiers remain recognizable for cleanup")
policy = block(services, "enum WorkOrderNotificationPolicy", "@MainActor\nfinal class NotificationService")
require('order.latestEntry.reminderDate > now' in policy, "expired explicit reminders cannot be recreated")
require('order.latestEntry.createdAt.addingTimeInterval(10)' in policy, "emergency follow-up time is anchored to the saved revision")
require('date > now ? date : nil' in policy, "expired emergency follow-ups are not resurrected from current time")
require('now.addingTimeInterval(10)' not in policy, "notification policy contains no current-time emergency resurrection")

# Reconciliation must be generation-safe and free of obsolete direct-cancel APIs.
reconcile = block(services, "    func reconcile(", "    nonisolated func userNotificationCenter")
require('reconciliationGeneration += 1' in reconcile, "each notification reconciliation gets a new generation")
require('self.reconciliationGeneration == generation' in reconcile, "stale async cleanup is rejected after a newer reconciliation")
require('eligibleIdentifiers' in reconcile, "reconciliation tracks the exact set of desired requests")
require('func cancelReminder(for orderID' not in services and 'func cancelReminders(for orderIDs' not in services, "unused per-order cancellation API was removed")
require('self.center.removePendingNotificationRequests(withIdentifiers: stale)\n                self.center.removePendingNotificationRequests(withIdentifiers: stale)' not in services, "stale notification cleanup is not executed twice")

# Notification Center side effects must happen only after durable local saves.
add_full = block(store, "    func addFull(entry: WorkOrderEntry)", "    @discardableResult\n    func update(")
require(add_full and add_full.index("guard save() else") < add_full.index("refreshNotifications()", add_full.index("guard save() else")), "new-order notifications reconcile only after save succeeds")
update = block(store, "    func update(", "    func addAudit(")
require(update and update.index("guard save() else") < update.index("refreshNotifications()", update.index("guard save() else")), "edited-order notifications reconcile only after save succeeds")
preferences = block(store, "    func applyNotificationPreferences", "    @discardableResult\n    func setStorageChoice")
require(preferences and preferences.index("guard save() else") < preferences.index("refreshNotifications()", preferences.index("guard save() else")), "notification preference side effects occur only after preference persistence")
for function_name, next_marker, message in [
    ("    func moveToTrash", "    @discardableResult\n    func recover(", "trash notification cleanup follows a successful save"),
    ("    func recover(", "    @discardableResult\n    func recoverAll", "single recovery notification reconciliation follows a successful save"),
    ("    func recoverAll", "    @discardableResult\n    func addAsset", "bulk recovery notification reconciliation follows a successful save"),
]:
    fragment = block(store, function_name, next_marker)
    require(fragment and fragment.index("guard save() else") < fragment.index("refreshNotifications()", fragment.index("guard save() else")), message)
restore = block(store, "    func restore(snapshot: AppSnapshot)", "    @discardableResult\n    func addQuick")
require(restore and restore.index("guard save() else") < restore.rindex("refreshNotifications()"), "snapshot restore applies restored notifications only after the restore snapshot is saved")
require('scheduleReminderIfNeeded' not in store, "AppStore has no legacy pre-save reminder scheduling path")

# System notification authorization is device-local and must not overwrite a synced app preference.
auth_refresh = block(store, "    func refreshNotificationAuthorization() async", "    func refreshNotifications()")
require("profile.notificationsEnabled = false" not in auth_refresh, "device authorization refresh never writes a synced notification preference")
require("applyNotificationPreferences" not in auth_refresh, "device authorization refresh does not persist a local permission denial")
require("notificationPermissionNeedsAttention = true" in auth_refresh and "notifications.cancelAllNotifications()" in auth_refresh, "denied device permission is handled locally and surfaced for attention")
require("store.profile.notificationsEnabled = granted" not in settings, "settings permission request does not persist a local denial as a shared preference")
require("store.profile = previousProfile" in settings and "await store.refreshNotificationAuthorization()" in settings, "settings preserves the prior synced preference when this device denies permission")
require("store.profile.notificationsEnabled = granted" not in onboarding, "onboarding permission request does not push a device-local denial into synced profile state")
require("device Settings" in settings and "device Settings" in onboarding and "iPhone Settings" not in settings + onboarding, "notification denial wording is device-neutral for iPhone and iPad")

# Notification routing is local-only; dormant remote-push launch handling is not shipped.
require('.remoteNotification' not in app, "app delegate contains no dormant remote-push launch path")
require('registerForRemoteNotifications' not in app + services, "app does not register for APNs")
require('func route(userInfo:' not in services, "unused remote-notification userInfo router was removed")
require('func route(url: URL)' in services and 'iworkorder' in services, "custom iWorkOrder deep links remain supported")

# A deep link received before cloud/local data finishes loading must retry when orders change.
retry_line = '.onChange(of: store.activeWorkOrders.map(\\.id)) { _, _ in openDeepLinkedOrderIfNeeded() }'
require(views.count(retry_line) == 3, "all three work-order themes retry pending deep links when work-order data changes")
require(views.count('.onChange(of: store.deepLinkedOrderID) { _, _ in openDeepLinkedOrderIfNeeded() }') == 3, "all three work-order themes react to newly received deep links")
require(views.count('store.deepLinkedOrderID = nil') == 3, "a deep link is consumed only after a matching work order is opened")

# Dead/fake UI from old theme implementations must stay out of the compiled source.
for forbidden in ["LegacyOrderMetrics", "LegacyStatusSegment", "Theme2FilterRow", '$0.00', 'Late 0']:
    require(forbidden not in views, f"compiled work-order UI excludes obsolete/fake surface: {forbidden}")
require("old project" not in components.lower() and "legacy command" not in components.lower(), "public theme descriptions contain no developer-history wording")
require('cloudSyncDetail = "iCloud sync has not run yet."' in store, "initial sync status uses current public iCloud wording")

# Regression tests pin the new notification policy behavior.
for test_name in [
    "testReminderAndEmergencyUseIndependentIdentifiers",
    "testExpiredEmergencyFollowUpIsNotRecreatedFromCurrentTime",
    "testFreshEmergencyFollowUpUsesRevisionTimestamp",
    "testExpiredExplicitReminderDoesNotResurrect",
]:
    require(test_name in tests, f"unit tests include {test_name}")

# Compiler-risk hygiene remains enforced for the application target.
all_swift = "\n".join(path.read_text(encoding="utf-8") for path in APP.glob("*.swift"))
for forbidden in ["TODO", "FIXME", "fatalError(", "try!", " as! "]:
    require(forbidden not in all_swift, f"app source excludes beta-risk marker: {forbidden}")
require(not re.search(r"\.forEach\(\s*[A-Za-z_][A-Za-z0-9_]*(?:\.[A-Za-z_][A-Za-z0-9_]*)+\s*\)", all_swift), "app source excludes direct qualified function references passed to forEach")

for item in checks:
    print(f"PASS: {item}")
if errors:
    for item in errors:
        print(f"FAIL: {item}")
    raise SystemExit(1)
print(f"HOTFIX 21 REAL-WORLD BETA HARNESS: PASS ({len(checks)} checks)")
