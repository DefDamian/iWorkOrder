#!/usr/bin/env python3
from __future__ import annotations

import argparse
import hashlib
import json
from datetime import datetime, timezone
from pathlib import Path


def main() -> int:
    parser = argparse.ArgumentParser(description="Create a SHA-256 index for Phase 56 qualification artifacts.")
    parser.add_argument("artifacts", type=Path)
    args = parser.parse_args()
    root = args.artifacts.resolve()
    root.mkdir(parents=True, exist_ok=True)
    output = root / "EVIDENCE_INDEX.json"

    files = []
    for path in sorted(root.rglob("*")):
        if not path.is_file() or path == output or path.name == ".DS_Store":
            continue
        relative = path.relative_to(root).as_posix()
        files.append({
            "path": relative,
            "bytes": path.stat().st_size,
            "sha256": hashlib.sha256(path.read_bytes()).hexdigest(),
        })

    payload = {
        "schema_version": 1,
        "phase": 56,
        "generated_at_utc": datetime.now(timezone.utc).isoformat(),
        "file_count": len(files),
        "files": files,
    }
    output.write_text(json.dumps(payload, indent=2, sort_keys=True) + "\n", encoding="utf-8")
    print(f"Indexed {len(files)} Phase 56 evidence files: {output}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
