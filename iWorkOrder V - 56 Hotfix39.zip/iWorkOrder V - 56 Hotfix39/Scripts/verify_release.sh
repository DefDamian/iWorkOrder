#!/bin/bash
set -euo pipefail

ROOT="$(cd "$(dirname "$0")/.." && pwd)"
cd "$ROOT"

python3 Scripts/verify_release.py
python3 Scripts/run_logic_harness.py
python3 Scripts/run_accessibility_harness.py
python3 Scripts/run_submission_harness.py
python3 Scripts/run_maintenance_harness.py
python3 Scripts/run_reliability_harness.py
python3 Scripts/run_defect_harness.py
python3 Scripts/run_transactional_harness.py
python3 Scripts/run_core_stability_harness.py
python3 Scripts/run_public_release_harness.py
python3 Scripts/run_public_beta_harness.py
python3 Scripts/run_release_candidate_harness.py
python3 Scripts/run_final_rc_harness.py
python3 Scripts/run_hotfix21_real_world_beta_harness.py
python3 Scripts/run_hotfix22_behavior_harness.py
python3 Scripts/run_hotfix22_integration_harness.py
python3 Scripts/run_hotfix23_xcode_runtime_harness.py
python3 Scripts/run_hotfix24_first_launch_recovery_harness.py
python3 Scripts/run_hotfix25_permissions_legal_harness.py
python3 Scripts/run_hotfix26_work_order_badge_layout_harness.py
python3 Scripts/run_hotfix27_photo_delete_harness.py
python3 Scripts/run_hotfix28_full_bug_loop_harness.py
python3 Scripts/run_hotfix29_theme_switch_harness.py
python3 Scripts/run_hotfix30_launch_continuity_harness.py
python3 Scripts/run_hotfix31_privacy_blur_harness.py
python3 Scripts/run_hotfix32_full_bug_loop_harness.py
python3 Scripts/run_hotfix33_theme_identity_harness.py
python3 Scripts/run_hotfix34_theme3_rebuild_harness.py
python3 Scripts/run_hotfix35_onboarding_theme_scope_harness.py
python3 Scripts/run_hotfix36_swiftui_semantic_lint_harness.py
python3 Scripts/run_hotfix37_xcode27_swift64_harness.py
python3 Scripts/run_hotfix38_ios26_baseline_harness.py
python3 Scripts/run_hotfix39_fullscreen_deprecation_harness.py
python3 Scripts/validate_app_store_metadata.py
python3 Scripts/validate_phase56_evidence.py ReleaseEvidence/phase56_evidence.template.json --root .

SWIFT_FILES=()
while IFS= read -r -d '' swift_file; do
  SWIFT_FILES+=("$swift_file")
done < <(find iWorkOrder iWorkOrderTests iWorkOrderUITests -name '*.swift' -print0)
if command -v swiftc >/dev/null 2>&1; then
  swiftc -parse "${SWIFT_FILES[@]}"
  swiftc -D DEBUG -parse "${SWIFT_FILES[@]}"
  echo "PASS: Swift parser validation (Release and Debug)"
else
  echo "WARNING: swiftc is unavailable; Swift parser validation was skipped." >&2
fi

python3 -m py_compile Scripts/*.py
for script in Scripts/*.sh; do
  bash -n "$script"
done

echo "PHASE 56 CROSS-PLATFORM VERIFICATION: PASS"
