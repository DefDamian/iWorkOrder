#!/usr/bin/env python3
from pathlib import Path
import re

ROOT = Path(__file__).resolve().parents[1]
APP = ROOT / "iWorkOrder"
checks: list[str] = []
errors: list[str] = []


def require(condition: bool, message: str) -> None:
    (checks if condition else errors).append(message)


models = (APP / "Models.swift").read_text(encoding="utf-8")
store = (APP / "AppStore.swift").read_text(encoding="utf-8")
views = (APP / "WorkOrderViews.swift").read_text(encoding="utf-8")
signature = (APP / "SignatureCaptureView.swift").read_text(encoding="utf-8")
services = (APP / "Services.swift").read_text(encoding="utf-8")
onboarding = (APP / "OnboardingView.swift").read_text(encoding="utf-8")
settings = (APP / "CalendarHubSettingsViews.swift").read_text(encoding="utf-8")
ui_tests = (ROOT / "iWorkOrderUITests/iWorkOrderUITests.swift").read_text(encoding="utf-8")

require("var hasRequiredFields: Bool" in models, "work-order entries expose required-field validation")
require("func normalizeUserEnteredText()" in models, "work-order text is normalized before persistence")
require("guard entry.hasRequiredFields" in store, "quick and full creation reject invalid required fields")
require("normalizedEntry?.hasRequiredFields == true" in store, "revision saves reject invalid required fields")
require("expectedLatestEntryID" in store and "latestEntry.id != expectedLatestEntryID" in store, "stale open revisions cannot overwrite newer synchronized revisions")
require("let originalWorkOrders = workOrders" in store and store.count("workOrders = originalWorkOrders") >= 3, "core work-order mutations roll back when local persistence fails")
require("func save() -> Bool" in store, "local save reports persistence success to callers")
require("guard onDone() else" in signature, "signature completion waits for successful work-order persistence")
require("SignatureStorageService.delete(filename: filename)" in signature, "failed completion removes the uncommitted signature file")
require("@State private var isSaving = false" in signature, "signature submission is protected from rapid duplicate taps")
require("dataRepresentation() != drawing.dataRepresentation()" in signature, "PencilKit updates do not blindly replace the active drawing")
require("[.calendar, .timeZone, .year, .month, .day, .hour, .minute, .second]" in services, "notification triggers retain seconds instead of truncating near-term reminders")
require("var id: String { url.absoluteString }" in views, "share-sheet items use stable URL identity")
require("cleanupUncommittedImages" in views and "cleanupUncommittedAttachments" in views, "cancelled drafts remove unreferenced photo and signature files")
require("setStorageChoice(choice)" in onboarding and "store.setICloudEnabled(enabled)" in onboarding, "onboarding storage controls cannot disagree")
require("store.setICloudEnabled(enabled)" in settings, "settings cloud toggle uses the same canonical state transition")
require("order.latestEntry.reminderDate < Date()" in views, "Theme 2 overdue filtering uses actual reminder dates")
require('Theme2MiniStat(title: "Overdue", value: "\\(overdue)"' in views, "Theme 2 overdue count is not hardcoded")
require('Theme2MiniStat(title: "Workers", value: "\\(workers)"' in views, "Theme 2 worker count is not hardcoded")
require("Theme2FilterRow()" not in views, "nonfunctional Theme 2 filter-looking controls are not displayed")
require('case .new: return "New"' in views, "Theme 2 displays the New status accurately")
require("evidenceError" in views and "The selected photo could not be read" in views, "photo import failures produce visible feedback")
require("static func setTorch(active: Bool) async -> Bool" in services, "flashlight state reports activation failure instead of displaying a false On state")
require("The PDF could not be created" in store, "failed PDF export produces visible feedback")
require("saveSignature.tap()" in ui_tests and 'app.buttons["Making Changes"]' in ui_tests, "UI automation completes and verifies the signed work-order transition")
require(not re.search(r"[A-Za-z0-9_\)\]]!([\.\),\]])", "\n".join([models, store, views, signature, services])), "core defect-audited sources contain no force unwraps")

if errors:
    print("HOTFIX 6 DEFECT HARNESS: FAIL")
    for item in errors:
        print(f"FAIL: {item}")
    raise SystemExit(1)

print("HOTFIX 6 DEFECT HARNESS: PASS")
print(f"Checks passed: {len(checks)}")
for item in checks:
    print(f"PASS: {item}")
