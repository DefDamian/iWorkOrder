#!/usr/bin/env python3
"""Compile and execute real core source with test-only Apple-service stand-ins.

This is NOT an Xcode build. Models, JSON codecs, migration validation, local
snapshot I/O, address state, lock state and notification coordination are
extracted unchanged. Only unavailable framework types and maintenance logging
are replaced. Build with Swift 6 strict concurrency and treat warnings as errors.
"""
from __future__ import annotations
import argparse
import os
from pathlib import Path
import subprocess
import tempfile


def block(source: str, marker: str) -> str:
    start = source.index(marker)
    opening = source.index("{", start)
    depth = 0
    for index in range(opening, len(source)):
        if source[index] == "{":
            depth += 1
        elif source[index] == "}":
            depth -= 1
            if depth == 0:
                return source[start:index + 1]
    raise ValueError(f"Unterminated Swift block: {marker}")


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--root", type=Path, default=Path(__file__).resolve().parents[1])
    args = parser.parse_args()
    root = args.root.resolve()
    app = root / "iWorkOrder"
    services = (app / "Services.swift").read_text()
    maintenance = (app / "MaintenanceService.swift").read_text()
    backup = (app / "BackupArchiveService.swift").read_text()
    store = (app / "AppStore.swift").read_text()
    parts = [(app / "Models.swift").read_text().replace("import SwiftUI\n", ""),
             (app / "LegalContent.swift").read_text(),
             (root / "Scripts/BehaviorTests/PlatformFakes.swift").read_text()]
    for marker in ["enum AppDataSchema", "struct DataMigrationResult", "enum DataMigrationError",
                   "enum MaintenanceEventKind", "enum MaintenanceOutcome"]:
        parts.append(block(maintenance, marker))
    parts.append(block(store, "struct AppSnapshot:"))
    parts.append("enum MaintenanceService {\n" + block(maintenance, "    static func migrate(") + r'''
    static var maintenanceDirectory: URL {
        URL(fileURLWithPath: ProcessInfo.processInfo.environment["IWORKORDER_TEST_ROOT"] ?? NSTemporaryDirectory())
            .appendingPathComponent("maintenance", isDirectory: true)
    }
    static func record(kind: MaintenanceEventKind, outcome: MaintenanceOutcome,
                       durationMilliseconds: Int? = nil, itemCount: Int? = nil) {}
    static func createMigrationBackup(sourceURL: URL, sourceVersion: Int, targetVersion: Int) throws -> URL {
        let target = sourceURL.deletingLastPathComponent().appendingPathComponent(UUID().uuidString + ".migration.json")
        try FileManager.default.copyItem(at: sourceURL, to: target)
        return target
    }
}
''')
    for marker in ["enum DeviceIdentity", "enum SnapshotFormatPolicy", "extension JSONEncoder", "enum SnapshotFingerprintEncoding", "extension JSONDecoder",
                   "enum WorkOrderNotificationIdentifier", "enum WorkOrderNotificationPolicy",
                   "enum WorkOrderSearchEngine", "enum ConflictMergeService",
                   "@MainActor final class AppLockState", "@MainActor\nfinal class AddressVerifier",
                   "@MainActor\nfinal class NotificationService"]:
        parts.append(block(services, marker))
    # The local load/save implementation is tested directly. Unrelated storage
    # inventory/erase utilities are covered by the project's existing checks.
    storage = services[services.index("final class StorageService {"):services.index("    func localDataSizeText()")]
    parts.append(storage + "}\n")
    parts.append("enum BackupArchiveError: Error { case snapshotUnreadable, invalidWorkOrderRevisionHistory(Int), unsupportedArchiveVersion(Int) }\n")
    functions = []
    for marker in ["private static func decodeSnapshotWithMigration", "private static func migrateDecodedSnapshot",
                   "private static func migrateLegacySnapshotJSON", "private static func applyDefaults", "private static func jsonObject"]:
        functions.append(block(backup, marker).replace("private static", "static", 1))
    parts.append("enum BackupArchiveService {\n" + "\n".join(functions) + "\n}\n")
    parts.append((root / "Scripts/BehaviorTests/ConsolidatedBehaviorTests.swift").read_text())
    with tempfile.TemporaryDirectory(prefix="iworkorder-behavior-") as directory:
        temporary = Path(directory)
        source = temporary / "BehaviorHarness.swift"
        executable = temporary / "behavior-tests"
        source.write_text("\n".join(parts))
        subprocess.run(["swiftc", "-swift-version", "6", "-strict-concurrency=complete", "-warnings-as-errors",
                        "-parse-as-library", str(source), "-o", str(executable)], check=True, timeout=120)
        environment = dict(os.environ, IWORKORDER_TEST_ROOT=str(temporary / "storage"))
        subprocess.run([str(executable)], check=True, timeout=60, env=environment)


if __name__ == "__main__":
    main()
