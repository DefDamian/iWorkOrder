#!/usr/bin/env python3
from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path

ALLOWED_STATUSES = {"pending", "pass", "fail", "blocked", "not_applicable"}
EXPECTED_PHASE = 56
EXPECTED_VERSION = "1.0"
EXPECTED_BUILD = "56"


def main() -> int:
    parser = argparse.ArgumentParser(description="Validate Phase 56 Apple release qualification evidence.")
    parser.add_argument("evidence", type=Path)
    parser.add_argument("--root", type=Path, default=Path.cwd())
    parser.add_argument("--require-complete", action="store_true")
    args = parser.parse_args()

    evidence_path = args.evidence.resolve()
    root = args.root.resolve()
    errors: list[str] = []
    warnings: list[str] = []

    try:
        payload = json.loads(evidence_path.read_text(encoding="utf-8"))
    except Exception as exc:
        print(f"PHASE 56 EVIDENCE VALIDATION: FAIL\nFAIL: unreadable evidence JSON: {exc}")
        return 1

    if payload.get("schema_version") != 1:
        errors.append("schema_version must be 1")
    if payload.get("phase") != EXPECTED_PHASE:
        errors.append(f"phase must be {EXPECTED_PHASE}")
    if payload.get("app_version") != EXPECTED_VERSION:
        errors.append(f"app_version must be {EXPECTED_VERSION}")
    if str(payload.get("build")) != EXPECTED_BUILD:
        errors.append(f"build must be {EXPECTED_BUILD}")

    gates = payload.get("gates")
    if not isinstance(gates, dict) or not gates:
        errors.append("gates must be a nonempty object")
        gates = {}

    passed = pending = failed = blocked = 0
    for name, gate in sorted(gates.items()):
        if not isinstance(gate, dict):
            errors.append(f"gate {name} must be an object")
            continue
        status = gate.get("status")
        required = gate.get("required")
        evidence = gate.get("evidence")
        notes = gate.get("notes")
        if status not in ALLOWED_STATUSES:
            errors.append(f"gate {name} has invalid status: {status!r}")
            continue
        if not isinstance(required, bool):
            errors.append(f"gate {name} required must be boolean")
        if not isinstance(evidence, list) or any(not isinstance(item, str) or not item.strip() for item in evidence):
            errors.append(f"gate {name} evidence must be a list of nonempty paths")
            evidence = []
        if not isinstance(notes, str):
            errors.append(f"gate {name} notes must be a string")

        if status == "pass":
            passed += 1
            if required and not evidence:
                errors.append(f"required passing gate {name} has no evidence path")
            for item in evidence:
                candidate = Path(item)
                if not candidate.is_absolute():
                    candidate = root / candidate
                try:
                    candidate.resolve().relative_to(root)
                except ValueError:
                    errors.append(f"gate {name} evidence escapes qualification root: {item}")
                    continue
                if not candidate.exists():
                    errors.append(f"gate {name} evidence does not exist: {item}")
        elif status == "fail":
            failed += 1
            errors.append(f"gate {name} is marked fail")
        elif status == "blocked":
            blocked += 1
            if required and args.require_complete:
                errors.append(f"required gate {name} is blocked")
        elif status == "pending":
            pending += 1
            if required and args.require_complete:
                errors.append(f"required gate {name} is pending")
        elif status == "not_applicable" and required:
            errors.append(f"required gate {name} cannot be not_applicable")

    if args.require_complete and not gates:
        errors.append("no gates were supplied for final qualification")

    label = "PASS" if not errors else "FAIL"
    print(f"PHASE 56 EVIDENCE VALIDATION: {label}")
    print(f"Passed gates: {passed}")
    print(f"Pending gates: {pending}")
    print(f"Blocked gates: {blocked}")
    print(f"Failed gates: {failed}")
    for warning in warnings:
        print(f"WARNING: {warning}")
    for error in errors:
        print(f"FAIL: {error}")
    return 0 if not errors else 1


if __name__ == "__main__":
    sys.exit(main())
