#!/usr/bin/env python3
from pathlib import Path
import json
import re

ROOT = Path(__file__).resolve().parents[1]
APP = ROOT / "iWorkOrder"

checks: list[str] = []
errors: list[str] = []


def require(condition: bool, message: str) -> None:
    (checks if condition else errors).append(message)


services = (APP / "Services.swift").read_text(encoding="utf-8")
views = (APP / "WorkOrderViews.swift").read_text(encoding="utf-8")
components = (APP / "Components.swift").read_text(encoding="utf-8")
root_view = (APP / "RootView.swift").read_text(encoding="utf-8")
settings = (APP / "CalendarHubSettingsViews.swift").read_text(encoding="utf-8")
store = (APP / "AppStore.swift").read_text(encoding="utf-8")
unit_tests = (ROOT / "iWorkOrderTests/iWorkOrderTests.swift").read_text(encoding="utf-8")
catalog = json.loads((APP / "Localizable.xcstrings").read_text(encoding="utf-8"))
all_app_swift = "\n".join(path.read_text(encoding="utf-8") for path in APP.glob("*.swift"))

# Evidence-gallery performance: no repeated full-size decode in the SwiftUI body.
require("struct WorkOrderEvidenceThumbnail" in views, "evidence gallery uses a dedicated thumbnail view")
require("WorkOrderEvidenceThumbnail(image: image)" in views, "evidence gallery renders cached display-size thumbnails")
require("ImageStorageService.load(image)" not in views, "work-order SwiftUI views do not synchronously decode full evidence images")
require("CGImageSourceCreateThumbnailAtIndex" in services, "thumbnail generation uses Image I/O downsampling")
require("kCGImageSourceThumbnailMaxPixelSize" in services, "thumbnail generation has an explicit pixel bound")
require("actor WorkOrderImageThumbnailCache" in services, "thumbnail cache is isolated from UI state")
require("private let maxEntries = 64" in services, "thumbnail cache is bounded")
require("contentModificationDateKey" in services and "fileSizeKey" in services, "thumbnail cache identity changes when attachment bytes are replaced")
require("WorkOrderImageThumbnailCache.shared.removeAll()" in store, "snapshot replacement and erase paths clear cached evidence")
require("testEvidenceThumbnailIsDownsampledAndReadable" in unit_tests, "unit tests cover readable bounded evidence thumbnails")
require("testThumbnailCacheDoesNotReturnDeletedAttachment" in unit_tests, "unit tests cover deleted-thumbnail cache safety")

# Accessibility presentation settings.
require("@Environment(\\.accessibilityReduceMotion) private var reduceMotion" in views, "work-order list reads Reduce Motion")
require("if reduceMotion" in views and "withAnimation { store.selectedStatus = status }" in views, "status-filter animation has a Reduce Motion path")
require("if reduceMotion" in views and "_ = store.moveToTrash(order)" in views, "trash animation has a Reduce Motion path")
require("accessibilityReduceTransparency" in components, "shared card/input components read Reduce Transparency")
require("cardFill(reduceTransparency:" in components, "card surfaces become opaque when Reduce Transparency is enabled")
require("accessibilityReduceTransparency" in root_view, "blocking backup overlay reads Reduce Transparency")
require("accessibilityReduceTransparency" in settings, "erase-progress overlay reads Reduce Transparency")

# iOS 26+ navigation should use the system bar appearance rather than overlaying custom tab-bar material.
require("toolbarBackground(.ultraThinMaterial, for: .tabBar)" not in root_view, "tab bar no longer forces a custom material over the system navigation appearance")
require("toolbarBackground(.visible, for: .tabBar)" not in root_view, "tab bar visibility is left to the standard system component")
require("NavigationSplitView" in root_view and "TabView(selection:" in root_view, "top-level navigation remains standard SwiftUI navigation")

# Public status must reflect actual state and must not claim fake integrations/actions.
require('Label("Sync ready"' not in views, "legacy themes do not display a hard-coded sync-ready state")
require('Sync failed - tap to retry' not in views, "legacy themes do not display a fake retry action")
require("syncStatusTitle" in views and "store.cloudSyncState" in views, "legacy theme sync status is derived from live app state")
require('Button("Google Drive")' not in settings and 'Button("OneDrive")' not in settings, "report export does not impersonate provider-specific integration")
require('Label("Share or Save Report"' in settings, "report export uses the system share-sheet action")
require("storage and sharing apps installed on this device" in settings, "report destination wording matches actual share-sheet behavior")

# Managed localization should match the public labels we ship.
strings = catalog.get("strings", {})
require("Share or Save Report" in strings, "string catalog includes the report share action")
require("The iOS share sheet shows the storage and sharing apps installed on this device." in strings, "string catalog includes accurate share-sheet guidance")
require("Use the iOS share sheet to save to Files, Google Drive, or OneDrive if those apps are installed." not in strings, "string catalog removes stale provider-specific share wording")

# General public-beta source hygiene.
for forbidden in ["TODO", "FIXME", "fatalError(", "try!", " as! "]:
    require(forbidden not in all_app_swift, f"app source excludes public-beta risk marker: {forbidden}")
require(not re.search(r"\.forEach\(\s*[A-Za-z_][A-Za-z0-9_]*\.[A-Za-z_][A-Za-z0-9_]*\s*\)", all_app_swift), "app source contains no direct qualified function reference passed to forEach")

for item in checks:
    print(f"PASS: {item}")
if errors:
    for item in errors:
        print(f"FAIL: {item}")
    raise SystemExit(1)
print(f"HOTFIX 18 PUBLIC BETA HARNESS: PASS ({len(checks)} checks)")
