#!/usr/bin/env python3
from pathlib import Path
import re
import sys

ROOT = Path(__file__).resolve().parents[1]
SOURCE_DIRS = [ROOT / "iWorkOrder", ROOT / "iWorkOrderTests", ROOT / "iWorkOrderUITests"]
SWIFT_FILES = sorted(path for directory in SOURCE_DIRS for path in directory.rglob("*.swift"))

passed: list[str] = []
failed: list[str] = []


def require(condition: bool, message: str) -> None:
    (passed if condition else failed).append(message)


sources = {path: path.read_text(encoding="utf-8") for path in SWIFT_FILES}
combined = "\n".join(sources.values())
work_orders = (ROOT / "iWorkOrder/WorkOrderViews.swift").read_text(encoding="utf-8")
verify_sh = (ROOT / "Scripts/verify_release.sh").read_text(encoding="utf-8")
phase56 = (ROOT / "Scripts/phase56_xcode_qualification.sh").read_text(encoding="utf-8")

# Xcode reported this exact invalid SwiftUI type usage in Hotfix35.
require(".stretch" not in combined, "shipping and test Swift contain no nonexistent .stretch alignment member")
require("HStack(alignment: .stretch" not in work_orders, "Theme3OrderRow no longer passes .stretch to HStack VerticalAlignment")
require(".overlay(alignment: .leading)" in work_orders and ".frame(width: 4)" in work_orders, "Theme3OrderRow keeps the full-height priority rail with a valid overlay alignment")

# Swift's parser accepts unknown enum members; Xcode type checking does not. Check
# literal stack-alignment members against the SwiftUI alignment type each stack expects.
valid = {
    "HStack": {"top", "center", "bottom", "firstTextBaseline", "lastTextBaseline"},
    "VStack": {"leading", "center", "trailing"},
    "ZStack": {"center", "top", "bottom", "leading", "trailing", "topLeading", "topTrailing", "bottomLeading", "bottomTrailing"},
}
invalid_stack_alignments: list[str] = []
pattern = re.compile(r"\b(HStack|VStack|ZStack)\s*\(\s*alignment\s*:\s*\.([A-Za-z_][A-Za-z0-9_]*)")
for path, source in sources.items():
    for match in pattern.finditer(source):
        stack, member = match.groups()
        if member not in valid[stack]:
            line = source.count("\n", 0, match.start()) + 1
            invalid_stack_alignments.append(f"{path.relative_to(ROOT)}:{line}:{stack}.{member}")
require(not invalid_stack_alignments, "all literal HStack/VStack/ZStack alignment members match the SwiftUI alignment type")

# Check the common full Alignment-taking modifiers too. These are easy to mistype
# during UI rebuilds and are not rejected by swiftc -parse alone.
full_alignment_members = {"center", "top", "bottom", "leading", "trailing", "topLeading", "topTrailing", "bottomLeading", "bottomTrailing"}
invalid_full_alignments: list[str] = []
modifier_patterns = {
    "overlay": re.compile(r"\.overlay\(\s*alignment\s*:\s*\.([A-Za-z_][A-Za-z0-9_]*)"),
    "background": re.compile(r"\.background\(\s*alignment\s*:\s*\.([A-Za-z_][A-Za-z0-9_]*)"),
    "frame": re.compile(r"\.frame\([^\)]*?alignment\s*:\s*\.([A-Za-z_][A-Za-z0-9_]*)", re.S),
}
for path, source in sources.items():
    for kind, modifier_pattern in modifier_patterns.items():
        for match in modifier_pattern.finditer(source):
            member = match.group(1)
            if member not in full_alignment_members:
                line = source.count("\n", 0, match.start()) + 1
                invalid_full_alignments.append(f"{path.relative_to(ROOT)}:{line}:{kind}.{member}")
require(not invalid_full_alignments, "literal frame/overlay/background alignments use valid SwiftUI Alignment members")

# Other enum-literal APIs that are common sources of parser-clean/Xcode-typecheck failures.
text_alignment_failures: list[str] = []
for path, source in sources.items():
    for match in re.finditer(r"\.multilineTextAlignment\(\.([A-Za-z_][A-Za-z0-9_]*)\)", source):
        if match.group(1) not in {"leading", "center", "trailing"}:
            line = source.count("\n", 0, match.start()) + 1
            text_alignment_failures.append(f"{path.relative_to(ROOT)}:{line}:{match.group(1)}")
require(not text_alignment_failures, "multilineTextAlignment literals use valid TextAlignment members")

nav_mode_failures: list[str] = []
for path, source in sources.items():
    for match in re.finditer(r"\.navigationBarTitleDisplayMode\(\.([A-Za-z_][A-Za-z0-9_]*)\)", source):
        if match.group(1) not in {"automatic", "inline", "large"}:
            line = source.count("\n", 0, match.start()) + 1
            nav_mode_failures.append(f"{path.relative_to(ROOT)}:{line}:{match.group(1)}")
require(not nav_mode_failures, "navigation title display mode literals use valid members")

# Preserve prior compile correction and the rebuilt Theme 3 identity while fixing this row.
onboarding = (ROOT / "iWorkOrder/OnboardingView.swift").read_text(encoding="utf-8")
require("private var selectedTheme: VisualTheme { VisualTheme(rawValue: selectedThemeRaw) ?? .defaultTheme }" in onboarding, "Hotfix35 selectedTheme scope correction remains present")
require("FIELD DECK / ACTIVE" in work_orders, "Theme 3 Field Deck rebuild remains present")
require("Theme3OrderRow" in work_orders, "Theme 3 work-order row remains present after compile correction")

# Release integration.
require("run_hotfix36_swiftui_semantic_lint_harness.py" in verify_sh, "portable verification executes the Hotfix36 semantic SwiftUI harness")
require("run_hotfix36_swiftui_semantic_lint_harness.py" in phase56, "Xcode qualification records the Hotfix36 semantic SwiftUI harness")
require((ROOT / "VERIFICATION_NOTES_v56_HOTFIX36_SWIFTUI_TYPECHECK_GUARD.md").is_file(), "Hotfix36 verification notes are included")

if failed:
    print("HOTFIX 36 SWIFTUI SEMANTIC LINT: FAIL")
    for item in failed:
        print("FAIL:", item)
    if invalid_stack_alignments:
        print("INVALID STACK ALIGNMENTS:", ", ".join(invalid_stack_alignments))
    if invalid_full_alignments:
        print("INVALID FULL ALIGNMENTS:", ", ".join(invalid_full_alignments))
    if text_alignment_failures:
        print("INVALID TEXT ALIGNMENTS:", ", ".join(text_alignment_failures))
    if nav_mode_failures:
        print("INVALID NAV MODES:", ", ".join(nav_mode_failures))
    print(f"Checks passed before failure: {len(passed)}")
    sys.exit(1)

print("HOTFIX 36 SWIFTUI SEMANTIC LINT: PASS")
print(f"Checks passed: {len(passed)}")
for item in passed:
    print("PASS:", item)
