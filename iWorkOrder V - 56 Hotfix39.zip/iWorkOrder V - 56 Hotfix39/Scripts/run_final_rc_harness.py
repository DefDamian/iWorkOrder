#!/usr/bin/env python3
from pathlib import Path
import json
import plistlib
import re

ROOT = Path(__file__).resolve().parents[1]
APP = ROOT / "iWorkOrder"
TESTS = ROOT / "iWorkOrderTests" / "iWorkOrderTests.swift"
checks: list[str] = []
errors: list[str] = []

def require(condition: bool, message: str) -> None:
    (checks if condition else errors).append(message)

services = (APP / "Services.swift").read_text(encoding="utf-8")
views = (APP / "WorkOrderViews.swift").read_text(encoding="utf-8")
settings = (APP / "CalendarHubSettingsViews.swift").read_text(encoding="utf-8")
tests = TESTS.read_text(encoding="utf-8")
catalog = json.loads((APP / "Localizable.xcstrings").read_text(encoding="utf-8"))
with (APP / "Info.plist").open("rb") as handle:
    info = plistlib.load(handle)

# Picker import must avoid UIKit full-image decode on the SwiftUI task path.
require("static func saveCompressed(data sourceData: Data" in services, "picker bytes have a dedicated ImageIO compression path")
require("CGImageSourceCreateWithData(sourceData as CFData" in services, "picker compression decodes through ImageIO")
require("kCGImageSourceThumbnailMaxPixelSize: maxPixelSize" in services, "picker compression enforces a maximum pixel dimension")
require("kCGImageSourceCreateThumbnailWithTransform: true" in services, "picker compression preserves source orientation")
require("CGImageDestinationCreateWithData" in services and "kCGImageDestinationLossyCompressionQuality: 0.74" in services, "picker compression writes bounded JPEG output")
require("Task.detached(priority: .userInitiated)" in views and "ImageStorageService.saveCompressed(data: data, kind: kind)" in views, "picker conversion runs away from the UI actor")
load_photo = views.split("private func loadPhoto", 1)[1].split("}\n}", 1)[0]
require("UIImage(data: data)" not in load_photo, "picker import no longer performs full UIImage decoding on the SwiftUI task path")
require("testPickerDataCompressionWritesBoundedReadableJPEG" in tests, "unit regression covers picker-data compression")
require("private static func canDecodeImageSource" in services and "kCGImageSourceThumbnailMaxPixelSize: 16" in services and "CGImageSourceCreateThumbnailAtIndex(source, 0, options as CFDictionary) != nil" in services, "attachment readability checks perform a tiny ImageIO pixel decode")
require("SignatureStorageService.isReadableImage(filename: signatureReference)" in (APP / "AppStore.swift").read_text(encoding="utf-8"), "signed-record integrity avoids full signature image decoding")

# Torch access must be permission-aware and lifecycle-safe.
require("AVCaptureDevice.authorizationStatus(for: .video)" in services, "flashlight checks camera authorization before activation")
require("await AVCaptureDevice.requestAccess(for: .video)" in services, "flashlight requests camera authorization when needed")
require("!Task.isCancelled" in services.split("enum FlashlightService", 1)[1], "flashlight authorization respects task cancellation")
require("@Environment(\\.scenePhase) private var scenePhase" in views, "work-order evidence form observes app lifecycle for torch safety")
require("phase != .active, torchOn" in views, "flashlight is shut down when the app leaves the foreground")
require("isFormVisible = false" in views and "requestedState && changed && (!isFormVisible || scenePhase != .active)" in views, "late flashlight authorization cannot turn hardware on after the form disappears")
require("torchOperationInProgress" in views and ".disabled(torchOperationInProgress)" in views, "flashlight button suppresses overlapping hardware requests")

# Support view must not recursively scan evidence/backups during ordinary body rendering.
require('@State private var localStorageText = "Calculating..."' in settings, "support screen caches local storage display state")
require('InfoLine(title: "Local Storage", value: localStorageText)' in settings, "support screen renders cached local storage usage")
require("StorageService().localDataSizeText()" in settings and "Task.detached(priority: .utility)" in settings, "support storage scan runs off the UI actor")
body_fragment = settings.split("struct SupportDiagnosticsView", 1)[1].split("private func exportSupportBundle", 1)[0]
require('InfoLine(title: "Local Storage", value: StorageService().localDataSizeText())' not in body_fragment, "support body no longer performs a recursive storage scan inline")
require('@State private var totalLocalStorageText = "Calculating..."' in settings and '@State private var safetyBackupsStorageText = "Calculating..."' in settings, "backup screen caches storage summary display state")
require('InfoLine(title: "Total Local Storage", value: totalLocalStorageText)' in settings and 'InfoLine(title: "Restore Safety Backups", value: safetyBackupsStorageText)' in settings, "backup screen renders cached storage summaries")
require('InfoLine(title: "Total Local Storage", value: StorageService().localDataSizeText())' not in settings and 'fromByteCount: BackupArchiveService.safetyBackupsSize()' not in settings.split('struct ExportBackupView',1)[1].split('private func refreshStorageSummary',1)[0], "backup view body no longer performs recursive storage scans inline")
require('@State private var latestSafetyBackupURL: URL?' in settings and '.disabled(isWorking || latestSafetyBackupURL == nil)' in settings, "backup view caches latest-safety-backup availability")
require('guard let url = latestSafetyBackupURL else' in settings, "latest safety restore uses the cached background inventory")

# Public URL metadata may use current product identity without changing bundle/iCloud compatibility IDs.
url_types = info.get("CFBundleURLTypes", [])
url_name = url_types[0].get("CFBundleURLName") if url_types else None
require(url_name == "com.damiancedeno.iWorkOrder", "custom URL type uses current iWorkOrder identity")
require("iworkorder" in (url_types[0].get("CFBundleURLSchemes", []) if url_types else []), "existing iworkorder deep-link scheme is preserved")

# General compiler-risk hygiene remains intact.
all_swift = "\n".join(path.read_text(encoding="utf-8") for path in APP.glob("*.swift"))
for forbidden in ["TODO", "FIXME", "fatalError(", "try!", " as! "]:
    require(forbidden not in all_swift, f"app source excludes final-RC risk marker: {forbidden}")
require(not re.search(r"\.forEach\(\s*[A-Za-z_][A-Za-z0-9_]*\.[A-Za-z_][A-Za-z0-9_]*\s*\)", all_swift), "app source still excludes direct qualified function references passed to forEach")

for item in checks:
    print(f"PASS: {item}")
if errors:
    for item in errors:
        print(f"FAIL: {item}")
    raise SystemExit(1)
print(f"HOTFIX 20 FINAL RELEASE CANDIDATE HARNESS: PASS ({len(checks)} checks)")
