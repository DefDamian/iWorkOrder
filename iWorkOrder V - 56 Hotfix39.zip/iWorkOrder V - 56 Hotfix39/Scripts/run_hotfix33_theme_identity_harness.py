#!/usr/bin/env python3
from pathlib import Path
import re
import sys

ROOT = Path(__file__).resolve().parents[1]
APP = ROOT / "iWorkOrder"
components = (APP / "Components.swift").read_text(encoding="utf-8")
work_orders = (APP / "WorkOrderViews.swift").read_text(encoding="utf-8")
settings = (APP / "CalendarHubSettingsViews.swift").read_text(encoding="utf-8")
root_view = (APP / "RootView.swift").read_text(encoding="utf-8")
ui_tests = (ROOT / "iWorkOrderUITests/iWorkOrderUITests.swift").read_text(encoding="utf-8")
verify_sh = (ROOT / "Scripts/verify_release.sh").read_text(encoding="utf-8")
phase56 = (ROOT / "Scripts/phase56_xcode_qualification.sh").read_text(encoding="utf-8")

checks: list[str] = []
errors: list[str] = []


def require(condition: bool, message: str) -> None:
    (checks if condition else errors).append(message)


def struct_block(source: str, name: str) -> str:
    match = re.search(rf"\bstruct\s+{re.escape(name)}\b[^{{]*\{{", source)
    if not match:
        return ""
    start = match.start()
    brace = source.find("{", match.start())
    depth = 0
    for idx in range(brace, len(source)):
        if source[idx] == "{":
            depth += 1
        elif source[idx] == "}":
            depth -= 1
            if depth == 0:
                return source[start:idx + 1]
    return ""

# Three persisted identities remain stable even though Design 3 was rebuilt later.
require("case defaultTheme" in components and "case design2" in components and "case design3" in components, "all three persisted theme identities exist")
require('static let storageKey = "selectedVisualTheme"' in components, "theme persistence key remains compatible")
require("case .defaultTheme: return 24" in components and "case .design2: return 16" in components and "case .design3: return 10" in components, "all three card geometries are distinct")
require("case .design2: return Color(red: 0.03, green: 0.45, blue: 0.93)" in components, "Design 2 keeps its electric command accent")
require("case .design3: return Color(red: 0.34, green: 0.94, blue: 0.72)" in components, "Design 3 uses its independent mint field accent")
require("case .design3: return .dark" in root_view, "Design 3 uses a dedicated dark appearance")

# Shared chrome branches independently for Design 2 and Design 3.
modern_card = struct_block(components, "ModernCard")
require("if selectedTheme == .design2" in modern_card and "if selectedTheme == .design3" in modern_card, "ModernCard retains separate Design 2 and Design 3 chrome")
require("Rectangle()" in modern_card and "AppTheme.accent(for: .design3)" in modern_card, "Design 3 shared cards use a field rail instead of the old circular ornament")
require("AppTheme.cardFill(reduceTransparency: reduceTransparency, theme: selectedTheme)" in modern_card, "shared cards keep accessibility-safe fills")

section_header = struct_block(components, "SectionHeader")
require("case .design2:" in section_header and "case .design3:" in section_header, "section headers define independent custom-theme layouts")
require('Text("FIELD / \\(title.uppercased())")' in section_header, "Design 3 headers expose field-deck identity")
require("design: .monospaced" in section_header, "Design 2 preserves command typography")

metric = struct_block(components, "MetricTile")
require("case .design2:" in metric and "case .design3:" in metric, "metric tiles have independent custom-theme layouts")
require("background(AppTheme.accent(for: .design3), in: RoundedRectangle(cornerRadius: 7" in metric, "Design 3 metrics use solid field markers")

settings_row = struct_block(components, "SettingsRow")
require("case .design2:" in settings_row and "case .design3:" in settings_row, "settings rows have independent custom-theme layouts")
require('selectedTheme == .design3 ? "arrow.up.right"' in settings_row, "Design 3 settings rows use field navigation affordances")

# Theme chooser renders the represented theme rather than the active theme.
chooser = struct_block(settings, "ThemeSettingsView")
option = struct_block(settings, "ThemeOptionCard")
preview = struct_block(settings, "ThemePreview")
require("ThemeOptionCard(theme: theme, isSelected: theme == selectedTheme)" in chooser, "theme chooser delegates each represented theme")
require("AppTheme.cardFill(reduceTransparency: reduceTransparency, theme: theme)" in option, "theme option fill is represented-theme specific")
require('case .defaultTheme: return "SYSTEM"' in option and 'case .design2: return "COMMAND"' in option and 'case .design3: return "FIELD"' in option, "theme chooser exposes system, command, and field identities")
require("case .defaultTheme:" in preview and "case .design2:" in preview and "case .design3:" in preview, "all three theme previews are independent")
require("AppTheme.accent(for: .design3)" in preview and "Color.purple" not in struct_block(settings, "ThemePreview"), "Design 3 preview no longer reuses the old purple workflow look")

# Work order roots are mutually exclusive.
home = struct_block(work_orders, "WorkOrderHomeView")
require("Theme2OrdersHomeView()" in home and "Theme3OrdersHomeView()" in home, "custom themes use dedicated work-order surfaces")
require("theme.surface.default" in work_orders and "theme.surface.design2" in work_orders and "theme.surface.design3" in work_orders, "three work-order surfaces expose distinct UI-test identities")
require("FIELD DECK / ACTIVE" in struct_block(work_orders, "Theme3OrdersHero"), "Design 3 work-order hero is the field-deck design")
require("design: .rounded" not in struct_block(work_orders, "Theme3OrdersHero"), "Design 3 no longer uses the old rounded workflow typography")
require("Color.purple" not in work_orders[work_orders.find("// MARK: - Design 3 field-deck theme"):], "rebuilt Design 3 work-order surface contains no old purple workflow styling")

# Calendar, Hub, and Settings have dedicated field-deck structures.
calendar = struct_block(settings, "CalendarWorkOrderView")
require("Theme3CalendarContent(orders: store.reminderWorkOrders)" in calendar, "Design 3 Calendar uses a dedicated field surface")
require("FIELD DECK / SCHEDULE" in struct_block(settings, "Theme3CalendarContent"), "Design 3 Calendar has field-deck identity")
hub = struct_block(settings, "HubView")
require("Theme3HubHeader" in hub and "FIELD DECK / OVERVIEW" in struct_block(settings, "Theme3HubHeader"), "Design 3 Hub has a dedicated field-deck header")
settings_view = struct_block(settings, "SettingsView")
require("Theme3SettingsHeader()" in settings_view and "Theme3SettingsGroup" in settings_view, "Design 3 Settings has a dedicated grouped field layout")
require("FIELD DECK / CONFIG" in struct_block(settings, "Theme3SettingsHeader"), "Design 3 Settings exposes field-deck identity")

# Native UI regression verifies the three theme surfaces and the new Design 3 destinations.
require("func testThemeWorkOrderSurfacesAreDistinct()" in ui_tests, "Xcode UI automation covers all three work-order surfaces")
require("func testTheme3FieldDeckSurfacesAreDistinct()" in ui_tests, "Xcode UI automation covers rebuilt Design 3 across main tabs")
for surface in ["theme.surface.default", "theme.surface.design2", "theme.surface.design3", "theme.design3.calendar", "theme.design3.hub", "theme.design3.settings"]:
    require(surface in ui_tests or surface in settings or surface in work_orders, f"surface identity exists: {surface}")

# Release integration remains intact.
require("run_hotfix33_theme_identity_harness.py" in verify_sh, "cross-platform verification executes Hotfix33 theme identity harness")
require("run_hotfix33_theme_identity_harness.py" in phase56, "Xcode qualification executes Hotfix33 theme identity harness")
require((ROOT / "VERIFICATION_NOTES_v56_HOTFIX33_THEME_IDENTITY.md").is_file(), "Hotfix33 verification notes remain included")

if errors:
    print("HOTFIX 33 THEME IDENTITY: FAIL")
    for item in errors:
        print("FAIL:", item)
    print(f"Passed before failure: {len(checks)}")
    sys.exit(1)

print("HOTFIX 33 THEME IDENTITY: PASS")
print(f"Checks passed: {len(checks)}")
for item in checks:
    print("PASS:", item)
