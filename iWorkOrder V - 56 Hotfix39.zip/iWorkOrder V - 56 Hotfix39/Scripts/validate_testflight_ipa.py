#!/usr/bin/env python3
from __future__ import annotations

import argparse
import plistlib
import sys
import tempfile
import zipfile
from pathlib import Path


def fail(message: str) -> None:
    print(f"FAIL: {message}")
    raise SystemExit(1)


parser = argparse.ArgumentParser()
parser.add_argument("ipa", type=Path)
parser.add_argument("--bundle-id", required=True)
parser.add_argument("--version", required=True)
parser.add_argument("--build", required=True)
args = parser.parse_args()

if not args.ipa.is_file():
    fail(f"IPA does not exist: {args.ipa}")
if not zipfile.is_zipfile(args.ipa):
    fail("file is not a valid IPA ZIP archive")

with tempfile.TemporaryDirectory(prefix="iworkorder-ipa-") as temporary:
    root = Path(temporary)
    with zipfile.ZipFile(args.ipa) as archive:
        bad = [name for name in archive.namelist() if name.startswith("/") or ".." in Path(name).parts]
        if bad:
            fail("IPA contains unsafe paths")
        archive.extractall(root)

    apps = list((root / "Payload").glob("*.app"))
    if len(apps) != 1:
        fail(f"expected one app bundle, found {len(apps)}")
    app = apps[0]
    info_path = app / "Info.plist"
    if not info_path.is_file():
        fail("app Info.plist is missing")
    info = plistlib.loads(info_path.read_bytes())

    checks = [
        (info.get("CFBundleIdentifier") == args.bundle_id, "bundle identifier matches"),
        (info.get("CFBundleShortVersionString") == args.version, "marketing version matches"),
        (str(info.get("CFBundleVersion")) == args.build, "build number matches"),
        ((app / "PrivacyInfo.xcprivacy").is_file(), "privacy manifest is embedded"),
        ((app / "Assets.car").is_file(), "compiled asset catalog is embedded"),
        ((app / "embedded.mobileprovision").is_file(), "distribution provisioning profile is embedded"),
        ((app / info.get("CFBundleExecutable", "")).is_file(), "application executable is embedded"),
    ]
    failures = [message for passed, message in checks if not passed]
    if failures:
        for message in failures:
            print(f"FAIL: {message}")
        sys.exit(1)

print("PHASE 53 TESTFLIGHT IPA VALIDATION: PASS")
for _, message in checks:
    print(f"PASS: {message}")
