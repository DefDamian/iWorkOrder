#!/usr/bin/env python3
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
APP = ROOT / "iWorkOrder"

store = (APP / "AppStore.swift").read_text(encoding="utf-8")
services = (APP / "Services.swift").read_text(encoding="utf-8")
onboarding = (APP / "OnboardingView.swift").read_text(encoding="utf-8")
settings = (APP / "CalendarHubSettingsViews.swift").read_text(encoding="utf-8")
logic_harness = (ROOT / "Scripts/run_logic_harness.py").read_text(encoding="utf-8")
unit_tests = (ROOT / "iWorkOrderTests/iWorkOrderTests.swift").read_text(encoding="utf-8")

checks: list[str] = []
errors: list[str] = []


def require(condition: bool, message: str) -> None:
    (checks if condition else errors).append(message)


def block(source: str, marker: str, next_marker: str) -> str:
    start = source.index(marker)
    end = source.index(next_marker, start)
    return source[start:end]


merge_block = block(services, "enum ConflictMergeService", "struct SecurityService")
save_block = block(store, "func save() -> Bool", "private func currentSnapshot")
purge_block = block(store, "func purgeOldData(years: Int)", "func syncNow() async")
backup_block = block(store, "func exportFullBackup() async", "func inspectBackup")
add_audit_block = block(store, "func addAudit(to order", "private func record")
mutation_block = block(store, "func moveToTrash", "func syncNow() async")
address_block = block(services, "final class AddressVerifier", "@MainActor\nfinal class NotificationService")

require("merged.isDeleted = a.isDeleted || b.isDeleted" not in merge_block, "cloud merge no longer makes deletion permanent")
require("deletionTransition(for:" in merge_block and ".recovered" in merge_block, "cloud merge resolves explicit delete and recovery events")
require("newer recovery event must beat an older deletion" in logic_harness, "executable logic harness covers recovery winning over stale deletion")
require("testRecoveryEventWinsOverOlderDeletionDuringMerge" in unit_tests, "unit tests cover recovered work orders during merge")
require("testNewerDeletionEventWinsOverOlderRecoveryDuringMerge" in unit_tests, "unit tests cover a later deletion after recovery")

require("nextSaveRevisionCandidate" in services and "commitSaveRevision" in services, "save revisions use reserve-then-commit semantics")
require("nextSaveRevision()" not in services, "save revisions are not consumed before persistence")
require(save_block.index("storage.save(snapshot)") < save_block.index("StorageService.commitSaveRevision"), "save revision commits only after protected storage succeeds")
require("workOrdersBeforeIntegrityRepair" in save_block and "workOrders = workOrdersBeforeIntegrityRepair" in save_block, "failed saves roll back in-memory integrity repair mutations")
require("applyPendingRevisionRepairAuditNotices()" in save_block and "pendingRevisionRepairOrderIDs.removeAll()" in save_block, "pending repair evidence is applied before save and cleared only after success")

require("guard !workOrders[index].isSignedAndLocked else { return }" in add_audit_block, "viewing a signed completed order cannot mutate its legal audit trail")
require("let originalWorkOrders = workOrders" in add_audit_block and "workOrders = originalWorkOrders" in add_audit_block, "failed ordinary audit writes roll back")

for marker in ["func moveToTrash", "func recover(_ order", "func recoverAll", "func addAsset", "func addTenant", "func importUnits"]:
    require(marker in mutation_block, f"transactional mutation exists: {marker}")
require(mutation_block.count("guard save() else") >= 6, "trash, recovery, directory, and import mutations require successful persistence")
require("if store.addAsset(asset)" in settings and "if store.addTenant(tenant)" in settings, "asset and contact forms clear only after successful save")
require("if store.importUnits" in settings and "if store.importUnits" in onboarding, "unit import text clears only after successful save")
require("applyNotificationPreferences(previousProfile:" in store, "notification preference persistence has an explicit rollback profile")
preference_block = block(store, "func applyNotificationPreferences", "func setStorageChoice")
require("profile = rollbackProfile" in preference_block and "guard save() else" in preference_block, "failed notification preference persistence restores the immediately previous state")
for name, source, marker, next_marker in [
    ("settings", settings, "private func updateNotificationsEnabled", "private func updateEmergencyNotificationsEnabled"),
    ("onboarding", onboarding, "private func updateNotificationPreference", "private func finishSetup")
]:
    prompt_block = block(source, marker, next_marker)
    granted_block = block(prompt_block, "if granted {", "} else {")
    denied_block = block(prompt_block, "} else {", "await store.refreshNotificationAuthorization()")
    require("let previousProfile = store.profile" in granted_block and "store.profile =" not in denied_block,
            name + " permission denial does not roll back unrelated changes made during the prompt")
require("updateSecuritySetting" in settings and "if store.save()" in settings and "store.profile = previousProfile" in settings, "security setting changes are transactional")
require(".disabled(isUpdatingSecurity)" in settings, "security control blocks duplicate asynchronous changes")

require(purge_block.index("guard save() else") < purge_block.index("ImageStorageService.deleteUnreferenced"), "retention cleanup persists the redaction before deleting files")
require("retainedFilenames" in purge_block and "deleteUnreferenced(keeping: retainedFilenames)" in purge_block, "retention cleanup preserves referenced attachment files and sweeps only orphans")
require("workOrders = originalWorkOrders" in purge_block, "retention cleanup rolls back database changes if persistence fails")
require("cleanup.removedCount" in purge_block and "cleanup.failedFilenames" in purge_block, "retention cleanup reports verified physical deletion and surfaces filesystem failures")
require("if orderChanged" in purge_block, "repeated retention purges do not append duplicate redaction audits when nothing changed")

require("verificationGeneration += 1" in address_block, "address verification invalidates earlier asynchronous requests")
require("generation == verificationGeneration" in address_block, "stale geocoder callbacks cannot overwrite a newer request")
require("cancelCurrentLookup()" in address_block and "request.cancel()" in address_block and "search.cancel()" not in address_block, "invalid and superseded address requests cancel the supported MKGeocodingRequest path")

require("captureInMemorySnapshotContents" in store and "restoreInMemorySnapshotContents" in store, "cloud merge application has an in-memory rollback boundary")
require(store.count("guard repairAndPersistLoadedState() else") >= 3, "cloud restore, sync, and replacement require local persistence before reporting success")
require("repairsChangedData" in backup_block and "guard storage.save(snapshot) else" in backup_block, "backup export commits pending integrity repairs before exporting")
require(backup_block.index("guard storage.save(snapshot) else") < backup_block.index("createPortableBackup"), "backup export never publishes an uncommitted repaired snapshot")

if errors:
    print("HOTFIX 7 TRANSACTIONAL HARNESS: FAIL")
    for item in errors:
        print(f"FAIL: {item}")
    raise SystemExit(1)

print("HOTFIX 7 TRANSACTIONAL HARNESS: PASS")
print(f"Checks passed: {len(checks)}")
for item in checks:
    print(f"PASS: {item}")
