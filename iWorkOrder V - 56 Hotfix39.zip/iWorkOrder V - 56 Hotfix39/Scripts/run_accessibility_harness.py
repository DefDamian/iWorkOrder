#!/usr/bin/env python3
from __future__ import annotations

import json
import plistlib
import re
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
APP = ROOT / "iWorkOrder"
UI_TESTS = ROOT / "iWorkOrderUITests" / "iWorkOrderUITests.swift"
PROJECT = ROOT / "iWorkOrder.xcodeproj" / "project.pbxproj"
SCHEME = ROOT / "iWorkOrder.xcodeproj" / "xcshareddata" / "xcschemes" / "iWorkOrder.xcscheme"

checks: list[tuple[bool, str]] = []

def check(condition: bool, message: str) -> None:
    checks.append((condition, message))

swift_files = sorted(APP.glob("*.swift"))
app_source = "\n".join(path.read_text(encoding="utf-8") for path in swift_files)
ui_source = UI_TESTS.read_text(encoding="utf-8")
project_source = PROJECT.read_text(encoding="utf-8")
scheme_source = SCHEME.read_text(encoding="utf-8")

with (APP / "Info.plist").open("rb") as handle:
    info = plistlib.load(handle)
with (APP / "Localizable.xcstrings").open("r", encoding="utf-8") as handle:
    catalog = json.load(handle)

ipad_orientations = set(info.get("UISupportedInterfaceOrientations~ipad", []))
required_ipad_orientations = {
    "UIInterfaceOrientationPortrait",
    "UIInterfaceOrientationPortraitUpsideDown",
    "UIInterfaceOrientationLandscapeLeft",
    "UIInterfaceOrientationLandscapeRight",
}
check(ipad_orientations == required_ipad_orientations, "iPad declares all portrait and landscape orientations")
check("UIRequiresFullScreen" not in info, "deprecated UIRequiresFullScreen key is absent so iPad uses modern resizable scenes")
check("NavigationSplitView" in app_source, "regular-width navigation uses NavigationSplitView")
check(app_source.count("ViewThatFits") >= 3, "large-text layouts use ViewThatFits fallbacks")
check(app_source.count("GridItem(.adaptive") >= 4, "active dashboard and filter layouts use adaptive grids")
check("accessibilityReduceMotion" in app_source, "splash behavior honors Reduce Motion")
check("keyboardShortcut" in app_source and "Command" in app_source, "iPad navigation exposes hardware-keyboard shortcuts")
check(".font(.system(size:" not in app_source, "interface source contains no fixed point-size fonts")
check(app_source.count("accessibilityLabel") >= 15, "VoiceOver labels are broadly applied")
check(app_source.count("accessibilityIdentifier") >= 20, "stable automation identifiers are broadly applied")
check(app_source.count("accessibilityHidden(true)") >= 10, "decorative visuals are hidden from assistive technologies")
check("accessibilityAction" in app_source, "work-order rows expose non-gesture accessibility actions")
check("@MainActor\nfinal class iWorkOrderUITests" not in ui_source and ui_source.count("@MainActor") >= 5, "UI automation methods are main-actor isolated without isolating XCTestCase")
check(ui_source.count("performAccessibilityAudit") >= 2, "UI automation audits onboarding and seeded work-order screens")
check(".textClipped" not in ui_source, "text-clipping accessibility findings are not suppressed")
check("-ui-testing-onboarding" in ui_source and "-ui-testing-seeded" in ui_source, "UI tests use deterministic onboarding and seeded launch modes")
check("iWorkOrderUITests" in project_source, "Xcode project includes the UI-test target")
check("iWorkOrderUITests" in scheme_source, "shared scheme executes the UI-test target")
check(catalog.get("sourceLanguage") == "en", "string catalog declares English source language")
check(len(catalog.get("strings", {})) >= 150, "string catalog contains the managed interface baseline")

# Every stable identifier queried by UI automation must exist in the app source or shared identifier definitions.
queried = {
    value
    for value in re.findall(r'\["([A-Za-z0-9_.-]+)"\]', ui_source)
    if value.startswith(("screen.", "main.tab.", "workOrders.", "quickAdd.", "newOrder.", "support.", "maintenance."))
}
dynamic_identifiers = {
    "main.tab.workOrders",
    "main.tab.calendar",
    "main.tab.hub",
    "main.tab.settings",
}
missing = sorted(identifier for identifier in queried if identifier not in app_source and identifier not in dynamic_identifiers)
check(not missing, "all UI-test accessibility identifiers are implemented by the application")
check("screen.support" in ui_source and "support.exportPackage" in ui_source and "support.email" in ui_source, "UI automation covers the public support screen")
check("MaintenanceRecoveryView" in app_source, "maintenance and recovery screen participates in adaptive accessibility UI")
check("maintenanceRecoveryScreen" in app_source, "maintenance screen has a stable accessibility identifier")
check("runMaintenanceHealthCheck" in app_source and "exportMaintenanceReport" in app_source, "maintenance actions have stable accessibility identifiers")
check("testMaintenanceRecoveryCanRunHealthCheck" in ui_source, "UI automation covers maintenance recovery health checks")

failures = [message for passed, message in checks if not passed]
if failures:
    print("PHASE 56 ACCESSIBILITY HARNESS: FAIL")
    for message in failures:
        print(f"FAIL: {message}")
    sys.exit(1)

print("PHASE 56 ACCESSIBILITY HARNESS: PASS")
print(f"Checks passed: {len(checks)}")
for _, message in checks:
    print(f"PASS: {message}")
