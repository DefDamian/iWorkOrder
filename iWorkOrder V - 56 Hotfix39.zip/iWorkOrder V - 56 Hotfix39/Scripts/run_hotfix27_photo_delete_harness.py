#!/usr/bin/env python3
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
APP = ROOT / "iWorkOrder"
checks = 0


def require(condition, message):
    global checks
    if not condition:
        raise SystemExit(f"FAIL: {message}")
    checks += 1
    print(f"PASS: {message}")


views = (APP / "WorkOrderViews.swift").read_text(encoding="utf-8")
services = (APP / "Services.swift").read_text(encoding="utf-8")

form_start = views.index("struct WorkOrderEntryForm: View")
form_end = views.index("struct WorkOrderDetailView: View", form_start)
form = views[form_start:form_end]

remove_start = form.index("private func removePhoto")
remove_end = form.index("private func appendActionNote", remove_start)
remove_block = form[remove_start:remove_end]

saved_start = form.index("private func isPhotoAlreadySaved")
saved_end = form.index("private func removePhoto", saved_start)
saved_block = form[saved_start:saved_end]

require("@State private var pendingPhotoDeletion: WorkOrderImage?" in form, "photo deletion uses explicit pending confirmation state")
require('Image(systemName: "trash.fill")' in form, "every evidence thumbnail exposes a visible trash control")
require('.foregroundStyle(.red)' in form, "delete affordance is visually destructive")
require('.frame(width: 36, height: 36)' in form and '.padding(4)' in form, "delete control retains an approximately 44-point touch target")
require('accessibilityLabel("Remove \\(image.kind.rawValue.lowercased()) photo")' in form, "delete control has a descriptive accessibility label")
require(".confirmationDialog(" in form and '"Remove Photo?"' in form, "deletion requires a confirmation dialog")
require('role: .destructive' in form, "confirmed deletion uses the destructive button role")
require('Button("Cancel", role: .cancel)' in form, "confirmation includes an explicit cancel action")
require("entry.images.firstIndex(where: { $0.id == image.id })" in remove_block, "the exact selected photo is located by stable image identity")
require("entry.images.remove(at: index)" in remove_block, "confirmed deletion removes the photo from the editable work-order revision")
require("order.entries.contains" in saved_block and "$0.filename == image.filename" in saved_block, "saved-revision detection checks all persisted work-order revisions")
require("isStillReferencedByDraft" in remove_block, "duplicate draft references prevent premature file deletion")
require("!isReferencedBySavedRevision" in remove_block, "saved historical evidence is never physically deleted by draft editing")
require("ImageStorageService.delete(image)" in remove_block, "new unsaved photo files are physically deleted after removal")
require("Earlier saved revisions keep their original evidence history." in form, "confirmation explains preserved revision history for previously saved evidence")
require("This removes the selected photo from this work order draft." in form, "confirmation clearly explains unsaved-photo removal")
require("WorkOrderImageThumbnailCache.shared.remove" in services, "physical photo deletion invalidates thumbnail cache state")
require("ImageStorageService.load(image)" not in form, "delete UI does not reintroduce synchronous full-size image decoding")

print(f"HOTFIX 27 PHOTO DELETE: PASS ({checks} checks; source-level verification)")
