#!/usr/bin/env python3
from pathlib import Path
import json
import plistlib
import re

ROOT = Path(__file__).resolve().parents[1]
APP = ROOT / "iWorkOrder"
checks: list[str] = []
errors: list[str] = []


def require(condition: bool, message: str) -> None:
    (checks if condition else errors).append(message)

app = (APP / "iWorkOrderApp.swift").read_text(encoding="utf-8")
splash = (APP / "SplashScreenView.swift").read_text(encoding="utf-8")
launch_colors = json.loads((APP / "Assets.xcassets/LaunchBackground.colorset/Contents.json").read_text(encoding="utf-8"))
store = (APP / "AppStore.swift").read_text(encoding="utf-8")
root_view = (APP / "RootView.swift").read_text(encoding="utf-8")
services = (APP / "Services.swift").read_text(encoding="utf-8")
cloud = (APP / "CloudSyncService.swift").read_text(encoding="utf-8")
views = (APP / "WorkOrderViews.swift").read_text(encoding="utf-8")
privacy_audit = (ROOT / "APP_STORE_PRIVACY_AUDIT.md").read_text(encoding="utf-8")
catalog = json.loads((APP / "Localizable.xcstrings").read_text(encoding="utf-8"))
with (APP / "Info.plist").open("rb") as handle:
    info = plistlib.load(handle)

# Background/task-switcher privacy.
require("private struct AppPrivacyShieldView" in app, "app has a dedicated privacy shield")
require("if hasBeenActive && scenePhase != .active" in app, "privacy shield activates for inactive/background snapshots after first activation")
require("hasBeenActive && scenePhase != .active ? 24 : 0" in app, "privacy shield strongly blurs underlying content before inactive/background snapshots")
require(".fill(.regularMaterial)" in app, "privacy shield adds a frosted material over blurred content")
require('Color("LaunchBackground")' in app and "accessibilityReduceTransparency" in app, "privacy shield has an opaque adaptive fallback when transparency is reduced")
require(all(item.get("color", {}).get("components", {}).get("alpha") == "1.000" for item in launch_colors.get("colors", [])), "shared launch background fallback is fully opaque in every appearance")
require(".privacySensitive()" in app, "root content is marked privacy-sensitive")
require(".allowsHitTesting(false)" in app, "privacy shield cannot intercept foreground interaction")

# Permission minimization: the system PhotosPicker grants only user-selected items.
require("NSPhotoLibraryUsageDescription" not in info, "unused full Photo Library permission purpose string is removed")
require("NSPhotoLibraryAddUsageDescription" not in info, "unused photo-library write permission purpose string is absent")
require("PhotosPicker" in views, "work-order evidence still uses the system PhotosPicker")
require("PHPhotoLibrary" not in views and "UIImagePickerController" not in views, "work-order evidence does not use direct PhotoKit/library picker APIs")
require("NSCameraUsageDescription" in info, "camera-hardware purpose string remains for the optional flashlight")
require("flashlight" in str(info.get("NSCameraUsageDescription", "")).lower(), "camera purpose string describes flashlight-only use")

# Torch handling should check actual hardware availability before activation.
require("device.isTorchAvailable" in services, "flashlight activation checks current torch availability")
require("device.isTorchModeSupported(.on)" in services, "flashlight activation checks supported torch mode")
require("defer { device.unlockForConfiguration() }" in services, "camera configuration lock is always released")

# Public sync wording should not expose implementation jargon in the main status layer.
require("CloudKit" not in store, "public AppStore sync status uses iCloud wording rather than CloudKit implementation jargon")
require("CloudKit synchronization" not in root_view, "compatibility gate uses iCloud wording")
require("private iCloud dataset" in cloud, "pending replacement error uses user-facing iCloud wording")
require("CloudKit dataset" not in cloud.split("enum CloudSyncError", 1)[1].split("final class NetworkStatusService", 1)[0], "public cloud error descriptions avoid CloudKit dataset wording")

# Stale public labels should not survive in localization.
strings = catalog.get("strings", {})
require("Sync ready" not in strings, "stale hard-coded sync-ready localization is removed")
require("Sync failed - tap to retry" not in strings, "stale fake sync-retry localization is removed")
require(not any("CloudKit" in key for key in strings), "shipped localization catalog contains no stale CloudKit UI wording")
require("iWorkOrder has disabled saving, iCloud synchronization, backup restore, and editing so a newer data file cannot be overwritten by an older app build." in strings, "localized compatibility message matches the iCloud public wording")

# Privacy documentation must match the public binary surface.
require("PhotosPicker" in privacy_audit and "NSPhotoLibraryUsageDescription" in privacy_audit, "privacy audit records PhotosPicker permission minimization")
require("privacy shield" in privacy_audit.lower(), "privacy audit records task-switcher shielding")

# General release-candidate source hygiene.
all_swift = "\n".join(path.read_text(encoding="utf-8") for path in APP.glob("*.swift"))
for forbidden in ["TODO", "FIXME", "fatalError(", "try!", " as! "]:
    require(forbidden not in all_swift, f"app source excludes release-candidate risk marker: {forbidden}")
require(not re.search(r"\.forEach\(\s*[A-Za-z_][A-Za-z0-9_]*\.[A-Za-z_][A-Za-z0-9_]*\s*\)", all_swift), "app source still excludes direct qualified function references passed to forEach")
require("prepareSnapshotCommit" in (APP / "BackupArchiveService.swift").read_text(encoding="utf-8"), "restore transaction commit preparation remains present")
require("fileprivate func prepareSnapshotCommit" not in (APP / "BackupArchiveService.swift").read_text(encoding="utf-8"), "restore commit preparation remains callable across app source files")

for item in checks:
    print(f"PASS: {item}")
if errors:
    for item in errors:
        print(f"FAIL: {item}")
    raise SystemExit(1)
print(f"HOTFIX 19 RELEASE CANDIDATE HARNESS: PASS ({len(checks)} checks)")
