#!/usr/bin/env python3
from pathlib import Path
import re
import sys

ROOT = Path(__file__).resolve().parents[1]
APP = ROOT / "iWorkOrder"
PBX = ROOT / "iWorkOrder.xcodeproj/project.pbxproj"
SCHEME = ROOT / "iWorkOrder.xcodeproj/xcshareddata/xcschemes/iWorkOrder.xcscheme"

passed: list[str] = []
failed: list[str] = []


def require(condition: bool, message: str) -> None:
    (passed if condition else failed).append(message)


swift_files = sorted(path for base in (APP, ROOT / "iWorkOrderTests", ROOT / "iWorkOrderUITests") for path in base.rglob("*.swift"))
shipping_files = sorted(APP.rglob("*.swift"))
swift = "\n".join(path.read_text(encoding="utf-8") for path in swift_files)
shipping = "\n".join(path.read_text(encoding="utf-8") for path in shipping_files)
services = (APP / "Services.swift").read_text(encoding="utf-8")
work_orders = (APP / "WorkOrderViews.swift").read_text(encoding="utf-8")
pbx = PBX.read_text(encoding="utf-8")
scheme = SCHEME.read_text(encoding="utf-8")
qualification = (ROOT / "Scripts/phase56_xcode_qualification.sh").read_text(encoding="utf-8")
verify_sh = (ROOT / "Scripts/verify_release.sh").read_text(encoding="utf-8")
workflow = (ROOT / ".github/workflows/ios-ci.yml").read_text(encoding="utf-8")
run_ci = (ROOT / "Scripts/run_xcode_ci.sh").read_text(encoding="utf-8")
fakes = (ROOT / "Scripts/BehaviorTests/PlatformFakes.swift").read_text(encoding="utf-8")
behavior = (ROOT / "Scripts/BehaviorTests/ConsolidatedBehaviorTests.swift").read_text(encoding="utf-8")
active_docs = "\n".join(
    (ROOT / name).read_text(encoding="utf-8")
    for name in (
        "README.md",
        "RELEASE_VALIDATION_CHECKLIST.md",
        "PHASE56_MAC_EXECUTION_GUIDE.md",
        "PHASE56_DEVICE_TEST_MATRIX.md",
        "Config/README_SIGNING.md",
    )
)

# Xcode 27 ships the Swift 6.4 compiler while the project correctly remains in Swift 6 language mode.
require(pbx.count("SWIFT_STRICT_CONCURRENCY = complete;") >= 8, "strict Swift concurrency remains enabled for app and test configurations")
require(pbx.count("SWIFT_VERSION = 6.0;") >= 8, "all app and test configurations remain in Swift 6 language mode")
require("SWIFT_VERSION = 6.4;" not in pbx, "project does not confuse compiler version 6.4 with Swift language mode")
require(pbx.count("IPHONEOS_DEPLOYMENT_TARGET = 26.0;") >= 6, "current package uses the iOS 26 deployment baseline under Xcode 27")
require("LastUpgradeCheck = 2600;" in pbx and "CreatedOnToolsVersion = 26.0;" in pbx, "last native Xcode project migration remains truthfully recorded as Xcode 26")
require("LastUpgradeCheck = 2700;" not in pbx, "project does not spoof an Xcode 27 recommended-settings migration that was not run natively")

# Address verification moved away from the geocoder APIs superseded by MapKit's current geocoding model.
require("import MapKit" in services, "address verification imports MapKit")
require("import CoreLocation" not in services and "import Contacts" not in services, "address verification no longer imports CoreLocation or Contacts")
for legacy_symbol in ("CLGeocoder", "CLPlacemark", "CNPostalAddressFormatter"):
    require(legacy_symbol not in shipping, f"shipping Swift no longer depends on {legacy_symbol}")
require("MKGeocodingRequest(addressString:" in services, "iOS 26+ address verification uses MKGeocodingRequest")
require("addressRepresentations" in services and "fullAddress(includingRegion: true, singleLine: true)" in services, "modern geocoding consumes MKAddressRepresentations formatted addresses")
require("MKLocalSearch" not in services and "startLegacyLookup" not in services, "retired pre-iOS-26 address fallback is absent")
require("if #available(iOS 26.0, *)" not in services, "iOS 26 geocoding no longer needs a baseline availability branch")
require("verificationGeneration += 1" in services and "cancelCurrentLookup()" in services, "stale address lookups remain generation-gated and cancellable")
require("MKGeocodingRequest" in fakes and "MKLocalSearch" not in fakes and "MKAddressRepresentations" in fakes, "portable behavior fakes cover the supported iOS 26+ address lookup implementation")
require("finishFirst()" in behavior, "address-verification behavior tests retain controlled stale-response completion")

# Common source-level Xcode 27 migration hazards.
for removed_or_risky in ("NavigationView", "UIWebView", "UIApplication.shared.keyWindow", "windows.first", "try!", " as! ", "fatalError("):
    require(removed_or_risky not in shipping, f"shipping Swift avoids {removed_or_risky.strip()} migration/risk pattern")
components = (APP / "Components.swift").read_text(encoding="utf-8")
require("func appRoundedTextFieldStyle()" in components, "text fields use an availability-safe Xcode 27 style bridge")
require(".textFieldStyle(.bordered)" in components and ".textInputBorderShape(.roundedRectangle)" in components, "iOS 27 text fields use the current bordered rounded-rectangle API")
require("@available(iOS, introduced: 26.0, obsoleted: 27.0)" in components and components.count(".textFieldStyle(.roundedBorder)") == 1, "rounded-border styling is isolated to the iOS 26 compatibility helper")
require(".textFieldStyle(.roundedBorder)" not in work_orders, "work-order UI no longer calls the deprecated roundedBorder style directly")
require("@State private var status: WorkOrderStatus\n" in work_orders and "_status = State(initialValue:" in work_orders, "custom WorkOrderDetail state initialization remains explicit")
for state_name in ("status", "draft", "baseRevisionID"):
    require(re.search(rf"@State private var {state_name}:[^=\n]+\n", work_orders) is not None, f"custom-initialized @State {state_name} has no competing declaration default")

# Native final gate must identify the exact stable toolchain; hosted CI stays compatibility-only.
require('REQUIRED_XCODE_MAJOR="${PHASE56_REQUIRED_XCODE_MAJOR:-27}"' in qualification, "native gate requires Xcode 27 by default")
require('REQUIRED_XCODE_BUILD="${PHASE56_REQUIRED_XCODE_BUILD:-27A266a}"' in qualification, "native gate pins Apple stable Xcode 27 build 27A266a")
require('REQUIRED_IOS_SDK_MAJOR="${PHASE56_REQUIRED_IOS_SDK_MAJOR:-27}"' in qualification, "native gate requires iOS 27 SDK by default")
require("XCODE_BUILD" in qualification and '"$XCODE_BUILD" == "$REQUIRED_XCODE_BUILD"' in qualification, "qualification verifies the Xcode build number, not only the major version")
require("PHASE56_ALLOW_XCODE26_COMPATIBILITY" in qualification, "qualification has an explicit hosted compatibility override")
require("PHASE56_ALLOW_XCODE26_COMPATIBILITY" in workflow and "runs-on: macos-26" in workflow, "hosted macOS 26 workflow declares compatibility mode")
require("compatibility" in workflow.lower() and "final" not in workflow.splitlines()[0].lower(), "hosted workflow is not labeled as final Xcode 27 qualification")
require("PHASE56_ALLOW_XCODE26_COMPATIBILITY" in run_ci, "CI launcher preserves compatibility-only scope")

# Active release guidance must match the stable toolchain without rewriting historical notes.
require("Xcode 27" in active_docs and "Swift 6.4" in active_docs, "active release guidance identifies Xcode 27 and Swift 6.4")
require("Xcode 27 RC" not in active_docs and "iOS 27 RC" not in active_docs, "active release guidance no longer points to the release candidate")
require("27A266a" in active_docs, "active release guidance records the stable Xcode 27 build")
require("native xcode 27" in active_docs.lower() or "xcode 27 native" in active_docs.lower(), "active guidance distinguishes native Xcode 27 validation from portable checks")

# Hotfix integration.
require("run_hotfix37_xcode27_swift64_harness.py" in verify_sh, "portable release loop executes Hotfix37 toolchain audit")
require("run_hotfix37_xcode27_swift64_harness.py" in qualification, "native qualification records Hotfix37 toolchain audit")
require((ROOT / "VERIFICATION_NOTES_v56_HOTFIX37_XCODE27_SWIFT64_AUDIT.md").is_file(), "Hotfix37 audit notes are included")

if failed:
    print("HOTFIX 37 XCODE27 SWIFT64 AUDIT: FAIL")
    for item in failed:
        print("FAIL:", item)
    print(f"Checks passed before failure: {len(passed)}")
    sys.exit(1)

print("HOTFIX 37 XCODE27 SWIFT64 AUDIT: PASS")
print(f"Checks passed: {len(passed)}")
for item in passed:
    print("PASS:", item)
