#!/usr/bin/env python3
from pathlib import Path
import re
import sys

ROOT = Path(__file__).resolve().parents[1]
APP = ROOT / "iWorkOrder"
app_source = (APP / "iWorkOrderApp.swift").read_text(encoding="utf-8")
work_orders = (APP / "WorkOrderViews.swift").read_text(encoding="utf-8")
onboarding = (APP / "OnboardingView.swift").read_text(encoding="utf-8")
settings = (APP / "CalendarHubSettingsViews.swift").read_text(encoding="utf-8")

checks = []
errors = []

def require(condition: bool, message: str) -> None:
    (checks if condition else errors).append(message)

def struct_block(source: str, name: str) -> str:
    match = re.search(rf"\bstruct\s+{re.escape(name)}\b[^{{]*\{{", source)
    if not match:
        return ""
    start = match.start()
    brace = source.find("{", match.start())
    depth = 0
    for idx in range(brace, len(source)):
        if source[idx] == "{":
            depth += 1
        elif source[idx] == "}":
            depth -= 1
            if depth == 0:
                return source[start:idx + 1]
    return ""

# Bug 1: Reduce Transparency must remove *all* material backgrounds from the privacy badge.
privacy = struct_block(app_source, "AppPrivacyShieldView")
require(bool(privacy), "privacy shield exists")
require('@Environment(\\.accessibilityReduceTransparency)' in privacy, "privacy shield observes Reduce Transparency")
require('reduceTransparency\n                        ? AnyShapeStyle(Color(.secondarySystemBackground))\n                        : AnyShapeStyle(.thinMaterial)' in privacy, "privacy badge switches to an opaque semantic fill when Reduce Transparency is enabled")
require('.background(.thinMaterial, in: Circle())' not in privacy, "privacy badge no longer forces translucent material under Reduce Transparency")
require('reduceTransparency\n                                ? Color.secondary' in privacy, "privacy badge border also avoids the translucent white treatment in Reduce Transparency mode")
require('if reduceTransparency {\n                Color("LaunchBackground")' in privacy, "full privacy cover remains opaque under Reduce Transparency")

# Bug 2: eliminate hidden UserDefaults theme dependencies from retained leaf views.
for name in ["PriorityQueueCard", "StatusFilterChip", "WorkOrderDateLabel", "WorkOrderRow"]:
    block = struct_block(work_orders, name)
    require(bool(block), f"{name} exists")
    require('@AppStorage(AppTheme.storageKey)' in block, f"{name} directly observes live theme changes")
    require('private var selectedTheme: VisualTheme' in block, f"{name} resolves a reactive selected theme")

priority = struct_block(work_orders, "PriorityQueueCard")
require('AppTheme.textSecondary(for: selectedTheme)' in priority, "priority queue empty state uses the reactive theme")
status_chip = struct_block(work_orders, "StatusFilterChip")
require('AppTheme.usesLegacyHero(for: selectedTheme)' in status_chip, "status chips change geometry from reactive theme state")
date_label = struct_block(work_orders, "WorkOrderDateLabel")
require('AppTheme.textSecondary(for: selectedTheme)' in date_label, "work-order date label changes color from reactive theme state")
row = struct_block(work_orders, "WorkOrderRow")
require('AppTheme.textPrimary(for: selectedTheme)' in row and 'AppTheme.textSecondary(for: selectedTheme)' in row, "work-order rows change text styling from reactive theme state")
hero = struct_block(work_orders, "Theme2OrdersHero")
require('AppTheme.heroGradient(for: .design2)' in hero, "Design 2 hero cannot transiently borrow another theme during a live switch")
entry_form = struct_block(work_orders, "WorkOrderEntryForm")
require('@Environment(\\.accessibilityReduceTransparency)' in entry_form, "evidence gallery observes Reduce Transparency")
require('reduceTransparency\n                                                    ? AnyShapeStyle(Color(.secondarySystemBackground))\n                                                    : AnyShapeStyle(.thinMaterial)' in entry_form, "evidence photo delete control becomes opaque under Reduce Transparency")
require('.background(.thinMaterial, in: Circle())' not in entry_form, "evidence photo delete control has no unconditional material background")

# Gated/setup/legal surfaces also avoid hidden global theme reads.
for name, source in [
    ("InitialDataRecoveryView", onboarding),
    ("OnboardingView", onboarding),
    ("PermissionSetupView", onboarding),
    ("LegalUpdateSplashView", settings),
    ("LegalDocumentView", settings),
]:
    block = struct_block(source, name)
    require(bool(block), f"{name} exists")
    require('@AppStorage(AppTheme.storageKey)' in block, f"{name} observes persisted theme state")
    require('AppTheme.horizontalPadding(for: selectedTheme)' in block, f"{name} uses explicit reactive theme padding")

# There must be no selected-theme styling call that silently reads AppTheme.selected.
all_swift = "\n".join(p.read_text(encoding="utf-8") for p in APP.glob("*.swift"))
hidden_theme_pattern = re.compile(
    r"AppTheme\.(corner|smallCorner|horizontalPadding|accent|textPrimary|textSecondary|background|cardFill|cardStroke|cardShadow|heroGradient|usesLegacyHero|legacyTitleFont)\b(?!\s*\()"
)
require(hidden_theme_pattern.search(all_swift) is None, "app source has no hidden selected-theme styling reads")

# Release integration / evidence.
verify_sh = (ROOT / "Scripts/verify_release.sh").read_text(encoding="utf-8")
phase56 = (ROOT / "Scripts/phase56_xcode_qualification.sh").read_text(encoding="utf-8")
verify_py = (ROOT / "Scripts/verify_release.py").read_text(encoding="utf-8")
require('run_hotfix32_full_bug_loop_harness.py' in verify_sh, "cross-platform verification executes Hotfix32 harness")
require('run_hotfix32_full_bug_loop_harness.py' in phase56, "Xcode qualification executes Hotfix32 harness")
require('HOTFIX 32 FULL BUG LOOP: PASS' in verify_py, "release verifier requires the Hotfix32 strict pass marker")
require((ROOT / "VERIFICATION_NOTES_v56_HOTFIX32_FULL_BUG_LOOP.md").is_file(), "Hotfix32 verification notes are included")
readme = (ROOT / "README.md").read_text(encoding="utf-8")
all_fixes = (ROOT / "ALL_FIXES_INCLUDED.md").read_text(encoding="utf-8")
require("# iWorkOrder v56 — Hotfix 31 Frosted Privacy Shield" in readme, "README release sequence includes Hotfix31")
require("# Hotfix 31 — Frosted Privacy Shield" in all_fixes, "all-fixes release sequence includes Hotfix31")

if errors:
    print("HOTFIX 32 FULL BUG LOOP: FAIL")
    for item in errors:
        print("FAIL:", item)
    print(f"Passed before failure: {len(checks)}")
    sys.exit(1)

print("HOTFIX 32 FULL BUG LOOP: PASS")
print(f"Checks passed: {len(checks)}")
for item in checks:
    print("PASS:", item)
