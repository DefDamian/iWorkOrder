#!/usr/bin/env python3
"""Source-wiring checks plus executed safety tests for build-output preparation.

These checks complement, and do not replace, the compiled behavioral harness or
native Xcode tests. A source assertion is not an end-to-end UI test.
"""
from pathlib import Path
import tempfile
from prepare_qualification_paths import prepare, validate_destination

ROOT = Path(__file__).resolve().parents[1]
APP = ROOT / "iWorkOrder"
checks = []


def require(condition, message):
    if not condition:
        raise AssertionError(message)
    checks.append(message)
    print("PASS: " + message)


def section(text, begin, end):
    start = text.index(begin)
    return text[start:text.index(end, start)]


services = (APP / "Services.swift").read_text()
store = (APP / "AppStore.swift").read_text()
backup = (APP / "BackupArchiveService.swift").read_text()
views = (APP / "WorkOrderViews.swift").read_text()
root_view = (APP / "RootView.swift").read_text()
onboarding = (APP / "OnboardingView.swift").read_text()
settings = (APP / "CalendarHubSettingsViews.swift").read_text()
app = (APP / "iWorkOrderApp.swift").read_text()
verify = (ROOT / "Scripts/verify_release.sh").read_text()
qualification = (ROOT / "Scripts/phase56_xcode_qualification.sh").read_text()
project = (ROOT / "iWorkOrder.xcodeproj/project.pbxproj").read_text()
tests = (ROOT / "iWorkOrderTests/iWorkOrderTests.swift").read_text()

save = section(store, "    func save() -> Bool", "    private func")
require(save.index("guard !cloud.isCloudErasePending()") < save.index("storage.save("), "pending erase blocks saves before storage writes")
checkpoint = section(store, "func persistLifecycleCheckpoint()", "func applyNotificationPreferences")
require("!cloud.isCloudErasePending()" in checkpoint, "lifecycle checkpoints respect pending deletion")
cloud_boundary = section(store, "private func persistStateForCloudOperation", "func persistLifecycleCheckpoint")
require("guard !cloud.isCloudErasePending()" in cloud_boundary, "cloud preparation cannot bypass deletion block")
load = section(store, "    func load()", "private func cleanupOrphanedLocalAttachments")
require(load.index("if let compatibilityBlockMessage") < load.index("recoverInterruptedRestores"), "unreadable local data blocks attachment recovery before mutation")
require(load.index("if let compatibilityBlockMessage") < load.index("cleanupOrphanedLocalAttachments()"), "unreadable local data cannot trigger orphan deletion")
update = section(store, "    func update(", "    func addAudit(")
require("guard !workOrders[index].isDeleted" in update, "stale detail cannot edit a trashed record")

for name, code, begin in [("onboarding", onboarding, "private func updateNotificationPreference("),
                           ("settings", settings, "private func updateNotificationsEnabled(")]:
    prompt = code[code.index(begin):]
    granted = section(prompt, "if granted {", "} else {")
    require("let previousProfile = store.profile" in granted, name + " captures rollback state after permission returns")
    denial = section(prompt, "} else {", "await store.refreshNotificationAuthorization()")
    require("store.profile =" not in denial, name + " denial cannot restore an obsolete whole profile")
    require("guard !Task.isCancelled" in prompt and "defer { isUpdatingNotifications = false }" in prompt, name + " permission operation clears its busy state")
require("guard !isFinishingSetup, !isUpdatingNotifications, completeAllowed" in onboarding, "setup completion prevents overlapping requests")
require("guard !Task.isCancelled, completeAllowed" in onboarding, "setup completion revalidates inputs after suspension")
require(views.count("activePhotoImports: $activePhotoImports") == 2, "new and edit forms both report pending photo imports")
require("guard activePhotoImports == 0 else { return }" in views and "guard activePhotoImports == 0 else { return false }" in views, "save handlers guard pending imports beyond disabled button styling")
require("defer { activePhotoImports = max(0, activePhotoImports - 1) }" in views, "all photo import outcomes release the save gate")
require("appLock.beginAuthentication()" in root_view and "appLock.completeAuthentication(token:" in root_view, "authentication UI uses attempt tokens instead of unconditional unlock")
require(".accessibilityHidden(store.isBackupOperationInProgress)" in root_view, "backup overlay hides protected underlying accessibility elements")
require(".accessibilityHidden(hasBeenActive && scenePhase != .active)" in app, "inactive content is hidden from the accessibility tree after first activation")
require("journal.snapshotEncodingVersion = SnapshotFingerprintEncoding.currentVersion" in backup, "new restore journals record fingerprint encoding")
require("snapshot, encodingVersion: journal.snapshotEncodingVersion" in backup, "restore recovery reads the recorded fingerprint encoding")
require("A newer restore journal was preserved" in backup, "unknown restore encoding blocks recovery rather than rolling back")
require("try await center.add(request)" in services and "let pendingIdentifiers = eligibleIdentifiers" in services, "notification additions await completion and callback sets are immutable")
require("await previousTask?.value" in services and "let deliveredIdentifiers = Set(" in services, "notification cancellation is sequenced and delivered history has separate eligibility")

pdf = services[services.index("enum PDFExportService"):]
require("CTFrameGetVisibleStringRange" in pdf and "offset = visible.location + visible.length" in pdf, "PDF text pagination advances by actually rendered characters")
require("images.prefix(6)" not in pdf and "for imageRecord in entry.images" in pdf, "PDF attachment loop has no hidden six-photo truncation")
require(pdf.count("Evidence unavailable:") >= 3, "unreadable evidence is disclosed in the PDF")
require('\\(cleanTitle)_\\(exportID).pdf' in pdf and "CharacterSet.alphanumerics" in pdf, "PDF filenames are sanitized and unique")
require("guard !layoutFailed" in pdf and "FileProtectionType.completeUntilFirstUserAuthentication" in pdf, "partial exports fail and finished PDFs receive file protection")
require("testLongNotesReachTheFinalPage" in tests and "testEveryMissingAttachmentIsDisclosedIncludingAfterSixPhotos" in tests, "native PDF regressions are present in the existing XCTest target")
require("BehaviorTests" not in project and "PlatformFakes.swift" not in project, "test framework stand-ins are excluded from app build targets")
require("mapfile" not in verify and "sort -z" not in verify and "read -r -d ''" in verify, "Swift source discovery avoids macOS-incompatible Bash/BSD commands")
require("prepare_qualification_paths.py" in qualification and 'rm -rf "$ARTIFACTS_DIR" "$DERIVED_DATA"' not in qualification, "qualification cleanup uses validated disposable directories")
require('static let currentVersion = "2026.09.16.56"' in (APP / "LegalContent.swift").read_text(), "current legal version remains wired into integration checks")
require("com.damiancedeno.SedgwickOrders" not in project and "com.damiancedeno.SedgwickWorkOrders" in project, "production bundle identifier remains unchanged")
print(f"HOTFIX 22 SOURCE WIRING: PASS ({len(checks)} checks; not UI execution)")

before = len(checks)
with tempfile.TemporaryDirectory(prefix="iworkorder-output-safety-") as temporary:
    root = Path(temporary) / "project"
    root.mkdir()
    sentinel = root / "source.swift"
    sentinel.write_text("preserve source")
    (root / "Artifacts").mkdir()
    (root / "build").mkdir()
    evidence = root / "evidence.json"
    evidence.write_text('{"status":"pending"}')
    for unsafe, category in [(root, "Artifacts"), (root.parent, "Artifacts"), (Path('/'), "Artifacts"),
                             (root / "Artifacts", "Artifacts"), (root / "build", "build"),
                             (root / "source.swift", "build"), (root / "Artifacts/../../outside", "Artifacts")]:
        try:
            validate_destination(root, unsafe, category)
            raise AssertionError("unsafe destination was accepted: " + str(unsafe))
        except ValueError:
            require(sentinel.read_text() == "preserve source", "unsafe output rejected without touching source: " + str(unsafe.relative_to(root) if unsafe.is_relative_to(root) else unsafe))
    outside = Path(temporary) / "outside"
    outside.mkdir()
    link = root / "build/link"
    link.symlink_to(outside, target_is_directory=True)
    try:
        validate_destination(root, link / "child", "build")
        raise AssertionError("symlink destination accepted")
    except ValueError:
        require(outside.exists(), "symbolic-link escape is rejected")
    artifacts = root / "Artifacts/Phase56"
    derived = root / "build/Phase56DerivedData"
    artifacts.mkdir(); derived.mkdir()
    (artifacts / "old.log").write_text("old")
    (derived / "object.o").write_text("old")
    prepare(root, artifacts, derived, evidence)
    require(sentinel.read_text() == "preserve source", "valid preparation preserves project source")
    require((artifacts / "phase56_evidence.json").read_bytes() == evidence.read_bytes(), "valid preparation copies exact pending evidence")
    require(not (artifacts / "old.log").exists() and not derived.exists(), "valid preparation removes only disposable output")
    try:
        prepare(root, artifacts, derived, artifacts / "phase56_evidence.json")
        raise AssertionError("evidence in disposable output accepted")
    except ValueError:
        require((artifacts / "phase56_evidence.json").exists(), "manual evidence within cleanup target is preserved and refused")
print(f"HOTFIX 22 EXECUTED BUILD-PATH SAFETY: PASS ({len(checks) - before} checks)")
