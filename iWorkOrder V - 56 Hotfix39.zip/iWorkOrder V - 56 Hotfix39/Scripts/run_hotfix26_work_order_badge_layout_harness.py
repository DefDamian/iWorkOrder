#!/usr/bin/env python3
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
APP = ROOT / "iWorkOrder"
checks = 0


def require(condition, message):
    global checks
    if not condition:
        raise SystemExit(f"FAIL: {message}")
    checks += 1
    print(f"PASS: {message}")


work = (APP / "WorkOrderViews.swift").read_text(encoding="utf-8")
components = (APP / "Components.swift").read_text(encoding="utf-8")
models = (APP / "Models.swift").read_text(encoding="utf-8")

row_start = work.index("struct WorkOrderRow: View")
row_end = work.index("struct QuickAddView: View", row_start)
row = work[row_start:row_end]
cluster_start = work.index("private struct WorkOrderBadgeCluster: View")
cluster_end = work.index("struct WorkOrderRow: View", cluster_start)
cluster = work[cluster_start:cluster_end]

date_start = work.index("private struct WorkOrderDateLabel: View")
date_end = work.index("private struct WorkOrderEditedLabel: View", date_start)
date_label = work[date_start:date_end]

status_start = components.index("struct StatusBadge: View")
status_end = components.index("struct MetricTile: View", status_start)
status_badge = components[status_start:status_end]

priority_start = components.index("struct PriorityBadge: View")
priority_end = components.index("struct ShareSheet: UIViewControllerRepresentable", priority_start)
priority_badge = components[priority_start:priority_end]

require("ViewThatFits(in: .horizontal)" in row, "work-order metadata adapts between wide and compact layouts")
require("WorkOrderBadgeCluster(priority: order.latestEntry.priority, status: order.status)" in row, "work-order row uses the responsive badge cluster")
require(".frame(maxWidth: .infinity, alignment: .trailing)" in row, "compact layout aligns badges cleanly at the trailing edge")
require("ViewThatFits(in: .horizontal)" in cluster, "badge cluster has its own horizontal-to-vertical fallback")
require("HStack(spacing: 8)" in cluster and "VStack(alignment: .trailing, spacing: 6)" in cluster, "badge cluster supports both side-by-side and stacked presentation")
require("PriorityBadge(priority: priority)" in cluster and "StatusBadge(status: status)" in cluster, "responsive cluster keeps both priority and workflow status visible")
require(".lineLimit(2)" in date_label, "date metadata is capped at two lines instead of consuming the badge width")
require(".layoutPriority(1)" in date_label, "date metadata keeps readable layout priority")
require('Text(status.rawValue)' in status_badge, "status badge renders status text explicitly")
require(".lineLimit(1)" in status_badge, "status badge text is restricted to one line")
require(".fixedSize(horizontal: true, vertical: false)" in status_badge, "status badge preserves its single-line capsule width")
require('Text(priority.rawValue)' in priority_badge, "priority badge renders priority text explicitly")
require(".lineLimit(1)" in priority_badge, "priority badge text is restricted to one line")
require(".fixedSize(horizontal: true, vertical: false)" in priority_badge, "priority badge preserves its single-line capsule width")
require('case inProgress = "In-progress"' in models, "persisted workflow status raw value remains unchanged")
require('case normal = "Normal"' in models, "persisted priority raw value remains unchanged")
require("Label(order.createdAt.shortDateTime, systemImage: \"calendar\").font(.caption).foregroundStyle(AppTheme.textSecondary)" not in row, "old compressed one-row metadata layout is removed")

print(f"HOTFIX 26 WORK-ORDER BADGE LAYOUT: PASS ({checks} checks; source-level verification)")
