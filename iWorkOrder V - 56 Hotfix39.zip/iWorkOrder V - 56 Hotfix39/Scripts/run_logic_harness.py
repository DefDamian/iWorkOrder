#!/usr/bin/env python3
from pathlib import Path
import subprocess
import tempfile

ROOT = Path(__file__).resolve().parents[1]


def swift_block(text: str, marker: str) -> str:
    start = text.index(marker)
    brace = text.index("{", start)
    depth = 0
    for index in range(brace, len(text)):
        if text[index] == "{":
            depth += 1
        elif text[index] == "}":
            depth -= 1
            if depth == 0:
                return text[start:index + 1]
    raise RuntimeError(f"Unterminated Swift block: {marker}")


models = (ROOT / "iWorkOrder/Models.swift").read_text().replace("import SwiftUI\n", "")
legal = (ROOT / "iWorkOrder/LegalContent.swift").read_text()
services = (ROOT / "iWorkOrder/Services.swift").read_text()
search = swift_block(services, "enum WorkOrderSearchEngine")
merge = swift_block(services, "enum ConflictMergeService")
notification_identifier = swift_block(services, "enum WorkOrderNotificationIdentifier")
notification_policy = swift_block(services, "enum WorkOrderNotificationPolicy")
app_snapshot = """
struct AppSnapshot: Codable, Sendable {
    var profile: UserProfile
    var workOrders: [WorkOrder]
    var assets: [AssetRecord]? = []
    var tenants: [TenantContact]? = []
    var categories: [WorkOrderCategory]?
    var categoryConfigurationUpdatedAt: Date?
    var profileConfigurationUpdatedAt: Date?
    var lastSynced: Date?
    var snapshotSavedAt: Date? = nil
    var deviceID: String? = nil
    var saveRevision: Int? = 0
    var dataSchemaVersion: Int? = 3
}
"""
harness = r'''
@main
struct Phase54Harness {
    static func require(_ condition: @autoclosure () -> Bool, _ message: String) {
        if !condition() {
            FileHandle.standardError.write(Data(("FAIL: " + message + "\n").utf8))
            exit(1)
        }
    }

    static func main() throws {
        var profile = UserProfile()
        profile.legalAccepted = true
        require(!LegalContent.isCurrentAcceptance(profile), "stale acceptance must fail")
        profile.legalAcceptedVersion = LegalContent.currentVersion
        require(!LegalContent.isCurrentAcceptance(profile), "current version without an acceptance date must fail")
        profile.legalAcceptedDate = Date()
        require(LegalContent.isCurrentAcceptance(profile), "complete current acceptance must pass")

        var invalidEntry = WorkOrderEntry(area: "   ", issueDescription: "\n")
        require(!invalidEntry.hasRequiredFields, "whitespace-only required fields must fail")
        invalidEntry.area = "  4A  "
        invalidEntry.issueDescription = "  Sink leak  "
        require(invalidEntry.hasRequiredFields, "non-empty required fields must pass")
        invalidEntry.normalizeUserEnteredText()
        require(invalidEntry.area == "4A" && invalidEntry.issueDescription == "Sink leak", "required fields normalize before persistence")

        var matching = WorkOrder(status: .pending, entries: [WorkOrderEntry(area: "5A", issueDescription: "Leak")])
        matching.auditLog = [AuditEvent(message: "Acme vendor assigned")]
        let wrong = WorkOrder(status: .completed, entries: [WorkOrderEntry(area: "5A", issueDescription: "Leak")])
        let filtered = WorkOrderSearchEngine.filter([matching, wrong], status: .pending, filters: WorkOrderFilters(searchText: "Acme"))
        require(filtered.map(\.id) == [matching.id], "search/status filtering")

        var localProfile = UserProfile()
        localProfile.personName = "Local"
        localProfile.buildingAddress = "Local Address"
        var cloudProfile = UserProfile()
        cloudProfile.personName = "Cloud"
        cloudProfile.buildingAddress = "Cloud Address"
        cloudProfile.legalAccepted = true
        cloudProfile.legalAcceptedDate = Date(timeIntervalSince1970: 10)
        cloudProfile.legalAcceptedVersion = LegalContent.currentVersion
        let local = AppSnapshot(profile: localProfile, workOrders: [], snapshotSavedAt: Date(timeIntervalSince1970: 20), deviceID: "local")
        let cloud = AppSnapshot(profile: cloudProfile, workOrders: [], snapshotSavedAt: Date(timeIntervalSince1970: 10), deviceID: "cloud")
        let merged = ConflictMergeService.merge(local: local, cloud: cloud)!
        require(merged.profile.personName == "Local", "merge must preserve current profile")
        require(merged.profile.buildingAddress == "Local Address", "merge must preserve building")
        require(LegalContent.isCurrentAcceptance(merged.profile), "merge must import current legal acceptance")

        let localCategoryDate = Date(timeIntervalSince1970: 50)
        let cloudCategoryDate = Date(timeIntervalSince1970: 40)
        let localCategories = AppSnapshot(
            profile: UserProfile(),
            workOrders: [],
            categories: [WorkOrderCategory(rawValue: "Elevators"), .plumbing],
            categoryConfigurationUpdatedAt: localCategoryDate,
            snapshotSavedAt: Date(timeIntervalSince1970: 30),
            deviceID: "local"
        )
        let cloudCategories = AppSnapshot(
            profile: UserProfile(),
            workOrders: [],
            categories: [.hvac, .other],
            categoryConfigurationUpdatedAt: cloudCategoryDate,
            snapshotSavedAt: Date(timeIntervalSince1970: 60),
            deviceID: "cloud"
        )
        let categoryMerge = ConflictMergeService.merge(local: localCategories, cloud: cloudCategories)!
        require(categoryMerge.categories == [WorkOrderCategory(rawValue: "Elevators"), .plumbing], "newest category configuration must win independently of snapshot date")

        var newerProfile = UserProfile()
        newerProfile.personName = "Newer Profile"
        newerProfile.buildingAddress = "100 Correct Street"
        newerProfile.firstBuildingUnits = ["1A", "１Ａ"]
        var staleProfile = UserProfile()
        staleProfile.personName = "Stale Profile"
        staleProfile.buildingAddress = "999 Stale Street"
        staleProfile.firstBuildingUnits = ["2B"]
        let profileMerge = ConflictMergeService.merge(
            local: AppSnapshot(
                profile: newerProfile,
                workOrders: [],
                profileConfigurationUpdatedAt: Date(timeIntervalSince1970: 500),
                snapshotSavedAt: Date(timeIntervalSince1970: 100),
                deviceID: "local"
            ),
            cloud: AppSnapshot(
                profile: staleProfile,
                workOrders: [],
                profileConfigurationUpdatedAt: Date(timeIntervalSince1970: 400),
                snapshotSavedAt: Date(timeIntervalSince1970: 900),
                deviceID: "cloud"
            )
        )!
        require(profileMerge.profile.personName == "Newer Profile", "profile freshness must be independent of unrelated snapshot freshness")
        require(profileMerge.profile.buildingAddress == "100 Correct Street", "newer profile configuration must survive an unrelated newer cloud snapshot")
        require(Set(profileMerge.profile.firstBuildingUnits) == Set(["1A", "2B"]), "unit merge must preserve both devices and canonicalize width variants")

        let legacyProfileMerge = ConflictMergeService.merge(
            local: AppSnapshot(
                profile: newerProfile,
                workOrders: [],
                profileConfigurationUpdatedAt: Date(timeIntervalSince1970: 500),
                snapshotSavedAt: Date(timeIntervalSince1970: 100),
                deviceID: "local"
            ),
            cloud: AppSnapshot(
                profile: staleProfile,
                workOrders: [],
                snapshotSavedAt: Date(timeIntervalSince1970: 1000),
                deviceID: "legacy-cloud"
            )
        )!
        require(legacyProfileMerge.profile.personName == "Newer Profile", "explicit profile freshness must beat a legacy snapshot with no profile timestamp")

        var declinedProfile = newerProfile
        declinedProfile.legalAccepted = false
        declinedProfile.legalAcceptedDate = nil
        declinedProfile.legalAcceptedVersion = nil
        var olderAcceptedProfile = staleProfile
        olderAcceptedProfile.legalAccepted = true
        olderAcceptedProfile.legalAcceptedDate = Date(timeIntervalSince1970: 150)
        olderAcceptedProfile.legalAcceptedVersion = LegalContent.currentVersion
        let declineMerge = ConflictMergeService.merge(
            local: AppSnapshot(
                profile: declinedProfile,
                workOrders: [],
                profileConfigurationUpdatedAt: Date(timeIntervalSince1970: 300),
                snapshotSavedAt: Date(timeIntervalSince1970: 100),
                deviceID: "newer-decline"
            ),
            cloud: AppSnapshot(
                profile: olderAcceptedProfile,
                workOrders: [],
                profileConfigurationUpdatedAt: Date(timeIntervalSince1970: 200),
                snapshotSavedAt: Date(timeIntervalSince1970: 400),
                deviceID: "older-acceptance"
            )
        )!
        require(!declineMerge.profile.legalAccepted, "an explicitly newer legal decline must not be resurrected by an older acceptance")
        let legacyAcceptanceMerge = ConflictMergeService.merge(
            local: AppSnapshot(
                profile: declinedProfile,
                workOrders: [],
                profileConfigurationUpdatedAt: Date(timeIntervalSince1970: 300),
                snapshotSavedAt: Date(timeIntervalSince1970: 100),
                deviceID: "newer-decline"
            ),
            cloud: AppSnapshot(
                profile: olderAcceptedProfile,
                workOrders: [],
                snapshotSavedAt: Date(timeIntervalSince1970: 400),
                deviceID: "legacy-older-acceptance"
            )
        )!
        require(!legacyAcceptanceMerge.profile.legalAccepted, "a legacy acceptance with an older acceptance date must not resurrect after an explicitly newer decline")
        require(AppSnapshot(profile: UserProfile(), workOrders: []).snapshotSavedAt == nil, "new snapshots must not invent freshness without a committed mutation")

        let orderID = UUID()
        let deletedAt = Date(timeIntervalSince1970: 100)
        let recoveredAt = Date(timeIntervalSince1970: 200)
        var deletedOrder = WorkOrder(id: orderID, status: .inProgress, entries: [WorkOrderEntry(area: "4A", issueDescription: "Leak")])
        deletedOrder.isDeleted = true
        deletedOrder.deletedAt = deletedAt
        deletedOrder.statusEntries = [StatusEntry(kind: .deleted, date: deletedAt, detail: "Moved to trash")]
        deletedOrder.auditLog = [AuditEvent(date: deletedAt, message: "Moved to trash")]

        var recoveredOrder = deletedOrder
        recoveredOrder.isDeleted = false
        recoveredOrder.deletedAt = nil
        recoveredOrder.statusEntries?.append(StatusEntry(kind: .recovered, date: recoveredAt, detail: "Recovered from trash"))
        recoveredOrder.auditLog.append(AuditEvent(date: recoveredAt, message: "Recovered from trash"))

        let oldCloudDeletion = AppSnapshot(profile: UserProfile(), workOrders: [deletedOrder], snapshotSavedAt: Date(timeIntervalSince1970: 300), deviceID: "cloud")
        let localRecovery = AppSnapshot(profile: UserProfile(), workOrders: [recoveredOrder], snapshotSavedAt: Date(timeIntervalSince1970: 250), deviceID: "local")
        let recoveredMerge = ConflictMergeService.merge(local: localRecovery, cloud: oldCloudDeletion)!
        require(recoveredMerge.workOrders.first?.isDeleted == false, "newer recovery event must beat an older deletion even when cloud snapshot timestamp is newer")
        require(recoveredMerge.workOrders.first?.deletedAt == nil, "recovered merge must clear deletedAt")

        let deletedAgainAt = Date(timeIntervalSince1970: 400)
        var deletedAgain = recoveredOrder
        deletedAgain.isDeleted = true
        deletedAgain.deletedAt = deletedAgainAt
        deletedAgain.statusEntries?.append(StatusEntry(kind: .deleted, date: deletedAgainAt, detail: "Moved to trash"))
        deletedAgain.auditLog.append(AuditEvent(date: deletedAgainAt, message: "Moved to trash"))
        let deletionMerge = ConflictMergeService.merge(
            local: AppSnapshot(profile: UserProfile(), workOrders: [recoveredOrder], snapshotSavedAt: Date(timeIntervalSince1970: 500), deviceID: "local"),
            cloud: AppSnapshot(profile: UserProfile(), workOrders: [deletedAgain], snapshotSavedAt: Date(timeIntervalSince1970: 450), deviceID: "cloud")
        )!
        require(deletionMerge.workOrders.first?.isDeleted == true, "newer deletion event must beat an older recovery")
        require(deletionMerge.workOrders.first?.deletedAt == deletedAgainAt, "newer deletion timestamp must be preserved")

        let duplicateWorkOrderID = UUID()
        let duplicateFirst = WorkOrder(
            id: duplicateWorkOrderID,
            status: .inProgress,
            entries: [WorkOrderEntry(area: "1A", issueDescription: "First revision")]
        )
        var duplicateSecond = WorkOrder(
            id: duplicateWorkOrderID,
            status: .inProgress,
            entries: [WorkOrderEntry(area: "1A", issueDescription: "Second revision")]
        )
        duplicateSecond.entries[0].createdAt = duplicateFirst.entries[0].createdAt.addingTimeInterval(1)
        let coalescedOrders = ConflictMergeService.coalesceWorkOrders([duplicateFirst, duplicateSecond])
        require(coalescedOrders.count == 1, "duplicate work-order IDs must coalesce into one logical record")
        require(coalescedOrders[0].entries.count == 2, "coalescing duplicate work-order IDs must preserve distinct revisions")

        let staleStatusOrderID = UUID()
        let statusChangedAt = Date(timeIntervalSince1970: 100)
        let merelyViewedAt = Date(timeIntervalSince1970: 200)
        var completedStatusOrder = WorkOrder(
            id: staleStatusOrderID,
            status: .completed,
            entries: [WorkOrderEntry(area: "7A", issueDescription: "Boiler")]
        )
        completedStatusOrder.statusEntries = [
            StatusEntry(kind: .statusChanged, date: statusChangedAt, detail: "Status changed to Completed")
        ]
        completedStatusOrder.auditLog = [
            AuditEvent(date: statusChangedAt, message: "Status changed to Completed")
        ]
        var staleViewedOrder = completedStatusOrder
        staleViewedOrder.status = .inProgress
        staleViewedOrder.statusEntries = []
        staleViewedOrder.auditLog = [
            AuditEvent(date: merelyViewedAt, message: "Work order opened")
        ]
        let statusMerge = ConflictMergeService.merge(
            local: AppSnapshot(
                profile: UserProfile(),
                workOrders: [staleViewedOrder],
                snapshotSavedAt: merelyViewedAt,
                deviceID: "stale-viewer"
            ),
            cloud: AppSnapshot(
                profile: UserProfile(),
                workOrders: [completedStatusOrder],
                snapshotSavedAt: statusChangedAt,
                deviceID: "status-writer"
            )
        )!
        require(statusMerge.workOrders.first?.status == .completed, "unrelated newer audit activity must not roll back an explicit status transition")

        var entry = WorkOrderEntry(issueDescription: "Signed")
        entry.signatureFilename = "signature.png"
        entry.signatureSignerName = "Alex"
        entry.signatureCapturedAt = Date(timeIntervalSince1970: 30)
        entry.signatureConsentVersion = LegalContent.currentVersion
        let data = try JSONEncoder().encode(entry)
        let decoded = try JSONDecoder().decode(WorkOrderEntry.self, from: data)
        require(decoded.signatureSignerName == "Alex", "signature signer round trip")
        require(decoded.signatureConsentVersion == LegalContent.currentVersion, "signature consent round trip")

        let reorderedCategories = WorkOrderCategory.reordered(
            [WorkOrderCategory(rawValue: "A"), WorkOrderCategory(rawValue: "B"), WorkOrderCategory(rawValue: "C"), WorkOrderCategory(rawValue: "D")],
            moving: IndexSet(integer: 1),
            to: 4
        )
        require(reorderedCategories.map(\.rawValue) == ["A", "C", "D", "B"], "category reordering")

        var customCategoryEntry = WorkOrderEntry(area: "2B", issueDescription: "Elevator inspection")
        customCategoryEntry.managedCategory = WorkOrderCategory(rawValue: "Elevators")
        let customCategoryData = try JSONEncoder().encode(customCategoryEntry)
        let customCategoryObject = try JSONSerialization.jsonObject(with: customCategoryData) as! [String: Any]
        require(customCategoryObject["category"] as? String == LegacyWorkOrderCategory.other.rawValue, "custom categories retain a legacy-decodable category value")
        require(customCategoryObject["customCategoryName"] as? String == "Elevators", "custom category name is persisted separately")
        let customCategoryRoundTrip = try JSONDecoder().decode(WorkOrderEntry.self, from: customCategoryData)
        require(customCategoryRoundTrip.managedCategory.rawValue == "Elevators", "custom category round trip")

        let notificationOrderID = UUID()
        var notificationEntry = WorkOrderEntry(area: "8C", issueDescription: "Water leak", priority: .emergency)
        let notificationNow = Date(timeIntervalSince1970: 2_000)
        notificationEntry.createdAt = notificationNow.addingTimeInterval(-2)
        notificationEntry.reminderEnabled = true
        notificationEntry.reminderDate = notificationNow.addingTimeInterval(300)
        let notificationOrder = WorkOrder(id: notificationOrderID, status: .inProgress, entries: [notificationEntry])
        let reminderIdentifier = WorkOrderNotificationIdentifier.reminder(orderID: notificationOrderID)
        let emergencyIdentifier = WorkOrderNotificationIdentifier.emergency(orderID: notificationOrderID, entryID: notificationEntry.id)
        require(reminderIdentifier != emergencyIdentifier, "explicit reminder and emergency identifiers must be independent")
        require(WorkOrderNotificationIdentifier.workOrderID(from: reminderIdentifier) == notificationOrderID, "reminder identifier routes to its work order")
        require(WorkOrderNotificationIdentifier.workOrderID(from: emergencyIdentifier) == notificationOrderID, "emergency identifier routes to its work order")
        require(WorkOrderNotificationPolicy.reminderDate(for: notificationOrder, now: notificationNow) == notificationEntry.reminderDate, "future explicit reminder remains eligible")
        require(WorkOrderNotificationPolicy.emergencyFollowUpDate(for: notificationOrder, enabled: true, now: notificationNow) == notificationEntry.createdAt.addingTimeInterval(10), "fresh emergency follow-up uses the revision timestamp")
        let expiredNow = notificationNow.addingTimeInterval(30)
        require(WorkOrderNotificationPolicy.emergencyFollowUpDate(for: notificationOrder, enabled: true, now: expiredNow) == nil, "expired emergency follow-up does not resurrect")
        var expiredReminderEntry = notificationEntry
        expiredReminderEntry.reminderDate = notificationNow.addingTimeInterval(-1)
        let expiredReminderOrder = WorkOrder(id: notificationOrderID, status: .inProgress, entries: [expiredReminderEntry])
        require(WorkOrderNotificationPolicy.reminderDate(for: expiredReminderOrder, now: notificationNow) == nil, "expired explicit reminder does not resurrect")

        print("PHASE 56 EXECUTABLE LOGIC HARNESS: PASS")
    }
}
'''

with tempfile.TemporaryDirectory(prefix="iworkorder-phase55-") as temporary:
    temporary_path = Path(temporary)
    source = temporary_path / "Phase54Harness.swift"
    binary = temporary_path / "Phase54Harness"
    source.write_text("\n".join([models, legal, app_snapshot, search, merge, notification_identifier, notification_policy, harness]))
    subprocess.run(["swiftc", "-parse-as-library", str(source), "-o", str(binary)], check=True)
    subprocess.run([str(binary)], check=True)
