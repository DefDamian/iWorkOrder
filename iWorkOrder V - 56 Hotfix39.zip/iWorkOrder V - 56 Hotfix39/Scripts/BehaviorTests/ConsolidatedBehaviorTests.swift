import Foundation

@main
@MainActor
struct ConsolidatedBehaviorTests {
    static var checks = 0
    static var failures: [String] = []

    static func expect(_ condition: @autoclosure () -> Bool, _ message: String) {
        checks += 1
        if condition() { print("PASS: " + message) }
        else { failures.append(message); print("FAIL: " + message) }
    }
    static func expectThrows(_ message: String, _ action: () throws -> Void) {
        do { try action(); expect(false, message) }
        catch { expect(true, message) }
    }
    static func settle() async {
        for _ in 0..<80 { await Task.yield() }
        try? await Task.sleep(for: .milliseconds(15))
    }
    static func waitFor(_ predicate: () -> Bool) async -> Bool {
        for _ in 0..<200 {
            if predicate() { return true }
            try? await Task.sleep(for: .milliseconds(2))
        }
        return predicate()
    }
    static func scratch(_ name: String) throws -> URL {
        let root = URL(fileURLWithPath: ProcessInfo.processInfo.environment["IWORKORDER_TEST_ROOT"] ?? NSTemporaryDirectory())
        let directory = root.appendingPathComponent(name, isDirectory: true)
        try FileManager.default.createDirectory(at: directory, withIntermediateDirectories: true)
        return directory
    }
    static func snapshot() -> AppSnapshot {
        AppSnapshot(profile: UserProfile(), workOrders: [], dataSchemaVersion: AppDataSchema.currentVersion)
    }

    static func main() async throws {
        try codecTests()
        try formatTests()
        try storageTests()
        await addressTests()
        lockTests()
        await notificationTests()
        if !failures.isEmpty {
            print("BEHAVIOR HARNESS: FAILED (\(failures.count) of \(checks) checks)")
            exit(1)
        }
        print("HOTFIX 22 EXECUTABLE BEHAVIOR HARNESS: PASS (\(checks) checks)")
    }

    static func codecTests() throws {
        struct Stamp: Codable { let date: Date }
        let original = Stamp(date: Date(timeIntervalSince1970: 1_700_000_000.125))
        let bytes = try JSONEncoder.pretty.encode(original)
        let decoded = try JSONDecoder.iso8601.decode(Stamp.self, from: bytes)
        expect(abs(decoded.date.timeIntervalSince(original.date)) < 0.0011, "subsecond timestamps survive save/load")
        let old = try JSONDecoder.iso8601.decode(Stamp.self, from: Data("{\"date\":\"2023-11-14T22:13:20Z\"}".utf8))
        expect(old.date == Date(timeIntervalSince1970: 1_700_000_000), "legacy second-only timestamps still decode")
        var previous: Date?
        var ordered = true
        for step in 1...250 {
            let input = Stamp(date: Date(timeIntervalSince1970: 1_700_000_000 + Double(step) * 0.002))
            let output = try JSONDecoder.iso8601.decode(Stamp.self, from: JSONEncoder.pretty.encode(input))
            if let previous, output.date <= previous { ordered = false }
            previous = output.date
        }
        expect(ordered, "250 rapid changes retain strict chronological ordering after JSON round-trip")
        expectThrows("invalid timestamp is rejected") {
            _ = try JSONDecoder.iso8601.decode(Stamp.self, from: Data("{\"date\":\"invalid\"}".utf8))
        }
        let legacyEncoder = JSONEncoder()
        legacyEncoder.outputFormatting = [.prettyPrinted, .sortedKeys]
        legacyEncoder.dateEncodingStrategy = .iso8601
        let legacyBytes = try legacyEncoder.encode(original)
        let compatibleBytes = try SnapshotFingerprintEncoding.encode(original, version: nil)
        expect(legacyBytes == compatibleBytes, "old restore journal retains its original fingerprint encoding")
        let currentBytes = try SnapshotFingerprintEncoding.encode(original, version: 2)
        expect(currentBytes == bytes, "new restore journal uses fractional timestamp encoding")
        expect(currentBytes != legacyBytes, "journal version distinguishes old and new timestamp encodings")
        let afterRoundTrip = try SnapshotFingerprintEncoding.encode(decoded, version: 2)
        expect(currentBytes == afterRoundTrip, "new fingerprint remains stable after persistence round-trip")
        expectThrows("unknown fingerprint encoding cannot be treated as a committed restore") {
            _ = try SnapshotFingerprintEncoding.encode(original, version: 99)
        }
        var stable = true
        for step in 0..<512 {
            let value = Stamp(date: Date(timeIntervalSince1970: 1_700_000_000 + Double(step) * 0.000731))
            let first = try SnapshotFingerprintEncoding.encode(value, version: 2)
            let decodedValue = try JSONDecoder.iso8601.decode(Stamp.self, from: first)
            let second = try SnapshotFingerprintEncoding.encode(decodedValue, version: 2)
            if first != second { stable = false }
        }
        expect(stable, "512 fractional values have persistence-stable fingerprint bytes")
        var legal = UserProfile()
        legal.legalAccepted = true
        legal.legalAcceptedDate = Date()
        legal.legalAcceptedVersion = "old-version"
        expect(!LegalContent.isCurrentAcceptance(legal), "old legal version cannot unlock app")
        legal.legalAcceptedVersion = LegalContent.currentVersion
        expect(LegalContent.isCurrentAcceptance(legal), "complete current acceptance remains valid")
        legal.legalAcceptedDate = nil
        expect(!LegalContent.isCurrentAcceptance(legal), "missing acceptance timestamp cannot unlock app")
    }

    static func formatTests() throws {
        let minimal = Data("{\"profile\":{},\"workOrders\":[]}".utf8)
        let restored = try BackupArchiveService.decodeSnapshotWithMigration(minimal)
        expect(restored.workOrders.isEmpty && restored.dataSchemaVersion == AppDataSchema.currentVersion, "recognized empty legacy backup migrates without invented records")
        expect(!restored.profile.legalAccepted, "legacy migration never invents legal acceptance")
        let flat = Data("{\"profile\":{},\"workOrders\":[{\"area\":\"101\",\"issueDescription\":\"Legacy leak\"}]}".utf8)
        let oldRecord = try BackupArchiveService.decodeSnapshotWithMigration(flat)
        expect(oldRecord.workOrders.count == 1 && oldRecord.workOrders[0].latestEntry.issueDescription == "Legacy leak", "recognized flat legacy record is preserved by migration")
        let emptyRevisionHistory = Data("{\"profile\":{},\"workOrders\":[{\"entries\":[]}]}".utf8)
        do {
            _ = try BackupArchiveService.decodeSnapshotWithMigration(emptyRevisionHistory)
            expect(false, "work order with empty revision history is rejected")
        } catch BackupArchiveError.invalidWorkOrderRevisionHistory(let count) {
            expect(count == 1, "empty revision-history rejection reports the affected record count")
        } catch {
            expect(false, "empty revision history uses the dedicated integrity error")
        }
        let malformed = [
            "{}", "[]", "null", "true", "{\"workOrders\":[]}",
            "{\"profile\":null,\"workOrders\":[]}",
            "{\"profile\":{},\"workOrders\":\"bad\"}",
            "{\"profile\":{},\"workOrders\":[42]}",
            "{\"profile\":{},\"workOrders\":[{},42]}",
            "{\"profile\":{},\"workOrders\":[],\"assets\":\"bad\"}",
            "{\"profile\":{},\"workOrders\":[],\"tenants\":[4]}",
            "{\"profile\":{},\"workOrders\":[{\"entries\":\"bad\"}]}",
            "{\"profile\":{},\"workOrders\":[{\"entries\":[4]}]}",
            "{\"profile\":{},\"workOrders\":[{\"entries\":null}]}",
            "{\"profile\":{},\"workOrders\":[{\"entries\":[{\"images\":[4]}]}]}",
            "{\"profile\":{},\"workOrders\":[{\"entries\":[],\"auditLog\":\"bad\"}]}",
            "{\"profile\":{},\"workOrders\":[{\"entries\":[],\"statusEntries\":[4]}]}"
        ]
        for (index, json) in malformed.enumerated() {
            expectThrows("malformed backup \(index + 1) is rejected rather than emptied") {
                _ = try BackupArchiveService.decodeSnapshotWithMigration(Data(json.utf8))
            }
        }
        for version in ["true", "false", "\"3\"", "3.5", "-1", "99", "9223372036854775808"] {
            let json = "{\"profile\":{},\"workOrders\":[],\"dataSchemaVersion\":\(version)}"
            expectThrows("invalid/unsupported schema \(version) is rejected") {
                _ = try BackupArchiveService.decodeSnapshotWithMigration(Data(json.utf8))
            }
        }
        for version in 1...AppDataSchema.currentVersion {
            let data = Data("{\"profile\":{},\"workOrders\":[],\"dataSchemaVersion\":\(version)}".utf8)
            let value = try BackupArchiveService.decodeSnapshotWithMigration(data)
            expect(value.dataSchemaVersion == AppDataSchema.currentVersion, "supported schema \(version) migrates")
        }
        let future = Data("{\"dataSchemaVersion\":99,\"profile\":{},\"workOrders\":[{\"status\":\"new-status\"}]}".utf8)
        do {
            _ = try BackupArchiveService.decodeSnapshotWithMigration(future)
            expect(false, "future schema is identified before unknown enums")
        } catch BackupArchiveError.unsupportedArchiveVersion(let value) {
            expect(value == 99, "future schema is identified before unknown enums")
        } catch { expect(false, "future schema is identified before unknown enums") }
    }

    static func storageTests() throws {
        let clean = try scratch("clean")
        let emptyStorage = StorageService(directory: clean)
        expect(emptyStorage.load() == nil && emptyStorage.compatibilityBlockMessage == nil, "a genuinely fresh install is not blocked")
        let missingSnapshot = try scratch("missing-snapshot-with-evidence")
        let imageDirectory = missingSnapshot.appendingPathComponent("WorkOrderImages", isDirectory: true)
        try FileManager.default.createDirectory(at: imageDirectory, withIntermediateDirectories: true)
        let evidenceFile = imageDirectory.appendingPathComponent("preserved-evidence.jpg")
        let evidenceBytes = Data([1, 2, 3, 4])
        try evidenceBytes.write(to: evidenceFile)
        let incompleteStorage = StorageService(directory: missingSnapshot)
        expect(incompleteStorage.load() == nil && incompleteStorage.compatibilityBlockMessage != nil, "existing evidence without a snapshot is not treated as a fresh install")
        let remainingEvidence = try Data(contentsOf: evidenceFile)
        expect(remainingEvidence == evidenceBytes, "snapshot loss does not delete surviving evidence")
        let corruptDir = try scratch("corrupt")
        let corruptFile = corruptDir.appendingPathComponent("iworkorder-data.json")
        let corruptBytes = Data("damaged-snapshot".utf8)
        try corruptBytes.write(to: corruptFile)
        let corruptStorage = StorageService(directory: corruptDir)
        expect(corruptStorage.load() == nil && corruptStorage.compatibilityBlockMessage != nil, "unreadable sole snapshot enters protection mode")
        let after = try Data(contentsOf: corruptFile)
        expect(after == corruptBytes, "sole unreadable snapshot remains intact at its original path")
        expect(corruptStorage.load() == nil && corruptStorage.compatibilityBlockMessage != nil, "repeated launch cannot mistake unreadable data for a fresh install")
        let emptyHistoryDir = try scratch("empty-revision-history")
        let emptyHistoryPrimary = emptyHistoryDir.appendingPathComponent("iworkorder-data.json")
        let emptyHistorySnapshot = AppSnapshot(
            profile: UserProfile(),
            workOrders: [WorkOrder(entries: [])],
            dataSchemaVersion: AppDataSchema.currentVersion
        )
        let emptyHistoryBytes = try JSONEncoder.pretty.encode(emptyHistorySnapshot)
        try emptyHistoryBytes.write(to: emptyHistoryPrimary)
        let emptyHistoryStorage = StorageService(directory: emptyHistoryDir)
        expect(emptyHistoryStorage.load() == nil && emptyHistoryStorage.compatibilityBlockMessage != nil, "empty work-order revision history enters protection mode")
        let emptyHistoryAfter = try Data(contentsOf: emptyHistoryPrimary)
        expect(emptyHistoryAfter == emptyHistoryBytes, "invalid revision-history snapshot remains byte-for-byte intact for recovery")
        let futureDir = try scratch("future")
        let primary = futureDir.appendingPathComponent("iworkorder-data.json")
        let fallback = futureDir.appendingPathComponent("iworkorder-data.backup.json")
        let newer = Data("{\"dataSchemaVersion\":99,\"profile\":{},\"workOrders\":[{\"status\":\"unknown\"}]}".utf8)
        try newer.write(to: primary)
        let fallbackBytes = try JSONEncoder.pretty.encode(snapshot())
        try fallbackBytes.write(to: fallback)
        let futureStorage = StorageService(directory: futureDir)
        expect(futureStorage.load() == nil && futureStorage.compatibilityBlockMessage != nil, "future primary blocks fallback downgrade")
        let futureAfter = try Data(contentsOf: primary)
        let fallbackAfter = try Data(contentsOf: fallback)
        expect(futureAfter == newer && fallbackAfter == fallbackBytes, "future primary and fallback are not overwritten")
        let recoveryDir = try scratch("recovery")
        let damaged = recoveryDir.appendingPathComponent("iworkorder-data.json")
        try corruptBytes.write(to: damaged)
        try fallbackBytes.write(to: recoveryDir.appendingPathComponent("iworkorder-data.backup.json"))
        let recoveryStorage = StorageService(directory: recoveryDir)
        let recovered = recoveryStorage.load()
        expect(recovered != nil && recoveryStorage.compatibilityBlockMessage == nil, "valid fallback still rebuilds a corrupt primary")
        expect(recoveryStorage.recoveryNotice != nil, "fallback recovery surfaces a notice")
        let rebuilt = try JSONDecoder.iso8601.decode(AppSnapshot.self, from: Data(contentsOf: damaged))
        expect(rebuilt.dataSchemaVersion == AppDataSchema.currentVersion, "rebuilt primary decodes as the current snapshot")
    }

    static func addressTests() async {
        let verifier = AddressVerifier()
        var completionCount = 0
        verifier.verify("123 Old Street, City") { _ in completionCount += 1 }
        expect(verifier.isChecking, "address verification enters checking state")
        verifier.resetIfNeeded(for: "999 New Street, City, ST 10001")
        expect(!verifier.isChecking && !verifier.isVerified, "editing an in-flight address cancels its checking state")
        MKGeocodingRequest.current?.finishFirst()
        await settle()
        expect(completionCount == 0 && !verifier.isVerified, "late geocoder response cannot overwrite newly typed address")
        verifier.verify("999 New Street, City, ST 10001") { _ in completionCount += 1 }
        verifier.resetIfNeeded(for: "999 New Street, City, ST 10001")
        expect(verifier.isChecking, "unchanged address does not cancel its own verification")
        MKGeocodingRequest.current?.finishFirst()
        await settle()
        expect(completionCount == 1 && verifier.isVerified, "current geocoder response still completes normally")
        verifier.resetIfNeeded(for: "Changed Again")
        expect(!verifier.isVerified && verifier.formattedAddress.isEmpty, "editing a verified address invalidates verification")
    }

    static func lockTests() {
        let lock = AppLockState()
        expect(lock.isLocked, "cold launch begins locked until policy is applied")
        lock.applicationDidBecomeActive(lockEnabled: false)
        expect(!lock.isLocked, "disabled app lock remains usable without authentication")
        lock.requireUnlock()
        let first = lock.beginAuthentication()
        expect(first != nil && lock.isAuthenticating, "locked app starts one authentication attempt")
        expect(lock.beginAuthentication() == nil, "overlapping unlock requests are rejected")
        lock.applicationDidEnterBackground(lockEnabled: true)
        if let first { lock.completeAuthentication(token: first, succeeded: true) }
        expect(lock.isLocked && !lock.isAuthenticating, "late successful authentication cannot unlock a newly backgrounded session")
        if let second = lock.beginAuthentication() { lock.completeAuthentication(token: second, succeeded: false) }
        expect(lock.isLocked, "failed authentication keeps data locked")
        if let third = lock.beginAuthentication() { lock.completeAuthentication(token: third, succeeded: true) }
        expect(!lock.isLocked && !lock.isAuthenticating, "current successful authentication unlocks")
    }

    static func notificationTests() async {
        let service = NotificationService()
        let center = UNUserNotificationCenter.current()
        var entry = WorkOrderEntry(area: "4A", issueDescription: "Leak")
        entry.reminderEnabled = true
        entry.reminderDate = Date().addingTimeInterval(600)
        let order = WorkOrder(entries: [entry])
        let identifier = WorkOrderNotificationIdentifier.reminder(orderID: order.id)
        center.holdNextAdd = true
        service.reconcile(orders: [order], notificationsEnabled: true, emergencyNotificationsEnabled: false)
        let addStarted = await waitFor { center.heldAdd != nil }
        expect(addStarted, "test holds a real notification-coordinator add in flight")
        service.cancelAllNotifications()
        center.releaseAdd()
        await settle()
        expect(center.pending.isEmpty, "late system add cannot resurrect a canceled reminder")
        center.holdNextAdd = true
        service.reconcile(orders: [order], notificationsEnabled: true, emergencyNotificationsEnabled: false)
        _ = await waitFor { center.heldAdd != nil }
        var changed = order
        changed.entries[0].area = "NEW AREA"
        service.reconcile(orders: [changed], notificationsEnabled: true, emergencyNotificationsEnabled: false)
        center.releaseAdd()
        let updated = await waitFor { center.pending[identifier]?.content.body.hasPrefix("NEW AREA") == true }
        expect(updated, "newer reconciliation wins after an older add completes")
        let trigger = center.pending[identifier]?.trigger as? UNCalendarNotificationTrigger
        expect(trigger?.dateComponents.timeZone != nil && trigger?.dateComponents.calendar != nil, "notification trigger retains calendar and time zone")
        var expired = changed
        expired.entries[0].reminderDate = Date().addingTimeInterval(-60)
        if let request = center.pending[identifier] { center.delivered[identifier] = UNNotification(request: request) }
        service.reconcile(orders: [expired], notificationsEnabled: true, emergencyNotificationsEnabled: false)
        await settle()
        expect(center.pending[identifier] == nil, "expired reminder is not rescheduled")
        expect(center.delivered[identifier] != nil, "active work order retains its already-delivered reminder")
        expired.status = .completed
        service.reconcile(orders: [expired], notificationsEnabled: true, emergencyNotificationsEnabled: false)
        await settle()
        expect(center.delivered.isEmpty, "completed work order clears delivered notifications")
        var emergency = order
        emergency.entries[0].priority = .emergency
        emergency.entries[0].createdAt = Date()
        service.reconcile(orders: [emergency], notificationsEnabled: true, emergencyNotificationsEnabled: true)
        let emergencyID = WorkOrderNotificationIdentifier.emergency(orderID: order.id, entryID: entry.id)
        _ = await waitFor { center.pending[emergencyID] != nil }
        expect(center.pending[identifier] != nil && center.pending[emergencyID] != nil, "explicit reminder and emergency follow-up remain independent")
        service.reconcile(orders: [emergency], notificationsEnabled: false, emergencyNotificationsEnabled: true)
        await settle()
        expect(center.pending.isEmpty && center.delivered.isEmpty, "disabled notification preference cancels both channels")
        var errors: [String] = []
        service.schedulingError = { errors.append($0) }
        center.failNextAdd = true
        service.reconcile(orders: [order], notificationsEnabled: true, emergencyNotificationsEnabled: false)
        _ = await waitFor { !errors.isEmpty }
        expect(errors.count == 1, "current scheduling failure reaches the error handler")
        var routes: [UUID] = []
        service.openWorkOrder = { routes.append($0) }
        if let url = URL(string: "iworkorder://workorder/" + order.id.uuidString) { service.route(url: url) }
        expect(routes == [order.id], "work-order deep link remains functional")
        if let bad = URL(string: "https://workorder/" + order.id.uuidString) { service.route(url: bad) }
        expect(routes.count == 1, "foreign URL scheme cannot route a work order")
        service.cancelAllNotifications()
        await settle()
    }
}
