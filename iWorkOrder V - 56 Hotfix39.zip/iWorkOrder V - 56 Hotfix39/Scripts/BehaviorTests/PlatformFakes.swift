// Test-only stand-ins for unavailable Apple UI, geocoding, and notification APIs.
// These exercise application control flow, not iOS service behavior or UI layout.
import Foundation

protocol ObservableObject: AnyObject {}
@propertyWrapper struct Published<Value> {
    var wrappedValue: Value
    init(wrappedValue: Value) { self.wrappedValue = wrappedValue }
}

final class MKAddressRepresentations: @unchecked Sendable {
    let cityName: String? = "City"
    func fullAddress(includingRegion: Bool, singleLine: Bool) -> String? {
        "123 Street, City, State 10001"
    }
}

final class MKMapItem: @unchecked Sendable {
    let name: String?
    let addressRepresentations: MKAddressRepresentations?

    init(name: String = "123 Street", addressRepresentations: MKAddressRepresentations? = MKAddressRepresentations()) {
        self.name = name
        self.addressRepresentations = addressRepresentations
    }
}

@MainActor
final class MKGeocodingRequest {
    typealias Completion = @MainActor @Sendable ([MKMapItem]?, (any Error)?) -> Void
    private var callbacks: [Completion] = []
    static var current: MKGeocodingRequest?
    let addressString: String

    init?(addressString: String) {
        guard !addressString.isEmpty else { return nil }
        self.addressString = addressString
        Self.current = self
    }

    func cancel() {}

    func getMapItems(completionHandler: @escaping Completion) {
        callbacks.append(completionHandler)
    }

    func finishFirst() {
        if !callbacks.isEmpty { callbacks.removeFirst()([MKMapItem()], nil) }
    }
}


enum UNAuthorizationStatus: Sendable { case authorized, provisional, ephemeral, notDetermined, denied }
struct UNAuthorizationOptions: OptionSet, Sendable {
    let rawValue: Int
    static let alert = Self(rawValue: 1)
    static let badge = Self(rawValue: 2)
    static let sound = Self(rawValue: 4)
}
struct UNNotificationPresentationOptions: OptionSet, Sendable {
    let rawValue: Int
    static let banner = Self(rawValue: 1)
    static let list = Self(rawValue: 2)
    static let sound = Self(rawValue: 4)
}
struct UNNotificationSettings: Sendable { let authorizationStatus: UNAuthorizationStatus }
struct UNNotificationSound: Sendable { static let `default` = Self() }
class UNNotificationContent: @unchecked Sendable {
    var title = ""
    var body = ""
    var sound: UNNotificationSound?
    var userInfo: [AnyHashable: Any] = [:]
}
final class UNMutableNotificationContent: UNNotificationContent, @unchecked Sendable {}
class UNNotificationTrigger: @unchecked Sendable {}
final class UNCalendarNotificationTrigger: UNNotificationTrigger, @unchecked Sendable {
    let dateComponents: DateComponents
    init(dateMatching: DateComponents, repeats: Bool) { self.dateComponents = dateMatching }
}
final class UNNotificationRequest: Sendable {
    let identifier: String
    let content: UNNotificationContent
    let trigger: UNNotificationTrigger?
    init(identifier: String, content: UNNotificationContent, trigger: UNNotificationTrigger?) {
        self.identifier = identifier; self.content = content; self.trigger = trigger
    }
}
struct UNNotification: Sendable { let request: UNNotificationRequest }
struct UNNotificationResponse: Sendable { let notification: UNNotification }
protocol UNUserNotificationCenterDelegate: AnyObject {
    nonisolated func userNotificationCenter(_ center: UNUserNotificationCenter, willPresent notification: UNNotification) async -> UNNotificationPresentationOptions
    nonisolated func userNotificationCenter(_ center: UNUserNotificationCenter, didReceive response: UNNotificationResponse) async
}
@MainActor final class UNUserNotificationCenter {
    static let shared = UNUserNotificationCenter()
    static func current() -> UNUserNotificationCenter { shared }
    weak var delegate: (any UNUserNotificationCenterDelegate)?
    var status: UNAuthorizationStatus = .authorized
    var pending: [String: UNNotificationRequest] = [:]
    var delivered: [String: UNNotification] = [:]
    var holdNextAdd = false
    var heldAdd: CheckedContinuation<Void, Never>?
    var failNextAdd = false
    var addCount = 0
    func notificationSettings() async -> UNNotificationSettings { UNNotificationSettings(authorizationStatus: status) }
    func requestAuthorization(options: UNAuthorizationOptions) async throws -> Bool { status == .authorized }
    func add(_ request: UNNotificationRequest) async throws {
        addCount += 1
        if holdNextAdd {
            holdNextAdd = false
            await withCheckedContinuation { heldAdd = $0 }
        }
        if failNextAdd { failNextAdd = false; throw CocoaError(.fileWriteUnknown) }
        pending[request.identifier] = request
    }
    func releaseAdd() { heldAdd?.resume(); heldAdd = nil }
    func getPendingNotificationRequests(completionHandler: @escaping @Sendable ([UNNotificationRequest]) -> Void) {
        completionHandler(Array(pending.values))
    }
    func getDeliveredNotifications(completionHandler: @escaping @Sendable ([UNNotification]) -> Void) {
        completionHandler(Array(delivered.values))
    }
    func pendingNotificationRequests() async -> [UNNotificationRequest] {
        Array(pending.values)
    }
    func deliveredNotifications() async -> [UNNotification] {
        Array(delivered.values)
    }
    func removePendingNotificationRequests(withIdentifiers ids: [String]) { for id in ids { pending.removeValue(forKey: id) } }
    func removeDeliveredNotifications(withIdentifiers ids: [String]) { for id in ids { delivered.removeValue(forKey: id) } }
    func removeAllPendingNotificationRequests() { pending.removeAll() }
    func removeAllDeliveredNotifications() { delivered.removeAll() }
}
