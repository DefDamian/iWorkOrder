#!/usr/bin/env python3
from pathlib import Path
import re
import sys

ROOT = Path(__file__).resolve().parents[1]
APP = ROOT / 'iWorkOrder'
maintenance = (APP / 'MaintenanceService.swift').read_text(encoding='utf-8')
backup = (APP / 'BackupArchiveService.swift').read_text(encoding='utf-8')
store = (APP / 'AppStore.swift').read_text(encoding='utf-8')
behavior = (ROOT / 'Scripts/BehaviorTests/ConsolidatedBehaviorTests.swift').read_text(encoding='utf-8')
maintenance_harness = (ROOT / 'Scripts/run_maintenance_harness.py').read_text(encoding='utf-8')

checks = 0
failures: list[str] = []

def require(condition: bool, message: str) -> None:
    global checks
    checks += 1
    if condition:
        print('PASS: ' + message)
    else:
        failures.append(message)
        print('FAIL: ' + message)

# Core invariant: a persisted work order must always have revision history.
require('case invalidWorkOrderRevisionHistory(Int)' in maintenance,
        'migration layer has a dedicated empty-revision-history integrity error')
require('if order.entries.isEmpty { count += 1 }' in maintenance,
        'migration explicitly counts work orders with no revisions')
require('throw DataMigrationError.invalidWorkOrderRevisionHistory(emptyWorkOrderCount)' in maintenance,
        'migration blocks empty work-order revision history before use')
require('original recovery evidence remains intact' in maintenance,
        'migration error explains that source data is preserved')

# Backup import/export must reject the same invalid state before mutation/archive creation.
require('case invalidWorkOrderRevisionHistory(Int)' in backup,
        'backup layer exposes a dedicated invalid-revision-history error')
require('Restore was stopped and no app data was changed.' in backup,
        'backup error states restore is non-mutating on integrity rejection')
require(backup.count('throw BackupArchiveError.invalidWorkOrderRevisionHistory(emptyWorkOrderCount)') >= 2,
        'backup validation protects both snapshot validation and archive creation')
require('catch DataMigrationError.invalidWorkOrderRevisionHistory(let count)' in backup and
        'throw BackupArchiveError.invalidWorkOrderRevisionHistory(count)' in backup,
        'backup migration preserves the dedicated integrity failure instead of flattening it')
create_archive_pos = backup.find('private static func createArchive')
work_dir_pos = backup.find('let workDirectory = FileManager.default.temporaryDirectory', create_archive_pos)
archive_guard_pos = backup.find('throw BackupArchiveError.invalidWorkOrderRevisionHistory(emptyWorkOrderCount)', create_archive_pos)
require(create_archive_pos >= 0 and archive_guard_pos >= 0 and archive_guard_pos < work_dir_pos,
        'backup export rejects invalid revision history before creating archive work files')

# Persistence boundaries must never manufacture synthetic history or upload invalid state.
require('private func validateCurrentRevisionHistoryForPersistence() -> Bool' in store,
        'AppStore has a shared persistence-boundary revision-history guard')
require('guard validateCurrentRevisionHistoryForPersistence() else { return false }' in store,
        'ordinary local save blocks invalid revision history')
require('guard validateCurrentRevisionHistoryForPersistence() else { return nil }' in store,
        'cloud-operation persistence blocks invalid revision history')
require('guard validateCurrentRevisionHistoryForPersistence() else { return }' in store,
        'lifecycle persistence blocks invalid revision history')
require('Backup export was stopped before any archive was written.' in store,
        'manual backup export stops before writing invalid data')
require('Cloud sync was not resumed because local revision history failed validation.' in store,
        'post-backup cloud resume does not schedule invalid local data')

# Failed normalization may never fall back to unvalidated external data.
require('normalizedRevisionSnapshot(outcome.snapshot)) ?? outcome.snapshot' not in store,
        'iCloud restore cannot fall back to an unnormalized cloud snapshot')
require('normalizedRevisionSnapshot(candidate.snapshot) ?? candidate.snapshot' not in store,
        'backup restore cannot fall back to an unnormalized backup snapshot')
require('guard let normalizedCloudSnapshot = normalizedRevisionSnapshot(outcome.snapshot)' in store,
        'iCloud restore requires a validated normalized snapshot')
require('guard var importedSnapshot = normalizedRevisionSnapshot(candidate.snapshot)' in store,
        'backup restore requires a validated normalized snapshot')
require('dataCompatibilityMessage = originalDataCompatibilityMessage' in store,
        'a rejected external backup does not permanently poison valid local compatibility state')
require('BackupArchiveService.discard(candidate)' in store,
        'rejected backup staging data is discarded')
require('await cloud.endExclusiveLocalDataAccess()' in store,
        'rejected restore releases exclusive cloud/local operation access')
rejected_guard = re.search(
    r'guard var importedSnapshot = normalizedRevisionSnapshot\(candidate\.snapshot\),.*?return nil\n\s*}',
    store,
    re.DOTALL,
)
require(rejected_guard is not None and 'resumeCloudAfterBackupOperation()' in rejected_guard.group(0),
        'rejected backup validation resumes the prior cloud operation after exclusive access is released')
restore_catch = re.search(
    r'func restoreBackup\(.*?\n\s*} catch \{(.*?)\n\s*}\n\s*}\n\n\s*func reportPDFURL',
    store,
    re.DOTALL,
)
require(restore_catch is not None and
        'if restoreRecoveryWriteBlocked' in restore_catch.group(1) and
        '} else {\n                resumeCloudAfterBackupOperation()' in restore_catch.group(1),
        'failed restore resumes cloud sync after a successful rollback but keeps sync paused when recovery is incomplete')

# Executable regression coverage.
require('empty revision-history rejection reports the affected record count' in behavior,
        'executable behavior tests cover backup empty-revision rejection')
require('empty work-order revision history enters protection mode' in behavior,
        'executable storage tests cover local protection mode')
require('invalid revision-history snapshot remains byte-for-byte intact for recovery' in behavior,
        'executable storage test verifies corrupt source bytes are preserved')
require('empty work-order revision history must be blocked' in maintenance_harness,
        'compiled maintenance harness exercises the invariant directly')

# Full-loop hygiene patterns: no intentional crash shortcuts in shipping app code.
shipping_swift = '\n'.join(path.read_text(encoding='utf-8') for path in APP.glob('*.swift'))
forbidden = ['fatalError(', 'preconditionFailure(', 'try!', ' as! ']
require(not any(token in shipping_swift for token in forbidden),
        'shipping Swift contains no fatal-error/forced-try/forced-cast shortcuts')
require(not re.search(r'\bTODO\b|\bFIXME\b|\bHACK\b', shipping_swift, re.IGNORECASE),
        'shipping Swift contains no TODO/FIXME/HACK placeholders')

if failures:
    print(f'HOTFIX 28 FULL BUG LOOP: FAIL ({len(failures)} of {checks} checks failed)')
    sys.exit(1)
print(f'HOTFIX 28 FULL BUG LOOP: PASS ({checks} checks)')
