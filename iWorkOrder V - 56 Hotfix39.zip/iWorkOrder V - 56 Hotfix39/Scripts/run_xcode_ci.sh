#!/bin/bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
exec env PHASE56_MODE=ci PHASE56_ALLOW_XCODE26_COMPATIBILITY="${PHASE56_ALLOW_XCODE26_COMPATIBILITY:-1}" \
  "$ROOT/Scripts/phase56_xcode_qualification.sh"
