#!/usr/bin/env python3
from __future__ import annotations

import json
import re
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
APP = ROOT / "iWorkOrder"
errors: list[str] = []
checks: list[str] = []


def require(condition: bool, message: str) -> None:
    (checks if condition else errors).append(message)


diagnostics = (APP / "DiagnosticReportService.swift").read_text(encoding="utf-8")
settings = (APP / "CalendarHubSettingsViews.swift").read_text(encoding="utf-8")
mail = (APP / "WorkOrderViews.swift").read_text(encoding="utf-8")
ids = (APP / "AccessibilitySupport.swift").read_text(encoding="utf-8")
unit_tests = (ROOT / "iWorkOrderTests/iWorkOrderTests.swift").read_text(encoding="utf-8")
ui_tests = (ROOT / "iWorkOrderUITests/iWorkOrderUITests.swift").read_text(encoding="utf-8")
pbx = (ROOT / "iWorkOrder.xcodeproj/project.pbxproj").read_text(encoding="utf-8")
workflow = (ROOT / ".github/workflows/ios-ci.yml").read_text(encoding="utf-8")
phase = (ROOT / "Scripts/phase56_xcode_qualification.sh").read_text(encoding="utf-8")

require("DiagnosticReportService.swift in Sources" in pbx, "diagnostic report service is compiled by the app target")
require("struct SupportDiagnosticsView" in settings, "public support screen exists")
require('SettingsRow(title: "Support"' in settings, "settings links to public support")
require("DiagnosticReportTests" in unit_tests, "unit tests cover diagnostic report generation")
require("testSupportDiagnosticsCanBeOpened" in ui_tests, "UI tests cover public support navigation")
require("testCaptureSubmissionScreenshots" in ui_tests, "UI tests capture named submission evidence")
require("MailAttachment" in mail and "addAttachmentData" in mail, "native Mail supports diagnostics attachments")
require("supportDraft(diagnosticsURL:" in mail, "support draft attaches the diagnostics report")
require("report intentionally excludes names" in diagnostics, "diagnostic output states its privacy exclusions")
require("recentErrorPresent" in diagnostics and diagnostics.count("lastErrorMessage") == 1 and "store.lastErrorMessage != nil" in diagnostics, "diagnostics report only whether an error exists and do not export its content")
require("cloudSyncDetail" not in diagnostics, "diagnostics do not export free-form cloud error details")
for forbidden in ["profile.personName", "profile.propertyManagerCompanyName", "profile.buildingAddress", "profile.deviceID"]:
    require(forbidden not in diagnostics, f"diagnostics do not access personal field: {forbidden}")
require("screen.support" in ids and "support.exportPackage" in ids and "support.email" in ids, "public support identifiers are centralized")

required_handoff = [
    "AppStoreConnect/metadata/en-US/name.txt",
    "AppStoreConnect/metadata/en-US/description.txt",
    "AppStoreConnect/review/app_review_notes.txt",
    "AppStoreConnect/review/APP_PRIVACY_RESPONSES.md",
    "AppStoreConnect/review/ACCOUNT_HOLDER_CONFIRMATION.md",
    "AppStoreConnect/testflight/beta_app_description.txt",
    "AppStoreConnect/testflight/what_to_test.txt",
    "AppStoreConnect/screenshots/README.md",
    "support.html",
    "index.html",
]
for relative in required_handoff:
    require((ROOT / relative).is_file(), f"submission handoff file exists: {relative}")

catalog = json.loads((APP / "Localizable.xcstrings").read_text(encoding="utf-8"))
for key in ["Support", "Support Package", "Create Support Package", "Email Support"]:
    require(key in catalog.get("strings", {}), f"string catalog contains public support label: {key}")

require("Artifacts/Phase56" in workflow, "CI retains Phase 56 evidence")
require("phase56-hosted-xcode-compatibility" in workflow, "CI publishes a hosted Xcode compatibility artifact")
require("validate_app_store_metadata.py" in phase, "Xcode qualification validates submission metadata")
require("validate_testflight_ipa.py" in phase, "signed qualification validates the exported IPA")
require("-test-iterations 5" in phase, "qualification repeats unit tests for stabilization")
require(phase.count("testCaptureSubmissionScreenshots") >= 2, "qualification captures iPhone and iPad screenshot evidence")
require("-exportArchive" in phase and "app-store-connect" in phase, "signed qualification exports an App Store Connect IPA")
require("Upload: Not performed" in phase, "release tooling does not upload without an explicit account-holder action")

if errors:
    print("PHASE 56 SUBMISSION HARNESS: FAIL")
    for message in errors:
        print(f"FAIL: {message}")
    print(f"Passed checks before failure: {len(checks)}")
    sys.exit(1)

print("PHASE 56 SUBMISSION HARNESS: PASS")
print(f"Checks passed: {len(checks)}")
for message in checks:
    print(f"PASS: {message}")
