#!/usr/bin/env python3
from pathlib import Path
import plistlib

ROOT = Path(__file__).resolve().parents[1]
APP = ROOT / "iWorkOrder"
checks = 0

def require(condition, message):
    global checks
    if not condition:
        raise SystemExit(f"FAIL: {message}")
    checks += 1
    print(f"PASS: {message}")

root = (APP / "RootView.swift").read_text()
onboarding = (APP / "OnboardingView.swift").read_text()
store = (APP / "AppStore.swift").read_text()
services = (APP / "Services.swift").read_text()
legal = (APP / "LegalContent.swift").read_text()
accessibility = (APP / "AccessibilitySupport.swift").read_text()
ui_tests = (ROOT / "iWorkOrderUITests/iWorkOrderUITests.swift").read_text()
info = plistlib.loads((APP / "Info.plist").read_bytes())

require('static let currentVersion = "2026.09.16.56"' in legal, "Hotfix25 legal version forces renewed acceptance")
require('static let effectiveDate = "September 16, 2026"' in legal, "Hotfix25 legal effective date is current")
require("first-use device permission review" in legal.lower(), "privacy/legal text discloses first-use permission review")
require("does not request broad Photo Library authorization" in legal, "legal text discloses PhotosPicker privacy boundary")
require("does not request device Contacts access, Calendar database access, microphone access, precise-location access, or App Tracking Transparency authorization" in legal, "legal text enumerates permissions not requested")
require("PermissionSetupView" in onboarding, "first-use permission screen exists")
require("Request iOS Permissions" in onboarding, "permission screen has an explicit user-initiated request action")
require("store.notifications.requestPermission()" in onboarding, "permission screen requests notifications through existing service")
require("FlashlightService.requestCameraPermission()" in onboarding, "permission screen requests camera authorization without turning on the torch")
require("permissionsReviewed" in onboarding and "notificationStatus != .notDetermined" in onboarding and "cameraStatus != .notDetermined" in onboarding, "permission review waits for both system permission decisions")
require("store.completePermissionSetup()" in onboarding, "permission review completion is explicit")
require("else if !store.hasCompletedPermissionSetup" in root and "PermissionSetupView()" in root, "RootView gates protected app access on permission review")
require("!store.hasCurrentLegalAcceptance" in root and root.index("!store.hasCurrentLegalAcceptance") < root.index("!store.hasCompletedPermissionSetup"), "legal acceptance occurs before device permission review")
require("hasCompletedPermissionSetup" in store and "PermissionSetupPersistenceService" in store, "AppStore persists permission-review completion separately from onboarding")
perm_block = services[services.index("final class PermissionSetupPersistenceService"):services.index("extension JSONEncoder")]
require("UserDefaults.standard" in perm_block and "NSUbiquitousKeyValueStore" not in perm_block, "permission-review completion is device-local only")
require("requestCameraPermission" in services and "AVCaptureDevice.requestAccess(for: .video)" in services, "camera authorization is reusable and explicit")
require("AVCaptureSession" not in services, "camera path does not create a media-capture session")
usage = {k for k in info if k.startswith("NS") and k.endswith("UsageDescription")}
require(usage == {"NSCameraUsageDescription", "NSFaceIDUsageDescription"}, "Info.plist contains only camera and Face ID purpose strings")
require("optional rear flashlight" in info["NSCameraUsageDescription"] and "does not capture or record photos or video" in info["NSCameraUsageDescription"], "camera purpose string is accurate and narrow")
require("only when you enable App Lock" in info["NSFaceIDUsageDescription"], "Face ID purpose string is conditional on App Lock")
require("NSPhotoLibraryUsageDescription" not in info and "NSLocationWhenInUseUsageDescription" not in info and "NSMicrophoneUsageDescription" not in info and "NSContactsUsageDescription" not in info and "NSCalendarsUsageDescription" not in info, "unused protected-resource purpose strings are absent")
require("startsPermissionSetup" in accessibility and "-ui-testing-permission-setup" in accessibility, "UI testing can launch directly into permission review")
require("testFirstUsePermissionReviewAppearsBeforeMainApp" in ui_tests, "UI automation covers permission-review routing")
require("permissionSetupPersistence.clearCompletedReview()" in store and "hasCompletedPermissionSetup = false" in store, "erase/reset paths clear the device-local permission-review state")
require("onboardingPersistence.markCompleted" in store and "permissionSetupPersistence.markCompleted" in store, "onboarding/legal completion and permission-review completion remain separate records")
print(f"HOTFIX 25 PERMISSIONS + LEGAL: PASS ({checks} checks; source-level verification)")
