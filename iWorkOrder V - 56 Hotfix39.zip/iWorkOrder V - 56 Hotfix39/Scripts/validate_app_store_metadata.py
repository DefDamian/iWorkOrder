#!/usr/bin/env python3
from __future__ import annotations

import argparse
import re
import struct
import sys
from pathlib import Path
from urllib.parse import urlparse

ROOT = Path(__file__).resolve().parents[1]
META = ROOT / "AppStoreConnect" / "metadata" / "en-US"
TESTFLIGHT = ROOT / "AppStoreConnect" / "testflight"
REVIEW = ROOT / "AppStoreConnect" / "review"
SCREENSHOTS = ROOT / "AppStoreConnect" / "screenshots"

errors: list[str] = []
checks: list[str] = []


def require(condition: bool, message: str) -> None:
    (checks if condition else errors).append(message)


def read(path: Path) -> str:
    require(path.is_file(), f"file exists: {path.relative_to(ROOT)}")
    if not path.is_file():
        return ""
    return path.read_text(encoding="utf-8").strip()


def validate_https_url(label: str, value: str) -> None:
    parsed = urlparse(value)
    require(parsed.scheme == "https" and bool(parsed.netloc), f"{label} is an absolute HTTPS URL")


def png_info(path: Path) -> tuple[int, int, bool] | None:
    payload = path.read_bytes()
    if not payload.startswith(b"\x89PNG\r\n\x1a\n") or len(payload) < 29:
        return None
    width, height, _, color_type, _, _, _ = struct.unpack(">IIBBBBB", payload[16:29])
    return width, height, color_type in {4, 6}


def jpeg_size(path: Path) -> tuple[int, int] | None:
    data = path.read_bytes()
    if not data.startswith(b"\xff\xd8"):
        return None
    index = 2
    while index + 4 <= len(data):
        if data[index] != 0xFF:
            index += 1
            continue
        marker = data[index + 1]
        index += 2
        if marker in {0xD8, 0xD9}:
            continue
        if index + 2 > len(data):
            break
        length = int.from_bytes(data[index:index + 2], "big")
        if length < 2 or index + length > len(data):
            break
        if marker in {0xC0, 0xC1, 0xC2, 0xC3, 0xC5, 0xC6, 0xC7, 0xC9, 0xCA, 0xCB, 0xCD, 0xCE, 0xCF}:
            if length >= 7:
                height = int.from_bytes(data[index + 3:index + 5], "big")
                width = int.from_bytes(data[index + 5:index + 7], "big")
                return width, height
        index += length
    return None


def validate_screenshot_directory(path: Path, accepted: set[tuple[int, int]], required: bool) -> None:
    images = sorted(
        item for item in path.iterdir()
        if item.is_file() and item.suffix.lower() in {".png", ".jpg", ".jpeg"}
    ) if path.is_dir() else []
    if required:
        require(1 <= len(images) <= 10, f"{path.name} contains one to ten screenshots")
    else:
        require(len(images) <= 10, f"{path.name} contains no more than ten screenshots")
    for image in images:
        suffix = image.suffix.lower()
        if suffix == ".png":
            info = png_info(image)
            require(info is not None, f"valid PNG screenshot: {image.name}")
            if info:
                width, height, has_alpha = info
                require((width, height) in accepted, f"accepted App Store dimensions: {image.name}")
                require(not has_alpha, f"screenshot has no alpha channel: {image.name}")
        else:
            size = jpeg_size(image)
            require(size is not None, f"valid JPEG screenshot: {image.name}")
            if size:
                require(size in accepted, f"accepted App Store dimensions: {image.name}")


parser = argparse.ArgumentParser()
parser.add_argument("--require-screenshots", action="store_true")
args = parser.parse_args()

name = read(META / "name.txt")
subtitle = read(META / "subtitle.txt")
promotional = read(META / "promotional_text.txt")
description = read(META / "description.txt")
keywords = read(META / "keywords.txt")
support_url = read(META / "support_url.txt")
marketing_url = read(META / "marketing_url.txt")
privacy_url = read(META / "privacy_url.txt")
copyright_text = read(META / "copyright.txt")
review_notes = read(REVIEW / "app_review_notes.txt")
beta_description = read(TESTFLIGHT / "beta_app_description.txt")
what_to_test = read(TESTFLIGHT / "what_to_test.txt")
feedback_email = read(TESTFLIGHT / "feedback_email.txt")

require(2 <= len(name) <= 30, "app name is between 2 and 30 characters")
require(1 <= len(subtitle) <= 30, "subtitle is no longer than 30 characters")
require(len(promotional) <= 170, "promotional text is no longer than 170 characters")
require(1 <= len(description) <= 4000, "description is between 1 and 4000 characters")
require("<" not in description and ">" not in description, "description is plain text without HTML")
require(1 <= len(keywords.encode("utf-8")) <= 100, "keywords use no more than 100 UTF-8 bytes")
keyword_items = [item.strip() for item in keywords.split(",") if item.strip()]
require(bool(keyword_items), "keyword list is not empty")
require(all(len(item) > 2 for item in keyword_items), "every keyword is longer than two characters")
require(len(keyword_items) == len(set(item.lower() for item in keyword_items)), "keywords contain no duplicates")
require("iworkorder" not in {item.lower() for item in keyword_items}, "keywords do not duplicate the app name")
require(len(review_notes.encode("utf-8")) <= 4000, "App Review notes use no more than 4000 bytes")
require(bool(beta_description), "TestFlight beta description is present")
require(bool(what_to_test), "TestFlight what-to-test instructions are present")
require(re.fullmatch(r"[^@\s]+@[^@\s]+\.[^@\s]+", feedback_email) is not None, "TestFlight feedback email is valid")
require(bool(copyright_text), "copyright wording is present")

for label, value in [
    ("support URL", support_url),
    ("marketing URL", marketing_url),
    ("privacy URL", privacy_url),
]:
    validate_https_url(label, value)

for value, local in [
    (support_url, ROOT / "support.html"),
    (marketing_url, ROOT / "index.html"),
    (privacy_url, ROOT / "iworkorder-privacy-policy.html"),
]:
    require(local.is_file(), f"publish-ready page exists for {value}")

support_html = (ROOT / "support.html").read_text(encoding="utf-8")
require(feedback_email in support_html, "support page contains the feedback email")
require("Privacy-Safe Diagnostics" in support_html or "privacy-safe diagnostics" in support_html, "support page explains privacy-safe diagnostics")

combined = "\n".join([
    name, subtitle, promotional, description, keywords, support_url, marketing_url,
    privacy_url, copyright_text, review_notes, beta_description, what_to_test,
])
for token in ["TODO", "TBD", "YOUR_TEAM", "YOUR_", "example.com", "<UUID>"]:
    require(token not in combined, f"submission text contains no unresolved placeholder: {token}")

iphone_sizes = {
    (1260, 2736), (2736, 1260),
    (1290, 2796), (2796, 1290),
    (1320, 2868), (2868, 1320),
}
ipad_sizes = {
    (2064, 2752), (2752, 2064),
    (2048, 2732), (2732, 2048),
}
validate_screenshot_directory(SCREENSHOTS / "iphone-6.9", iphone_sizes, args.require_screenshots)
validate_screenshot_directory(SCREENSHOTS / "ipad-13", ipad_sizes, args.require_screenshots)

if errors:
    print("PHASE 56 APP STORE METADATA: FAIL")
    for item in errors:
        print(f"FAIL: {item}")
    print(f"Checks passed before failure: {len(checks)}")
    sys.exit(1)

print("PHASE 56 APP STORE METADATA: PASS")
print(f"Checks passed: {len(checks)}")
for item in checks:
    print(f"PASS: {item}")
