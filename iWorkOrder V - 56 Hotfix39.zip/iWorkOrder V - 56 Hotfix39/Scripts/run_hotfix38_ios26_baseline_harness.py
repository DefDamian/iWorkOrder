#!/usr/bin/env python3
from pathlib import Path
import sys

ROOT = Path(__file__).resolve().parents[1]
APP = ROOT / "iWorkOrder"
PBX = ROOT / "iWorkOrder.xcodeproj/project.pbxproj"

passed: list[str] = []
failed: list[str] = []

def require(condition: bool, message: str) -> None:
    (passed if condition else failed).append(message)

pbx = PBX.read_text(encoding="utf-8")
services = (APP / "Services.swift").read_text(encoding="utf-8")
components = (APP / "Components.swift").read_text(encoding="utf-8")
fakes = (ROOT / "Scripts/BehaviorTests/PlatformFakes.swift").read_text(encoding="utf-8")
behavior = (ROOT / "Scripts/BehaviorTests/ConsolidatedBehaviorTests.swift").read_text(encoding="utf-8")
verify_sh = (ROOT / "Scripts/verify_release.sh").read_text(encoding="utf-8")
qualification = (ROOT / "Scripts/phase56_xcode_qualification.sh").read_text(encoding="utf-8")
readme = (ROOT / "README.md").read_text(encoding="utf-8")
checklist = (ROOT / "RELEASE_VALIDATION_CHECKLIST.md").read_text(encoding="utf-8")
matrix = (ROOT / "PHASE56_DEVICE_TEST_MATRIX.md").read_text(encoding="utf-8")
shipping = "\n".join(path.read_text(encoding="utf-8") for path in APP.rglob("*.swift"))

# The app and both test targets must share one modern deployment baseline.
require(pbx.count("IPHONEOS_DEPLOYMENT_TARGET = 26.0;") == 8, "all eight project/target build configurations require iOS 26.0")
for old in ("15.0", "16.0", "17.0", "18.0", "19.0", "20.0", "21.0", "22.0", "23.0", "24.0", "25.0"):
    require(f"IPHONEOS_DEPLOYMENT_TARGET = {old};" not in pbx, f"no build configuration retains iOS {old} deployment support")
require(pbx.count("SWIFT_STRICT_CONCURRENCY = complete;") >= 8, "strict concurrency remains enabled across app and tests")
require(pbx.count("SWIFT_VERSION = 6.0;") >= 8, "Swift 6 language mode remains enabled across app and tests")

# iOS 26 is now the baseline, so pre-26 geocoding code must be gone rather than dormant.
require("MKGeocodingRequest(addressString:" in services, "address verification uses MKGeocodingRequest directly")
require("addressRepresentations" in services and "fullAddress(includingRegion: true, singleLine: true)" in services, "address verification consumes structured MapKit address representations")
for obsolete in ("MKLocalSearch", "startLegacyLookup", "legacySearchResultMatchesInput", "looksLikeCompleteAddress", "normalizedAddressTokens"):
    require(obsolete not in services, f"pre-iOS-26 address compatibility symbol {obsolete} is removed")
require("if #available(iOS 26.0, *)" not in services, "iOS 26 baseline does not carry redundant geocoding availability dispatch")
require("cancelActiveLookup = { request.cancel() }" in services and "verificationGeneration += 1" in services, "address lookup cancellation and stale-response generation guard remain intact")
require("MKLocalSearch" not in fakes and "MKLocalSearch" not in behavior, "portable behavior tests no longer carry the removed legacy geocoder")
require("MKGeocodingRequest" in fakes and "finishFirst()" in behavior, "portable behavior tests still exercise controlled modern geocoder completion")

# iOS 27-only presentation stays guarded because iOS 26 remains supported.
require("if #available(iOS 27.0, *)" in components, "iOS 27 text-field presentation remains availability guarded")
require("@available(iOS, introduced: 26.0, obsoleted: 27.0)" in components, "iOS 26-only text-field fallback is explicitly availability bounded")
require(components.count(".textFieldStyle(.roundedBorder)") == 1, "deprecated rounded-border styling is isolated to one iOS 26-only helper")
require("iOS26RoundedTextFieldStyle" in components, "iOS 26 text-field fallback is named for its actual compatibility scope")

# Active operational guidance must match the new support policy.
require("iOS/iPadOS 26.0" in readme, "README declares the iOS/iPadOS 26.0 minimum")
require("iOS 26.0 minimum deployment target" in checklist, "release checklist preserves the iOS 26.0 minimum")
require("iOS 26–27" in checklist, "release checklist tests only the supported iOS 26-27 matrix")
require("iOS 26.0 deployment target" in matrix and "iOS 26–27" in matrix, "device matrix covers the supported iOS 26-27 range")
require("MKLocalSearch" not in checklist and "MKLocalSearch" not in matrix, "active release guidance no longer requires legacy MapKit search")

# Shipping source should not reintroduce the superseded geocoder stack.
for symbol in ("CLGeocoder", "CLPlacemark", "CNPostalAddressFormatter"):
    require(symbol not in shipping, f"shipping Swift does not use {symbol}")

# The new gate must be part of portable and native release qualification.
require("run_hotfix38_ios26_baseline_harness.py" in verify_sh, "portable release loop executes Hotfix38 iOS 26 baseline audit")
require("run_hotfix38_ios26_baseline_harness.py" in qualification, "native qualification records Hotfix38 iOS 26 baseline audit")
require((ROOT / "VERIFICATION_NOTES_v56_HOTFIX38_IOS26_BASELINE.md").is_file(), "Hotfix38 audit notes are included")

if failed:
    print("HOTFIX 38 IOS26 BASELINE AUDIT: FAIL")
    for item in failed:
        print("FAIL:", item)
    print(f"Checks passed before failure: {len(passed)}")
    sys.exit(1)

print("HOTFIX 38 IOS26 BASELINE AUDIT: PASS")
print(f"Checks passed: {len(passed)}")
for item in passed:
    print("PASS:", item)
