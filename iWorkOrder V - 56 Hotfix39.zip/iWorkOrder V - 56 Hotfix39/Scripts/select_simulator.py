#!/usr/bin/env python3
from __future__ import annotations

import argparse
import json
import re
import subprocess
import sys
from dataclasses import dataclass
from typing import Iterable


@dataclass(frozen=True)
class Candidate:
    runtime: tuple[int, ...]
    runtime_name: str
    name: str
    udid: str


def runtime_version(identifier: str) -> tuple[int, ...]:
    match = re.search(r"iOS-(\d+(?:-\d+)*)$", identifier)
    if not match:
        return ()
    return tuple(int(part) for part in match.group(1).split("-"))


def preferences(family: str) -> list[str]:
    if family == "iphone":
        return [
            "iPhone 17 Pro Max",
            "iPhone 17 Pro",
            "iPhone 17",
            "iPhone 16 Pro Max",
            "iPhone 16 Pro",
            "iPhone",
        ]
    return [
        "iPad Pro 13-inch",
        "iPad Pro 11-inch",
        "iPad Air 13-inch",
        "iPad Air 11-inch",
        "iPad",
    ]


def rank_name(name: str, preferred: Iterable[str]) -> int:
    for index, prefix in enumerate(preferred):
        if name.startswith(prefix):
            return len(list(preferred)) - index
    return 0


def main() -> int:
    parser = argparse.ArgumentParser(description="Select the newest available iOS simulator by device family.")
    parser.add_argument("--family", choices=("iphone", "ipad"), required=True)
    args = parser.parse_args()

    completed = subprocess.run(
        ["xcrun", "simctl", "list", "devices", "available", "-j"],
        check=True,
        capture_output=True,
        text=True,
    )
    payload = json.loads(completed.stdout)
    candidates: list[Candidate] = []

    for runtime_identifier, devices in payload.get("devices", {}).items():
        version = runtime_version(runtime_identifier)
        if not version:
            continue
        for device in devices:
            if not device.get("isAvailable"):
                continue
            name = str(device.get("name", ""))
            matches_family = name.startswith("iPhone") if args.family == "iphone" else name.startswith("iPad")
            if not matches_family:
                continue
            udid = str(device.get("udid", ""))
            if udid:
                candidates.append(Candidate(version, runtime_identifier, name, udid))

    if not candidates:
        print(f"No available {args.family} simulator was found.", file=sys.stderr)
        return 1

    preferred = preferences(args.family)
    candidates.sort(
        key=lambda item: (item.runtime, rank_name(item.name, preferred), item.name),
        reverse=True,
    )
    selected = candidates[0]
    print(
        f"Selected {selected.name} ({selected.runtime_name}) [{selected.udid}]",
        file=sys.stderr,
    )
    print(selected.udid)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
