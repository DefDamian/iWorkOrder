#!/usr/bin/env python3
from pathlib import Path
import json
import re

ROOT = Path(__file__).resolve().parents[1]
APP = ROOT / "iWorkOrder"

checks: list[str] = []
errors: list[str] = []


def require(condition: bool, message: str) -> None:
    (checks if condition else errors).append(message)


def release_source(text: str) -> str:
    """Resolve the simple DEBUG conditionals used by the app sources for a Release build."""
    output: list[str] = []
    stack: list[tuple[bool, bool]] = []  # (parent_include, is_debug_condition)
    include = True

    for line in text.splitlines():
        token = line.strip()
        if token == "#if DEBUG":
            stack.append((include, True))
            include = False
            continue
        if token.startswith("#if "):
            # This harness intentionally only resolves DEBUG gates. Preserve other
            # conditional content as active because it is not a dev/release switch.
            stack.append((include, False))
            continue
        if token == "#else":
            if stack and stack[-1][1]:
                parent, _ = stack[-1]
                include = parent and not include
            continue
        if token == "#endif":
            if stack:
                parent, _ = stack.pop()
                include = parent
            continue
        if include:
            output.append(line)

    return "\n".join(output)


settings_raw = (APP / "CalendarHubSettingsViews.swift").read_text(encoding="utf-8")
store_raw = (APP / "AppStore.swift").read_text(encoding="utf-8")
accessibility_raw = (APP / "AccessibilitySupport.swift").read_text(encoding="utf-8")
root_raw = (APP / "RootView.swift").read_text(encoding="utf-8")
splash_raw = (APP / "SplashScreenView.swift").read_text(encoding="utf-8")
pbx = (ROOT / "iWorkOrder.xcodeproj/project.pbxproj").read_text(encoding="utf-8")

settings = release_source(settings_raw)
store = release_source(store_raw)
accessibility = release_source(accessibility_raw)
release_ui = "\n".join([settings, root_raw, accessibility])
release_core = "\n".join([store, accessibility, release_source(splash_raw)])

# Developer / UI-test hooks must not be present in Release-active source.
for forbidden in [
    "-ui-testing",
    "-ui-testing-onboarding",
    "-ui-testing-seeded",
    "-ui-testing-legal-update",
    "UI Test Superintendent",
    "UI Test Property Management",
    "Seeded UI test record",
    "Seeded for automated UI testing",
]:
    require(forbidden not in release_core, f"Release excludes development test hook: {forbidden}")

# Internal release-health and recovery controls must not be navigable in Release.
for forbidden in [
    'SettingsRow(title: "Maintenance & Recovery"',
    'Toggle("Pause Cloud Sync for Recovery"',
    'Section("Release Health")',
    'Label("Run Maintenance Health Check"',
    'Label("Export Maintenance Report"',
    'Button("Clear Operational History"',
    'Label("Export Diagnostics"',
    'SettingsRow(title: "Support & Diagnostics"',
    'InfoLine(title: "Supported Data Schema"',
]:
    require(forbidden not in release_ui, f"Release UI hides internal/developer surface: {forbidden}")

# Public support remains available, but with user-appropriate wording and actions.
for required in [
    'SettingsRow(title: "Support"',
    'Section("Support Package")',
    'Label("Create Support Package"',
    'Label("Email Support"',
    'InfoLine(title: "Sync Status"',
]:
    require(required in settings, f"Release retains public support surface: {required}")

# Internal-only code is explicitly DEBUG-gated instead of merely hidden at runtime.
require('#if DEBUG\n    private func loadUITestingState()' in store_raw, "UI-test state loader is compile-time DEBUG-only")
require('#if DEBUG\nstruct MaintenanceRecoveryView' in settings_raw, "maintenance/release-health screen is compile-time DEBUG-only")
require('#if DEBUG\n    func setCloudSyncPausedForRecovery' in store_raw, "manual recovery-pause API is compile-time DEBUG-only")
require('#if DEBUG\nenum UITestingConfiguration' in accessibility_raw, "UI-testing configuration type is compile-time DEBUG-only")
require("UITestingConfiguration" not in accessibility, "Release-active accessibility support contains no UI-testing configuration type")

# Release target must not enable development surfaces.
release_target_start = pbx.index('FBE5CC35BA76CB71C31E843C /* Release */')
release_target_end = pbx.index('\n\t\t};', release_target_start)
release_target = pbx[release_target_start:release_target_end]
require('ENABLE_PREVIEWS = NO;' in release_target, "Release target disables Xcode previews")
require('ENABLE_TESTABILITY = NO;' in release_target, "Release target disables @testable access")
require('SWIFT_ACTIVE_COMPILATION_CONDITIONS = DEBUG;' not in release_target, "Release target does not define DEBUG")

# The app bundle resources remain limited to user-facing runtime resources.
resources_match = re.search(r'66F8606E9F0A136E2228EBCB /\* Resources \*/ = \{(.*?)\n\t\t\};', pbx, re.S)
require(resources_match is not None, "app resources build phase is present")
if resources_match:
    resources = resources_match.group(1)
    for forbidden in ["VERIFICATION_NOTES", "Scripts/", "PHASE", "README", "ReleaseEvidence"]:
        require(forbidden not in resources, f"app bundle resources exclude source/verification artifact: {forbidden}")
    for required in ["PrivacyInfo.xcprivacy", "Assets.xcassets", "Localizable.xcstrings"]:
        require(required in resources, f"app bundle retains required runtime resource: {required}")

app_sources_match = re.search(r'E7209FB05162B7572F88D05E /\* Sources \*/ = \{(.*?)\n\t\t\};', pbx, re.S)
require(app_sources_match is not None, "app sources build phase is present")
if app_sources_match:
    app_sources = app_sources_match.group(1)
    require("iWorkOrderTests.swift" not in app_sources, "unit-test source is not compiled into the app target")
    require("iWorkOrderUITests.swift" not in app_sources, "UI-test source is not compiled into the app target")

# Stale developer-facing localization strings must not be shipped as release resources.
catalog = json.loads((APP / "Localizable.xcstrings").read_text(encoding="utf-8"))
strings = catalog.get("strings", {})
for forbidden in [
    "Maintenance & Recovery",
    "Release Health",
    "Support & Diagnostics",
    "Export Diagnostics",
    "Email Support with Diagnostics",
    "Run Maintenance Health Check",
    "Export Maintenance Report",
    "Clear Operational History",
    "Recovery pause blocks ordinary CloudKit upload, download, and manual re-sync while keeping local work orders editable. Pending verified backup replacement or cloud deletion transactions are still allowed to finish.",
]:
    require(forbidden not in strings, f"release string catalog excludes internal label: {forbidden}")

for item in checks:
    print(f"PASS: {item}")
if errors:
    for item in errors:
        print(f"FAIL: {item}")
    raise SystemExit(1)
print(f"PUBLIC RELEASE HARNESS: PASS ({len(checks)} checks)")
