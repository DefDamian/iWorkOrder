#!/bin/bash
set -euo pipefail

ROOT="$(cd "$(dirname "$0")/.." && pwd)"
cd "$ROOT"

PROJECT="iWorkOrder.xcodeproj"
SCHEME="iWorkOrder"
BUNDLE_ID="com.damiancedeno.SedgwickWorkOrders"
ICLOUD_CONTAINER="iCloud.com.damiancedeno.SedgwickWorkOrders"
MARKETING_VERSION="1.0"
BUILD_NUMBER="56"
MODE="${PHASE56_MODE:-ci}"
FINAL_GATE="${PHASE56_FINAL_GATE:-0}"
ARTIFACTS_DIR="${PHASE56_ARTIFACTS_DIR:-$ROOT/Artifacts/Phase56}"
DERIVED_DATA="${PHASE56_DERIVED_DATA:-$ROOT/build/Phase56DerivedData}"
ARCHIVE_PATH="$ARTIFACTS_DIR/iWorkOrder.xcarchive"
EXPORT_PATH="$ARTIFACTS_DIR/TestFlightExport"
EVIDENCE_FILE="$ARTIFACTS_DIR/phase56_evidence.json"
MANUAL_EVIDENCE="${PHASE56_MANUAL_EVIDENCE:-$ROOT/ReleaseEvidence/phase56_evidence.template.json}"
IPHONE_DEVICE_ID="${PHASE56_IPHONE_DEVICE_ID:-}"
IPAD_DEVICE_ID="${PHASE56_IPAD_DEVICE_ID:-}"
REQUIRED_XCODE_MAJOR="${PHASE56_REQUIRED_XCODE_MAJOR:-27}"
REQUIRED_XCODE_BUILD="${PHASE56_REQUIRED_XCODE_BUILD:-27A266a}"
REQUIRED_IOS_SDK_MAJOR="${PHASE56_REQUIRED_IOS_SDK_MAJOR:-27}"
ALLOW_XCODE26_COMPATIBILITY="${PHASE56_ALLOW_XCODE26_COMPATIBILITY:-0}"

if [[ "$(uname -s)" != "Darwin" ]]; then
  echo "Phase 56 Xcode qualification requires macOS." >&2
  exit 2
fi
if [[ "$MODE" != "ci" && "$MODE" != "signed" ]]; then
  echo "PHASE56_MODE must be ci or signed." >&2
  exit 1
fi
if [[ "$FINAL_GATE" == "1" && "$MODE" != "signed" ]]; then
  echo "PHASE56_FINAL_GATE=1 requires PHASE56_MODE=signed." >&2
  exit 1
fi
if [[ "$MODE" == "signed" && -z "${APPLE_TEAM_ID:-}" ]]; then
  echo "APPLE_TEAM_ID is required for PHASE56_MODE=signed." >&2
  exit 1
fi

python3 Scripts/prepare_qualification_paths.py \
  --root "$ROOT" --artifacts "$ARTIFACTS_DIR" \
  --derived-data "$DERIVED_DATA" --evidence "$MANUAL_EVIDENCE"

select_xcode() {
  if [[ -n "${DEVELOPER_DIR:-}" && -x "$DEVELOPER_DIR/usr/bin/xcodebuild" ]]; then return; fi
  local selected
  selected="$(REQUIRED_XCODE_MAJOR="$REQUIRED_XCODE_MAJOR" REQUIRED_XCODE_BUILD="$REQUIRED_XCODE_BUILD" ALLOW_XCODE26_COMPATIBILITY="$ALLOW_XCODE26_COMPATIBILITY" python3 - <<'PY'
from pathlib import Path
import os
import plistlib
import subprocess

required_major = int(os.environ['REQUIRED_XCODE_MAJOR'])
required_build = os.environ['REQUIRED_XCODE_BUILD']
allow_compatibility = os.environ['ALLOW_XCODE26_COMPATIBILITY'] == '1'
candidates = []
for app in Path('/Applications').glob('Xcode*.app'):
    plist = app / 'Contents' / 'Info.plist'
    xcodebuild = app / 'Contents' / 'Developer' / 'usr' / 'bin' / 'xcodebuild'
    if not plist.is_file() or not xcodebuild.is_file():
        continue
    try:
        version = str(plistlib.loads(plist.read_bytes()).get('CFBundleShortVersionString', ''))
        numeric = version.split(' ')[0]
        parts = tuple(int(part) for part in numeric.split('.') if part.isdigit())
        version_output = subprocess.check_output([str(xcodebuild), '-version'], text=True, stderr=subprocess.DEVNULL)
        build = next((line.split()[-1] for line in version_output.splitlines() if line.startswith('Build version ')), '')
    except Exception:
        continue
    if not parts:
        continue
    major = parts[0]
    exact_stable = major == required_major and build == required_build
    if exact_stable or (allow_compatibility and major >= 26):
        candidates.append((1 if exact_stable else 0, parts, app.name, app))
if candidates:
    print(max(candidates)[3] / 'Contents' / 'Developer')
PY
)"
  if [[ -n "$selected" ]]; then export DEVELOPER_DIR="$selected"; fi
}
select_xcode

{
  echo "Phase 56 environment"
  echo "Date: $(date -u +%Y-%m-%dT%H:%M:%SZ)"
  echo "Mode: $MODE"
  echo "Final gate requested: $FINAL_GATE"
  echo "Developer directory: ${DEVELOPER_DIR:-$(xcode-select -p)}"
  xcodebuild -version
  echo "iOS SDK: $(xcrun --sdk iphoneos --show-sdk-version)"
  echo "Simulator SDK: $(xcrun --sdk iphonesimulator --show-sdk-version)"
  sw_vers
  system_profiler SPHardwareDataType 2>/dev/null || true
} | tee "$ARTIFACTS_DIR/environment.txt"

XCODE_VERSION="$(xcodebuild -version | awk '/Xcode/{print $2; exit}')"
XCODE_MAJOR="${XCODE_VERSION%%.*}"
XCODE_BUILD="$(xcodebuild -version | awk '/Build version/{print $3; exit}')"
SDK_VERSION="$(xcrun --sdk iphoneos --show-sdk-version)"
SDK_MAJOR="${SDK_VERSION%%.*}"
QUALIFICATION_SCOPE="CURRENT STABLE XCODE 27 / IOS 27"

if [[ "$ALLOW_XCODE26_COMPATIBILITY" == "1" ]]; then
  QUALIFICATION_SCOPE="HOSTED XCODE 26+ COMPATIBILITY ONLY"
  [[ -n "$XCODE_MAJOR" && "$XCODE_MAJOR" -ge 26 ]] || { echo "Hosted compatibility requires Xcode 26 or later." >&2; exit 1; }
  [[ -n "$SDK_MAJOR" && "$SDK_MAJOR" -ge 26 ]] || { echo "Hosted compatibility requires iOS SDK 26 or later." >&2; exit 1; }
else
  [[ "$XCODE_MAJOR" == "$REQUIRED_XCODE_MAJOR" ]] || {
    echo "Stable release qualification requires Xcode major $REQUIRED_XCODE_MAJOR. Found: $XCODE_VERSION ($XCODE_BUILD)." >&2
    exit 1
  }
  [[ "$XCODE_BUILD" == "$REQUIRED_XCODE_BUILD" ]] || {
    echo "Stable release qualification requires Xcode build $REQUIRED_XCODE_BUILD. Found: $XCODE_BUILD." >&2
    exit 1
  }
  [[ "$SDK_MAJOR" == "$REQUIRED_IOS_SDK_MAJOR" ]] || {
    echo "Stable release qualification requires iOS SDK major $REQUIRED_IOS_SDK_MAJOR. Found: $SDK_VERSION." >&2
    exit 1
  }
fi

./Scripts/verify_release.sh | tee "$ARTIFACTS_DIR/static-verification.txt"
./Scripts/run_reliability_harness.py | tee "$ARTIFACTS_DIR/runtime-reliability.txt"
./Scripts/run_defect_harness.py | tee "$ARTIFACTS_DIR/hotfix6-defect-audit.txt"
./Scripts/run_transactional_harness.py | tee "$ARTIFACTS_DIR/hotfix7-transactional-integrity.txt"
./Scripts/run_core_stability_harness.py | tee "$ARTIFACTS_DIR/hotfix12-core-stability.txt"
./Scripts/run_public_release_harness.py | tee "$ARTIFACTS_DIR/public-release-surface.txt"
./Scripts/run_public_beta_harness.py | tee "$ARTIFACTS_DIR/hotfix18-public-beta-qualification.txt"
./Scripts/run_release_candidate_harness.py | tee "$ARTIFACTS_DIR/hotfix19-release-candidate-hardening.txt"
./Scripts/run_final_rc_harness.py | tee "$ARTIFACTS_DIR/hotfix20-final-release-candidate.txt"
./Scripts/run_hotfix21_real_world_beta_harness.py | tee "$ARTIFACTS_DIR/hotfix21-real-world-beta.txt"
./Scripts/run_hotfix23_xcode_runtime_harness.py | tee "$ARTIFACTS_DIR/hotfix23-xcode-runtime-cleanup.txt"
./Scripts/run_hotfix24_first_launch_recovery_harness.py | tee "$ARTIFACTS_DIR/hotfix24-first-launch-recovery.txt"
./Scripts/run_hotfix25_permissions_legal_harness.py | tee "$ARTIFACTS_DIR/hotfix25-permissions-legal.txt"
./Scripts/run_hotfix26_work_order_badge_layout_harness.py | tee "$ARTIFACTS_DIR/hotfix26-work-order-badge-layout.txt"
./Scripts/run_hotfix27_photo_delete_harness.py | tee "$ARTIFACTS_DIR/hotfix27-photo-delete.txt"
./Scripts/run_hotfix28_full_bug_loop_harness.py | tee "$ARTIFACTS_DIR/hotfix28-full-bug-loop.txt"
./Scripts/run_hotfix29_theme_switch_harness.py | tee "$ARTIFACTS_DIR/hotfix29-live-theme-switching.txt"
./Scripts/run_hotfix30_launch_continuity_harness.py | tee "$ARTIFACTS_DIR/hotfix30-launch-continuity.txt"
./Scripts/run_hotfix31_privacy_blur_harness.py | tee "$ARTIFACTS_DIR/hotfix31-frosted-privacy-shield.txt"
./Scripts/run_hotfix32_full_bug_loop_harness.py | tee "$ARTIFACTS_DIR/hotfix32-full-bug-loop.txt"
./Scripts/run_hotfix33_theme_identity_harness.py | tee "$ARTIFACTS_DIR/hotfix33-theme-identity.txt"
./Scripts/run_hotfix34_theme3_rebuild_harness.py | tee "$ARTIFACTS_DIR/hotfix34-theme3-rebuild.txt"
./Scripts/run_hotfix35_onboarding_theme_scope_harness.py | tee "$ARTIFACTS_DIR/hotfix35-onboarding-theme-scope.txt"
./Scripts/run_hotfix36_swiftui_semantic_lint_harness.py | tee "$ARTIFACTS_DIR/hotfix36-swiftui-semantic-lint.txt"
./Scripts/run_hotfix37_xcode27_swift64_harness.py | tee "$ARTIFACTS_DIR/hotfix37-xcode27-swift64-audit.txt"
./Scripts/run_hotfix38_ios26_baseline_harness.py | tee "$ARTIFACTS_DIR/hotfix38-ios26-baseline-audit.txt"
./Scripts/run_hotfix39_fullscreen_deprecation_harness.py | tee "$ARTIFACTS_DIR/hotfix39-fullscreen-deprecation-audit.txt"
xcodebuild -project "$PROJECT" -list -json > "$ARTIFACTS_DIR/project-list.json"
xcodebuild -project "$PROJECT" -scheme "$SCHEME" -configuration Debug -showBuildSettings > "$ARTIFACTS_DIR/debug-build-settings.txt"
xcodebuild -project "$PROJECT" -scheme "$SCHEME" -configuration Release -showBuildSettings > "$ARTIFACTS_DIR/release-build-settings.txt"
xcrun simctl list --json > "$ARTIFACTS_DIR/simulators.json"
xcrun devicectl list devices --json-output "$ARTIFACTS_DIR/connected-devices.json" >/dev/null 2>&1 || true

IPHONE_SIM_ID="$(./Scripts/select_simulator.py --family iphone)"
IPAD_SIM_ID="$(./Scripts/select_simulator.py --family ipad)"
COMMON=(
  -project "$PROJECT" -scheme "$SCHEME" -derivedDataPath "$DERIVED_DATA"
  SWIFT_TREAT_WARNINGS_AS_ERRORS=YES GCC_TREAT_WARNINGS_AS_ERRORS=YES
  CLANG_TREAT_WARNINGS_AS_ERRORS=YES COMPILER_INDEX_STORE_ENABLE=NO
)

xcodebuild "${COMMON[@]}" -configuration Debug \
  -destination "platform=iOS Simulator,id=$IPHONE_SIM_ID" \
  -resultBundlePath "$ARTIFACTS_DIR/iPhoneTests.xcresult" clean test \
  | tee "$ARTIFACTS_DIR/iphone-tests.log"

xcodebuild "${COMMON[@]}" -configuration Debug \
  -destination "platform=iOS Simulator,id=$IPAD_SIM_ID" \
  -resultBundlePath "$ARTIFACTS_DIR/iPadTests.xcresult" test \
  | tee "$ARTIFACTS_DIR/ipad-tests.log"

xcodebuild "${COMMON[@]}" -configuration Debug \
  -destination "platform=iOS Simulator,id=$IPHONE_SIM_ID" \
  -only-testing:iWorkOrderTests -test-iterations 5 \
  -resultBundlePath "$ARTIFACTS_DIR/StabilityTests.xcresult" test \
  | tee "$ARTIFACTS_DIR/stability-tests.log"

xcodebuild "${COMMON[@]}" -configuration Debug \
  -destination "platform=iOS Simulator,id=$IPHONE_SIM_ID" \
  -only-testing:iWorkOrderUITests/iWorkOrderUITests/testMaintenanceRecoveryCanRunHealthCheck \
  -resultBundlePath "$ARTIFACTS_DIR/MaintenanceRecoveryUI.xcresult" test \
  | tee "$ARTIFACTS_DIR/maintenance-recovery-ui.log"

xcodebuild "${COMMON[@]}" -configuration Debug \
  -destination "platform=iOS Simulator,id=$IPHONE_SIM_ID" \
  -only-testing:iWorkOrderUITests/iWorkOrderUITests/testRecoveryCloudPauseCanBeEnabledAndDisabled \
  -resultBundlePath "$ARTIFACTS_DIR/RecoveryPauseUI.xcresult" test \
  | tee "$ARTIFACTS_DIR/recovery-pause-ui.log"

xcodebuild "${COMMON[@]}" -configuration Debug \
  -destination "platform=iOS Simulator,id=$IPHONE_SIM_ID" \
  -only-testing:iWorkOrderUITests/iWorkOrderUITests/testCaptureSubmissionScreenshots \
  -resultBundlePath "$ARTIFACTS_DIR/iPhoneSubmissionScreenshots.xcresult" test \
  | tee "$ARTIFACTS_DIR/iphone-screenshots.log"

xcodebuild "${COMMON[@]}" -configuration Debug \
  -destination "platform=iOS Simulator,id=$IPAD_SIM_ID" \
  -only-testing:iWorkOrderUITests/iWorkOrderUITests/testCaptureSubmissionScreenshots \
  -resultBundlePath "$ARTIFACTS_DIR/iPadSubmissionScreenshots.xcresult" test \
  | tee "$ARTIFACTS_DIR/ipad-screenshots.log"

xcodebuild "${COMMON[@]}" -configuration Debug \
  -destination "platform=iOS Simulator,id=$IPHONE_SIM_ID" \
  -resultBundlePath "$ARTIFACTS_DIR/Analyze.xcresult" analyze \
  | tee "$ARTIFACTS_DIR/analyze.log"

if [[ -n "$IPHONE_DEVICE_ID" ]]; then
  xcodebuild "${COMMON[@]}" -configuration Debug \
    -destination "platform=iOS,id=$IPHONE_DEVICE_ID" \
    -only-testing:iWorkOrderTests \
    -resultBundlePath "$ARTIFACTS_DIR/PhysicalIPhoneTests.xcresult" test \
    | tee "$ARTIFACTS_DIR/physical-iphone-tests.log"
fi
if [[ -n "$IPAD_DEVICE_ID" ]]; then
  xcodebuild "${COMMON[@]}" -configuration Debug \
    -destination "platform=iOS,id=$IPAD_DEVICE_ID" \
    -only-testing:iWorkOrderTests \
    -resultBundlePath "$ARTIFACTS_DIR/PhysicalIPadTests.xcresult" test \
    | tee "$ARTIFACTS_DIR/physical-ipad-tests.log"
fi

ARCHIVE_ARGS=(
  -project "$PROJECT" -scheme "$SCHEME" -configuration Release
  -destination "generic/platform=iOS" -archivePath "$ARCHIVE_PATH"
  -derivedDataPath "$DERIVED_DATA"
  SWIFT_TREAT_WARNINGS_AS_ERRORS=YES GCC_TREAT_WARNINGS_AS_ERRORS=YES
  CLANG_TREAT_WARNINGS_AS_ERRORS=YES COMPILER_INDEX_STORE_ENABLE=NO
)
if [[ "$MODE" == "signed" ]]; then
  ARCHIVE_ARGS+=(DEVELOPMENT_TEAM="$APPLE_TEAM_ID" CODE_SIGN_STYLE=Automatic CODE_SIGNING_ALLOWED=YES CODE_SIGNING_REQUIRED=YES -allowProvisioningUpdates)
else
  ARCHIVE_ARGS+=(CODE_SIGNING_ALLOWED=NO CODE_SIGNING_REQUIRED=NO)
fi
xcodebuild "${ARCHIVE_ARGS[@]}" archive | tee "$ARTIFACTS_DIR/archive.log"

./Scripts/validate_xcode_archive.py "$ARCHIVE_PATH" \
  --bundle-id "$BUNDLE_ID" --version "$MARKETING_VERSION" --build "$BUILD_NUMBER" \
  --icloud-container "$ICLOUD_CONTAINER" | tee "$ARTIFACTS_DIR/archive-validation.txt"

if [[ "$MODE" == "signed" ]]; then
  codesign --verify --deep --strict --verbose=2 "$ARCHIVE_PATH/Products/Applications/iWorkOrder.app" 2>&1 \
    | tee "$ARTIFACTS_DIR/codesign-verification.txt"
  codesign -d --entitlements :- "$ARCHIVE_PATH/Products/Applications/iWorkOrder.app" \
    > "$ARTIFACTS_DIR/signed-entitlements.plist" 2> "$ARTIFACTS_DIR/codesign-details.txt"

  cat > "$ARTIFACTS_DIR/ExportOptions.plist" <<EOF
<?xml version="1.0" encoding="UTF-8"?>
<!DOCTYPE plist PUBLIC "-//Apple//DTD PLIST 1.0//EN" "http://www.apple.com/DTDs/PropertyList-1.0.dtd">
<plist version="1.0"><dict>
<key>method</key><string>app-store-connect</string>
<key>destination</key><string>export</string>
<key>signingStyle</key><string>automatic</string>
<key>teamID</key><string>$APPLE_TEAM_ID</string>
<key>uploadSymbols</key><true/>
<key>manageAppVersionAndBuildNumber</key><false/>
</dict></plist>
EOF
  xcodebuild -exportArchive -archivePath "$ARCHIVE_PATH" -exportPath "$EXPORT_PATH" \
    -exportOptionsPlist "$ARTIFACTS_DIR/ExportOptions.plist" -allowProvisioningUpdates \
    | tee "$ARTIFACTS_DIR/export.log"
  IPA_PATH="$(find "$EXPORT_PATH" -maxdepth 1 -name '*.ipa' -print -quit)"
  [[ -n "$IPA_PATH" ]] || { echo "Signed export did not produce an IPA." >&2; exit 1; }
  ./Scripts/validate_testflight_ipa.py "$IPA_PATH" --bundle-id "$BUNDLE_ID" \
    --version "$MARKETING_VERSION" --build "$BUILD_NUMBER" \
    | tee "$ARTIFACTS_DIR/ipa-validation.txt"
fi

python3 - "$EVIDENCE_FILE" "$MODE" "$IPHONE_DEVICE_ID" "$IPAD_DEVICE_ID" <<'PY'
import json, sys
from datetime import datetime, timezone
from pathlib import Path
path=Path(sys.argv[1]); mode=sys.argv[2]; iphone=sys.argv[3]; ipad=sys.argv[4]
data=json.loads(path.read_text())
data['qualification_date']=datetime.now(timezone.utc).isoformat()
g=data['gates']
def mark(name, evidence):
    g[name]['status']='pass'; g[name]['evidence']=evidence
mark('cross_platform_verification',['Artifacts/Phase56/static-verification.txt'])
mark('iphone_simulator_tests',['Artifacts/Phase56/iPhoneTests.xcresult','Artifacts/Phase56/iphone-tests.log'])
mark('ipad_simulator_tests',['Artifacts/Phase56/iPadTests.xcresult','Artifacts/Phase56/ipad-tests.log'])
mark('repeated_unit_tests',['Artifacts/Phase56/StabilityTests.xcresult','Artifacts/Phase56/stability-tests.log'])
mark('static_analysis',['Artifacts/Phase56/Analyze.xcresult','Artifacts/Phase56/analyze.log'])
if mode=='signed':
    mark('signed_archive',['Artifacts/Phase56/iWorkOrder.xcarchive','Artifacts/Phase56/archive.log'])
    mark('archive_and_ipa_validation',['Artifacts/Phase56/archive-validation.txt','Artifacts/Phase56/ipa-validation.txt'])
    mark('code_signing_and_entitlements',['Artifacts/Phase56/codesign-verification.txt','Artifacts/Phase56/signed-entitlements.plist'])
if iphone:
    g['physical_iphone_matrix']['notes']='Automated unit-test evidence captured; manual device matrix remains required.'
    g['physical_iphone_matrix']['evidence']=['Artifacts/Phase56/PhysicalIPhoneTests.xcresult','Artifacts/Phase56/physical-iphone-tests.log']
if ipad:
    g['physical_ipad_matrix']['notes']='Automated unit-test evidence captured; manual device matrix remains required.'
    g['physical_ipad_matrix']['evidence']=['Artifacts/Phase56/PhysicalIPadTests.xcresult','Artifacts/Phase56/physical-ipad-tests.log']
path.write_text(json.dumps(data,indent=2,sort_keys=True)+'\n')
PY

./Scripts/validate_phase56_evidence.py "$EVIDENCE_FILE" --root "$ROOT"

if [[ "$FINAL_GATE" == "1" ]]; then
  ./Scripts/validate_app_store_metadata.py --require-screenshots | tee "$ARTIFACTS_DIR/final-metadata-validation.txt"
  ./Scripts/validate_phase56_evidence.py "$EVIDENCE_FILE" --root "$ROOT" --require-complete \
    | tee "$ARTIFACTS_DIR/final-evidence-validation.txt"
  FINAL_STATUS="PASS"
else
  FINAL_STATUS="PENDING MANUAL AND APPLE-SERVICE EVIDENCE"
fi

cat > "$ARTIFACTS_DIR/QUALIFICATION_STATUS.txt" <<EOF
PHASE 56 AUTOMATED QUALIFICATION: PASS
Final release qualification: $FINAL_STATUS
Mode: $MODE
Qualification scope: $QUALIFICATION_SCOPE
Xcode version: $XCODE_VERSION
Xcode build: $XCODE_BUILD
iOS SDK version: $SDK_VERSION
iPhone simulator: $IPHONE_SIM_ID
iPad simulator: $IPAD_SIM_ID
Physical iPhone automated test: ${IPHONE_DEVICE_ID:-Not run}
Physical iPad automated test: ${IPAD_DEVICE_ID:-Not run}
Archive: $ARCHIVE_PATH
TestFlight export: $([[ "$MODE" == "signed" ]] && echo "$EXPORT_PATH" || echo "Not created in CI mode")
Upload: Not performed automatically
EOF
cat "$ARTIFACTS_DIR/QUALIFICATION_STATUS.txt"
./Scripts/index_phase56_artifacts.py "$ARTIFACTS_DIR"
