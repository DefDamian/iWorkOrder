#!/usr/bin/env python3
from pathlib import Path
import re
import sys

ROOT = Path(__file__).resolve().parents[1]
APP = ROOT / "iWorkOrder"
onboarding_path = APP / "OnboardingView.swift"
onboarding = onboarding_path.read_text(encoding="utf-8")
verify_sh = (ROOT / "Scripts/verify_release.sh").read_text(encoding="utf-8")
phase56 = (ROOT / "Scripts/phase56_xcode_qualification.sh").read_text(encoding="utf-8")

passed: list[str] = []
failed: list[str] = []


def require(condition: bool, message: str) -> None:
    (passed if condition else failed).append(message)


def top_level_struct_ranges(source: str):
    lines = source.splitlines()
    starts: list[tuple[int, str]] = []
    struct_re = re.compile(r"^\s*(?:@\w+(?:\([^)]*\))?\s*)*struct\s+(\w+)")
    for index, line in enumerate(lines):
        match = struct_re.search(line)
        if match:
            starts.append((index, match.group(1)))
    for pos, (start, name) in enumerate(starts):
        end = starts[pos + 1][0] if pos + 1 < len(starts) else len(lines)
        yield name, start + 1, end, "\n".join(lines[start:end])


onboarding_blocks = [item for item in top_level_struct_ranges(onboarding) if item[0] == "OnboardingView"]
require(len(onboarding_blocks) == 1, "OnboardingView is uniquely located for scope validation")
if onboarding_blocks:
    _, _, _, block = onboarding_blocks[0]
    require('@AppStorage(AppTheme.storageKey) private var selectedThemeRaw' in block, "OnboardingView observes the persisted visual theme")
    require('private var selectedTheme: VisualTheme { VisualTheme(rawValue: selectedThemeRaw) ?? .defaultTheme }' in block, "OnboardingView defines selectedTheme in its own lexical scope")
    require('AppTheme.horizontalPadding(for: selectedTheme)' in block, "OnboardingView adaptive padding resolves through its local theme value")

scope_failures: list[str] = []
for path in sorted(APP.glob("*.swift")):
    source = path.read_text(encoding="utf-8")
    for name, start, end, block in top_level_struct_ranges(source):
        if not re.search(r"\bselectedTheme\b", block):
            continue
        declared = bool(
            re.search(r"\b(?:private\s+)?var\s+selectedTheme\s*:", block)
            or re.search(r"\b(?:private\s+)?let\s+selectedTheme\b", block)
            or re.search(r"@\w+[^\n]*\bselectedTheme\b", block)
        )
        if not declared:
            scope_failures.append(f"{path.name}:{start}-{end}:{name}")
require(not scope_failures, "every shipping Swift struct that references selectedTheme declares it in local scope")

require('run_hotfix35_onboarding_theme_scope_harness.py' in verify_sh, "cross-platform verification executes the Hotfix35 scope harness")
require('run_hotfix35_onboarding_theme_scope_harness.py' in phase56, "Xcode qualification executes the Hotfix35 scope harness")
require((ROOT / 'VERIFICATION_NOTES_v56_HOTFIX35_ONBOARDING_THEME_SCOPE.md').is_file(), "Hotfix35 verification notes are included")

if failed:
    print("HOTFIX 35 ONBOARDING THEME SCOPE: FAIL")
    for item in failed:
        print("FAIL:", item)
    if scope_failures:
        print("SCOPE FAILURES:", ", ".join(scope_failures))
    print(f"Checks passed before failure: {len(passed)}")
    sys.exit(1)

print("HOTFIX 35 ONBOARDING THEME SCOPE: PASS")
print(f"Checks passed: {len(passed)}")
for item in passed:
    print("PASS:", item)
