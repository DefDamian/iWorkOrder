#!/usr/bin/env python3
from pathlib import Path
import re

ROOT = Path(__file__).resolve().parents[1]
APP = ROOT / "iWorkOrder"

models = (APP / "Models.swift").read_text(encoding="utf-8")
store = (APP / "AppStore.swift").read_text(encoding="utf-8")
services = (APP / "Services.swift").read_text(encoding="utf-8")
settings = (APP / "CalendarHubSettingsViews.swift").read_text(encoding="utf-8")
onboarding = (APP / "OnboardingView.swift").read_text(encoding="utf-8")
views = (APP / "WorkOrderViews.swift").read_text(encoding="utf-8")
app_lifecycle = (APP / "iWorkOrderApp.swift").read_text(encoding="utf-8")
backup = (APP / "BackupArchiveService.swift").read_text(encoding="utf-8")
cloud = (APP / "CloudSyncService.swift").read_text(encoding="utf-8")
maintenance = (APP / "MaintenanceService.swift").read_text(encoding="utf-8")
unit_tests = (ROOT / "iWorkOrderTests/iWorkOrderTests.swift").read_text(encoding="utf-8")
ui_tests = (ROOT / "iWorkOrderUITests/iWorkOrderUITests.swift").read_text(encoding="utf-8")
legal = (APP / "LegalContent.swift").read_text(encoding="utf-8")
root_view = (APP / "RootView.swift").read_text(encoding="utf-8")
accessibility = (APP / "AccessibilitySupport.swift").read_text(encoding="utf-8")
info_plist = (APP / "Info.plist").read_text(encoding="utf-8")
logic_harness = (ROOT / "Scripts/run_logic_harness.py").read_text(encoding="utf-8")
pbx = (ROOT / "iWorkOrder.xcodeproj/project.pbxproj").read_text(encoding="utf-8")
gitignore = (ROOT / ".gitignore").read_text(encoding="utf-8")

checks: list[str] = []
errors: list[str] = []


def require(condition: bool, message: str) -> None:
    (checks if condition else errors).append(message)


def block(source: str, start_marker: str, end_marker: str) -> str:
    start = source.index(start_marker)
    end = source.index(end_marker, start)
    return source[start:end]


category_block = block(models, "static func identityKey", "static func reordered")
latest_date_block = block(services, "private static func latestDate", "private static func mergeByID")
filename_policy_block = block(services, "enum AttachmentFilenamePolicy", "enum DeviceIdentity")
image_storage_block = block(services, "enum ImageStorageService", "enum FlashlightService")
signature_storage_block = block(services, "enum SignatureStorageService", "enum PDFExportService")

require('Locale(identifier: "en_US_POSIX")' in category_block, "category identity uses a deterministic POSIX locale")
require("Locale.current" not in category_block, "category identity does not depend on the device locale")
require(".diacriticInsensitive" in category_block and ".widthInsensitive" in category_block, "category identity normalizes accents and Unicode width")
require("WorkOrderCategory.identityKey(value)" in store, "category state uses the shared canonical identity")
require("pendingDeleteCategories" in settings and "pendingDeleteOffsets" not in settings, "category confirmation retains selected category identities instead of row indexes")
require("func deleteCategories(_ categoriesToDelete: [WorkOrderCategory])" in store, "category deletion supports identity-based confirmation")
require("store.deleteCategories(pendingDeleteCategories)" in settings, "Category Manager deletes the originally selected categories")
require("categoryNamesEqual($0.managedCategory.rawValue, category.rawValue)" in store, "category usage counts use canonical identity")
require(services.count("WorkOrderCategory.identityKey(entry.managedCategory.rawValue)") >= 1, "core work-order filtering uses canonical category identity")
require(views.count("WorkOrderCategory.identityKey(entry.managedCategory.rawValue)") >= 1, "alternate dashboard filtering uses canonical category identity")
photo_import_block = block(views, "private func loadPhoto", "struct WorkOrderDetailView")
require(photo_import_block.count("Task.isCancelled") >= 3, "asynchronous photo import checks cancellation before and after protected-storage writes")
require("ImageStorageService.delete(stored)" in photo_import_block, "a canceled photo import removes any file created after draft cleanup")

for token in ['filename != "."', 'filename != ".."', 'filename.utf8.count <= 255', '.controlCharacters', '!filename.contains("/")', '!filename.contains("\\\\")']:
    require(token in filename_policy_block, f"attachment filename policy includes guard: {token}")
require("safeURL(forFilename" in image_storage_block and "guard let url = safeURL" in image_storage_block, "image loading and deletion reject unsafe persisted filenames")
require("safeURL(forFilename" in signature_storage_block and "guard let filename, let url = safeURL" in signature_storage_block, "signature loading and deletion reject unsafe persisted filenames")
require("AttachmentFilenamePolicy.isSafe(filename)" in backup, "backup import/export shares the attachment filename policy")
require("AttachmentFilenamePolicy.isSafe(filename)" in cloud, "CloudKit attachment sync shares the attachment filename policy")
require("order.entries.map(\\.createdAt).max()" in latest_date_block, "conflict resolution considers revision timestamps")
require("scheduleCloudSync(currentSnapshot(incrementSaveRevision: true))" not in store, "post-resync cloud upload does not advertise an uncommitted local save revision")
require("recoveredPersistedSnapshot && onboardingPersistence.hasCompletedOnboarding" in store, "stale cross-install onboarding flags cannot bypass setup without recovered app data")
require("$store.profile.notificationsEnabled" not in settings, "notification settings do not use a reentrant direct profile binding")
require("updateNotificationsEnabled" in settings and "updateEmergencyNotificationsEnabled" in settings, "notification settings use explicit transactional setters")
require("$store.profile.notificationsEnabled" not in onboarding and "updateNotificationPreference" in onboarding, "onboarding notification permission uses an explicit transactional setter")
require("save(migrated, rotatePrimaryIntoFallback: false)" in services, "fallback recovery rebuilds primary storage without overwriting the known-good fallback")
require("rotatePrimaryIntoFallback: !recoveringFromFallback" in services, "fallback schema migration preserves the known-good fallback copy")
rotation_block = block(services, "private func rotatePrimarySnapshotIntoFallback", "func localDataSizeText")
require("copyItem(at: url, to: stagedBackup)" in rotation_block and "replaceItemAt(backupURL, withItemAt: stagedBackup)" in rotation_block, "normal saves stage the previous primary before replacing the fallback")
require("removeItem(at: backupURL)" not in rotation_block, "fallback rotation never deletes the prior fallback before a replacement copy is ready")
quarantine_block = block(services, "private func quarantineUnreadablePrimary", "static func currentSaveRevision")
require("removeItem(at: url)" not in quarantine_block, "failed quarantine never deletes the only unreadable primary copy")

# Hotfix 12 loop: conflict freshness, onboarding upload gating, recovery metadata, and attachment integrity.
storage_save_block = block(services, "func save(_ snapshot: AppSnapshot", "private func rotatePrimarySnapshotIntoFallback")
require("snapshot.snapshotSavedAt = Date()" not in storage_save_block, "storage transport does not invent a content freshness timestamp")
require("snapshotSavedAt: incrementSaveRevision ? Date() : contentModifiedAt" in store, "snapshot freshness advances only for committed local mutations")
require("merged.snapshotSavedAt = syncedAt" not in cloud and "replacement.snapshotSavedAt = syncedAt" not in cloud, "CloudKit transport time does not overwrite content freshness")
require("StorageService.commitSaveRevision(localSnapshot?.saveRevision ?? 0)" in store, "launch reconciles the monotonic save counter from the persisted snapshot")
require("guard isOnboardingComplete else" in store and "bootstrapCloudDownloadForOnboarding" in store, "incomplete onboarding cannot upload partial/default profile data")
require("downloadFromCloud()" in block(store, "private func bootstrapCloudDownloadForOnboarding", "private func scheduleCloudSync"), "pre-onboarding CloudKit recovery is read-only download")
require("persistLifecycleCheckpoint()" in app_lifecycle and "case .inactive:\n                        RuntimeReliabilityService.transition(to: .inactive)\n                        store.save()" not in app_lifecycle, "lifecycle transitions do not create false content revisions")
require("profileConfigurationUpdatedAt" in store and "profileConfigurationUpdatedAt" in services, "profile configuration has independent cloud conflict freshness")
require("mergeUnitNames" in services and 'Locale(identifier: "en_US_POSIX")' in block(services, "private static func mergeUnitNames", "private static func mergeByID"), "building-unit merge is deterministic across device locales")
require("store.categorySelection(for: entry.managedCategory)" in views and "store.containsManagedCategory(entry.managedCategory)" in views, "work-order category picker uses canonical managed-category identity")
require("SignatureStorageService.isReadableImage(filename: signatureReference)" in store and "return AttachmentContentPolicy.isReadableImage(at: url)" in services, "signed-record integrity verifies readable signature content without full UI image decoding")
require(".completeFileProtectionUntilFirstUserAuthentication" in image_storage_block and ".completeFileProtectionUntilFirstUserAuthentication" in signature_storage_block, "photos and signatures use explicit Data Protection on write")
require("originalContentModifiedAt" in store and "contentModifiedAt = originalContentModifiedAt" in store, "failed backup restore rolls freshness metadata back with app data")
require("let matches = tenants.filter { unitIdentityKey($0.unit) == key }" in store and "guard matches.count == 1 else { return nil }" in store, "ambiguous duplicate unit contacts cannot silently grant automatic entry permission")
require("enum AttachmentContentPolicy" in services and "isReadableImageData" in services and "isReadableImage(at" in services, "shared attachment content policy verifies decodable image bytes")
require("invalidAttachmentContent" in backup and backup.count("AttachmentContentPolicy.isReadableImage(at:") >= 3, "backup creation, import, and install reject unreadable attachment payloads")
require(cloud.count("AttachmentContentPolicy.isReadableImageData(data)") >= 2, "CloudKit upload and download reject unreadable attachment payloads")
restore_commit_block = block(store, "applySnapshotContents(restoredSnapshot)", "guard storage.save(savedSnapshot)")
require(restore_commit_block.index("beginAttachmentInstall") < restore_commit_block.index("enforceSignedLockIntegrity()"), "backup restore installs verified signatures before signed-record integrity validation")

# Hotfix 12 later loop: destructive-cloud preflight, merge identity/status isolation,
# interrupted restore durability, onboarding recovery boundaries, and verified erase.
replace_block = block(cloud, "func replaceCloudData(with localSnapshot", "func deleteCloudData()")
require("prepareCloudReplacement(replacement)" in replace_block, "authoritative CloudKit replacement builds a complete local payload first")
require(replace_block.index("prepareCloudReplacement(replacement)") < replace_block.index("deleteZoneIfPresent()"), "CloudKit zone deletion cannot start before replacement payload preflight succeeds")
require("uploadPreparedAttachments(prepared.attachments)" in replace_block and "preparedPayloadURL: prepared.snapshotURL" in replace_block, "CloudKit replacement uploads only the staged preflight payload")
prepared_cloud_block = block(cloud, "private func prepareCloudReplacement", "private func uploadPreparedAttachments")
require("AttachmentContentPolicy.isReadableImageData(data)" in prepared_cloud_block and "missingLocalAttachments" in prepared_cloud_block, "CloudKit replacement preflight verifies every local attachment before destructive cloud work")

merge_order_block = block(services, "private static func mergeOrder", "private static func statusTransition")
require("statusTransition(for: a)" in merge_order_block and "statusTransition(for: b)" in merge_order_block, "work-order status merge is based on explicit workflow transitions")
require("aLatest >= bLatest ? a.status : b.status" not in merge_order_block, "unrelated audit recency cannot directly select workflow status")
require("static func coalesceWorkOrders" in services and "coalesceWorkOrders(snapshot.workOrders)" in store, "duplicate work-order identities are coalesced during normalization")
require("unrelated newer audit activity must not roll back an explicit status transition" in logic_harness, "executable logic harness covers stale audit activity versus explicit workflow status")
require("coalescing duplicate work-order IDs must preserve distinct revisions" in logic_harness, "executable logic harness covers duplicate work-order identity repair")

onboarding_download_block = block(store, "private func bootstrapCloudDownloadForOnboarding", "private func scheduleCloudSync")
require("guard !hasPersistedLocalState else" in onboarding_download_block, "pre-onboarding CloudKit recovery cannot overwrite an existing local snapshot")
require("let hasPersistedLocalState: Bool" in store and "hasPersistedLocalState = state.hasPersistedLocalState" in store, "local-state recovery guard participates in in-memory transactional rollback")

rollback_block = block(backup, "func rollback() -> Bool", "func finalize(referencedImages")
require("guard rollbackSucceeded else { return false }" in rollback_block, "attachment rollback reports failure instead of discarding failed recovery state")
require("try manager.removeItem(at: transactionDirectory)" in rollback_block and "return false" in rollback_block, "restore recovery journal is retained when rollback cleanup cannot complete")
require("else if transaction.rollback()" in backup and "Recovery copies were retained" in backup, "startup retries interrupted attachment rollback without deleting recovery copies")
require("stripUnrecoverableSafetyAttachments" in backup and "result.warnings = [" in backup, "safety backup degrades explicitly when already-missing attachments would otherwise block a verified restore")
require("candidate.warnings.count + safetyBackup.warnings.count" in store, "restore surfaces both imported-backup and degraded-safety-backup warnings")

storage_delete_block = block(services, "func deleteAll() -> Bool", "final class OnboardingPersistenceService")
require("targets.contains(where: { manager.fileExists(atPath: $0.path) })" in storage_delete_block, "local erase verifies protected data paths are actually gone")
require("MaintenanceService.deleteAll()" in storage_delete_block, "local erase includes privacy-safe maintenance storage")
require("BackupArchiveService.deleteTemporaryData()" in storage_delete_block, "local erase includes temporary full-backup import/export staging data")
require("AppTemporaryDataService.deleteAll()" in storage_delete_block, "local erase includes app-owned CloudKit, PDF, diagnostic, and support temporary artifacts")
require("enum AppTemporaryDataService" in services and "iWorkOrderCloudReplacement-" in services and "iWorkOrderPDFExports" in services, "temporary artifact eraser covers crash-leftover CloudKit and PDF data")
maintenance_delete_block = block(maintenance, "static func deleteAll() -> Bool", "private static func writeEvents")
require("fileExists(atPath: maintenanceDirectory.path)" in maintenance_delete_block and "return succeeded" in maintenance_delete_block, "maintenance erase reports filesystem deletion failure")
require("static func deleteTemporaryData() -> Bool" in backup and "importRootDirectory()" in backup and "exportDirectoryName" in backup, "temporary backup staging deletion verifies filesystem success")
cloud_erase_block = block(store, "private func completePendingCloudErase() async", "func restore(snapshot")
require("guard storage.deleteAll() else" in cloud_erase_block, "CloudKit erase cannot clear its pending marker until local deletion is verified")
require(cloud_erase_block.index("guard storage.deleteAll() else") < cloud_erase_block.index("try await cloud.deleteCloudData()"), "verified local erase precedes final CloudKit deletion")

# Hotfix 12 newest loop: legal freshness, exact restore commit identity, and cloud attachment identity conflicts.
legal_merge_block = block(services, "if !LegalContent.isCurrentAcceptance(base.profile)", "base.snapshotSavedAt = max(localDate, cloudDate)")
require("acceptanceIsNotExplicitlyOlder" in legal_merge_block, "legal acceptance merge compares explicit profile freshness")
require("acceptedEvidenceDate" in legal_merge_block and "$0 >= selectedProfileDate" in legal_merge_block, "an older explicit or legacy acceptance cannot resurrect after a newer explicit decline")
require("an explicitly newer legal decline must not be resurrected by an older acceptance" in logic_harness and "a legacy acceptance with an older acceptance date must not resurrect" in logic_harness, "executable logic harness covers explicit and legacy legal-decline freshness")

restore_journal_block = block(backup, "private struct BackupTransactionJournal", "struct InterruptedRestoreRecoveryResult")
require("expectedSnapshotSHA256" in restore_journal_block, "restore journal stores the exact expected committed-snapshot fingerprint")
prepare_commit_block = block(backup, "func prepareSnapshotCommit", "fileprivate func matchesCommittedSnapshot")
require("snapshot.saveRevision == journal.expectedSaveRevision" in prepare_commit_block and "snapshotFingerprint(snapshot)" in prepare_commit_block, "restore transaction fingerprints the exact expected snapshot before commit")
require("fileprivate func prepareSnapshotCommit" not in backup and "func prepareSnapshotCommit(_ snapshot: AppSnapshot) throws" in backup, "restore snapshot-commit API is module-visible to AppStore rather than incorrectly fileprivate")
match_commit_block = block(backup, "fileprivate func matchesCommittedSnapshot", "fileprivate func recordCreated")
require("currentRevision == journal.expectedSaveRevision" in match_commit_block and "currentFingerprint == expectedSnapshotSHA256" in match_commit_block, "same-revision interrupted restore recovery requires the exact snapshot fingerprint")
recover_block = block(backup, "static func recoverInterruptedRestores", "static func referencedAttachmentFilenames")
require("transaction.matchesCommittedSnapshot" in recover_block, "startup restore recovery uses exact snapshot matching instead of revision-only inference")
restore_commit_flow = block(store, "let savedSnapshot = currentSnapshot(incrementSaveRevision: true)", "StorageService.commitSaveRevision")
require("prepareSnapshotCommit(savedSnapshot)" in restore_commit_flow, "restore persists expected snapshot fingerprint before local snapshot commit")
require(restore_commit_flow.index("prepareSnapshotCommit(savedSnapshot)") < restore_commit_flow.index("guard storage.save(savedSnapshot)"), "snapshot fingerprint journal is durable before the restored snapshot is saved")

attachment_restore_block = block(cloud, "private func restoreAttachments", "private func uploadSnapshot")
require("attachmentContentConflict" in cloud, "CloudKit exposes a dedicated immutable-attachment content conflict")
require("AttachmentContentPolicy.isReadableImage(at: descriptor.localURL)" in attachment_restore_block, "CloudKit distinguishes a valid conflicting local attachment from a corrupt local file")
require("localHash != downloadedHash" in attachment_restore_block and "throw CloudSyncError.attachmentContentConflict" in attachment_restore_block, "same-name readable local/cloud attachment bytes stop sync instead of silently overwriting local data")
require("let localReadable = localExists && AttachmentContentPolicy.isReadableImage(at: descriptor.localURL)" in attachment_restore_block and attachment_restore_block.count("if !localReadable { missing.append(descriptor.filename) }") >= 2, "CloudKit recovery never treats a corrupt local attachment as a valid fallback for a missing remote asset")

require(pbx.count('DEVELOPMENT_TEAM = "";') == 2, "distributed project contains no embedded Apple Team ID")
require(not re.search(r"DEVELOPMENT_TEAM = [A-Z0-9]{6,};", pbx), "no concrete Apple Team ID is embedded")
require("xcuserdata/" in gitignore and "*.xcuserstate" in gitignore, "per-user Xcode state is excluded from source packages")
require(not any(path.name == "xcuserdata" for path in ROOT.rglob("xcuserdata")), "source package contains no Xcode per-user workspace directory")

for test_name in [
    "testCategoryIdentityIsStableAcrossCaseDiacriticsAndWidth",
    "testCategoryFilterUsesCanonicalIdentity",
    "testAttachmentFilenamePolicyRejectsTraversalAndDirectoryAliases",
    "testAttachmentContentPolicyRejectsCorruptBytesAndAcceptsImageData",
    "testNewerRevisionTimestampWinsLegacyMergeWithoutAuditEvents",
    "testExplicitProfileFreshnessWinsOverNewerUnrelatedSnapshot",
    "testExplicitProfileFreshnessBeatsLegacySnapshotWithoutProfileTimestamp",
    "testSnapshotWithoutCommittedMutationDoesNotInventFreshness",
    "testUnrelatedNewerAuditCannotRollBackExplicitStatusTransition",
    "testDuplicateWorkOrderIDsCoalesceWithoutDroppingDistinctRevisions",
    "testNewerExplicitLegalDeclineIsNotOverriddenByOlderAcceptance",
    "testNewerExplicitLegalDeclineBeatsLegacyOlderAcceptanceDate",
]:
    require(test_name in unit_tests, f"unit regression exists: {test_name}")


require("func finalize(referencedImages: Set<String>, referencedSignatures: Set<String>) -> Bool" in backup, "restore finalization reports whether privacy cleanup really completed")
require("guard imagesClean && signaturesClean" in backup and "return false" in backup[backup.index("func finalize(referencedImages"):backup.index("private func persistJournal", backup.index("func finalize(referencedImages"))], "restore finalization retains recovery state when unreferenced attachment deletion fails")
require("if transaction.finalize(" in backup and "result.finalizedTransactions += 1" in backup, "startup reports a restore finalized only after verified transaction cleanup")
require("finalizationWarningCount" in store and "+ finalizationWarningCount" in store, "successful restore surfaces deferred transaction-cleanup warnings")
require("attachmentRecordNamesInZone" in cloud and "CKQueryOperation.maximumResults" in cloud, "CloudKit sync inventories actual attachment records with paginated current APIs")
require("return fallback" in cloud[cloud.index("private func attachmentRecordNamesInZone"):cloud.index("private func deleteAttachmentRecords")], "CloudKit orphan cleanup inventory cannot block normal sync when querying is temporarily unavailable")
require("remoteAttachmentManifest.subtracting(newManifest)" in cloud, "later syncs delete crash-leftover CloudKit attachment records not present in the snapshot manifest")
require("try? FileManager.default.setAttributes" not in backup, "backup and restore never silently ignore Data Protection failures")
require(backup.count("try FileManager.default.setAttributes") >= 3, "restored attachments, exported backups, and imported staging files require Data Protection")
require("if existingMetadata.sha256 == item.sha256" in backup and "ofItemAtPath: targetURL.path" in backup, "backup restore upgrades Data Protection even when attachment bytes are already identical")
require("if localReadable && !shouldVerifyRemote" in cloud and "try enforceDataProtection(at: descriptor.localURL)" in cloud, "CloudKit sync upgrades protection on valid local attachments it keeps")
require("else if localReadable" in cloud and cloud.count("try enforceDataProtection(at: descriptor.localURL)") >= 2, "CloudKit verified same-content attachments do not bypass Data Protection enforcement")
require("if journal.state == .snapshotCommitted" in backup, "durably committed restore journals remain finalizable after later valid saves")
require("currentRevision == journal.expectedSaveRevision" in backup and "currentFingerprint == expectedSnapshotSHA256" in backup, "same-revision restore recovery still requires the exact committed snapshot fingerprint")
require("func markSnapshotCommitted() -> Bool" in backup and "journal.state = previousState" in backup, "restore commit-journal persistence failure is observable and does not pretend durability")
require("requiresWriteBlock" in backup and "restoreRecoveryWriteBlocked" in store, "ambiguous restore recovery blocks later writes instead of allowing revision evidence to be overwritten")
require("guard !restoreRecoveryWriteBlocked" in store and "Local changes are temporarily blocked" in store, "ordinary saves are rejected while restore commit evidence is ambiguous")
require("if !durableRestoreCommitRecorded" in store and "restoreRecoveryWriteBlocked = true" in store, "a restore with both commit-marker and finalization failure enters safe read-only recovery mode")
require("if restoreRecoveryWriteBlocked" in store and "iCloud sync are paused until restart recovery succeeds" in store, "ambiguous restore recovery cannot start a later cloud transaction")
require("var schedulingError: (@MainActor @Sendable (String) -> Void)?" in services, "notification scheduling failures have an explicit reporting channel")
schedule_request_block = block(services, "private func scheduleRequest(", "func scheduleReminder(for order: WorkOrder, emergencyFollowUp: Bool = false)")
notification_block = block(services, "func scheduleReminder(for order: WorkOrder, emergencyFollowUp: Bool = false)", "func cancelAllNotifications()")
require("try await center.add(request)" in schedule_request_block and "} catch {" in schedule_request_block and "schedulingError?(" in schedule_request_block, "notification scheduling no longer discards iOS scheduling errors")
require("notifications.schedulingError" in store and "lastErrorMessage = message" in store, "notification scheduling failures reach visible app error state")
require("static func delete(filename: String?) -> Bool" in services, "signature deletion reports whether protected-file removal really completed")
require("static func deleteUnreferenced(keeping retainedFilenames: Set<String>) -> CleanupResult" in services, "signature storage supports verified orphan cleanup")
require("private func cleanupOrphanedLocalAttachments()" in store and "ImageStorageService.deleteUnreferenced" in store and "SignatureStorageService.deleteUnreferenced" in store, "startup orphan cleanup covers photos and signatures")
require("if !restoreRecoveryWriteBlocked" in store[store.index("let preferredSnapshot = mergedSnapshot"):store.index("if cloudErasePending", store.index("let preferredSnapshot = mergedSnapshot"))], "orphan cleanup is disabled during ambiguous restore recovery")
policy_block = block(services, "enum WorkOrderNotificationPolicy", "@MainActor\nfinal class NotificationService")
require("order.latestEntry.reminderEnabled" in policy_block and "order.latestEntry.reminderDate > now" in policy_block, "expired explicit reminders are excluded from scheduling")
require("WorkOrderNotificationIdentifier.reminder(orderID: order.id)" in notification_block and "WorkOrderNotificationIdentifier.emergency(" in notification_block, "explicit reminders and emergency follow-ups use independent identifiers")
require("order.latestEntry.createdAt.addingTimeInterval(10)" in policy_block and "date > now ? date : nil" in policy_block, "emergency follow-ups are anchored to the work-order revision time")
require("now.addingTimeInterval(10)" not in notification_block and "now.addingTimeInterval(10)" not in policy_block, "expired emergency follow-ups cannot be resurrected relative to the current time")
reconcile_block = block(services, "func reconcile(", "nonisolated func userNotificationCenter")
require("WorkOrderNotificationPolicy.reminderDate(for: order, now: now)" in reconcile_block, "notification reconciliation excludes expired explicit reminders")
require("WorkOrderNotificationPolicy.emergencyFollowUpDate(" in reconcile_block and "now: now" in reconcile_block, "notification reconciliation excludes expired emergency follow-ups")
require("reconciliationGeneration" in reconcile_block and "self.reconciliationGeneration == generation" in reconcile_block, "stale asynchronous notification cleanup cannot overwrite a newer reconciliation")
create_block = block(store, "func addFull(entry: WorkOrderEntry)", "func update(")
require(create_block.index("guard save() else") < create_block.index("refreshNotifications()", create_block.index("guard save() else")), "new-work-order notifications reconcile only after the local save commits")
update_block = block(store, "func update(", "func addAudit(")
require(update_block.index("guard save() else") < update_block.index("refreshNotifications()", update_block.index("guard save() else")), "edited-work-order notifications reconcile only after the local save commits")
preference_block = block(store, "func applyNotificationPreferences", "func setStorageChoice")
require(preference_block.index("guard save() else") < preference_block.index("refreshNotifications()", preference_block.index("guard save() else")), "notification preference side effects occur only after persistence succeeds")
install_catch_block = block(backup, "return transaction", "static func recoverInterruptedRestores")
require("guard transaction.rollback() else" in install_catch_block and "attachmentRollbackIncomplete" in install_catch_block, "attachment-install failure propagates an incomplete rollback instead of discarding it")
restore_failure_block = block(store, "} catch {\n            var rollbackWarning", "func reportPDFURL")
require("case .attachmentRollbackIncomplete = backupError" in restore_failure_block and "restoreRecoveryWriteBlocked = true" in restore_failure_block, "restore enters protected recovery mode when lower-level attachment rollback is incomplete")
require("if !rolledBack" in restore_failure_block and restore_failure_block.count("restoreRecoveryWriteBlocked = true") >= 2, "restore also blocks writes when AppStore-owned transaction rollback fails")
require("cloudSyncState = .paused" in restore_failure_block and "invalidatePendingCloudSync()" in restore_failure_block, "incomplete rollback immediately pauses CloudKit activity")

# Hotfix 14: refreshed legal package, splash, and mandatory renewed acceptance.
require('static let currentVersion = "2026.09.16.56"' in legal, "Hotfix25 legal version is current")
require('static let effectiveDate = "September 16, 2026"' in legal, "Hotfix25 legal effective date is current")
require("profile.legalAccepted && profile.legalAcceptedDate != nil && profile.legalAcceptedVersion == currentVersion" in legal, "legal acceptance requires a complete current-version acceptance record")
require("testCurrentAcceptanceRequiresAcceptanceDate" in unit_tests, "unit regression rejects current-version acceptance with a missing acceptance date")
require("else if !store.hasCurrentLegalAcceptance" in root_view and "LegalUpdateRequiredView()" in root_view, "root navigation blocks normal access for stale legal acceptance")
require(".task(id: store.isOnboardingComplete && store.hasCurrentLegalAcceptance && store.hasCompletedPermissionSetup)" in root_view and "guard store.isOnboardingComplete, store.hasCurrentLegalAcceptance, store.hasCompletedPermissionSetup else { return }" in root_view, "launch biometric authentication waits until onboarding, legal, and permission gates are current")
require("LegalUpdateSplashView" in settings and "stage: Stage = .splash" in settings, "stale legal acceptance first presents the legal update splash")
require("Review Updated Legal Terms" in settings and "You must review and accept" in settings, "legal update splash clearly requires review and acceptance")
require("store.acceptCurrentLegalAgreement()" in settings and "store.declineLegalAgreement()" in settings, "updated legal flow exposes explicit accept and decline actions")
accept_block = block(store, "func acceptCurrentLegalAgreement()", "func declineLegalAgreement()")
require("profile.legalAcceptedVersion = LegalContent.currentVersion" in accept_block and "guard save()" in accept_block, "re-acceptance persists the exact current legal version transactionally")
decline_block = block(store, "func declineLegalAgreement()", "func completeOnboarding()")
require("profile.legalAcceptedVersion = nil" in decline_block and "guard save()" in decline_block, "declining clears legal acceptance transactionally")
require("startsLegalUpdate" in accessibility and "-ui-testing-legal-update" in accessibility, "UI test mode can simulate an older accepted legal version")
require("testUpdatedLegalVersionShowsSplashAndRequiresReacceptance" in ui_tests, "UI automation covers the updated legal splash and mandatory re-acceptance")
require("Normal app access remains disabled until the current legal version is accepted." in ui_tests, "UI automation verifies decline cannot bypass the legal gate")
require("NSCameraUsageDescription" in info_plist and "optional rear flashlight" in info_plist and "does not capture or record photos or video" in info_plist, "camera purpose string accurately covers torch-only hardware access")
require("AVCaptureDevice.default(for: .video)" in services and "AVCaptureSession" not in services, "flashlight uses camera hardware without a media-capture session")
require("Photos are selected with Apple's system picker" in onboarding and "optional flashlight" in onboarding and "camera hardware access" in onboarding, "onboarding permission copy distinguishes PhotosPicker access from torch hardware access")

# Hotfix 16: Swift 6 callback return-type compile fix.
require("entry.images.forEach(ImageStorageService.delete)" not in views, "draft-image cleanup no longer passes a Bool-returning delete function directly to forEach")
cleanup_block = block(views, "private func cleanupUncommittedImages()", "struct WorkOrderEntryForm")
require("for image in entry.images" in cleanup_block and "_ = ImageStorageService.delete(image)" in cleanup_block, "draft-image cleanup uses an explicit Void-compatible loop while retaining verified deletion attempts")
app_swift_source = "\n".join(path.read_text(encoding="utf-8") for path in APP.glob("*.swift"))
require(not re.search(r"\.forEach\(\s*[A-Za-z_][A-Za-z0-9_]*(?:\.[A-Za-z_][A-Za-z0-9_]*)+\s*\)", app_swift_source), "app source contains no direct qualified function reference passed to forEach")

if errors:
    print("HOTFIX 16 CORE STABILITY HARNESS: FAIL")
    for item in errors:
        print(f"FAIL: {item}")
    raise SystemExit(1)

print("HOTFIX 16 CORE STABILITY HARNESS: PASS")
print(f"Checks passed: {len(checks)}")
for item in checks:
    print(f"PASS: {item}")
