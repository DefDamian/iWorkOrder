#!/usr/bin/env python3
from __future__ import annotations

import json
import plistlib
import struct
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
APP = ROOT / "iWorkOrder"
ASSETS = APP / "Assets.xcassets"

checks: list[str] = []
errors: list[str] = []


def require(condition: bool, message: str) -> None:
    (checks if condition else errors).append(message)


def png_size(path: Path) -> tuple[int, int] | None:
    try:
        data = path.read_bytes()
    except OSError:
        return None
    if len(data) < 24 or data[:8] != b"\x89PNG\r\n\x1a\n" or data[12:16] != b"IHDR":
        return None
    return struct.unpack(">II", data[16:24])


with (APP / "Info.plist").open("rb") as handle:
    info = plistlib.load(handle)
launch = info.get("UILaunchScreen", {})
require(launch.get("UIImageName") == "LaunchLogo", "native launch screen uses the shared LaunchLogo asset")
require(launch.get("UIColorName") == "LaunchBackground", "native launch screen uses the shared LaunchBackground color")

color_path = ASSETS / "LaunchBackground.colorset" / "Contents.json"
require(color_path.is_file(), "adaptive launch background color asset is included")
if color_path.is_file():
    color_catalog = json.loads(color_path.read_text(encoding="utf-8"))
    colors = color_catalog.get("colors", [])
    require(len(colors) == 2, "launch background defines light and dark appearances")
    require(any(not item.get("appearances") for item in colors), "launch background includes a default/light appearance")
    require(any(item.get("appearances", [{}])[0].get("value") == "dark" for item in colors if item.get("appearances")), "launch background includes a dark appearance")

logo_dir = ASSETS / "LaunchLogo.imageset"
logo_catalog_path = logo_dir / "Contents.json"
require(logo_catalog_path.is_file(), "adaptive launch logo asset catalog is included")
if logo_catalog_path.is_file():
    logo_catalog = json.loads(logo_catalog_path.read_text(encoding="utf-8"))
    images = logo_catalog.get("images", [])
    require(len(images) == 6, "launch logo declares three light and three dark scale variants")
    require(sum(1 for item in images if not item.get("appearances")) == 3, "launch logo contains all light appearance scales")
    require(sum(1 for item in images if item.get("appearances")) == 3, "launch logo contains all dark appearance scales")

expected = {
    "LaunchLogoLight@1x.png": (170, 170),
    "LaunchLogoLight@2x.png": (340, 340),
    "LaunchLogoLight@3x.png": (510, 510),
    "LaunchLogoDark@1x.png": (170, 170),
    "LaunchLogoDark@2x.png": (340, 340),
    "LaunchLogoDark@3x.png": (510, 510),
}
for filename, size in expected.items():
    path = logo_dir / filename
    require(path.is_file(), f"launch logo file exists: {filename}")
    require(png_size(path) == size, f"launch logo intrinsic size matches the SwiftUI splash: {filename}")
for stale in ["LaunchLogo@1x.png", "LaunchLogo@2x.png", "LaunchLogo@3x.png"]:
    require(not (logo_dir / stale).exists(), f"obsolete low-contrast launch logo is removed: {stale}")

splash = (APP / "SplashScreenView.swift").read_text(encoding="utf-8")
require('Color("LaunchBackground")' in splash, "SwiftUI splash uses the same background asset as the native launch screen")
require('Image("LaunchLogo")' in splash, "SwiftUI splash uses the same adaptive logo as the native launch screen")
require('.frame(width: 170, height: 170)' in splash, "SwiftUI splash matches the launch logo intrinsic 170-point size")
require("LinearGradient(" not in splash, "startup no longer jumps from a solid native screen to a different gradient")
require('Text("iWorkOrder")' not in splash, "startup no longer adds a second-stage title absent from the native launch screen")
require("850_000_000" not in splash and "320_000_000" in splash, "artificial splash hold is reduced from 850 ms to 320 ms")
require("easeOut(duration: 0.18)" in splash, "startup uses a short fade into the first app screen")
require("accessibilityReduceMotion" in splash and "reduceMotion ? 60_000_000 : 320_000_000" in splash, "startup still honors Reduce Motion")

app = (APP / "iWorkOrderApp.swift").read_text(encoding="utf-8")
require("AppPrivacyShieldView" in app, "inactive-scene privacy protection remains present")
require("@State private var hasBeenActive = false" in app, "startup is protected from an inactive-scene privacy-overlay flash before first activation")
require('Color(.systemBackground)' not in app, "startup no longer introduces a light system-background flash")
require('Text("iWorkOrder")' not in app, "startup and privacy protection do not add a mismatched second-stage title")

for item in checks:
    print(f"PASS: {item}")
if errors:
    for item in errors:
        print(f"FAIL: {item}")
    raise SystemExit(1)
print(f"HOTFIX 30 LAUNCH CONTINUITY: PASS ({len(checks)} checks)")
