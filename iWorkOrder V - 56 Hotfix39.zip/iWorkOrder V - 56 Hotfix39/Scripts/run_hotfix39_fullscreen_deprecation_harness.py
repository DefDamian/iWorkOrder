#!/usr/bin/env python3
from pathlib import Path
import plistlib
import sys

ROOT = Path(__file__).resolve().parents[1]
APP = ROOT / "iWorkOrder"
PBX = ROOT / "iWorkOrder.xcodeproj/project.pbxproj"

passed: list[str] = []
failed: list[str] = []

def require(condition: bool, message: str) -> None:
    (passed if condition else failed).append(message)

info = plistlib.loads((APP / "Info.plist").read_bytes())
pbx = PBX.read_text(encoding="utf-8")
verify_sh = (ROOT / "Scripts/verify_release.sh").read_text(encoding="utf-8")
qualification = (ROOT / "Scripts/phase56_xcode_qualification.sh").read_text(encoding="utf-8")
shipping = "\n".join(path.read_text(encoding="utf-8") for path in APP.rglob("*.swift"))
accessibility = (ROOT / "Scripts/run_accessibility_harness.py").read_text(encoding="utf-8")
release_verifier = (ROOT / "Scripts/verify_release.py").read_text(encoding="utf-8")

# iPadOS 26 deprecates UIRequiresFullScreen. The key must be absent, not false.
require("UIRequiresFullScreen" not in info, "Info.plist omits deprecated UIRequiresFullScreen")
require("INFOPLIST_KEY_UIRequiresFullScreen" not in pbx, "Xcode build settings do not regenerate UIRequiresFullScreen")

# Apple requires an adaptive, resizable scene configuration when the compatibility mode is removed.
ipad_orientations = set(info.get("UISupportedInterfaceOrientations~ipad", []))
required_orientations = {
    "UIInterfaceOrientationPortrait",
    "UIInterfaceOrientationPortraitUpsideDown",
    "UIInterfaceOrientationLandscapeLeft",
    "UIInterfaceOrientationLandscapeRight",
}
require(ipad_orientations == required_orientations, "iPad declares all four interface orientations")
launch = info.get("UILaunchScreen")
require(isinstance(launch, dict) and bool(launch.get("UIImageName")) and bool(launch.get("UIColorName")), "modern launch screen configuration is present")
require("WindowGroup" in shipping, "SwiftUI app uses scene-based WindowGroup lifecycle")
require("UIScreen.main" not in shipping and "UIScreen(" not in shipping, "shipping Swift does not size layouts from a fixed physical screen")
require("NavigationSplitView" in shipping, "regular-width navigation has adaptive split-view support")
require(shipping.count("ViewThatFits") >= 3, "responsive layouts retain ViewThatFits fallbacks")
require(shipping.count("GridItem(.adaptive") >= 4, "grid layouts retain adaptive sizing")

# Release gates must enforce absence of the deprecated key rather than merely setting it false.
require('"UIRequiresFullScreen" not in info' in accessibility, "accessibility gate requires UIRequiresFullScreen to be absent")
require('"UIRequiresFullScreen" not in info' in release_verifier, "master release gate requires UIRequiresFullScreen to be absent")
require('info.get("UIRequiresFullScreen") is False' not in accessibility, "no stale accessibility assertion accepts UIRequiresFullScreen=false")
require('info.get("UIRequiresFullScreen") is False' not in release_verifier, "no stale release assertion accepts UIRequiresFullScreen=false")

# iOS 26 baseline and native qualification remain intact.
require(pbx.count("IPHONEOS_DEPLOYMENT_TARGET = 26.0;") == 8, "all app/test configurations retain iOS 26.0 minimum")
require("run_hotfix39_fullscreen_deprecation_harness.py" in verify_sh, "portable release loop executes Hotfix39 windowing audit")
require("run_hotfix39_fullscreen_deprecation_harness.py" in qualification, "native qualification records Hotfix39 windowing audit")
require((ROOT / "VERIFICATION_NOTES_v56_HOTFIX39_FULLSCREEN_DEPRECATION.md").is_file(), "Hotfix39 verification notes are included")

if failed:
    print("HOTFIX 39 FULLSCREEN DEPRECATION AUDIT: FAIL")
    for item in failed:
        print("FAIL:", item)
    print(f"Checks passed before failure: {len(passed)}")
    sys.exit(1)

print("HOTFIX 39 FULLSCREEN DEPRECATION AUDIT: PASS")
print(f"Checks passed: {len(passed)}")
for item in passed:
    print("PASS:", item)
