# v19 Logo and Splash Screen Update

Changes made:
- Added `Assets.xcassets` to the Xcode project.
- Added the dark iWorkOrder logo as the app icon set.
- Added bundled logo assets for dark and light variants.
- Added `LaunchLogo` asset for startup branding.
- Added `SplashScreenView.swift` with a brief launch splash screen before the existing root flow.
- Updated generated launch screen settings to reference `LaunchLogo`.

Stability notes:
- No data models were changed.
- No SwiftData, iCloud, persistence, audit log, PDF export, notification, onboarding save, or work order logic was changed.
- Existing `RootView` routing remains intact after the short splash screen.
