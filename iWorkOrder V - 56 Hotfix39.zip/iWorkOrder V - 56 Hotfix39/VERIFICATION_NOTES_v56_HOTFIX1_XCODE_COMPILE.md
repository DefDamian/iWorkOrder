# iWorkOrder v56 Hotfix 1: Xcode compile correction

## Defects reproduced from the first real Xcode build

1. Three row actions called `EmailHelper.email(order:)`, an API that no longer existed after the native Mail composer migration.
2. `supportDraft(diagnosticsURL:)` accessed `pathExtension` through an optional URL in a nested conditional expression.
3. Physical-device signing could not continue until the local Apple development team was selected.

## Corrections

- Added local `MailDraft` state to `SwipeToDeleteWorkOrderRow`.
- Routed accessibility, swipe, and context-menu email actions through one `presentEmail()` method.
- Presented `MailComposerView` when Mail is configured and `ShareSheet` otherwise.
- Replaced the optional URL conditional expression with explicit `if let` unwrapping.
- Retained automatic signing with an intentionally empty distributed Team ID. The authorized developer must select a Team locally.

## Verification

- No `EmailHelper.email` references remain.
- All Swift source files pass parser validation.
- Phase 56 cross-platform verification and all existing harnesses pass after the source manifest is regenerated.
- A real Xcode compile still requires macOS. Device execution additionally requires selecting the local development team.
