# Export-compliance handoff

iWorkOrder uses Apple platform networking and CloudKit and uses CryptoKit SHA-256 for integrity checks. It does not implement a custom encrypted communications protocol.

The Account Holder must answer App Store Connect’s current export-compliance questionnaire for the signed build. Do not set or change `ITSAppUsesNonExemptEncryption` solely from this document. If App Store Connect determines that no documentation is required, record the final answers and then set the Info.plist value Apple instructs you to use so future uploads do not repeat unnecessary questions.
