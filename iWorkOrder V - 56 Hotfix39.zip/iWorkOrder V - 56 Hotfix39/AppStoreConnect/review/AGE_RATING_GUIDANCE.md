# Age-rating guidance

The app has no social network, public user-generated-content feed, messaging service, web browser, advertising, gambling, purchases, or developer-hosted content. Users may enter private maintenance text and attach private photos for their own property workflows.

Answer the current App Store Connect age-rating questionnaire truthfully from the final build. The questionnaire changed in 2026 to include social-media capability questions, so do not copy an older rating form. Apple determines the displayed rating from the submitted answers.
