# Proposed App Privacy response

Based on the Phase 56 source package, the proposed App Store Connect answer is:

**No, the developer does not collect data from this app.**

Rationale:

- Work-order content is stored on the user’s device.
- Optional sync uses the user’s private Apple CloudKit database.
- There is no developer-operated work-order backend.
- There are no advertising, tracking, attribution, or third-party analytics SDKs.
- Support email and privacy-safe diagnostics are shared only when the user explicitly sends them through Mail or the share sheet.

This answer must be rechecked against Xcode’s privacy report and the exact signed archive. Any later analytics, crash-reporting, support, advertising, account, or backend SDK can change the answer.

## Phase 54 maintenance history

The app maintains a bounded local operational history for migration and reliability troubleshooting. It contains fixed technical categories, outcomes, durations, aggregate counts, schema versions, and build numbers only. It excludes user-entered work-order content, names, addresses, tenant data, images, signatures, filenames, audit text, and device identifiers. The history is not transmitted to the developer and is exported only after an explicit user action.

This feature does not change the proposed App Store Connect response of **Data Not Collected**, subject to confirming the final signed archive and network behavior before submission.

## Phase 55 field reliability records

The app stores one replaceable local lifecycle checkpoint, aggregate memory-pressure evidence, and a local recovery-sync pause preference. It can also create a checksum-verified support bundle after an explicit user action. These records contain fixed technical categories, lifecycle state, dates, outcomes, build/schema values, durations, and aggregate counts only. They exclude names, addresses, tenant or building details, work-order text, notes, audit text, attachment filenames, photos, signatures, and device identifiers. Nothing is sent to the developer automatically.

The proposed answer remains **Data Not Collected**, subject to confirmation from the final signed archive, Xcode privacy report, network inspection, and any future third-party SDK changes.
## Hotfix 25 legal and permission refresh

Legal version `2026.09.16.56` updates the in-app Privacy Policy, Terms & Conditions, and Data & Liability Disclaimer. The privacy disclosure now explicitly covers Apple geocoding of a user-entered address, optional private CloudKit sync, user-controlled exports, retention/deletion behavior, and the absence of advertising, tracking, third-party analytics, or a developer-operated work-order backend. Existing users must re-accept this legal version before normal app access resumes. The current build also discloses its first-use device permission review for notifications and torch-only camera access, while PhotosPicker, typed-address geocoding, Contacts/Calendar non-access, microphone non-access, and no tracking authorization are stated explicitly.

