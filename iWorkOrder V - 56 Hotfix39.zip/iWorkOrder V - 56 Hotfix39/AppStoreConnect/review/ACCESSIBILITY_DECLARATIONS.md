# Accessibility Nutrition Label evidence

Potential supported features in the source package:

- VoiceOver
- Voice Control
- Larger Text
- Reduced Motion
- Differentiate Without Color Alone
- Sufficient Contrast

Do not publish any Accessibility Nutrition Label claim until the final signed build passes the corresponding Apple evaluation criteria on physical iPhone and iPad devices. Source modifiers and automated audits are evidence, not a substitute for direct assistive-technology testing.
