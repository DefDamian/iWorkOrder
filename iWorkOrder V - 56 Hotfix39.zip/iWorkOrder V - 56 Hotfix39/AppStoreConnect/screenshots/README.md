# App Store screenshot handoff

The app runs on iPhone and iPad, so final submission requires screenshots for both platforms.

Current required primary sizes:

- iPhone 6.9-inch: one to ten screenshots at an accepted portrait or landscape size, including 1260x2736, 1290x2796, or 1320x2868 portrait equivalents.
- iPad 13-inch: one to ten screenshots at 2064x2752 or 2048x2732 portrait, or the corresponding landscape sizes.

Images must be PNG or JPEG and cannot contain transparency. Capture only synthetic data. Do not show real tenant names, addresses, phone numbers, email addresses, signatures, or property evidence.

Recommended set:

1. Work-order dashboard
2. Work-order detail and evidence workflow
3. Building operations hub and reports
4. Backup and private CloudKit controls
5. Accessibility and iPad layout

The Phase 56 UI-test target stores named screenshot attachments in its `.xcresult` bundle. Export and review those images on macOS, then place approved files in `iphone-6.9` and `ipad-13` before running the final submission gate with screenshot enforcement enabled.
