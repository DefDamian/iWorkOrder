# Internal TestFlight group plan

## Group 1: Release qualification

Use App Store Connect users who can verify installation, launch, signing, CloudKit entitlements, notifications, biometric relocking, backup and restore, and iPad layouts.

Exit criteria:

- No launch crash or unrecoverable onboarding failure.
- No data loss in local-only workflows.
- No missing photo or signature after a completed sync.
- No backup archive that validates but cannot restore.
- No stale notification after completion, deletion, or erase.
- No blocker-level VoiceOver, Dynamic Type, or iPad resizing defect.

## Group 2: Operational workflow

Use a small set of authorized building-operations testers with synthetic data. Test repeated daily work-order usage, long histories, many photos, offline periods, and realistic backup routines.

Do not begin external testing until Group 1 exit criteria pass and all critical or high-severity issues are closed.
