# iWork v15 Hardened

Baseline: iWork v13/v14 stabilized. No new large feature direction was added.

Hardening changes:
- StorageService now writes an automatic JSON backup before replacing the primary local save.
- JSON date decoding now accepts ISO-8601 values with or without fractional seconds to avoid onboarding/data reset caused by decoder mismatch.
- Local data size includes JSON, image, and signature folders.
- Erase All Data now also removes stored work order images and signatures.
- Audit integrity is checked after load; missing created/signed trail entries are backfilled instead of leaving legally weak records.
- Repeated view openings no longer spam identical audit entries.
- Signature capture now saves an actual PNG file, not only a filename placeholder.
- PDF export now includes entry metadata, notes, audit trail entries, compressed photo thumbnails, and electronic signatures when present.
- iCloud key-value snapshot save avoids oversized writes; photos/signatures remain file-backed.

Verification performed in this environment:
- Required project files exist.
- Swift files passed a brace-balance and basic token scan.
- Privacy manifest plist parsed successfully with plutil.
- Entitlements plist parsed successfully with plutil.

Xcode device test checklist:
1. Install fresh, complete onboarding, force close, reopen: onboarding should not reappear.
2. Create quick and full work orders; force close/reopen: data should remain.
3. Complete a work order with signature; export PDF: signature and audit trail should appear.
4. Add before/after photos; export PDF: thumbnails should appear.
5. Move a work order to Trash, recover it, force close/reopen: state should remain.
6. Run on second iPhone signed into same iCloud account and test Sync Now/Re-sync from iCloud.
