# iWorkOrder v56 Hotfix 9 — SwiftUI Action Result Ambiguity

## Reported failure

Xcode 26 reported `Conflicting arguments to generic parameter Result (Void vs. Bool)` at `WorkOrderViews.swift:54`.

## Cause

`AppStore.moveToTrash(_:)` returns `Bool` to report whether protected persistence succeeded. The swipe-row callback requires a `Void` action, but its nested `withAnimation` closure returned the Boolean result as its final expression. SwiftUI therefore attempted to reconcile incompatible `Void` and `Bool` generic results.

## Correction

The persistence result is now explicitly discarded inside the animation closure:

```swift
SwipeToDeleteWorkOrderRow(order: order) {
    withAnimation {
        _ = store.moveToTrash(order)
    }
}
```

`moveToTrash(_:)` continues to perform its own failure reporting and transactional rollback. This change only makes the UI action's return type unambiguously `Void`.

## Regression protection

The release verifier now requires the explicit discard and rejects the prior Boolean-returning `withAnimation` form.

## Environment limitation

The package is parser- and regression-validated here. Final SwiftUI generic type checking must be confirmed by rebuilding with Xcode 26 on macOS.
