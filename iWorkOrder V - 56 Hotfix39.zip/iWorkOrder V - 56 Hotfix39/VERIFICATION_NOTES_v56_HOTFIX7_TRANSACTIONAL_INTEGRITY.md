# iWorkOrder v56 Hotfix 7 — Transactional Integrity

Date: 2026-08-05

## Scope

This is a defect-only stabilization hotfix. It adds no product features and does not change the data schema or legal disclosures.

## Confirmed defects corrected

- A recovered work order could become deleted again when merged with an older CloudKit snapshot because deletion was resolved with a permanent Boolean OR.
- Save revision numbers were consumed before protected local persistence succeeded.
- Revision-identity repair evidence could be removed before it was successfully written.
- Integrity repair mutations could remain visible only in memory after a failed save.
- Cloud download, merge sync, and authoritative cloud replacement could report success after their resulting snapshot failed to persist locally.
- Merely opening a signed completed work order could append to its embedded audit trail.
- Trash, recovery, asset, tenant, and unit-import mutations could remain visible after persistence failure.
- Asset, tenant, unit-import, notification, and app-lock controls could change or clear UI state despite a failed save.
- Retention cleanup deleted image files before its redacted snapshot was safely stored.
- Retention cleanup could delete a physical image file that remained referenced by another legacy revision.
- A stale Apple Maps geocoder callback could overwrite the result of a newer address-verification request.
- Backup export could include integrity repairs that had never been committed to protected local storage.
- Legacy snapshot restoration could mark onboarding complete before restored data was successfully saved.

## Corrective behavior

- Delete and recovery events are resolved by their newest explicit transition date.
- Save revisions use candidate-and-commit semantics.
- Pending integrity notices are cleared only after successful persistence.
- Cloud-applied state has a rollback boundary when local persistence fails.
- Signed completed records remain immutable when viewed.
- User-facing transactional mutations and security/notification preferences roll back on save failure.
- Files are deleted only after the updated snapshot is committed and only when no remaining record references them.
- Address verification rejects superseded asynchronous callbacks.
- Backup export commits any pending integrity repairs before generating the archive.

## Regression coverage

- Executable logic tests cover recovery winning over stale deletion and a newer deletion winning over an older recovery.
- XCTest coverage mirrors both merge-state cases.
- `run_transactional_harness.py` validates 35 transactional, merge, retention, rollback, and stale-callback invariants.
- The Phase 56 Xcode qualification runner executes the transactional harness and retains its output as evidence.
