# v23 Theme 2 Scope Fix

Updated Theme 2 so it is applied across the visible app shell instead of only the hero/header areas.

Changes made:
- Kept Default Theme on normal system light/dark behavior.
- Kept custom themes forced to light appearance so iOS dark mode does not override the legacy skins.
- Updated Design 2 colors to match the provided command-center screenshots more closely.
- Applied Design 2 styling to global backgrounds, cards, setting rows, filters, legacy controls, and tab bar treatment.
- Updated legacy work-order action labels to match the old Theme 2 UI language: Select and Full Order.
- Added themed backgrounds for Form/List based utility screens so they no longer fall back to unthemed system grouped backgrounds when Design 2 is active.

Safety notes:
- No SwiftData models were changed.
- No CloudKit/iCloud sync logic was changed.
- No audit log logic was changed.
- No PDF export logic was changed.
- No work order persistence logic was changed.
