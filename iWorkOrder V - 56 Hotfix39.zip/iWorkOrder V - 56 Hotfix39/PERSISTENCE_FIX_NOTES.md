# iWork v5 Persistence Fix Notes

Fixed the onboarding and data loss bug reported after closing the app from the background.

## What changed

- Fixed local JSON decoding by using the same ISO 8601 date strategy for loading that the app already used for saving.
- Added full-app snapshot persistence to iCloud Key-Value Store when iCloud sync is enabled.
- App launch now checks both the local phone save and the iCloud save, then restores the newest valid snapshot.
- Onboarding completion is restored from the saved profile and iCloud completion flag.
- Closing the app, backgrounding the app, or reopening it no longer resets onboarding or wipes work orders.
- Sync Now now writes the real current snapshot to iCloud.
- Re-sync from iCloud now restores the real saved snapshot into the app.
- Erase All Data now clears both local storage and the iCloud app snapshot.

## Important Xcode requirement

iCloud Key-Value Storage must be enabled for the app target in Signing & Capabilities. The entitlement file is already included with:

`com.apple.developer.ubiquity-kvstore-identifier = $(TeamIdentifierPrefix)com.damiancedeno.SedgwickWorkOrders`

Use a real Apple Developer Team in Xcode so the entitlement can work on device.

## Phase 47 persistence update

The full work-order snapshot is no longer written to `NSUbiquitousKeyValueStore`. It is stored as a CloudKit asset in the user's private database. Photos and signatures are separate verified CloudKit assets. The prior key-value snapshot is read only for one-time migration and is removed after the first successful CloudKit commit. The small onboarding-completion flag continues to use key-value storage.

## Phase 48 backup and restore update

Portable backups are now independent of CloudKit and local snapshot storage. A `.iworkorderbackup` archive includes the JSON snapshot and every referenced photo and signature. The app validates the manifest, archive checksum, item checksums, lengths, filenames, paths, snapshot counts, and attachment references before offering a restore.

Restore is transactional. A verified pre-restore safety archive is created first, imported attachments are staged, and the current snapshot is committed only after file installation succeeds. Merge preserves current device preferences. Replace establishes a persistent CloudKit replacement transaction when either the current or restored profile uses iCloud, preventing older cloud records from being merged back into the restored dataset.
