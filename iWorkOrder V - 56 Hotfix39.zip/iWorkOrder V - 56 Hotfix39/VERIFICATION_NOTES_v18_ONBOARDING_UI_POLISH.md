# iWorkOrder v18 Onboarding UI Polish

Changes made:
- Updated onboarding input boxes to use the same blended material styling as the polished work order search field.
- Removed the bright rounded-border look from onboarding text fields so they sit naturally inside the onboarding cards.
- Kept the changes limited to UI chrome only. No model, persistence, iCloud, onboarding completion, audit log, notification, address verification, or PDF export logic was changed.

Files changed:
- `iWorkOrder/iWorkOrder/Components.swift`
- `iWorkOrder/iWorkOrder/OnboardingView.swift`

Verification focus:
- Confirm onboarding still requires name, company, verified address, and legal acceptance before completion.
- Confirm typing into name, company, building address, and quick-start unit import fields still saves/works as before.
- Confirm the app still builds after the UI-only modifiers are applied.
