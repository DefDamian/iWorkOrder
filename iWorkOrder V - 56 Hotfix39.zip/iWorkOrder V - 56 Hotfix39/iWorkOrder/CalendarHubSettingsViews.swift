import SwiftUI
import UniformTypeIdentifiers
import UIKit
import MessageUI

struct CalendarWorkOrderView: View {
    @EnvironmentObject private var store: AppStore
    @AppStorage(AppTheme.storageKey) private var selectedThemeRaw = VisualTheme.defaultTheme.rawValue

    private var selectedTheme: VisualTheme { VisualTheme(rawValue: selectedThemeRaw) ?? .defaultTheme }

    var body: some View {
        NavigationStack {
            ScreenBackground {
                SwiftUI.ScrollView(.vertical, showsIndicators: true) {
                    VStack(alignment: .leading, spacing: 18) {
                        if selectedTheme == .design3 {
                            Theme3CalendarContent(orders: store.reminderWorkOrders)
                        } else {
                            if selectedTheme == .defaultTheme {
                                SectionHeader(title: "Calendar", subtitle: "Work orders with reminders enabled.")
                            } else {
                                LegacyPageHero(
                                    kicker: "SCHEDULE GRID",
                                    title: "Calendar",
                                    subtitle: "Reminder queue and scheduled maintenance checkpoints."
                                )
                            }

                            if store.reminderWorkOrders.isEmpty {
                                ModernCard {
                                    VStack(spacing: 10) {
                                        Image(systemName: selectedTheme == .design2 ? "calendar.badge.clock" : "calendar.badge.checkmark")
                                            .font(.title2.weight(.semibold))
                                            .foregroundStyle(AppTheme.accent(for: selectedTheme))
                                        Text("No reminders yet")
                                            .font(selectedTheme == .design2 ? .system(.headline, design: .monospaced) : .headline)
                                            .foregroundStyle(AppTheme.textPrimary(for: selectedTheme))
                                    }
                                    .frame(maxWidth: .infinity)
                                    .padding(.vertical, 18)
                                }
                            } else {
                                LazyVStack(spacing: selectedTheme == .design2 ? 10 : 14) {
                                    ForEach(store.reminderWorkOrders) { order in
                                        NavigationLink { WorkOrderDetailView(order: order) } label: {
                                            ModernCard(padding: selectedTheme == .design2 ? 12 : 16) {
                                                HStack(spacing: 12) {
                                                    Image(systemName: "bell.fill")
                                                        .foregroundStyle(.orange)
                                                        .frame(width: 34, height: 34)
                                                        .background(Color.orange.opacity(0.11), in: RoundedRectangle(cornerRadius: 9, style: .continuous))
                                                    VStack(alignment: .leading, spacing: 3) {
                                                        Text(order.latestEntry.area)
                                                            .font(selectedTheme == .design2 ? .system(.headline, design: .monospaced).weight(.bold) : .headline)
                                                            .foregroundStyle(AppTheme.textPrimary(for: selectedTheme))
                                                        Text(order.title)
                                                            .font(.subheadline)
                                                            .foregroundStyle(AppTheme.textSecondary(for: selectedTheme))
                                                        Text(order.latestEntry.reminderDate.shortDateTime)
                                                            .font(.caption.weight(.semibold))
                                                            .foregroundStyle(.orange)
                                                    }
                                                    Spacer(minLength: 4)
                                                    Image(systemName: "chevron.right")
                                                        .font(.caption.weight(.bold))
                                                        .foregroundStyle(.secondary)
                                                }
                                            }
                                        }
                                        .buttonStyle(.plain)
                                    }
                                }
                            }
                        }
                    }
                    .padding(AppTheme.horizontalPadding(for: selectedTheme))
                    .padding(.bottom, 28)
                }
            }
            .navigationTitle(selectedTheme == .design3 ? "Schedule" : (AppTheme.usesLegacyHero(for: selectedTheme) ? "" : "Calendar"))
            .navigationBarTitleDisplayMode(.inline)
            .toolbar(AppTheme.usesLegacyHero(for: selectedTheme) ? .hidden : .visible, for: .navigationBar)
            .accessibilityIdentifier(AccessibilityID.calendarScreen)
        }
    }
}

struct Theme3CalendarContent: View {
    let orders: [WorkOrder]

    var body: some View {
        VStack(alignment: .leading, spacing: 14) {
            HStack(alignment: .top, spacing: 12) {
                VStack(alignment: .leading, spacing: 6) {
                    Text("FIELD DECK / SCHEDULE")
                        .font(.caption2.weight(.heavy))
                        .tracking(1.5)
                        .foregroundStyle(AppTheme.accent(for: .design3))
                    Text("Maintenance Timeline")
                        .font(.title2.weight(.heavy))
                        .foregroundStyle(AppTheme.textPrimary(for: .design3))
                    Text("Upcoming reminders and scheduled follow-ups.")
                        .font(.subheadline)
                        .foregroundStyle(AppTheme.textSecondary(for: .design3))
                }
                Spacer(minLength: 8)
                Text("\(orders.count)")
                    .font(.title2.weight(.heavy))
                    .foregroundStyle(Color(red: 0.03, green: 0.08, blue: 0.08))
                    .frame(minWidth: 46, minHeight: 46)
                    .background(AppTheme.accent(for: .design3), in: RoundedRectangle(cornerRadius: 8, style: .continuous))
            }
            .padding(16)
            .background(Color(red: 0.045, green: 0.075, blue: 0.080), in: RoundedRectangle(cornerRadius: 10, style: .continuous))
            .overlay(alignment: .top) {
                Rectangle().fill(AppTheme.accent(for: .design3)).frame(height: 3).padding(.horizontal, 12)
            }

            if orders.isEmpty {
                VStack(alignment: .leading, spacing: 8) {
                    Image(systemName: "calendar.badge.checkmark")
                        .font(.title2.weight(.semibold))
                        .foregroundStyle(AppTheme.accent(for: .design3))
                    Text("Schedule clear")
                        .font(.headline.weight(.heavy))
                        .foregroundStyle(AppTheme.textPrimary(for: .design3))
                    Text("Work orders with reminders will appear here.")
                        .font(.subheadline)
                        .foregroundStyle(AppTheme.textSecondary(for: .design3))
                }
                .frame(maxWidth: .infinity, alignment: .leading)
                .padding(18)
                .background(Color(red: 0.052, green: 0.080, blue: 0.084), in: RoundedRectangle(cornerRadius: 9, style: .continuous))
            } else {
                LazyVStack(spacing: 9) {
                    ForEach(orders) { order in
                        NavigationLink { WorkOrderDetailView(order: order) } label: {
                            Theme3CalendarRow(order: order)
                        }
                        .buttonStyle(.plain)
                    }
                }
            }
        }
        .accessibilityIdentifier("theme.design3.calendar")
    }
}

struct Theme3CalendarRow: View {
    let order: WorkOrder

    var body: some View {
        HStack(spacing: 12) {
            VStack(spacing: 2) {
                Image(systemName: "calendar")
                    .font(.caption.weight(.heavy))
                Text(order.latestEntry.reminderDate.formatted(.dateTime.month(.abbreviated).day()))
                    .font(.caption2.weight(.heavy))
                    .multilineTextAlignment(.center)
                    .lineLimit(2)
            }
            .foregroundStyle(Color(red: 0.03, green: 0.08, blue: 0.08))
            .frame(width: 58, height: 54)
            .background(AppTheme.accent(for: .design3), in: RoundedRectangle(cornerRadius: 7, style: .continuous))

            VStack(alignment: .leading, spacing: 4) {
                Text(order.latestEntry.area.isEmpty ? "Area" : order.latestEntry.area)
                    .font(.headline.weight(.heavy))
                    .foregroundStyle(AppTheme.textPrimary(for: .design3))
                Text(order.title)
                    .font(.subheadline)
                    .foregroundStyle(AppTheme.textSecondary(for: .design3))
                    .lineLimit(2)
                Text(order.latestEntry.reminderDate.shortDateTime)
                    .font(.caption.weight(.semibold))
                    .foregroundStyle(AppTheme.accent(for: .design3))
            }
            Spacer(minLength: 4)
            Image(systemName: "arrow.up.right")
                .font(.caption.weight(.heavy))
                .foregroundStyle(AppTheme.accent(for: .design3))
        }
        .padding(12)
        .background(Color(red: 0.052, green: 0.080, blue: 0.084), in: RoundedRectangle(cornerRadius: 8, style: .continuous))
        .overlay(RoundedRectangle(cornerRadius: 8, style: .continuous).stroke(Color.white.opacity(0.065), lineWidth: 1))
    }
}

struct HubView: View {
    @EnvironmentObject private var store: AppStore
    @AppStorage(AppTheme.storageKey) private var selectedThemeRaw = VisualTheme.defaultTheme.rawValue
    @State private var reportMonth = Date()
    @State private var shareURL: URL?

    private var selectedTheme: VisualTheme { VisualTheme(rawValue: selectedThemeRaw) ?? .defaultTheme }
    private var recurring: [(String, Int)] {
        Dictionary(grouping: store.activeWorkOrders, by: { $0.latestEntry.area })
            .mapValues(\.count)
            .filter { $0.value > 1 }
            .sorted { $0.value > $1.value }
    }
    private var monthOrders: [WorkOrder] {
        store.activeWorkOrders.filter { Calendar.current.isDate($0.createdAt, equalTo: reportMonth, toGranularity: .month) }
    }

    var body: some View {
        NavigationStack {
            ScreenBackground {
                SwiftUI.ScrollView(.vertical, showsIndicators: true) {
                    VStack(alignment: .leading, spacing: selectedTheme == .design3 ? 14 : 18) {
                        if selectedTheme == .design3 {
                            Theme3HubHeader(total: store.activeWorkOrders.count, recurring: recurring.count)
                        } else {
                            LegacyPageHero(
                                kicker: selectedTheme == .design2 ? "OPERATIONS CONSOLE" : "HUB",
                                title: selectedTheme == .design2 ? "Dashboard" : "Hub",
                                subtitle: "Building overview, reports, assets, and directory."
                            )
                        }

                        LazyVGrid(columns: [GridItem(.adaptive(minimum: selectedTheme == .design3 ? 150 : 180), spacing: 10)], spacing: 10) {
                            NavigationLink { HubMetricDetailView(title: "Total Work Orders", orders: store.activeWorkOrders) } label: {
                                MetricTile(title: "Total Work Orders", value: "\(store.activeWorkOrders.count)", icon: "tray.full")
                            }
                            NavigationLink { UnitsAreasView() } label: {
                                MetricTile(title: "Units / Areas", value: "\(Set(store.activeWorkOrders.map { $0.latestEntry.area }).count)", icon: "building")
                            }
                            NavigationLink { HubMetricDetailView(title: "Completed", orders: store.activeWorkOrders.filter { $0.status == .completed }) } label: {
                                MetricTile(title: "Completed", value: "\(store.activeWorkOrders.filter { $0.status == .completed }.count)", icon: "checkmark.seal", tint: .green)
                            }
                            NavigationLink { RecurringIssuesView() } label: {
                                MetricTile(title: "Recurring Issues", value: "\(recurring.count)", icon: "arrow.triangle.2.circlepath", tint: .orange)
                            }
                        }
                        .buttonStyle(.plain)

                        ModernCard {
                            VStack(alignment: .leading, spacing: 12) {
                                SectionHeader(title: selectedTheme == .design3 ? "Monthly Report" : "Report", subtitle: "Export a formal PDF with building info, work orders, photo references, signatures, and audit logs.")
                                LegalBanner(kind: .export)
                                DatePicker("Month", selection: $reportMonth, displayedComponents: [.date])
                                InfoLine(title: "Work orders this month", value: "\(monthOrders.count)")
                                InfoLine(title: "Completed", value: "\(monthOrders.filter { $0.status == .completed }.count)")
                                Button {
                                    shareURL = store.reportPDFURL(orders: monthOrders, title: "iWorkOrder Monthly Report")
                                } label: {
                                    Label("Share or Save Report", systemImage: "square.and.arrow.up")
                                        .frame(maxWidth: .infinity)
                                }
                                .buttonStyle(.borderedProminent)
                                .tint(selectedTheme == .design3 ? AppTheme.accent(for: .design3) : .blue)
                                .accessibilityHint("Opens the iOS share sheet so you can save the report to Files or another installed provider")
                                Text("The iOS share sheet shows the storage and sharing apps installed on this device.")
                                    .font(.caption)
                                    .foregroundStyle(AppTheme.textSecondary(for: selectedTheme))
                            }
                        }

                        if selectedTheme == .design3 {
                            SectionHeader(title: "Field Tools", subtitle: "Building assets and unit directory.")
                        }
                        NavigationLink { AssetManagerView() } label: {
                            SettingsRow(title: "Asset Tags & QR", subtitle: "Track boilers, elevators, pumps, and other assets by tag.", icon: "qrcode.viewfinder")
                        }
                        .buttonStyle(.plain)
                        NavigationLink { DirectoryView() } label: {
                            SettingsRow(title: "Unit / Tenant Directory", subtitle: "Store entry permission, contact info, and CSV-style unit lists.", icon: "person.2")
                        }
                        .buttonStyle(.plain)
                    }
                    .padding(AppTheme.horizontalPadding(for: selectedTheme))
                    .padding(.bottom, 28)
                }
            }
            .navigationTitle(selectedTheme == .design3 ? "Field Deck" : (AppTheme.usesLegacyHero(for: selectedTheme) ? "" : "Hub"))
            .navigationBarTitleDisplayMode(.inline)
            .toolbar(AppTheme.usesLegacyHero(for: selectedTheme) ? .hidden : .visible, for: .navigationBar)
            .accessibilityIdentifier(AccessibilityID.hubScreen)
            .sheet(item: Binding(get: { shareURL.map { IdentifiableURL(url: $0) } }, set: { _ in shareURL = nil })) {
                ShareSheet(items: [$0.url])
            }
        }
    }
}

struct Theme3HubHeader: View {
    let total: Int
    let recurring: Int

    var body: some View {
        VStack(alignment: .leading, spacing: 12) {
            HStack {
                Text("FIELD DECK / OVERVIEW")
                    .font(.caption2.weight(.heavy))
                    .tracking(1.5)
                    .foregroundStyle(AppTheme.accent(for: .design3))
                Spacer()
                HStack(spacing: 5) {
                    Circle().fill(Color.green).frame(width: 7, height: 7)
                    Text("LIVE")
                        .font(.caption2.weight(.heavy))
                        .foregroundStyle(Color.green)
                }
            }
            Text("Building Operations")
                .font(.title.weight(.heavy))
                .foregroundStyle(AppTheme.textPrimary(for: .design3))
            HStack(spacing: 18) {
                Label("\(total) records", systemImage: "tray.full")
                Label("\(recurring) recurring", systemImage: "arrow.triangle.2.circlepath")
            }
            .font(.caption.weight(.semibold))
            .foregroundStyle(AppTheme.textSecondary(for: .design3))
        }
        .padding(16)
        .background(Color(red: 0.045, green: 0.075, blue: 0.080), in: RoundedRectangle(cornerRadius: 10, style: .continuous))
        .overlay(alignment: .top) {
            Rectangle().fill(AppTheme.accent(for: .design3)).frame(height: 3).padding(.horizontal, 12)
        }
        .accessibilityElement(children: .combine)
        .accessibilityAddTraits(.isHeader)
        .accessibilityIdentifier("theme.design3.hub")
    }
}

struct HubMetricDetailView: View {
    let title: String
    let orders: [WorkOrder]
    var body: some View { List(orders) { order in NavigationLink { WorkOrderDetailView(order: order) } label: { VStack(alignment: .leading) { Text(order.latestEntry.area).font(.headline); Text(order.title).foregroundStyle(.secondary); HStack { StatusBadge(status: order.status); PriorityBadge(priority: order.latestEntry.priority) } } } }.themedScrollableBackground().navigationTitle(title) }
}

struct UnitsAreasView: View {
    @EnvironmentObject private var store: AppStore
    var units: [(String, Int)] { Dictionary(grouping: store.activeWorkOrders, by: { $0.latestEntry.area }).mapValues(\.count).sorted { $0.key < $1.key } }
    var body: some View { List { ForEach(units, id: \.0) { unit, count in NavigationLink { HubMetricDetailView(title: unit, orders: store.activeWorkOrders.filter { $0.latestEntry.area == unit }) } label: { HStack { Text(unit); Spacer(); Text("\(count)").foregroundStyle(.secondary) } } } }.themedScrollableBackground().navigationTitle("Units / Areas") }
}

struct RecurringIssuesView: View {
    @EnvironmentObject private var store: AppStore
    var items: [(String, Int)] { Dictionary(grouping: store.activeWorkOrders, by: { $0.latestEntry.area }).mapValues(\.count).filter { $0.value > 1 }.sorted { $0.value > $1.value } }
    var body: some View { List { ForEach(items, id: \.0) { area, count in NavigationLink { HubMetricDetailView(title: "Recurring \(area)", orders: store.activeWorkOrders.filter { $0.latestEntry.area == area }) } label: { HStack { Text(area); Spacer(); Text("\(count) work orders") } } } }.themedScrollableBackground().navigationTitle("Recurring Issues") }
}

struct AssetManagerView: View {
    @EnvironmentObject private var store: AppStore
    @State private var asset = AssetRecord()

    var body: some View {
        Form {
            Section("Add Asset") {
                TextField("Tag or QR value", text: $asset.tag)
                TextField("Name", text: $asset.name)
                TextField("Location", text: $asset.location)
                TextField("Notes", text: $asset.notes, axis: .vertical)
                Button("Save Asset") {
                    if store.addAsset(asset) {
                        asset = AssetRecord()
                    }
                }
                .disabled(asset.tag.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty)
            }

            Section("Assets") {
                ForEach(store.assets) { asset in
                    VStack(alignment: .leading, spacing: 4) {
                        Text(asset.tag).font(.headline)
                        Text("\(asset.name) - \(asset.location)").foregroundStyle(.secondary)
                    }
                }
            }
        }
        .themedScrollableBackground()
        .navigationTitle("Assets")
    }
}

struct DirectoryView: View {
    @EnvironmentObject private var store: AppStore
    @State private var tenant = TenantContact()
    @State private var importText = ""

    var body: some View {
        Form {
            Section("Import Units") {
                TextField("1A, 1B, Lobby", text: $importText, axis: .vertical)
                Button("Import") {
                    if store.importUnits(CSVHelper.parseUnits(from: importText)) {
                        importText = ""
                    }
                }
                .disabled(importText.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty)
            }

            Section("Add Tenant / Unit Contact") {
                TextField("Unit", text: $tenant.unit)
                TextField("Name", text: $tenant.name)
                TextField("Phone", text: $tenant.phone)
                TextField("Email", text: $tenant.email)
                Toggle("Entry permitted", isOn: $tenant.entryPermission)
                Button("Save Contact") {
                    if store.addTenant(tenant) {
                        tenant = TenantContact()
                    }
                }
                .disabled(tenant.unit.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty)
            }

            Section("Directory") {
                ForEach(store.tenants) { tenant in
                    VStack(alignment: .leading, spacing: 4) {
                        Text(tenant.unit).font(.headline)
                        Text(tenant.name).foregroundStyle(.secondary)
                        Text(tenant.entryPermission ? "Entry permitted" : "No entry permission on file")
                            .font(.caption)
                            .foregroundStyle(tenant.entryPermission ? .green : .orange)
                    }
                }
            }
        }
        .themedScrollableBackground()
        .navigationTitle("Directory")
    }
}

struct LegacyPageHero: View {
    @AppStorage(AppTheme.storageKey) private var selectedThemeRaw = VisualTheme.defaultTheme.rawValue
    let kicker: String
    let title: String
    let subtitle: String

    private var selectedTheme: VisualTheme { VisualTheme(rawValue: selectedThemeRaw) ?? .defaultTheme }

    var body: some View {
        switch selectedTheme {
        case .defaultTheme:
            SectionHeader(
                title: kicker == "SETTINGS" ? "Settings" : (title == "Command" || title == "Dashboard" ? "Hub" : title),
                subtitle: kicker == "SETTINGS" ? nil : subtitle
            )
        case .design2:
            VStack(alignment: .leading, spacing: 14) {
                HStack {
                    Label(kicker.uppercased(), systemImage: "waveform.path.ecg")
                        .font(.system(.caption2, design: .monospaced).weight(.black))
                        .tracking(1.5)
                        .foregroundStyle(Color.cyan.opacity(0.82))
                    Spacer()
                    Text("LIVE")
                        .font(.system(.caption2, design: .monospaced).weight(.black))
                        .foregroundStyle(.green)
                        .padding(.horizontal, 8)
                        .padding(.vertical, 4)
                        .background(Color.green.opacity(0.12), in: Capsule())
                }
                Text(title.uppercased())
                    .font(AppTheme.legacyTitleFont(for: selectedTheme))
                    .foregroundStyle(.white)
                    .lineLimit(2)
                    .minimumScaleFactor(0.72)
                Text(subtitle)
                    .font(.subheadline.weight(.medium))
                    .foregroundStyle(.white.opacity(0.72))
                    .lineLimit(3)
                HStack(spacing: 5) {
                    ForEach(0..<4, id: \.self) { index in
                        Capsule()
                            .fill(index == 0 ? Color.cyan : Color.white.opacity(0.18))
                            .frame(width: index == 0 ? 34 : 10, height: 4)
                    }
                }
                .accessibilityHidden(true)
            }
            .padding(20)
            .frame(maxWidth: .infinity, alignment: .leading)
            .background(AppTheme.heroGradient(for: .design2), in: RoundedRectangle(cornerRadius: 20, style: .continuous))
            .overlay(
                RoundedRectangle(cornerRadius: 20, style: .continuous)
                    .stroke(Color.cyan.opacity(0.22), lineWidth: 1)
            )
            .shadow(color: Color.black.opacity(0.14), radius: 14, x: 0, y: 8)
            .accessibilityElement(children: .combine)
            .accessibilityAddTraits(.isHeader)
        case .design3:
            VStack(alignment: .leading, spacing: 8) {
                HStack(spacing: 7) {
                    RoundedRectangle(cornerRadius: 2)
                        .fill(AppTheme.accent(for: .design3))
                        .frame(width: 8, height: 8)
                    Text("FIELD DECK / \(kicker.uppercased())")
                        .font(.caption2.weight(.heavy))
                        .tracking(1.5)
                        .foregroundStyle(AppTheme.accent(for: .design3))
                }
                Text(title)
                    .font(AppTheme.legacyTitleFont(for: selectedTheme))
                    .foregroundStyle(AppTheme.textPrimary(for: .design3))
                    .lineLimit(2)
                    .minimumScaleFactor(0.76)
                Text(subtitle)
                    .font(.subheadline.weight(.medium))
                    .foregroundStyle(AppTheme.textSecondary(for: .design3))
                    .lineLimit(3)
            }
            .padding(18)
            .frame(maxWidth: .infinity, minHeight: 136, alignment: .leading)
            .background(Color(red: 0.045, green: 0.075, blue: 0.080), in: RoundedRectangle(cornerRadius: 10, style: .continuous))
            .overlay(alignment: .top) {
                Rectangle().fill(AppTheme.accent(for: .design3)).frame(height: 3).padding(.horizontal, 12)
            }
            .overlay(RoundedRectangle(cornerRadius: 10, style: .continuous).stroke(Color.white.opacity(0.07), lineWidth: 1))
            .accessibilityElement(children: .combine)
            .accessibilityAddTraits(.isHeader)
        }
    }
}

struct SettingsView: View {
    @EnvironmentObject private var store: AppStore
    @EnvironmentObject private var appLock: AppLockState
    @AppStorage(AppTheme.storageKey) private var selectedThemeRaw = VisualTheme.defaultTheme.rawValue

    private var selectedTheme: VisualTheme { VisualTheme(rawValue: selectedThemeRaw) ?? .defaultTheme }

    var body: some View {
        NavigationStack {
            ScreenBackground {
                SwiftUI.ScrollView(.vertical, showsIndicators: true) {
                    VStack(alignment: .leading, spacing: selectedTheme == .design3 ? 12 : 16) {
                        if selectedTheme == .design3 {
                            Theme3SettingsHeader()
                            Theme3SettingsGroup(title: "PROFILE") {
                                InfoLine(title: "Role", value: store.profile.role.rawValue)
                                InfoLine(title: "Company", value: store.profile.propertyManagerCompanyName)
                                InfoLine(title: "Building", value: store.profile.buildingAddress)
                            }
                            Theme3SettingsGroup(title: "SYSTEM") {
                                NavigationLink { CloudView() } label: { SettingsRow(title: "Cloud", subtitle: "Sync status, connectivity, and restore state.", icon: "icloud") }.buttonStyle(.plain)
                                NavigationLink { ExportBackupView() } label: { SettingsRow(title: "Export & Backup", subtitle: "Verified portable archives, restore, and local safety copies.", icon: "externaldrive") }.buttonStyle(.plain)
                                NavigationLink { SecurityView() } label: { SettingsRow(title: "Security", subtitle: "Face ID or passcode app lock.", icon: "lock.shield") }.buttonStyle(.plain)
                                NavigationLink { NotificationSettingsView() } label: { SettingsRow(title: "Notifications", subtitle: "Reminder and emergency notification controls.", icon: "bell.badge") }.buttonStyle(.plain)
                            }
                            Theme3SettingsGroup(title: "WORKFLOW") {
                                NavigationLink { ThemeSettingsView() } label: { SettingsRow(title: "Themes", subtitle: "Default Theme, Design 2, and Design 3 UI styles.", icon: "paintpalette") }.buttonStyle(.plain)
                                NavigationLink { CategoryManagerView() } label: { SettingsRow(title: "Category Manager", subtitle: "Add, delete, and reorder work order categories.", icon: "tag") }.buttonStyle(.plain)
                                NavigationLink { DataPrivacyView() } label: { SettingsRow(title: "Data Privacy Redaction", subtitle: "Purge old photos and names after retention period.", icon: "eye.slash") }.buttonStyle(.plain)
                            }
                            Theme3SettingsGroup(title: "SUPPORT") {
                                NavigationLink { SupportDiagnosticsView() } label: { SettingsRow(title: "Support", subtitle: "Contact support or create a privacy-safe support package.", icon: "lifepreserver") }.buttonStyle(.plain)
#if DEBUG
                                NavigationLink { MaintenanceRecoveryView() } label: { SettingsRow(title: "Maintenance & Recovery", subtitle: "Internal data-integrity and release troubleshooting tools.", icon: "wrench.and.screwdriver") }.buttonStyle(.plain)
#endif
                                NavigationLink { LegalAboutView() } label: { SettingsRow(title: "Legal and About", subtitle: "Privacy, terms, disclaimers, version, and support.", icon: "doc.text") }.buttonStyle(.plain)
                                NavigationLink { TrashView() } label: { SettingsRow(title: "Trash", subtitle: "Recover deleted work orders or reset app.", icon: "trash") }.buttonStyle(.plain)
                            }
                        } else {
                            LegacyPageHero(
                                kicker: "SETTINGS",
                                title: selectedTheme == .design2 ? "Settings Console" : "iWorkOrder",
                                subtitle: "Profile, cloud, backups, privacy, support, and legal."
                            )
                            ModernCard {
                                VStack(alignment: .leading, spacing: 8) {
                                    InfoLine(title: "Role", value: store.profile.role.rawValue)
                                    InfoLine(title: "Company", value: store.profile.propertyManagerCompanyName)
                                    InfoLine(title: "Building", value: store.profile.buildingAddress)
                                }
                            }
                            NavigationLink { CloudView() } label: { SettingsRow(title: "Cloud", subtitle: "Sync status, connectivity, and restore state.", icon: "icloud") }.buttonStyle(.plain)
                            NavigationLink { ExportBackupView() } label: { SettingsRow(title: "Export & Backup", subtitle: "Verified portable archives, restore, and local safety copies.", icon: "externaldrive") }.buttonStyle(.plain)
                            NavigationLink { SecurityView() } label: { SettingsRow(title: "Security", subtitle: "Face ID or passcode app lock.", icon: "lock.shield") }.buttonStyle(.plain)
                            NavigationLink { NotificationSettingsView() } label: { SettingsRow(title: "Notifications", subtitle: "Reminder and emergency notification controls.", icon: "bell.badge") }.buttonStyle(.plain)
                            NavigationLink { ThemeSettingsView() } label: { SettingsRow(title: "Themes", subtitle: "Default Theme, Design 2, and Design 3 UI styles.", icon: "paintpalette") }.buttonStyle(.plain)
                            NavigationLink { CategoryManagerView() } label: { SettingsRow(title: "Category Manager", subtitle: "Add, delete, and reorder work order categories.", icon: "tag") }.buttonStyle(.plain)
                            NavigationLink { DataPrivacyView() } label: { SettingsRow(title: "Data Privacy Redaction", subtitle: "Purge old photos and names after retention period.", icon: "eye.slash") }.buttonStyle(.plain)
                            NavigationLink { SupportDiagnosticsView() } label: { SettingsRow(title: "Support", subtitle: "Contact support or create a privacy-safe support package.", icon: "lifepreserver") }.buttonStyle(.plain)
#if DEBUG
                            NavigationLink { MaintenanceRecoveryView() } label: { SettingsRow(title: "Maintenance & Recovery", subtitle: "Internal data-integrity and release troubleshooting tools.", icon: "wrench.and.screwdriver") }.buttonStyle(.plain)
#endif
                            NavigationLink { LegalAboutView() } label: { SettingsRow(title: "Legal and About", subtitle: "Privacy, terms, disclaimers, version, and support.", icon: "doc.text") }.buttonStyle(.plain)
                            NavigationLink { TrashView() } label: { SettingsRow(title: "Trash", subtitle: "Recover deleted work orders or reset app.", icon: "trash") }.buttonStyle(.plain)
                        }
                    }
                    .padding(AppTheme.horizontalPadding(for: selectedTheme))
                    .padding(.bottom, 28)
                }
            }
            .navigationTitle(selectedTheme == .design2 ? "" : "Settings")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar(selectedTheme == .design2 ? .hidden : .visible, for: .navigationBar)
            .accessibilityIdentifier(AccessibilityID.settingsScreen)
        }
    }
}

struct Theme3SettingsHeader: View {
    var body: some View {
        VStack(alignment: .leading, spacing: 7) {
            Text("FIELD DECK / CONFIG")
                .font(.caption2.weight(.heavy))
                .tracking(1.5)
                .foregroundStyle(AppTheme.accent(for: .design3))
            Text("iWorkOrder Settings")
                .font(.title2.weight(.heavy))
                .foregroundStyle(AppTheme.textPrimary(for: .design3))
            Text("Profile, storage, security, workflow, privacy, and support.")
                .font(.subheadline)
                .foregroundStyle(AppTheme.textSecondary(for: .design3))
        }
        .frame(maxWidth: .infinity, alignment: .leading)
        .padding(16)
        .background(Color(red: 0.045, green: 0.075, blue: 0.080), in: RoundedRectangle(cornerRadius: 10, style: .continuous))
        .overlay(alignment: .top) {
            Rectangle().fill(AppTheme.accent(for: .design3)).frame(height: 3).padding(.horizontal, 12)
        }
        .accessibilityIdentifier("theme.design3.settings")
    }
}

struct Theme3SettingsGroup<Content: View>: View {
    let title: String
    @ViewBuilder var content: Content

    var body: some View {
        VStack(alignment: .leading, spacing: 7) {
            Text(title)
                .font(.caption2.weight(.heavy))
                .tracking(1.4)
                .foregroundStyle(AppTheme.accent(for: .design3))
                .padding(.horizontal, 2)
            VStack(spacing: 0) {
                content
            }
            .padding(.horizontal, 12)
            .padding(.vertical, 6)
            .background(Color(red: 0.052, green: 0.080, blue: 0.084), in: RoundedRectangle(cornerRadius: 9, style: .continuous))
            .overlay(RoundedRectangle(cornerRadius: 9, style: .continuous).stroke(Color.white.opacity(0.065), lineWidth: 1))
        }
    }
}

struct CloudView: View {
    @EnvironmentObject private var store: AppStore

    var body: some View {
        Form {
            Section("Cloud") {
                Toggle("Use iCloud Sync", isOn: Binding(
                    get: { store.profile.iCloudEnabled && store.profile.storageChoice == .iCloud },
                    set: { enabled in
                        Task { @MainActor in
                            await Task.yield()
                            store.setICloudEnabled(enabled)
                        }
                    }
                ))

#if DEBUG
                Toggle("Pause Cloud Sync for Recovery", isOn: Binding(
                    get: { store.cloudSyncPausedForRecovery },
                    set: { paused in
                        Task { @MainActor in
                            await Task.yield()
                            store.setCloudSyncPausedForRecovery(paused)
                        }
                    }
                ))
                .accessibilityIdentifier(AccessibilityID.cloudRecoveryPause)

                Text("Recovery pause blocks ordinary CloudKit upload, download, and manual re-sync while keeping local work orders editable. Pending verified backup replacement or cloud deletion transactions are still allowed to finish.")
                    .font(.caption)
                    .foregroundStyle(.secondary)
#endif

                InfoLine(title: "Sync Status", value: store.cloudSyncState.title)
                InfoLine(title: "Network", value: store.isOnline ? "Online" : "Offline")
                InfoLine(title: "Last Successful Sync", value: store.lastSynced?.shortDateTime ?? "Never")

                Text(store.cloudSyncDetail)
                    .font(.caption)
                    .foregroundStyle(store.cloudSyncState == .offline || store.cloudSyncState == .paused || store.cloudSyncState == .noAccount || store.cloudSyncState == .restricted ? Color.orange : Color.secondary)

                if let disabled = store.profile.iCloudDisabledDate, !store.profile.iCloudEnabled {
                    Text("iCloud was turned off on \(disabled.shortDateTime). Data is saving locally on this device.")
                        .font(.caption)
                        .foregroundStyle(.orange)
                }

                Button(store.cloud.isCloudReplacementPending() ? "Complete Backup Replacement" : "Sync Now") {
                    Task { await store.syncNow() }
                }
                .disabled((!store.profile.iCloudEnabled && !store.cloud.isCloudReplacementPending()) || (!store.cloud.isCloudReplacementPending() && store.cloudSyncPausedForRecovery) || !store.isOnline || store.cloudSyncState.isBusy)

                Button("Re-sync from iCloud") { Task { await store.resyncFromICloud() } }
                    .disabled(!store.profile.iCloudEnabled || store.cloud.isCloudReplacementPending() || store.cloudSyncPausedForRecovery || !store.isOnline || store.cloudSyncState.isBusy)
            }
        }
        .themedScrollableBackground()
        .navigationTitle("Cloud")
    }
}

struct ExportBackupView: View {
    @EnvironmentObject private var store: AppStore
    @State private var shareURL: URL?
    @State private var isImporterPresented = false
    @State private var isWorking = false
    @State private var statusMessage: String?
    @State private var restoreCandidate: BackupRestoreCandidate?
    @State private var showRestoreOptions = false
    @State private var totalLocalStorageText = "Calculating..."
    @State private var safetyBackupsStorageText = "Calculating..."
    @State private var latestSafetyBackupURL: URL?

    var body: some View {
        Form {
            Section("Portable Backup") {
                LegalBanner(kind: .export)
                Text("A full backup contains the app snapshot, work orders, revisions, assets, tenant contacts, photos, signatures, and integrity metadata in one verified .iworkorderbackup file.")
                    .font(.caption)
                    .foregroundStyle(.secondary)

                Button {
                    exportBackup()
                } label: {
                    Label("Export Full Backup", systemImage: "externaldrive.badge.plus")
                }
                .disabled(isWorking)

                Button {
                    isImporterPresented = true
                } label: {
                    Label("Restore Backup File", systemImage: "arrow.counterclockwise.circle")
                }
                .disabled(isWorking)

                Button {
                    restoreLatestSafetyBackup()
                } label: {
                    Label("Restore Latest Safety Backup", systemImage: "clock.arrow.circlepath")
                }
                .disabled(isWorking || latestSafetyBackupURL == nil)

                if isWorking {
                    HStack(spacing: 10) {
                        ProgressView()
                        Text("Processing backup data...")
                            .font(.caption)
                            .foregroundStyle(.secondary)
                    }
                }

                if let statusMessage {
                    Text(statusMessage)
                        .font(.caption)
                        .foregroundStyle(store.lastErrorMessage == nil ? Color.secondary : Color.red)
                        .textSelection(.enabled)
                }
            }

            Section("Storage") {
                InfoLine(title: "Total Local Storage", value: totalLocalStorageText)
                InfoLine(title: "Restore Safety Backups", value: safetyBackupsStorageText)
                Text("Before any restore, iWorkOrder creates a verified local safety backup and retains the three newest safety copies.")
                    .font(.caption)
                    .foregroundStyle(.secondary)
            }
        }
        .themedScrollableBackground()
        .navigationTitle("Export & Backup")
        .task {
            await refreshStorageSummary()
        }
        .onChange(of: isWorking) { _, working in
            if !working {
                Task { await refreshStorageSummary() }
            }
        }
        .fileImporter(
            isPresented: $isImporterPresented,
            allowedContentTypes: [.data, .json],
            allowsMultipleSelection: false
        ) { result in
            switch result {
            case .success(let urls):
                guard let url = urls.first else { return }
                inspectBackup(url)
            case .failure(let error):
                statusMessage = "Backup selection failed: \(error.localizedDescription)"
            }
        }
        .confirmationDialog(
            "Restore Verified Backup",
            isPresented: $showRestoreOptions,
            presenting: restoreCandidate
        ) { candidate in
            Button("Merge with Current Data") {
                restore(candidate, mode: .merge)
            }
            Button("Replace Current Data", role: .destructive) {
                restore(candidate, mode: .replace)
            }
            Button("Cancel", role: .cancel) {
                store.discardBackupCandidate(candidate)
                restoreCandidate = nil
            }
        } message: { candidate in
            let warningText = candidate.warnings.isEmpty
                ? "All archive checks passed."
                : candidate.warnings.joined(separator: " ")
            Text("\(candidate.sourceFormat.rawValue): \(candidate.summary). \(warningText) A safety backup is created before either restore option.")
        }
        .sheet(item: Binding(get: {
            shareURL.map { IdentifiableURL(url: $0) }
        }, set: { _ in
            shareURL = nil
        })) { wrappedURL in
            ShareSheet(items: [wrappedURL.url])
        }
    }

    private func refreshStorageSummary() async {
        let summary = await Task.detached(priority: .utility) {
            (
                StorageService().localDataSizeText(),
                ByteCountFormatter.string(
                    fromByteCount: BackupArchiveService.safetyBackupsSize(),
                    countStyle: .file
                ),
                BackupArchiveService.latestSafetyBackupURL()
            )
        }.value
        guard !Task.isCancelled else { return }
        totalLocalStorageText = summary.0
        safetyBackupsStorageText = summary.1
        latestSafetyBackupURL = summary.2
    }

    private func exportBackup() {
        Task {
            isWorking = true
            statusMessage = nil
            defer { isWorking = false }
            if let result = await store.exportFullBackup() {
                shareURL = result.url
                let counts = result.manifest.counts
                statusMessage = "Backup verified: \(counts.workOrders) work order(s), \(counts.photos) photo(s), and \(counts.signatures) signature(s)."
            } else {
                statusMessage = store.lastErrorMessage ?? "Backup export failed."
            }
        }
    }

    private func restoreLatestSafetyBackup() {
        guard let url = latestSafetyBackupURL else {
            statusMessage = "No pre-restore safety backup is available."
            return
        }
        inspectBackup(url)
    }

    private func inspectBackup(_ url: URL) {
        Task {
            isWorking = true
            statusMessage = nil
            defer { isWorking = false }
            if let candidate = await store.inspectBackup(at: url) {
                restoreCandidate = candidate
                showRestoreOptions = true
                statusMessage = "Backup verification passed. Choose Merge or Replace."
            } else {
                statusMessage = store.lastErrorMessage ?? "Backup validation failed."
            }
        }
    }

    private func restore(_ candidate: BackupRestoreCandidate, mode: BackupRestoreMode) {
        Task {
            isWorking = true
            statusMessage = nil
            defer {
                isWorking = false
                restoreCandidate = nil
            }
            if let result = await store.restoreBackup(candidate, mode: mode) {
                let action = result.mode == .merge ? "merged" : "replaced"
                let warnings = result.warningCount == 0
                    ? ""
                    : " \(result.warningCount) restore warning(s) were recorded."
                statusMessage = "Backup restored. Current data was \(action) using \(result.restoredCounts.workOrders) work order(s). A verified pre-restore safety backup was retained.\(warnings)"
            } else {
                statusMessage = store.lastErrorMessage ?? "Backup restore failed. Current data was preserved."
            }
        }
    }
}

@MainActor
struct SecurityView: View {
    @EnvironmentObject private var store: AppStore
    @EnvironmentObject private var appLock: AppLockState
    private let security = SecurityService()
    @State private var isUpdatingSecurity = false

    var body: some View {
        Form {
            Toggle(
                "Lock app with Face ID or Passcode",
                isOn: Binding(
                    get: { store.profile.faceIDEnabled },
                    set: { enabled in
                        Task { @MainActor in
                            await Task.yield()
                            updateSecuritySetting(enabled)
                        }
                    }
                )
            )
            .disabled(isUpdatingSecurity)

            Text("When enabled, iWorkOrder locks whenever it enters the background. Returning to the app requires Face ID, Touch ID, or the device passcode.")
                .font(.caption)
                .foregroundStyle(.secondary)
        }
        .themedScrollableBackground()
        .navigationTitle("Security")
    }

    private func updateSecuritySetting(_ enabled: Bool) {
        guard !isUpdatingSecurity, enabled != store.profile.faceIDEnabled else { return }
        isUpdatingSecurity = true
        if !enabled {
            let previousProfile = store.profile
            store.profile.faceIDEnabled = false
            if store.save() {
                appLock.unlock()
            } else {
                store.profile = previousProfile
            }
            isUpdatingSecurity = false
            return
        }

        Task {
            let authenticated = await security.authenticate(reason: "Enable app lock")
            await MainActor.run {
                defer { isUpdatingSecurity = false }
                guard authenticated else { return }
                let previousProfile = store.profile
                store.profile.faceIDEnabled = true
                if store.save() {
                    appLock.unlock()
                } else {
                    store.profile = previousProfile
                }
            }
        }
    }
}

@MainActor
struct NotificationSettingsView: View {
    @EnvironmentObject private var store: AppStore
    @State private var showDenied = false
    @State private var isUpdatingNotifications = false

    var body: some View {
        Form {
            Section("Notifications") {
                Toggle("Allow Work Order Notifications", isOn: Binding(
                    get: { store.profile.notificationsEnabled },
                    set: { enabled in
                        Task { @MainActor in
                            await Task.yield()
                            updateNotificationsEnabled(enabled)
                        }
                    }
                ))
                .disabled(isUpdatingNotifications)

                Toggle("Emergency Follow-up Notifications", isOn: Binding(
                    get: { store.profile.emergencyNotificationsEnabled },
                    set: { enabled in
                        Task { @MainActor in
                            await Task.yield()
                            updateEmergencyNotificationsEnabled(enabled)
                        }
                    }
                ))
                .disabled(!store.profile.notificationsEnabled || isUpdatingNotifications)

                Text("Turning notifications off cancels pending reminders and removes delivered iWorkOrder notifications from Notification Center. Emergency follow-ups are scheduled only when both controls are enabled.")
                    .font(.caption)
                    .foregroundStyle(.secondary)

                if store.notificationPermissionNeedsAttention && store.profile.notificationsEnabled {
                    Label("Notification permission is not enabled on this device. Enable notifications in device Settings to receive iWorkOrder alerts here.", systemImage: "exclamationmark.triangle.fill")
                        .font(.caption)
                        .foregroundStyle(.orange)
                }
            }
        }
        .themedScrollableBackground()
        .navigationTitle("Notifications")
        .alert("Notifications Not Enabled", isPresented: $showDenied) {
            Button("OK", role: .cancel) {}
        } message: {
            Text("Notification permission was not granted. You can enable it later in device Settings.")
        }
    }

    private func updateNotificationsEnabled(_ enabled: Bool) {
        guard !isUpdatingNotifications, enabled != store.profile.notificationsEnabled else { return }
        if !enabled {
            let previousProfile = store.profile
            store.profile.notificationsEnabled = false
            _ = store.applyNotificationPreferences(previousProfile: previousProfile)
            return
        }

        isUpdatingNotifications = true
        Task {
            defer { isUpdatingNotifications = false }
            let granted = await store.notifications.requestPermission()
            guard !Task.isCancelled else { return }
            if granted {
                let previousProfile = store.profile
                store.profile.notificationsEnabled = true
                _ = store.applyNotificationPreferences(previousProfile: previousProfile)
            } else {
                // Keep the previously persisted app preference. A denial belongs
                // to this device and must not disable notifications on other synced devices.
                showDenied = true
            }
            await store.refreshNotificationAuthorization()
        }
    }

    private func updateEmergencyNotificationsEnabled(_ enabled: Bool) {
        guard !isUpdatingNotifications, enabled != store.profile.emergencyNotificationsEnabled else { return }
        let previousProfile = store.profile
        store.profile.emergencyNotificationsEnabled = enabled
        _ = store.applyNotificationPreferences(previousProfile: previousProfile)
    }
}

struct ThemeSettingsView: View {
    @AppStorage(AppTheme.storageKey) private var selectedThemeRaw = VisualTheme.defaultTheme.rawValue

    private var selectedTheme: VisualTheme {
        VisualTheme(rawValue: selectedThemeRaw) ?? .defaultTheme
    }

    var body: some View {
        ScreenBackground {
            SwiftUI.ScrollView(.vertical, showsIndicators: true) {
                VStack(alignment: .leading, spacing: 16) {
                    SectionHeader(title: "Themes", subtitle: "Each choice has its own layout language. Switch instantly and compare the previews below.")

                    ForEach(VisualTheme.allCases) { theme in
                        Button {
                            applyTheme(theme)
                        } label: {
                            ThemeOptionCard(theme: theme, isSelected: theme == selectedTheme)
                                .environment(\.colorScheme, theme == .design3 ? .dark : .light)
                        }
                        .buttonStyle(.plain)
                        .accessibilityIdentifier("theme.\(theme.rawValue)")
                        .accessibilityValue(theme == selectedTheme ? "Selected" : "Not selected")
                    }
                }
                .padding(AppTheme.horizontalPadding(for: selectedTheme))
                .padding(.bottom, 28)
            }
        }
        .navigationTitle("Themes")
        .navigationBarTitleDisplayMode(.inline)
        .toolbar(.visible, for: .navigationBar)
        .accessibilityIdentifier("screen.themes")
    }

    private func applyTheme(_ theme: VisualTheme) {
        guard theme != selectedTheme else { return }
        var transaction = Transaction()
        transaction.disablesAnimations = true
        withTransaction(transaction) {
            selectedThemeRaw = theme.rawValue
        }
    }
}

struct ThemeOptionCard: View {
    @Environment(\.accessibilityReduceTransparency) private var reduceTransparency
    let theme: VisualTheme
    let isSelected: Bool

    var body: some View {
        HStack(spacing: 14) {
            ThemePreview(theme: theme)

            VStack(alignment: .leading, spacing: 5) {
                HStack(spacing: 8) {
                    Text(theme.title)
                        .font(theme == .design2 ? .system(.headline, design: .monospaced).weight(.black) : .headline)
                        .foregroundStyle(AppTheme.textPrimary(for: theme))
                    Text(identityTag)
                        .font(.caption2.weight(.black))
                        .tracking(0.8)
                        .foregroundStyle(AppTheme.accent(for: theme))
                        .padding(.horizontal, 7)
                        .padding(.vertical, 4)
                        .background(AppTheme.accent(for: theme).opacity(0.10), in: Capsule())
                }
                Text(theme.subtitle)
                    .font(.caption)
                    .foregroundStyle(AppTheme.textSecondary(for: theme))
                    .multilineTextAlignment(.leading)
                    .fixedSize(horizontal: false, vertical: true)
            }

            Spacer(minLength: 8)
            Image(systemName: isSelected ? "checkmark.circle.fill" : "circle")
                .font(.title3)
                .foregroundStyle(isSelected ? AppTheme.accent(for: theme) : AppTheme.textSecondary(for: theme).opacity(0.55))
        }
        .padding(theme == .design2 ? 13 : 15)
        .background(
            AppTheme.cardFill(reduceTransparency: reduceTransparency, theme: theme),
            in: RoundedRectangle(cornerRadius: AppTheme.corner(for: theme), style: .continuous)
        )
        .overlay(
            RoundedRectangle(cornerRadius: AppTheme.corner(for: theme), style: .continuous)
                .stroke(isSelected ? AppTheme.accent(for: theme) : AppTheme.cardStroke(for: theme), lineWidth: isSelected ? 2 : 1)
        )
        .overlay(alignment: .leading) {
            if theme == .design2 {
                Capsule()
                    .fill(AppTheme.accent(for: .design2))
                    .frame(width: 3)
                    .padding(.vertical, 11)
                    .offset(x: 5)
                    .accessibilityHidden(true)
            }
        }
        .shadow(color: AppTheme.cardShadow(for: theme), radius: theme == .design2 ? 7 : 13, x: 0, y: 5)
    }

    private var identityTag: String {
        switch theme {
        case .defaultTheme: return "SYSTEM"
        case .design2: return "COMMAND"
        case .design3: return "FIELD"
        }
    }
}

struct ThemePreview: View {
    let theme: VisualTheme

    var body: some View {
        ZStack {
            RoundedRectangle(cornerRadius: theme == .design2 ? 12 : 18, style: .continuous)
                .fill(previewGradient)

            switch theme {
            case .defaultTheme:
                VStack(spacing: 6) {
                    HStack(spacing: 5) {
                        previewBlock(.blue, width: 24)
                        previewBlock(.orange, width: 18)
                        Spacer(minLength: 0)
                    }
                    HStack(spacing: 5) {
                        previewRow(.blue.opacity(0.42))
                        previewRow(.orange.opacity(0.35))
                    }
                    previewRow(.gray.opacity(0.22))
                }
                .padding(10)
            case .design2:
                VStack(spacing: 6) {
                    HStack {
                        Capsule().fill(Color.cyan).frame(width: 30, height: 4)
                        Spacer()
                        Circle().fill(Color.green).frame(width: 6, height: 6)
                    }
                    HStack(spacing: 5) {
                        commandTile()
                        commandTile()
                        commandTile()
                    }
                    HStack(spacing: 4) {
                        Capsule().fill(Color.white.opacity(0.70)).frame(height: 5)
                        Capsule().fill(Color.cyan.opacity(0.80)).frame(width: 18, height: 5)
                    }
                }
                .padding(9)
            case .design3:
                VStack(spacing: 6) {
                    HStack {
                        Rectangle().fill(AppTheme.accent(for: .design3)).frame(width: 24, height: 3)
                        Spacer()
                        Circle().fill(Color.green).frame(width: 6, height: 6)
                    }
                    HStack(spacing: 5) {
                        RoundedRectangle(cornerRadius: 3).fill(AppTheme.accent(for: .design3)).frame(width: 18, height: 18)
                        RoundedRectangle(cornerRadius: 3).fill(Color.white.opacity(0.10)).frame(height: 18)
                        RoundedRectangle(cornerRadius: 3).fill(Color.orange.opacity(0.55)).frame(width: 18, height: 18)
                    }
                    HStack(spacing: 4) {
                        Rectangle().fill(Color.white.opacity(0.18)).frame(height: 5)
                        Rectangle().fill(AppTheme.accent(for: .design3).opacity(0.72)).frame(width: 24, height: 5)
                    }
                }
                .padding(9)
            }
        }
        .frame(width: 92, height: 70)
        .overlay(
            RoundedRectangle(cornerRadius: theme == .design2 ? 12 : 18, style: .continuous)
                .stroke(theme == .design2 ? Color.cyan.opacity(0.24) : Color.white.opacity(0.62), lineWidth: 1)
        )
        .accessibilityHidden(true)
    }

    private var previewGradient: LinearGradient {
        switch theme {
        case .defaultTheme:
            return LinearGradient(colors: [Color(.systemGroupedBackground), Color.blue.opacity(0.22), Color.orange.opacity(0.17)], startPoint: .topLeading, endPoint: .bottomTrailing)
        case .design2:
            return LinearGradient(colors: [Color(red: 0.035, green: 0.055, blue: 0.10), Color(red: 0.02, green: 0.32, blue: 0.62)], startPoint: .topLeading, endPoint: .bottomTrailing)
        case .design3:
            return LinearGradient(colors: [Color(red: 0.035, green: 0.055, blue: 0.060), Color(red: 0.035, green: 0.16, blue: 0.14)], startPoint: .topLeading, endPoint: .bottomTrailing)
        }
    }

    private func previewBlock(_ color: Color, width: CGFloat) -> some View {
        RoundedRectangle(cornerRadius: 5, style: .continuous)
            .fill(color.opacity(0.42))
            .frame(width: width, height: 18)
    }

    private func previewRow(_ color: Color) -> some View {
        RoundedRectangle(cornerRadius: 5, style: .continuous)
            .fill(color)
            .frame(maxWidth: .infinity)
            .frame(height: 12)
    }

    private func commandTile() -> some View {
        RoundedRectangle(cornerRadius: 4, style: .continuous)
            .fill(Color.white.opacity(0.18))
            .frame(maxWidth: .infinity)
            .frame(height: 19)
            .overlay(alignment: .bottomLeading) {
                Capsule().fill(Color.cyan.opacity(0.72)).frame(width: 12, height: 3).padding(4)
            }
    }
}

struct CategoryManagerView: View {
    @EnvironmentObject private var store: AppStore
    @State private var showAddCategory = false
    @State private var newCategoryName = ""
    @State private var pendingDeleteCategories: [WorkOrderCategory] = []
    @State private var showDeleteConfirmation = false
    @State private var errorMessage: String?

    var body: some View {
        List {
            Section {
                ForEach(store.categories) { category in
                    HStack(spacing: 12) {
                        Image(systemName: "line.3.horizontal")
                            .foregroundStyle(.secondary)
                            .accessibilityHidden(true)
                        VStack(alignment: .leading, spacing: 3) {
                            Text(category.rawValue)
                            if store.categoryUsageCount(category) > 0 {
                                Text("Used by \(store.categoryUsageCount(category)) work order\(store.categoryUsageCount(category) == 1 ? "" : "s")")
                                    .font(.caption)
                                    .foregroundStyle(.secondary)
                            }
                        }
                    }
                    .accessibilityElement(children: .combine)
                    .accessibilityIdentifier("category.row.\(category.rawValue)")
                }
                .onMove { source, destination in
                    if !store.moveCategories(from: source, to: destination) {
                        errorMessage = store.lastErrorMessage ?? "The category order could not be saved."
                    }
                }
                .onDelete { offsets in
                    pendingDeleteCategories = offsets.compactMap { index in
                        store.categories.indices.contains(index) ? store.categories[index] : nil
                    }
                    showDeleteConfirmation = !pendingDeleteCategories.isEmpty
                }
            } header: {
                Text("Available Categories")
            } footer: {
                Text("Changes are used by new-work-order forms and category filters throughout the app. Deleting a category removes it from future selection but preserves the category already recorded on existing work orders.")
            }
        }
        .themedScrollableBackground()
        .navigationTitle("Categories")
        .toolbar {
            ToolbarItemGroup(placement: .topBarTrailing) {
                EditButton()
                    .accessibilityIdentifier("category.edit")
                Button {
                    newCategoryName = ""
                    showAddCategory = true
                } label: {
                    Image(systemName: "plus")
                }
                .accessibilityLabel("Add category")
                .accessibilityIdentifier("category.add")
            }
        }
        .alert("Add Category", isPresented: $showAddCategory) {
            TextField("Category name", text: $newCategoryName)
                .textInputAutocapitalization(.words)
            Button("Cancel", role: .cancel) {
                newCategoryName = ""
            }
            Button("Add") {
                if !store.addCategory(named: newCategoryName) {
                    errorMessage = store.lastErrorMessage ?? "The category could not be added."
                }
                newCategoryName = ""
            }
        } message: {
            Text("Enter a unique category name.")
        }
        .confirmationDialog(
            "Delete Category?",
            isPresented: $showDeleteConfirmation,
            titleVisibility: .visible
        ) {
            Button("Delete", role: .destructive) {
                if !store.deleteCategories(pendingDeleteCategories) {
                    errorMessage = store.lastErrorMessage ?? "The category could not be deleted."
                }
                pendingDeleteCategories = []
            }
            Button("Cancel", role: .cancel) {
                pendingDeleteCategories = []
            }
        } message: {
            Text(deleteConfirmationMessage)
        }
        .alert("Category Manager", isPresented: Binding(
            get: { errorMessage != nil },
            set: { if !$0 { errorMessage = nil } }
        )) {
            Button("OK", role: .cancel) { errorMessage = nil }
        } message: {
            Text(errorMessage ?? "The category change could not be saved.")
        }
    }

    private var deleteConfirmationMessage: String {
        let usageCount = pendingDeleteCategories.reduce(0) { $0 + store.categoryUsageCount($1) }
        if usageCount > 0 {
            return "This removes the category from future selection. \(usageCount) existing work order\(usageCount == 1 ? "" : "s") will keep the recorded category."
        }
        return "This removes the category from work-order forms and filters."
    }
}

struct DataPrivacyView: View {
    @EnvironmentObject private var store: AppStore
    @State private var result = ""

    var body: some View {
        Form {
            Section("Purge Old Data") {
                Text("Deletes photos and redacts names for work orders older than the selected retention window, while keeping core descriptions and audit history.")
                    .font(.caption)
                    .foregroundStyle(.secondary)
                Button("Purge Older Than 3 Years") {
                    result = "Purged \(store.purgeOldData(years: 3)) photo(s)."
                }
                Button("Purge Older Than 7 Years") {
                    result = "Purged \(store.purgeOldData(years: 7)) photo(s)."
                }
                if !result.isEmpty {
                    Text(result).foregroundStyle(.green)
                }
            }
        }
        .themedScrollableBackground()
        .navigationTitle("Data Privacy")
    }
}

struct SupportDiagnosticsView: View {
    @EnvironmentObject private var store: AppStore
    @State private var shareURL: URL?
    @State private var mailDraft: MailDraft?
    @State private var statusMessage: String?
    @State private var localStorageText = "Calculating..."

    var body: some View {
        Form {
            Section("App Status") {
                InfoLine(title: "Version", value: AppBuildInfo.displayVersion)
                InfoLine(title: "Cloud", value: store.cloudSyncState.title)
                InfoLine(title: "Network", value: store.isOnline ? "Available" : "Unavailable")
                InfoLine(title: "Last Successful Sync", value: store.lastSynced?.shortDateTime ?? "Never")
                InfoLine(title: "Local Storage", value: localStorageText)
            }

            Section("Support Package") {
                Text("If support asks for it, you can create a privacy-safe support package containing limited technical status and integrity information. It excludes names, property details, tenant contacts, work-order descriptions and notes, audit text, filenames, photos, and signatures.")
                    .font(.caption)
                    .foregroundStyle(.secondary)

                Button {
                    exportSupportBundle()
                } label: {
                    Label("Create Support Package", systemImage: "shippingbox.and.arrow.backward")
                }
                .accessibilityIdentifier(AccessibilityID.exportSupportPackage)

                Button {
                    emailSupport()
                } label: {
                    Label("Email Support", systemImage: "envelope.badge")
                }
                .accessibilityIdentifier(AccessibilityID.emailSupport)

                if let statusMessage {
                    Text(statusMessage)
                        .font(.caption)
                        .foregroundStyle(.secondary)
                        .textSelection(.enabled)
                }
            }

            Section("Support") {
                InfoLine(title: "Email", value: LegalContent.supportEmail)
                Text("Review the support package before sharing it. Nothing is sent automatically; sharing requires an action from you through Mail or the iOS share sheet.")
                    .font(.caption)
                    .foregroundStyle(.secondary)
            }
        }
        .themedScrollableBackground()
        .navigationTitle("Support")
        .accessibilityIdentifier(AccessibilityID.supportScreen)
        .task {
            let value = await Task.detached(priority: .utility) {
                StorageService().localDataSizeText()
            }.value
            guard !Task.isCancelled else { return }
            localStorageText = value
        }
        .sheet(item: Binding(
            get: { shareURL.map { IdentifiableURL(url: $0) } },
            set: { _ in shareURL = nil }
        )) { item in
            ShareSheet(items: [item.url])
        }
        .sheet(item: $mailDraft) { draft in
            if MFMailComposeViewController.canSendMail() {
                MailComposerView(draft: draft)
            } else {
                ShareSheet(items: [draft.shareText] + draft.attachmentURLs)
            }
        }
    }

    private func exportSupportBundle() {
        do {
            let url = try store.writeSupportBundle()
            statusMessage = "Verified support bundle created: \(url.lastPathComponent)"
            shareURL = url
        } catch {
            statusMessage = (error as? LocalizedError)?.errorDescription ?? error.localizedDescription
        }
    }

    private func emailSupport() {
        do {
            let url = try store.writeSupportBundle()
            mailDraft = EmailHelper.supportDraft(diagnosticsURL: url)
            statusMessage = "A verified privacy-safe support bundle is ready to review and send."
        } catch {
            statusMessage = (error as? LocalizedError)?.errorDescription ?? error.localizedDescription
            mailDraft = EmailHelper.supportDraft()
        }
    }
}

#if DEBUG
struct MaintenanceRecoveryView: View {
    @EnvironmentObject private var store: AppStore
    @State private var report: MaintenanceHealthReport?
    @State private var shareURL: URL?
    @State private var statusMessage: String?
    @State private var confirmClearHistory = false
    @State private var reliability = RuntimeReliabilityService.summary()

    var body: some View {
        Form {
            Section("Release Health") {
                InfoLine(title: "Version", value: AppBuildInfo.displayVersion)
                InfoLine(title: "Current Data Schema", value: String(AppDataSchema.currentVersion))
                InfoLine(title: "Stored Data Schema", value: report.map { String($0.snapshotSchemaVersion) } ?? "Not checked")
                InfoLine(title: "Last Known Good Build", value: report?.lastKnownGoodBuild ?? "Not recorded")
                InfoLine(title: "Possible Interrupted Sessions (7 Days)", value: String(reliability.interruptedSessionCount7Days))
                InfoLine(title: "Memory Warnings (7 Days)", value: String(reliability.memoryWarningCount7Days))
                InfoLine(title: "Current Session Memory Warnings", value: String(reliability.currentSessionMemoryWarningCount))
                if reliability.previousSessionPossiblyInterrupted {
                    Text("The prior session did not reach a background checkpoint. This can result from a force quit, restart, operating-system termination, or application failure; it is not proof of a crash.")
                        .font(.caption)
                        .foregroundStyle(.orange)
                }
                if let report {
                    InfoLine(title: "Health", value: report.isHealthy ? "Pass" : "Attention Required")
                    InfoLine(title: "Critical Issues", value: String(report.criticalIssueCount))
                    InfoLine(title: "Warnings", value: String(report.warningCount))
                }
            }

            Section("Integrity Check") {
                Text("The check compares data references with local photos and signatures, verifies revision identity, reviews migration and safety backups, and reports pending cloud replacement or deletion state.")
                    .font(.caption)
                    .foregroundStyle(.secondary)
                Button {
                    runHealthCheck()
                } label: {
                    Label("Run Maintenance Health Check", systemImage: "checkmark.shield")
                }
                .accessibilityIdentifier(AccessibilityID.runMaintenanceHealthCheck)

                if let report {
                    InfoLine(title: "Missing Photos", value: String(report.missingPhotoCount))
                    InfoLine(title: "Missing Signatures", value: String(report.missingSignatureCount))
                    InfoLine(title: "Orphan Photos", value: String(report.orphanPhotoCount))
                    InfoLine(title: "Orphan Signatures", value: String(report.orphanSignatureCount))
                    InfoLine(title: "Duplicate Revision IDs", value: String(report.duplicateRevisionIDCount))
                    InfoLine(title: "Empty Work Orders", value: String(report.emptyWorkOrderCount))
                    InfoLine(title: "Migration Recovery Copies", value: String(report.migrationBackupCount))
                    InfoLine(title: "Portable Safety Backups", value: String(report.safetyBackupCount))
                }
            }

            Section("Issue Containment") {
                Toggle("Pause Cloud Sync for Recovery", isOn: Binding(
                    get: { store.cloudSyncPausedForRecovery },
                    set: { enabled in
                        Task { @MainActor in
                            await Task.yield()
                            store.setCloudSyncPausedForRecovery(enabled)
                            reliability = RuntimeReliabilityService.summary()
                            report = store.runMaintenanceHealthCheck()
                        }
                    }
                ))
                .accessibilityIdentifier(AccessibilityID.cloudRecoveryPause)

                Text("Use this temporary pause when investigating a release or sync problem. Local saves remain enabled. Ordinary CloudKit synchronization is blocked until you turn the pause off. Pending cloud deletion and verified backup replacement transactions are not abandoned.")
                    .font(.caption)
                    .foregroundStyle(.secondary)
            }

            Section("Privacy-Safe Operational History") {
                Text("iWorkOrder retains up to 250 fixed-category events for 30 days on this device. Events contain outcomes, durations, schema versions, and aggregate counts only. No work-order text, names, addresses, contacts, filenames, images, signatures, or device identifiers are recorded.")
                    .font(.caption)
                    .foregroundStyle(.secondary)
                Button {
                    exportReport()
                } label: {
                    Label("Export Maintenance Report", systemImage: "square.and.arrow.up")
                }
                .accessibilityIdentifier(AccessibilityID.exportMaintenanceReport)

                Button("Clear Operational History", role: .destructive) {
                    confirmClearHistory = true
                }
                .accessibilityIdentifier(AccessibilityID.clearMaintenanceHistory)
            }

            if let statusMessage {
                Section("Status") {
                    Text(statusMessage)
                        .font(.caption)
                        .textSelection(.enabled)
                }
            }
        }
        .themedScrollableBackground()
        .navigationTitle("Maintenance & Recovery")
        .accessibilityIdentifier(AccessibilityID.maintenanceRecoveryScreen)
        .sheet(item: Binding(
            get: { shareURL.map { IdentifiableURL(url: $0) } },
            set: { _ in shareURL = nil }
        )) { item in
            ShareSheet(items: [item.url])
        }
        .confirmationDialog("Clear local operational history?", isPresented: $confirmClearHistory, titleVisibility: .visible) {
            Button("Clear History", role: .destructive) {
                store.clearMaintenanceHistory()
                statusMessage = "Operational history was cleared. A single history-cleared event was recorded."
                report = store.runMaintenanceHealthCheck()
            }
            Button("Cancel", role: .cancel) {}
        } message: {
            Text("This does not delete work orders, photos, signatures, backups, or CloudKit data.")
        }
        .onAppear {
            reliability = RuntimeReliabilityService.summary()
            report = store.runMaintenanceHealthCheck()
        }
    }

    private func runHealthCheck() {
        reliability = RuntimeReliabilityService.summary()
        report = store.runMaintenanceHealthCheck()
        statusMessage = report?.isHealthy == true
            ? "Health check passed. Review any warnings shown above."
            : "The health check found an issue that should be reviewed before the next release or restore."
    }

    private func exportReport() {
        do {
            let url = try store.writeMaintenanceReport()
            reliability = RuntimeReliabilityService.summary()
            report = store.runMaintenanceHealthCheck()
            statusMessage = "Maintenance report created: \(url.lastPathComponent)"
            shareURL = url
        } catch {
            statusMessage = (error as? LocalizedError)?.errorDescription ?? error.localizedDescription
        }
    }
}
#endif

struct LegalAboutView: View {
    @EnvironmentObject private var store: AppStore

    var body: some View {
        List {
            Section("Authoritative In-App Documents") {
                NavigationLink {
                    LegalDocumentView(title: "Privacy Policy", document: .privacy)
                } label: {
                    Label("Privacy Policy", systemImage: "hand.raised")
                }
                NavigationLink {
                    LegalDocumentView(title: "Terms & Conditions", document: .terms)
                } label: {
                    Label("Terms & Conditions", systemImage: "doc.text")
                }
                NavigationLink {
                    LegalDocumentView(title: "Data & Liability Disclaimer", document: .liability)
                } label: {
                    Label("Data & Liability Disclaimer", systemImage: "exclamationmark.shield")
                }
                HStack {
                    Text("Current legal version accepted")
                    Spacer()
                    Image(systemName: store.hasCurrentLegalAcceptance ? "checkmark.circle.fill" : "xmark.circle")
                        .foregroundStyle(store.hasCurrentLegalAcceptance ? .green : .red)
                }
            }

            Section("About") {
                InfoLine(title: "Version", value: AppBuildInfo.displayVersion)
                InfoLine(title: "Region", value: "United States only")
                InfoLine(title: "Legal Updated", value: LegalContent.effectiveDate)
                InfoLine(title: "Legal Version", value: LegalContent.currentVersion)
                Button("Email Support") {
                    EmailHelper.openSupportEmail()
                }
            }
        }
        .navigationTitle("Legal & About")
    }
}

enum LegalDocumentKind { case agreement, privacy, terms, liability }

struct LegalUpdateRequiredView: View {
    @EnvironmentObject private var store: AppStore
    @State private var stage: Stage = .splash
    @State private var declined = false

    private enum Stage {
        case splash
        case agreement
    }

    var body: some View {
        Group {
            switch stage {
            case .splash:
                LegalUpdateSplashView {
                    stage = .agreement
                }
            case .agreement:
                NavigationStack {
                    LegalDocumentView(
                        title: "Updated Legal Agreement",
                        document: .agreement,
                        showAccept: true,
                        accept: {
                            store.acceptCurrentLegalAgreement()
                            declined = false
                        },
                        decline: {
                            store.declineLegalAgreement()
                            declined = true
                        }
                    )
                    .safeAreaInset(edge: .bottom) {
                        if declined {
                            Text("Normal app access remains disabled until the current legal version is accepted.")
                                .font(.caption)
                                .foregroundStyle(.secondary)
                                .multilineTextAlignment(.center)
                                .padding(.horizontal)
                                .padding(.bottom, 8)
                        }
                    }
                }
            }
        }
    }
}

struct LegalUpdateSplashView: View {
    @AppStorage(AppTheme.storageKey) private var selectedThemeRaw = VisualTheme.defaultTheme.rawValue
    let review: () -> Void
    private var selectedTheme: VisualTheme { VisualTheme(rawValue: selectedThemeRaw) ?? .defaultTheme }

    var body: some View {
        ZStack {
            LinearGradient(
                colors: [Color.black, Color(red: 0.04, green: 0.08, blue: 0.16)],
                startPoint: .top,
                endPoint: .bottom
            )
            .ignoresSafeArea()

            SwiftUI.ScrollView(.vertical, showsIndicators: true) {
                VStack(spacing: 22) {
                    Spacer(minLength: 42)

                    Image(systemName: "doc.badge.clock")
                        .font(.largeTitle.weight(.semibold))
                        .foregroundStyle(.white)
                        .accessibilityHidden(true)

                    VStack(spacing: 8) {
                        Text("Legal Terms Updated")
                            .font(.largeTitle.bold())
                            .foregroundStyle(.white)
                            .multilineTextAlignment(.center)

                        Text("Effective \(LegalContent.effectiveDate)")
                            .font(.headline)
                            .foregroundStyle(.white.opacity(0.82))

                        Text("Legal version \(LegalContent.currentVersion)")
                            .font(.caption.monospaced())
                            .foregroundStyle(.white.opacity(0.68))
                    }

                    VStack(alignment: .leading, spacing: 12) {
                        Text("What changed")
                            .font(.headline)
                            .foregroundStyle(.white)

                        ForEach(LegalContent.updateSummary, id: \.self) { item in
                            HStack(alignment: .top, spacing: 10) {
                                Image(systemName: "checkmark.circle.fill")
                                    .foregroundStyle(.green)
                                    .padding(.top, 2)
                                Text(item)
                                    .font(.subheadline)
                                    .foregroundStyle(.white.opacity(0.9))
                                    .fixedSize(horizontal: false, vertical: true)
                            }
                        }
                    }
                    .padding(18)
                    .frame(maxWidth: .infinity, alignment: .leading)
                    .background(.white.opacity(0.09), in: RoundedRectangle(cornerRadius: 18, style: .continuous))
                    .overlay(
                        RoundedRectangle(cornerRadius: 18, style: .continuous)
                            .stroke(.white.opacity(0.12), lineWidth: 1)
                    )

                    Text("You must review and accept the current Privacy Policy, Terms & Conditions, and Data & Liability Disclaimer before normal app access can continue.")
                        .font(.subheadline)
                        .foregroundStyle(.white.opacity(0.82))
                        .multilineTextAlignment(.center)
                        .fixedSize(horizontal: false, vertical: true)

                    Button(action: review) {
                        Label("Review Updated Legal Terms", systemImage: "doc.text.magnifyingglass")
                            .font(.headline)
                            .frame(maxWidth: .infinity)
                            .padding(.vertical, 12)
                    }
                    .buttonStyle(.borderedProminent)
                    .controlSize(.large)
                    .accessibilityIdentifier(AccessibilityID.legalUpdateReview)

                    Spacer(minLength: 28)
                }
                .frame(maxWidth: 640)
                .padding(.horizontal, AppTheme.horizontalPadding(for: selectedTheme))
            }
        }
        .accessibilityIdentifier(AccessibilityID.legalUpdateSplash)
    }
}

struct LegalDocumentView: View {
    @AppStorage(AppTheme.storageKey) private var selectedThemeRaw = VisualTheme.defaultTheme.rawValue
    @Environment(\.dismiss) private var dismiss
    let title: String
    let document: LegalDocumentKind
    var showAccept: Bool = false
    var accept: (() -> Void)? = nil
    var decline: (() -> Void)? = nil

    private var selectedTheme: VisualTheme { VisualTheme(rawValue: selectedThemeRaw) ?? .defaultTheme }

    var body: some View {
        ScreenBackground {
            SwiftUI.ScrollView(.vertical, showsIndicators: true) {
                VStack(alignment: .leading, spacing: 16) {
                    Text(title).font(.largeTitle.weight(.bold))
                    LegalBanner(kind: .privacy)
                    ModernCard {
                        Text(text)
                            .font(.body)
                            .textSelection(.enabled)
                            .frame(maxWidth: .infinity, alignment: .leading)
                    }
                    if showAccept {
                        Button {
                            accept?()
                        } label: {
                            Label("I Understand and Agree", systemImage: "checkmark.circle.fill")
                                .frame(maxWidth: .infinity)
                                .padding(.vertical, 12)
                        }
                        .buttonStyle(.borderedProminent)
                        .disabled(accept == nil)
                        .accessibilityIdentifier("legal.accept")

                        Button(role: .cancel) {
                            if let decline { decline() } else { dismiss() }
                        } label: {
                            Text("I Do Not Agree").frame(maxWidth: .infinity)
                        }
                        .buttonStyle(.bordered)
                        .accessibilityIdentifier("legal.decline")
                    }
                }
                .padding(AppTheme.horizontalPadding(for: selectedTheme))
            }
        }
        .navigationTitle(title)
        .navigationBarTitleDisplayMode(.inline)
    }

    private var text: String {
        switch document {
        case .agreement: return LegalContent.agreement
        case .privacy: return LegalContent.privacy
        case .terms: return LegalContent.terms
        case .liability: return LegalContent.liability
        }
    }
}

struct TrashView: View {
    @EnvironmentObject private var store: AppStore
    @Environment(\.accessibilityReduceTransparency) private var reduceTransparency
    @State private var showReset = false
    @State private var erasing = false
    @State private var progress: Double = 0

    var body: some View {
        List {
            Section("Deleted Work Orders") {
                Button("Recover All") { store.recoverAll() }
                    .disabled(store.trash.isEmpty)

                ForEach(store.trash) { order in
                    HStack {
                        VStack(alignment: .leading, spacing: 4) {
                            Text(order.latestEntry.area).font(.headline)
                            Text(order.title).foregroundStyle(.secondary)
                        }
                        Spacer()
                        Button("Recover") { store.recover(order) }
                    }
                }
            }

            Section("Erase All Data & Reset") {
                Button(role: .destructive) { showReset = true } label: {
                    Text("Erase All Data & Reset")
                }
            }
        }
        .themedScrollableBackground()
        .navigationTitle("Trash")
        .confirmationDialog("Erase All Data & Reset", isPresented: $showReset) {
            Button("Reset - Restart onboarding, keep data") {
                store.resetOnboardingOnly()
            }
            Button("Erase all data", role: .destructive) {
                erasing = true
                progress = 1
                store.eraseAllData()
            }
            Button("Cancel", role: .cancel) {}
        } message: {
            Text("Reset restarts onboarding without deleting data. Erase all data deletes local and iCloud app data.")
        }
        .overlay {
            if erasing {
                VStack(spacing: 12) {
                    ProgressView(value: progress)
                    Text("Deleting all app data...")
                }
                .padding()
                .background(
                    reduceTransparency
                        ? AnyShapeStyle(Color(.secondarySystemBackground))
                        : AnyShapeStyle(.regularMaterial),
                    in: RoundedRectangle(cornerRadius: 18)
                )
            }
        }
    }
}
