import Foundation
import UIKit

struct DiagnosticReportContext: Equatable, Sendable {
    var generatedAt: Date
    var appVersion: String
    var systemName: String
    var systemVersion: String
    var deviceFamily: String
    var localeIdentifier: String
    var timeZoneIdentifier: String
    var storageMode: String
    var iCloudEnabled: Bool
    var cloudState: String
    var networkAvailable: Bool
    var lastSuccessfulSync: Date?
    var cloudReplacementPending: Bool
    var cloudErasePending: Bool
    var cloudSyncPausedForRecovery: Bool
    var possibleInterruptedSessionCount7Days: Int
    var memoryPressureCount7Days: Int
    var currentSessionMemoryWarningCount: Int
    var notificationsEnabled: Bool
    var emergencyNotificationsEnabled: Bool
    var appLockEnabled: Bool
    var activeWorkOrderCount: Int
    var deletedWorkOrderCount: Int
    var revisionCount: Int
    var photoReferenceCount: Int
    var signatureReferenceCount: Int
    var assetCount: Int
    var tenantCount: Int
    var localStorageUsage: String
    var legalVersion: String
    var legalAcceptanceCurrent: Bool
    var backupOperationActive: Bool
    var recentErrorPresent: Bool
}

enum DiagnosticReportError: LocalizedError {
    case unableToEncode

    var errorDescription: String? {
        switch self {
        case .unableToEncode:
            return "The privacy-safe diagnostics report could not be created."
        }
    }
}

enum DiagnosticReportService {
    static let formatVersion = 1

    @MainActor
    static func context(for store: AppStore, generatedAt: Date = Date()) -> DiagnosticReportContext {
        let allEntries = store.workOrders.flatMap(\.entries)
        let reliability = RuntimeReliabilityService.summary(at: generatedAt)
        return DiagnosticReportContext(
            generatedAt: generatedAt,
            appVersion: AppBuildInfo.displayVersion,
            systemName: UIDevice.current.systemName,
            systemVersion: UIDevice.current.systemVersion,
            deviceFamily: UIDevice.current.model,
            localeIdentifier: Locale.current.identifier,
            timeZoneIdentifier: TimeZone.current.identifier,
            storageMode: store.profile.storageChoice.rawValue,
            iCloudEnabled: store.profile.iCloudEnabled,
            cloudState: store.cloudSyncState.title,
            networkAvailable: store.isOnline,
            lastSuccessfulSync: store.lastSynced,
            cloudReplacementPending: store.cloud.isCloudReplacementPending(),
            cloudErasePending: store.cloud.isCloudErasePending(),
            cloudSyncPausedForRecovery: reliability.cloudSyncPausedForRecovery,
            possibleInterruptedSessionCount7Days: reliability.interruptedSessionCount7Days,
            memoryPressureCount7Days: reliability.memoryWarningCount7Days,
            currentSessionMemoryWarningCount: reliability.currentSessionMemoryWarningCount,
            notificationsEnabled: store.profile.notificationsEnabled,
            emergencyNotificationsEnabled: store.profile.emergencyNotificationsEnabled,
            appLockEnabled: store.profile.faceIDEnabled,
            activeWorkOrderCount: store.activeWorkOrders.count,
            deletedWorkOrderCount: store.trash.count,
            revisionCount: allEntries.count,
            photoReferenceCount: allEntries.reduce(0) { $0 + $1.images.count },
            signatureReferenceCount: allEntries.reduce(0) { $0 + ($1.signatureFilename == nil ? 0 : 1) },
            assetCount: store.assets.count,
            tenantCount: store.tenants.count,
            localStorageUsage: StorageService().localDataSizeText(),
            legalVersion: LegalContent.currentVersion,
            legalAcceptanceCurrent: store.hasCurrentLegalAcceptance,
            backupOperationActive: store.isBackupOperationInProgress,
            recentErrorPresent: store.lastErrorMessage != nil
        )
    }

    static func reportText(for context: DiagnosticReportContext) -> String {
        let iso = ISO8601DateFormatter()
        iso.formatOptions = [.withInternetDateTime, .withFractionalSeconds]

        func yesNo(_ value: Bool) -> String { value ? "Yes" : "No" }
        func dateText(_ value: Date?) -> String { value.map(iso.string(from:)) ?? "Never" }

        return [
            "iWorkOrder Privacy-Safe Diagnostics",
            "Format Version: \(formatVersion)",
            "Generated: \(iso.string(from: context.generatedAt))",
            "",
            "Application",
            "Version: \(context.appVersion)",
            "Legal Version: \(context.legalVersion)",
            "Current Legal Acceptance: \(yesNo(context.legalAcceptanceCurrent))",
            "",
            "Device Environment",
            "Operating System: \(context.systemName) \(context.systemVersion)",
            "Device Family: \(context.deviceFamily)",
            "Locale: \(context.localeIdentifier)",
            "Time Zone: \(context.timeZoneIdentifier)",
            "",
            "Storage and Cloud",
            "Storage Mode: \(context.storageMode)",
            "iCloud Enabled: \(yesNo(context.iCloudEnabled))",
            "Cloud State: \(context.cloudState)",
            "Network Available: \(yesNo(context.networkAvailable))",
            "Last Successful Sync: \(dateText(context.lastSuccessfulSync))",
            "Cloud Replacement Pending: \(yesNo(context.cloudReplacementPending))",
            "Cloud Erase Pending: \(yesNo(context.cloudErasePending))",
            "Cloud Sync Paused for Recovery: \(yesNo(context.cloudSyncPausedForRecovery))",
            "Local Storage Usage: \(context.localStorageUsage)",
            "Backup Operation Active: \(yesNo(context.backupOperationActive))",
            "",
            "Security and Notifications",
            "App Lock Enabled: \(yesNo(context.appLockEnabled))",
            "Notifications Enabled: \(yesNo(context.notificationsEnabled))",
            "Emergency Notifications Enabled: \(yesNo(context.emergencyNotificationsEnabled))",
            "",
            "Runtime Reliability",
            "Possible Interrupted Sessions in Last 7 Days: \(context.possibleInterruptedSessionCount7Days)",
            "Memory-Pressure Warnings in Last 7 Days: \(context.memoryPressureCount7Days)",
            "Current Session Memory Warnings: \(context.currentSessionMemoryWarningCount)",
            "",
            "Record Counts",
            "Active Work Orders: \(context.activeWorkOrderCount)",
            "Deleted Work Orders: \(context.deletedWorkOrderCount)",
            "Revisions: \(context.revisionCount)",
            "Photo References: \(context.photoReferenceCount)",
            "Signature References: \(context.signatureReferenceCount)",
            "Assets: \(context.assetCount)",
            "Tenant Records: \(context.tenantCount)",
            "Recent Error Present: \(yesNo(context.recentErrorPresent))",
            "",
            "Privacy Notice",
            "This report intentionally excludes names, company and building details, tenant contact information, work-order descriptions and notes, audit text, photo and signature contents, filenames, and the app's internal device identifier.",
            ""
        ].joined(separator: "\n")
    }

    @MainActor
    static func writeReport(for store: AppStore, generatedAt: Date = Date()) throws -> URL {
        try writeReport(context: context(for: store, generatedAt: generatedAt))
    }

    static func writeReport(context: DiagnosticReportContext) throws -> URL {
        guard let data = reportText(for: context).data(using: .utf8) else {
            throw DiagnosticReportError.unableToEncode
        }

        let formatter = DateFormatter()
        formatter.locale = Locale(identifier: "en_US_POSIX")
        formatter.timeZone = TimeZone(secondsFromGMT: 0)
        formatter.dateFormat = "yyyyMMdd-HHmmss"

        let directory = FileManager.default.temporaryDirectory
            .appendingPathComponent("iWorkOrderDiagnostics", isDirectory: true)
        try FileManager.default.createDirectory(at: directory, withIntermediateDirectories: true)

        if let existing = try? FileManager.default.contentsOfDirectory(
            at: directory,
            includingPropertiesForKeys: nil,
            options: [.skipsHiddenFiles]
        ) {
            for url in existing where url.pathExtension.lowercased() == "txt" {
                try? FileManager.default.removeItem(at: url)
            }
        }

        let output = directory.appendingPathComponent(
            "iWorkOrder-Diagnostics-\(formatter.string(from: context.generatedAt)).txt"
        )
        try data.write(to: output, options: [.atomic, .completeFileProtectionUntilFirstUserAuthentication])
        return output
    }
}
