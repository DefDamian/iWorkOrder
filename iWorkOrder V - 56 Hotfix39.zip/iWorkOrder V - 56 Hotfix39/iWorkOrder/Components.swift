import SwiftUI

enum VisualTheme: String, CaseIterable, Identifiable {
    case defaultTheme
    case design2
    case design3

    var id: String { rawValue }

    var title: String {
        switch self {
        case .defaultTheme: return "Default Theme"
        case .design2: return "Design 2"
        case .design3: return "Design 3"
        }
    }

    var subtitle: String {
        switch self {
        case .defaultTheme: return "Current polished iWorkOrder layout."
        case .design2: return "Focused command-center layout with compact operational summaries."
        case .design3: return "Dark field-deck layout with graphite panels, mint status rails, and high-contrast work cards."
        }
    }
}

struct AppTheme {
    static let storageKey = "selectedVisualTheme"

    static var selected: VisualTheme {
        get {
            let raw = UserDefaults.standard.string(forKey: storageKey) ?? VisualTheme.defaultTheme.rawValue
            return VisualTheme(rawValue: raw) ?? .defaultTheme
        }
        set {
            guard UserDefaults.standard.string(forKey: storageKey) != newValue.rawValue else { return }
            UserDefaults.standard.set(newValue.rawValue, forKey: storageKey)
        }
    }

    static func corner(for theme: VisualTheme) -> CGFloat {
        switch theme {
        case .defaultTheme: return 24
        case .design2: return 16
        case .design3: return 10
        }
    }
    static var corner: CGFloat { corner(for: selected) }

    static func smallCorner(for theme: VisualTheme) -> CGFloat {
        switch theme {
        case .defaultTheme: return 16
        case .design2: return 12
        case .design3: return 8
        }
    }
    static var smallCorner: CGFloat { smallCorner(for: selected) }

    static func horizontalPadding(for theme: VisualTheme) -> CGFloat {
        switch theme {
        case .defaultTheme: return 20
        case .design2: return 16
        case .design3: return 16
        }
    }
    static var horizontalPadding: CGFloat { horizontalPadding(for: selected) }

    static func accent(for theme: VisualTheme) -> Color {
        switch theme {
        case .defaultTheme: return .blue
        case .design2: return Color(red: 0.03, green: 0.45, blue: 0.93)
        case .design3: return Color(red: 0.34, green: 0.94, blue: 0.72)
        }
    }
    static var accent: Color { accent(for: selected) }

    static func textPrimary(for theme: VisualTheme) -> Color {
        switch theme {
        case .defaultTheme: return .primary
        case .design2: return Color(red: 0.06, green: 0.08, blue: 0.13)
        case .design3: return Color(red: 0.93, green: 0.98, blue: 0.96)
        }
    }
    static var textPrimary: Color { textPrimary(for: selected) }

    static func textSecondary(for theme: VisualTheme) -> Color {
        switch theme {
        case .defaultTheme: return .secondary
        case .design2: return Color(red: 0.25, green: 0.30, blue: 0.38)
        case .design3: return Color(red: 0.61, green: 0.70, blue: 0.68)
        }
    }
    static var textSecondary: Color { textSecondary(for: selected) }

    static func background(for theme: VisualTheme) -> LinearGradient {
        switch theme {
        case .defaultTheme:
            return LinearGradient(
                colors: [Color(.systemGroupedBackground), Color.blue.opacity(0.08), Color.orange.opacity(0.07)],
                startPoint: .topLeading,
                endPoint: .bottomTrailing
            )
        case .design2:
            return LinearGradient(
                colors: [
                    Color(red: 0.91, green: 0.94, blue: 0.98),
                    Color(red: 0.96, green: 0.98, blue: 1.0),
                    Color(red: 0.88, green: 0.96, blue: 0.98)
                ],
                startPoint: .topLeading,
                endPoint: .bottomTrailing
            )
        case .design3:
            return LinearGradient(
                colors: [
                    Color(red: 0.035, green: 0.055, blue: 0.060),
                    Color(red: 0.045, green: 0.085, blue: 0.090),
                    Color(red: 0.025, green: 0.060, blue: 0.058)
                ],
                startPoint: .topLeading,
                endPoint: .bottomTrailing
            )
        }
    }
    static var background: LinearGradient { background(for: selected) }

    static func cardFill(for theme: VisualTheme) -> AnyShapeStyle {
        switch theme {
        case .defaultTheme:
            return AnyShapeStyle(.regularMaterial)
        case .design2:
            return AnyShapeStyle(Color.white.opacity(0.985))
        case .design3:
            return AnyShapeStyle(Color(red: 0.060, green: 0.095, blue: 0.100).opacity(0.96))
        }
    }
    static var cardFill: AnyShapeStyle { cardFill(for: selected) }

    static func cardFill(reduceTransparency: Bool, theme: VisualTheme) -> AnyShapeStyle {
        guard reduceTransparency else { return cardFill(for: theme) }
        switch theme {
        case .defaultTheme:
            return AnyShapeStyle(Color(.secondarySystemGroupedBackground))
        case .design2:
            return AnyShapeStyle(Color.white)
        case .design3:
            return AnyShapeStyle(Color(red: 0.055, green: 0.085, blue: 0.090))
        }
    }
    static func cardFill(reduceTransparency: Bool) -> AnyShapeStyle { cardFill(reduceTransparency: reduceTransparency, theme: selected) }

    static func cardStroke(for theme: VisualTheme) -> Color {
        switch theme {
        case .defaultTheme: return .white.opacity(0.32)
        case .design2: return Color(red: 0.07, green: 0.11, blue: 0.18).opacity(0.10)
        case .design3: return Color(red: 0.34, green: 0.94, blue: 0.72).opacity(0.22)
        }
    }
    static var cardStroke: Color { cardStroke(for: selected) }

    static func cardShadow(for theme: VisualTheme) -> Color {
        switch theme {
        case .defaultTheme: return .black.opacity(0.08)
        case .design2: return Color(red: 0.05, green: 0.09, blue: 0.16).opacity(0.10)
        case .design3: return Color.black.opacity(0.32)
        }
    }
    static var cardShadow: Color { cardShadow(for: selected) }

    static func heroGradient(for theme: VisualTheme) -> LinearGradient {
        switch theme {
        case .defaultTheme:
            return LinearGradient(colors: [Color(.secondarySystemBackground), Color(.secondarySystemBackground)], startPoint: .topLeading, endPoint: .bottomTrailing)
        case .design2:
            return LinearGradient(
                colors: [
                    Color(red: 0.035, green: 0.055, blue: 0.10),
                    Color(red: 0.055, green: 0.12, blue: 0.22),
                    Color(red: 0.02, green: 0.44, blue: 0.78)
                ],
                startPoint: .topLeading,
                endPoint: .bottomTrailing
            )
        case .design3:
            return LinearGradient(
                colors: [
                    Color(red: 0.045, green: 0.085, blue: 0.090),
                    Color(red: 0.035, green: 0.18, blue: 0.16),
                    Color(red: 0.20, green: 0.66, blue: 0.52)
                ],
                startPoint: .topLeading,
                endPoint: .bottomTrailing
            )
        }
    }
    static var heroGradient: LinearGradient { heroGradient(for: selected) }

    static func usesLegacyHero(for theme: VisualTheme) -> Bool { theme == .design2 }
    static var usesLegacyHero: Bool { usesLegacyHero(for: selected) }

    static func legacyTitleFont(for theme: VisualTheme) -> Font {
        switch theme {
        case .defaultTheme: return .title2.weight(.bold)
        case .design2: return .system(.largeTitle, design: .monospaced).weight(.black)
        case .design3: return .system(.largeTitle, design: .default).weight(.heavy)
        }
    }
    static var legacyTitleFont: Font { legacyTitleFont(for: selected) }

    static func statusTint(_ status: WorkOrderStatus) -> Color {
        switch status {
        case .new: return .blue
        case .pending: return .orange
        case .inProgress: return .purple
        case .completed: return .green
        }
    }

    static func statusIcon(_ status: WorkOrderStatus) -> String {
        switch status {
        case .new: return "sparkles"
        case .pending: return "clock"
        case .inProgress: return "hammer.fill"
        case .completed: return "checkmark.seal.fill"
        }
    }
}

struct ScreenBackground<Content: View>: View {
    @AppStorage(AppTheme.storageKey) private var selectedThemeRaw = VisualTheme.defaultTheme.rawValue
    @ViewBuilder var content: Content

    private var selectedTheme: VisualTheme { VisualTheme(rawValue: selectedThemeRaw) ?? .defaultTheme }

    var body: some View {
        ZStack {
            AppTheme.background(for: selectedTheme).ignoresSafeArea()

            switch selectedTheme {
            case .defaultTheme:
                EmptyView()
            case .design2:
                Rectangle()
                    .fill(
                        LinearGradient(
                            colors: [Color(red: 0.03, green: 0.08, blue: 0.15).opacity(0.10), Color.clear],
                            startPoint: .top,
                            endPoint: .bottom
                        )
                    )
                    .frame(height: 190)
                    .frame(maxHeight: .infinity, alignment: .top)
                    .ignoresSafeArea()
                    .accessibilityHidden(true)
                Circle()
                    .fill(Color.blue.opacity(0.13))
                    .frame(width: 290, height: 290)
                    .blur(radius: 62)
                    .offset(x: -165, y: -330)
                    .accessibilityHidden(true)
                Circle()
                    .fill(Color.cyan.opacity(0.13))
                    .frame(width: 330, height: 330)
                    .blur(radius: 72)
                    .offset(x: 185, y: 300)
                    .accessibilityHidden(true)
            case .design3:
                VStack(spacing: 27) {
                    ForEach(0..<24, id: \.self) { _ in
                        Rectangle()
                            .fill(Color.white.opacity(0.028))
                            .frame(height: 1)
                    }
                }
                .ignoresSafeArea()
                .accessibilityHidden(true)
                HStack(spacing: 27) {
                    ForEach(0..<16, id: \.self) { _ in
                        Rectangle()
                            .fill(AppTheme.accent(for: .design3).opacity(0.022))
                            .frame(width: 1)
                    }
                }
                .ignoresSafeArea()
                .accessibilityHidden(true)
                LinearGradient(
                    colors: [AppTheme.accent(for: .design3).opacity(0.11), Color.clear],
                    startPoint: .topTrailing,
                    endPoint: .center
                )
                .ignoresSafeArea()
                .accessibilityHidden(true)
            }

            content
        }
    }
}

struct ModernCard<Content: View>: View {
    @Environment(\.accessibilityReduceTransparency) private var reduceTransparency
    @AppStorage(AppTheme.storageKey) private var selectedThemeRaw = VisualTheme.defaultTheme.rawValue
    var padding: CGFloat = 16
    @ViewBuilder var content: Content

    private var selectedTheme: VisualTheme { VisualTheme(rawValue: selectedThemeRaw) ?? .defaultTheme }
    private var radius: CGFloat { AppTheme.corner(for: selectedTheme) }

    var body: some View {
        content
            .frame(maxWidth: .infinity, alignment: .leading)
            .padding(padding)
            .background(
                AppTheme.cardFill(reduceTransparency: reduceTransparency, theme: selectedTheme),
                in: RoundedRectangle(cornerRadius: radius, style: .continuous)
            )
            .overlay(
                RoundedRectangle(cornerRadius: radius, style: .continuous)
                    .stroke(AppTheme.cardStroke(for: selectedTheme), lineWidth: selectedTheme == .design2 ? 1.2 : 1)
            )
            .overlay(alignment: .leading) {
                if selectedTheme == .design2 {
                    Capsule()
                        .fill(AppTheme.accent(for: .design2))
                        .frame(width: 3)
                        .padding(.vertical, 12)
                        .offset(x: 5)
                        .accessibilityHidden(true)
                }
            }
            .overlay(alignment: .top) {
                if selectedTheme == .design3 {
                    Rectangle()
                        .fill(AppTheme.accent(for: .design3).opacity(0.78))
                        .frame(height: 2)
                        .padding(.horizontal, 12)
                        .accessibilityHidden(true)
                }
            }
            .shadow(
                color: AppTheme.cardShadow(for: selectedTheme),
                radius: selectedTheme == .design2 ? 8 : (selectedTheme == .design3 ? 10 : 16),
                x: 0,
                y: selectedTheme == .design2 ? 4 : (selectedTheme == .design3 ? 5 : 8)
            )
    }
}



struct LegalBanner: View {
    @AppStorage(AppTheme.storageKey) private var selectedThemeRaw = VisualTheme.defaultTheme.rawValue

    private var selectedTheme: VisualTheme { VisualTheme(rawValue: selectedThemeRaw) ?? .defaultTheme }

    enum Kind {
        case privacy
        case audit
        case export
        case signature

        var icon: String {
            switch self {
            case .privacy: return "lock.shield"
            case .audit: return "checkmark.seal"
            case .export: return "doc.text.magnifyingglass"
            case .signature: return "signature"
            }
        }

        var title: String {
            switch self {
            case .privacy: return "Private iCloud storage"
            case .audit: return "Audit record notice"
            case .export: return "Export and backup notice"
            case .signature: return "Electronic signature notice"
            }
        }

        var message: String {
            switch self {
            case .privacy:
                return "iWorkOrder stores app data on this device and, when enabled, in the user's iCloud account. The developer does not run an external work-order server."
            case .audit:
                return "Work-order changes are timestamped in the audit log to help preserve a maintenance record. Review entries before saving."
            case .export:
                return "PDF exports and portable backups may contain names, property details, photos, signatures, and audit records. Verify the contents and store shared files securely."
            case .signature:
                return "By signing, the signer confirms the work-order record and agrees the signature may be used as an electronic signature for this document."
            }
        }
    }

    let kind: Kind

    var body: some View {
        HStack(alignment: .top, spacing: 10) {
            Image(systemName: kind.icon)
                .font(.subheadline.weight(.semibold))
                .foregroundStyle(.orange)
                .frame(width: 22)
            VStack(alignment: .leading, spacing: 3) {
                Text(kind.title)
                    .font(.caption.weight(.bold))
                    .foregroundStyle(AppTheme.textPrimary(for: selectedTheme))
                Text(kind.message)
                    .font(.caption2)
                    .foregroundStyle(AppTheme.textSecondary(for: selectedTheme))
                    .fixedSize(horizontal: false, vertical: true)
            }
        }
        .padding(12)
        .frame(maxWidth: .infinity, alignment: .leading)
        .background(Color.orange.opacity(selectedTheme == .defaultTheme ? 0.10 : 0.08), in: RoundedRectangle(cornerRadius: 16, style: .continuous))
        .overlay(RoundedRectangle(cornerRadius: 16, style: .continuous).stroke(Color.orange.opacity(0.18), lineWidth: 1))
        .accessibilityElement(children: .combine)
    }
}

struct SectionHeader: View {
    @AppStorage(AppTheme.storageKey) private var selectedThemeRaw = VisualTheme.defaultTheme.rawValue
    let title: String
    var subtitle: String? = nil

    private var selectedTheme: VisualTheme { VisualTheme(rawValue: selectedThemeRaw) ?? .defaultTheme }

    var body: some View {
        Group {
            switch selectedTheme {
            case .defaultTheme:
                VStack(alignment: .leading, spacing: 4) {
                    Text(title)
                        .font(.title3.weight(.semibold))
                        .foregroundStyle(AppTheme.textPrimary(for: selectedTheme))
                    if let subtitle {
                        Text(subtitle)
                            .font(.subheadline)
                            .foregroundStyle(AppTheme.textSecondary(for: selectedTheme))
                    }
                }
            case .design2:
                HStack(alignment: .top, spacing: 10) {
                    RoundedRectangle(cornerRadius: 2, style: .continuous)
                        .fill(AppTheme.accent(for: .design2))
                        .frame(width: 4, height: subtitle == nil ? 24 : 42)
                        .accessibilityHidden(true)
                    VStack(alignment: .leading, spacing: 3) {
                        Text(title.uppercased())
                            .font(.system(.caption, design: .monospaced).weight(.black))
                            .tracking(1.8)
                            .foregroundStyle(AppTheme.textPrimary(for: selectedTheme))
                        if let subtitle {
                            Text(subtitle)
                                .font(.caption)
                                .foregroundStyle(AppTheme.textSecondary(for: selectedTheme))
                        }
                    }
                }
            case .design3:
                HStack(alignment: .top, spacing: 10) {
                    RoundedRectangle(cornerRadius: 2, style: .continuous)
                        .fill(AppTheme.accent(for: .design3))
                        .frame(width: 5, height: subtitle == nil ? 28 : 48)
                        .accessibilityHidden(true)
                    VStack(alignment: .leading, spacing: 4) {
                        Text("FIELD / \(title.uppercased())")
                            .font(.caption.weight(.heavy))
                            .tracking(1.4)
                            .foregroundStyle(AppTheme.accent(for: .design3))
                        if let subtitle {
                            Text(subtitle)
                                .font(.subheadline.weight(.medium))
                                .foregroundStyle(AppTheme.textSecondary(for: selectedTheme))
                        }
                    }
                }
            }
        }
        .frame(maxWidth: .infinity, alignment: .leading)
        .accessibilityElement(children: .combine)
        .accessibilityAddTraits(.isHeader)
    }
}

private struct ActionButtonLabel: View {
    let title: String
    let systemImage: String
    @ScaledMetric(relativeTo: .headline) private var minimumHeight: CGFloat = 54

    var body: some View {
        Label {
            Text(title)
                .multilineTextAlignment(.center)
                .lineLimit(3)
                .fixedSize(horizontal: false, vertical: true)
        } icon: {
            Image(systemName: systemImage)
        }
        .font(.headline.weight(.semibold))
        .frame(maxWidth: .infinity, minHeight: minimumHeight)
        .contentShape(Rectangle())
    }
}

struct PrimaryActionButton: View {
    @AppStorage(AppTheme.storageKey) private var selectedThemeRaw = VisualTheme.defaultTheme.rawValue
    let title: String
    let systemImage: String
    let action: () -> Void

    private var selectedTheme: VisualTheme { VisualTheme(rawValue: selectedThemeRaw) ?? .defaultTheme }

    var body: some View {
        Button(action: action) {
            ActionButtonLabel(title: title, systemImage: systemImage)
        }
        .buttonStyle(.borderedProminent)
        .accessibilityLabel(Text(title))
        .controlSize(.regular)
        .clipShape(RoundedRectangle(cornerRadius: AppTheme.smallCorner(for: selectedTheme), style: .continuous))
    }
}

struct SecondaryActionButton: View {
    @AppStorage(AppTheme.storageKey) private var selectedThemeRaw = VisualTheme.defaultTheme.rawValue
    let title: String
    let systemImage: String
    let action: () -> Void

    private var selectedTheme: VisualTheme { VisualTheme(rawValue: selectedThemeRaw) ?? .defaultTheme }

    var body: some View {
        Button(action: action) {
            ActionButtonLabel(title: title, systemImage: systemImage)
        }
        .buttonStyle(.bordered)
        .accessibilityLabel(Text(title))
        .controlSize(.regular)
        .clipShape(RoundedRectangle(cornerRadius: AppTheme.smallCorner(for: selectedTheme), style: .continuous))
    }
}

struct StatusBadge: View {
    let status: WorkOrderStatus

    var body: some View {
        HStack(spacing: 5) {
            Image(systemName: AppTheme.statusIcon(status))
                .font(.caption.weight(.bold))
            Text(status.rawValue)
                .lineLimit(1)
        }
        .font(.caption.weight(.semibold))
        .foregroundStyle(AppTheme.statusTint(status))
        .padding(.horizontal, 10)
        .padding(.vertical, 6)
        .fixedSize(horizontal: true, vertical: false)
        .background(AppTheme.statusTint(status).opacity(0.11), in: Capsule())
        .overlay(Capsule().stroke(AppTheme.statusTint(status).opacity(0.10), lineWidth: 1))
        .accessibilityElement(children: .ignore)
        .accessibilityLabel("Status")
        .accessibilityValue(status.rawValue)
    }
}

struct MetricTile: View {
    @AppStorage(AppTheme.storageKey) private var selectedThemeRaw = VisualTheme.defaultTheme.rawValue
    let title: String
    let value: String
    let icon: String
    var tint: Color = .blue

    private var selectedTheme: VisualTheme { VisualTheme(rawValue: selectedThemeRaw) ?? .defaultTheme }

    var body: some View {
        ModernCard(padding: selectedTheme == .design2 ? 12 : 14) {
            switch selectedTheme {
            case .defaultTheme:
                VStack(alignment: .leading, spacing: 12) {
                    metricIcon(shape: .roundedSquare)
                    Text(value)
                        .font(.title2.weight(.bold))
                        .foregroundStyle(AppTheme.textPrimary(for: selectedTheme))
                    Text(title)
                        .font(.caption)
                        .foregroundStyle(AppTheme.textSecondary(for: selectedTheme))
                        .lineLimit(2)
                }
                .frame(maxWidth: .infinity, alignment: .leading)
            case .design2:
                HStack(spacing: 12) {
                    Image(systemName: icon)
                        .font(.headline.weight(.bold))
                        .foregroundStyle(.white)
                        .frame(width: 38, height: 38)
                        .background(Color(red: 0.04, green: 0.09, blue: 0.16), in: RoundedRectangle(cornerRadius: 9, style: .continuous))
                    VStack(alignment: .leading, spacing: 2) {
                        Text(title.uppercased())
                            .font(.system(.caption2, design: .monospaced).weight(.black))
                            .tracking(1.1)
                            .foregroundStyle(AppTheme.textSecondary(for: selectedTheme))
                            .lineLimit(2)
                        Text(value)
                            .font(.system(.title2, design: .monospaced).weight(.black))
                            .foregroundStyle(AppTheme.textPrimary(for: selectedTheme))
                    }
                    Spacer(minLength: 0)
                }
            case .design3:
                HStack(alignment: .center, spacing: 12) {
                    Image(systemName: icon)
                        .font(.headline.weight(.heavy))
                        .foregroundStyle(Color(red: 0.03, green: 0.08, blue: 0.08))
                        .frame(width: 38, height: 38)
                        .background(AppTheme.accent(for: .design3), in: RoundedRectangle(cornerRadius: 7, style: .continuous))
                    VStack(alignment: .leading, spacing: 2) {
                        Text(value)
                            .font(.title2.weight(.heavy))
                            .foregroundStyle(AppTheme.textPrimary(for: selectedTheme))
                        Text(title.uppercased())
                            .font(.caption2.weight(.bold))
                            .tracking(0.8)
                            .foregroundStyle(AppTheme.textSecondary(for: selectedTheme))
                            .lineLimit(2)
                    }
                    Spacer(minLength: 0)
                }
            }
        }
        .accessibilityElement(children: .ignore)
        .accessibilityLabel(title)
        .accessibilityValue(value)
    }

    private enum IconShape { case roundedSquare, circle }

    @ViewBuilder
    private func metricIcon(shape: IconShape) -> some View {
        let iconView = Image(systemName: icon)
            .font(.title3.weight(.semibold))
            .foregroundStyle(selectedTheme == .design3 ? AppTheme.accent(for: .design3) : tint)
            .frame(width: 36, height: 36)

        switch shape {
        case .roundedSquare:
            iconView.background(tint.opacity(0.12), in: RoundedRectangle(cornerRadius: 10, style: .continuous))
        case .circle:
            iconView.background(AppTheme.accent(for: .design3).opacity(0.12), in: Circle())
        }
    }
}



struct SettingsRow: View {
    @AppStorage(AppTheme.storageKey) private var selectedThemeRaw = VisualTheme.defaultTheme.rawValue
    let title: String
    let subtitle: String
    let icon: String

    private var selectedTheme: VisualTheme { VisualTheme(rawValue: selectedThemeRaw) ?? .defaultTheme }

    var body: some View {
        HStack(spacing: selectedTheme == .design2 ? 10 : 12) {
            Group {
                switch selectedTheme {
                case .defaultTheme:
                    Image(systemName: icon)
                        .font(.headline)
                        .foregroundStyle(AppTheme.accent(for: selectedTheme))
                        .frame(width: 34, height: 34)
                        .background(AppTheme.accent(for: selectedTheme).opacity(0.14), in: RoundedRectangle(cornerRadius: 10, style: .continuous))
                case .design2:
                    Image(systemName: icon)
                        .font(.subheadline.weight(.bold))
                        .foregroundStyle(.white)
                        .frame(width: 34, height: 34)
                        .background(Color(red: 0.04, green: 0.09, blue: 0.16), in: RoundedRectangle(cornerRadius: 8, style: .continuous))
                case .design3:
                    Image(systemName: icon)
                        .font(.subheadline.weight(.heavy))
                        .foregroundStyle(Color(red: 0.03, green: 0.08, blue: 0.08))
                        .frame(width: 36, height: 36)
                        .background(AppTheme.accent(for: .design3), in: RoundedRectangle(cornerRadius: 7, style: .continuous))
                }
            }

            VStack(alignment: .leading, spacing: selectedTheme == .design2 ? 2 : 3) {
                Text(selectedTheme == .design2 ? title.uppercased() : title)
                    .font(selectedTheme == .design2 ? .system(.caption, design: .monospaced).weight(.black) : .subheadline.weight(.semibold))
                    .tracking(selectedTheme == .design2 ? 0.9 : 0)
                    .foregroundStyle(AppTheme.textPrimary(for: selectedTheme))
                Text(subtitle)
                    .font(.caption)
                    .foregroundStyle(AppTheme.textSecondary(for: selectedTheme))
                    .lineLimit(2)
            }

            Spacer(minLength: 8)
            Image(systemName: selectedTheme == .design3 ? "arrow.up.right" : "chevron.right")
                .font(selectedTheme == .design3 ? .caption.weight(.heavy) : .caption.weight(.bold))
                .foregroundStyle(selectedTheme == .design3 ? AppTheme.accent(for: .design3).opacity(0.82) : Color.secondary.opacity(0.65))
        }
        .contentShape(Rectangle())
        .accessibilityElement(children: .combine)
        .accessibilityLabel(Text(title))
        .accessibilityHint(Text(subtitle))
        .padding(.vertical, selectedTheme == .design2 ? 7 : (selectedTheme == .design3 ? 9 : 8))
    }
}

extension Date {
    var shortDateTime: String {
        formatted(date: .abbreviated, time: .shortened)
    }
}

// MARK: - Keyboard dismissal helpers
extension UIApplication {
    func dismissKeyboard() {
        sendAction(#selector(UIResponder.resignFirstResponder), to: nil, from: nil, for: nil)
    }
}

struct KeyboardDismissModifier: ViewModifier {
    func body(content: Content) -> some View {
        content
            .scrollDismissesKeyboard(.interactively)
            .toolbar {
                ToolbarItemGroup(placement: .keyboard) {
                    Spacer()
                    Button("Done") {
                        UIApplication.shared.dismissKeyboard()
                    }
                    .fontWeight(.semibold)
                }
            }
            .simultaneousGesture(
                TapGesture().onEnded {
                    UIApplication.shared.dismissKeyboard()
                }
            )
    }
}

extension View {
    func keyboardDismissable() -> some View {
        modifier(KeyboardDismissModifier())
    }
}


private struct AppInputFieldChromeModifier: ViewModifier {
    @Environment(\.accessibilityReduceTransparency) private var reduceTransparency

    func body(content: Content) -> some View {
        content
            .padding(.horizontal, 12)
            .padding(.vertical, 11)
            .background(
                reduceTransparency
                    ? AnyShapeStyle(Color(.secondarySystemBackground))
                    : AnyShapeStyle(.thinMaterial),
                in: RoundedRectangle(cornerRadius: 14, style: .continuous)
            )
            .overlay(
                RoundedRectangle(cornerRadius: 14, style: .continuous)
                    .stroke(reduceTransparency ? Color(.separator) : .white.opacity(0.18), lineWidth: 1)
            )
    }
}

extension View {
    func appInputFieldChrome() -> some View {
        modifier(AppInputFieldChromeModifier())
    }

    @ViewBuilder
    func appRoundedTextFieldStyle() -> some View {
        if #available(iOS 27.0, *) {
            self
                .textFieldStyle(.bordered)
                .textInputBorderShape(.roundedRectangle)
        } else {
            self.iOS26RoundedTextFieldStyle()
        }
    }

    @available(iOS, introduced: 26.0, obsoleted: 27.0)
    private func iOS26RoundedTextFieldStyle() -> some View {
        self.textFieldStyle(.roundedBorder)
    }
}

struct PriorityBadge: View {
    let priority: WorkOrderPriority
    var body: some View {
        HStack(spacing: 5) {
            Image(systemName: priority == .emergency ? "exclamationmark.octagon.fill" : "flag.fill")
                .font(.caption.weight(.bold))
            Text(priority.rawValue)
                .lineLimit(1)
        }
        .font(.caption.weight(.semibold))
        .foregroundStyle(tint)
        .padding(.horizontal, 10)
        .padding(.vertical, 6)
        .fixedSize(horizontal: true, vertical: false)
        .background(tint.opacity(0.11), in: Capsule())
        .overlay(Capsule().stroke(tint.opacity(0.10), lineWidth: 1))
        .accessibilityElement(children: .ignore)
        .accessibilityLabel("Priority")
        .accessibilityValue(priority.rawValue)
    }
    private var tint: Color {
        switch priority {
        case .emergency: return .red
        case .high: return .orange
        case .normal: return .blue
        case .low: return .gray
        }
    }
}

struct ShareSheet: UIViewControllerRepresentable {
    let items: [Any]
    func makeUIViewController(context: Context) -> UIActivityViewController { UIActivityViewController(activityItems: items, applicationActivities: nil) }
    func updateUIViewController(_ uiViewController: UIActivityViewController, context: Context) {}
}

struct InfoLine: View {
    @AppStorage(AppTheme.storageKey) private var selectedThemeRaw = VisualTheme.defaultTheme.rawValue
    let title: String
    let value: String

    private var selectedTheme: VisualTheme { VisualTheme(rawValue: selectedThemeRaw) ?? .defaultTheme }

    var body: some View {
        HStack(alignment: .top, spacing: 12) {
            Text(selectedTheme == .design2 ? title.uppercased() : title)
                .font(selectedTheme == .design2 ? .system(.caption, design: .monospaced).weight(.bold) : .subheadline)
                .tracking(selectedTheme == .design2 ? 0.8 : 0)
                .foregroundStyle(AppTheme.textSecondary(for: selectedTheme))
            Spacer()
            Text(value)
                .font(selectedTheme == .design3 ? .subheadline.weight(.semibold) : .subheadline)
                .foregroundStyle(AppTheme.textPrimary(for: selectedTheme))
                .multilineTextAlignment(.trailing)
        }
        .accessibilityElement(children: .ignore)
        .accessibilityLabel(title)
        .accessibilityValue(value)
    }
}


private struct ThemedScrollableBackgroundModifier: ViewModifier {
    @AppStorage(AppTheme.storageKey) private var selectedThemeRaw = VisualTheme.defaultTheme.rawValue

    private var selectedTheme: VisualTheme { VisualTheme(rawValue: selectedThemeRaw) ?? .defaultTheme }

    @ViewBuilder
    func body(content: Content) -> some View {
        if selectedTheme == .defaultTheme {
            content
        } else {
            content
                .scrollContentBackground(.hidden)
                .background(AppTheme.background(for: selectedTheme))
        }
    }
}

extension View {
    func themedScrollableBackground() -> some View {
        modifier(ThemedScrollableBackgroundModifier())
    }
}
