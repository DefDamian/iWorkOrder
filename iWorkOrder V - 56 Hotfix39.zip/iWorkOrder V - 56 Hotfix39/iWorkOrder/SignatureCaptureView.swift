import SwiftUI
import PencilKit

struct SignatureCaptureView: View {
    @Environment(\.dismiss) private var dismiss
    @EnvironmentObject private var store: AppStore
    @Binding var entry: WorkOrderEntry
    let onDone: () -> Bool
    @State private var drawing = PKDrawing()
    @State private var signerName = ""
    @State private var saveError: String?
    @State private var isSaving = false

    private var trimmedSignerName: String {
        signerName.trimmingCharacters(in: .whitespacesAndNewlines)
    }

    private var canSave: Bool {
        !isSaving && !drawing.strokes.isEmpty && !trimmedSignerName.isEmpty
    }

    var body: some View {
        NavigationStack {
            VStack(spacing: 12) {
                Text("Sign to mark this work order completed.")
                    .font(.headline)
                Text("The signer attests that this drawing applies to the current work-order revision. iWorkOrder does not verify identity, authority, or legal enforceability.")
                    .font(.caption)
                    .foregroundStyle(.secondary)
                    .multilineTextAlignment(.center)

                TextField("Signer full name", text: $signerName)
                    .textInputAutocapitalization(.words)
                    .autocorrectionDisabled()
                    .appRoundedTextFieldStyle()

                SignatureCanvas(drawing: $drawing)
                    .frame(minHeight: 220, idealHeight: 260, maxHeight: 360)
                    .clipShape(RoundedRectangle(cornerRadius: 18))
                    .overlay(RoundedRectangle(cornerRadius: 18).stroke(.secondary))
                    .accessibilityIdentifier("signature.canvas")

                Button("Clear Signature", role: .destructive) {
                    drawing = PKDrawing()
                }
                .buttonStyle(.bordered)
                .disabled(drawing.strokes.isEmpty)
                .accessibilityIdentifier("signature.clear")

                if drawing.strokes.isEmpty {
                    Text("Add a signature drawing before saving.")
                        .font(.caption)
                        .foregroundStyle(.secondary)
                }

                Button("Save Signature") {
                    saveSignature()
                }
                .accessibilityLabel("Save electronic signature attestation")
                .accessibilityHint("Saves the current drawing and signer name for this work-order revision")
                .accessibilityIdentifier("signature.save")
                .buttonStyle(.borderedProminent)
                .disabled(!canSave)
            }
            .padding()
            .navigationTitle("Completion Signature")
            .onAppear {
                if signerName.isEmpty {
                    signerName = entry.signatureSignerName ?? store.profile.personName
                }
            }
            .alert("Signature Not Saved", isPresented: Binding(
                get: { saveError != nil },
                set: { if !$0 { saveError = nil } }
            )) {
                Button("OK", role: .cancel) { saveError = nil }
            } message: {
                Text(saveError ?? "The signature could not be saved.")
            }
        }
    }

    private func saveSignature() {
        guard canSave else { return }
        isSaving = true
        let bounds = drawing.bounds.isEmpty
            ? CGRect(x: 0, y: 0, width: 600, height: 260)
            : drawing.bounds.insetBy(dx: -12, dy: -12)
        let image = drawing.image(from: bounds, scale: 2)
        guard let data = image.pngData() else {
            isSaving = false
            saveError = "The signature image could not be created."
            return
        }
        guard let filename = SignatureStorageService.save(data: data) else {
            isSaving = false
            saveError = "The signature file could not be written to protected app storage."
            return
        }

        entry.signatureFilename = filename
        entry.signatureSignerName = trimmedSignerName
        entry.signatureCapturedAt = Date()
        entry.signatureConsentVersion = LegalContent.currentVersion

        guard onDone() else {
            SignatureStorageService.delete(filename: filename)
            entry.signatureFilename = nil
            entry.signatureSignerName = nil
            entry.signatureCapturedAt = nil
            entry.signatureConsentVersion = nil
            isSaving = false
            saveError = "The completed work order could not be saved. Your signature was not retained. Review the error and try again."
            return
        }

        HapticManager.success()
        dismiss()
    }
}

@MainActor
struct SignatureCanvas: UIViewRepresentable {
    @Binding var drawing: PKDrawing

    func makeCoordinator() -> Coordinator {
        Coordinator(drawing: $drawing)
    }

    func makeUIView(context: Context) -> PKCanvasView {
        let view = PKCanvasView()
        view.delegate = context.coordinator
        view.drawingPolicy = .anyInput
        view.isAccessibilityElement = true
        view.accessibilityLabel = "Signature drawing area"
        view.accessibilityHint = "Draw a signature with a finger or Apple Pencil"
        view.backgroundColor = .systemBackground
        view.tool = PKInkingTool(.pen, color: .label, width: 3)
        return view
    }

    func updateUIView(_ uiView: PKCanvasView, context: Context) {
        if uiView.drawing.dataRepresentation() != drawing.dataRepresentation() {
            uiView.drawing = drawing
        }
        uiView.accessibilityValue = drawing.strokes.isEmpty ? "Empty" : "Signature entered"
    }

    @MainActor
    final class Coordinator: NSObject, PKCanvasViewDelegate {
        private var drawing: Binding<PKDrawing>

        init(drawing: Binding<PKDrawing>) {
            self.drawing = drawing
        }

        func canvasViewDrawingDidChange(_ canvasView: PKCanvasView) {
            drawing.wrappedValue = canvasView.drawing
        }
    }
}
