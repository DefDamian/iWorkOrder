import SwiftUI
import PhotosUI
import UIKit
import MessageUI

struct WorkOrderHomeView: View {
    @EnvironmentObject private var store: AppStore
    @Environment(\.accessibilityReduceMotion) private var reduceMotion
    @AppStorage(AppTheme.storageKey) private var selectedThemeRaw = VisualTheme.defaultTheme.rawValue
    @State private var quickAdd = false
    @State private var newOrder = false
    @State private var selectedDeepLink: WorkOrder?

    private var selectedTheme: VisualTheme { VisualTheme(rawValue: selectedThemeRaw) ?? .defaultTheme }
    private var statusCounts: [WorkOrderStatus: Int] { Dictionary(grouping: store.activeWorkOrders, by: { $0.status }).mapValues(\.count) }

    var body: some View {
        if selectedTheme == .design2 {
            Theme2OrdersHomeView()
        } else if selectedTheme == .design3 {
            Theme3OrdersHomeView()
        } else {
        NavigationStack {
            ScreenBackground {
                SwiftUI.ScrollView(.vertical, showsIndicators: true) {
                    VStack(alignment: .leading, spacing: 18) {
                        HeaderCard(personName: store.profile.personName, buildingName: store.profile.buildingName, total: store.activeWorkOrders.count)
                        if store.profile.role == .handyman { PriorityQueueCard(orders: store.priorityQueue) }
                        AdaptiveButtonPair {
                            PrimaryActionButton(title: "Quick Add", systemImage: "bolt.fill") { quickAdd = true }
                                .accessibilityIdentifier(AccessibilityID.quickAddButton)
                        } second: {
                            SecondaryActionButton(title: "New Work Order", systemImage: "plus.circle.fill") { newOrder = true }
                                .accessibilityIdentifier(AccessibilityID.newWorkOrderButton)
                        }
                        .frame(maxWidth: .infinity)
                        FilterPanel()
                        ScrollView(.horizontal, showsIndicators: false) {
                            HStack(spacing: 10) {
                                ForEach(WorkOrderStatus.allCases) { status in
                                    StatusFilterChip(status: status, count: statusCounts[status, default: 0], isSelected: store.selectedStatus == status) {
                                        if reduceMotion {
                                            store.selectedStatus = status
                                        } else {
                                            withAnimation { store.selectedStatus = status }
                                        }
                                    }
                                }
                            }.padding(.vertical, 2)
                        }
                        SectionHeader(title: store.selectedStatus.rawValue, subtitle: "Filtered and sorted by original creation date")
                        if store.filteredWorkOrders.isEmpty { EmptyWorkOrderState(status: store.selectedStatus) } else {
                            LazyVStack(spacing: 14) {
                                ForEach(store.filteredWorkOrders) { order in
                                    SwipeToDeleteWorkOrderRow(order: order) {
                                        if reduceMotion {
                                            _ = store.moveToTrash(order)
                                        } else {
                                            withAnimation {
                                                _ = store.moveToTrash(order)
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }.padding(AppTheme.horizontalPadding(for: selectedTheme)).padding(.bottom, 28)
                }
            }
            .keyboardDismissable()
            .accessibilityIdentifier(AccessibilityID.workOrdersScreen)
            .navigationTitle("Work Order")
            .navigationBarTitleDisplayMode(.inline)
            .toolbarColorScheme(nil, for: .navigationBar)
            .sheet(isPresented: $quickAdd) { QuickAddView() }
            .sheet(isPresented: $newOrder) { NewWorkOrderView() }
            .onAppear { openDeepLinkedOrderIfNeeded() }
            .onChange(of: store.deepLinkedOrderID) { _, _ in openDeepLinkedOrderIfNeeded() }
            .onChange(of: store.activeWorkOrders.map(\.id)) { _, _ in openDeepLinkedOrderIfNeeded() }
            .navigationDestination(item: $selectedDeepLink) { WorkOrderDetailView(order: $0) }
        }
        }
    }

    private func openDeepLinkedOrderIfNeeded() {
        guard let id = store.deepLinkedOrderID, let order = store.activeWorkOrders.first(where: { $0.id == id }) else { return }
        selectedDeepLink = order
        store.deepLinkedOrderID = nil
    }
}

struct FilterPanel: View {
    @EnvironmentObject private var store: AppStore
    @Environment(\.accessibilityReduceTransparency) private var reduceTransparency
    @AppStorage(AppTheme.storageKey) private var selectedThemeRaw = VisualTheme.defaultTheme.rawValue
    @State private var showMore = false

    private var selectedTheme: VisualTheme { VisualTheme(rawValue: selectedThemeRaw) ?? .defaultTheme }

    var body: some View {
        ModernCard {
            VStack(spacing: 12) {
                HStack(spacing: 12) {
                    HStack(spacing: 8) {
                        Image(systemName: "magnifyingglass")
                            .foregroundStyle(.secondary)
                        TextField("Search unit, issue, notes, asset", text: $store.filters.searchText)
                            .textInputAutocapitalization(.never)
                            .disableAutocorrection(true)
                            .submitLabel(.search)
                            .accessibilityLabel("Search work orders")
                            .accessibilityHint("Search by unit, issue, notes, or asset")
                            .accessibilityIdentifier(AccessibilityID.searchField)
                    }
                    .padding(.horizontal, 12)
                    .padding(.vertical, 11)
                    .background(
                        reduceTransparency
                            ? AnyShapeStyle(selectedTheme == .defaultTheme ? Color(.secondarySystemBackground) : Color.white)
                            : (selectedTheme == .design2 ? AnyShapeStyle(Color.white.opacity(0.82)) : AnyShapeStyle(.thinMaterial)),
                        in: RoundedRectangle(cornerRadius: 14, style: .continuous)
                    )
                    .overlay(
                        RoundedRectangle(cornerRadius: 14, style: .continuous)
                            .stroke(AppTheme.cardStroke(for: selectedTheme), lineWidth: 1)
                    )

                    Button(showMore ? "Hide" : "Filter") { showMore.toggle() }
                        .font(.subheadline.weight(.semibold))
                        .accessibilityIdentifier(AccessibilityID.filterButton)
                        .accessibilityValue(showMore ? "Expanded" : "Collapsed")
                }
                if showMore {
                    TextField("Filter by unit / area", text: $store.filters.unit).appRoundedTextFieldStyle()
                    TextField("Filter by handyman", text: $store.filters.handyman).appRoundedTextFieldStyle()
                    Toggle("Emergency only", isOn: $store.filters.emergencyOnly)
                    Picker("Category", selection: $store.filters.category) {
                        Text("Any").tag(nil as WorkOrderCategory?)
                        ForEach(store.filterCategories) { category in
                            Text(category.rawValue).tag(Optional(category))
                        }
                    }
                    HStack { Spacer(); Button("Clear Filters") { store.filters = WorkOrderFilters() }.buttonStyle(.bordered) }
                }
            }
        }
    }
}

struct PriorityQueueCard: View {
    @AppStorage(AppTheme.storageKey) private var selectedThemeRaw = VisualTheme.defaultTheme.rawValue
    let orders: [WorkOrder]
    private var selectedTheme: VisualTheme { VisualTheme(rawValue: selectedThemeRaw) ?? .defaultTheme }

    var body: some View {
        ModernCard {
            VStack(alignment: .leading, spacing: 10) {
                SectionHeader(title: "Priority Queue", subtitle: "Emergency and high priority work first.")
                ForEach(orders.prefix(4)) { order in
                    NavigationLink { WorkOrderDetailView(order: order) } label: {
                        HStack { PriorityBadge(priority: order.latestEntry.priority); Text(order.latestEntry.area).font(.headline); Spacer(); Image(systemName: "chevron.right").foregroundStyle(.secondary) }
                    }.buttonStyle(.plain)
                    if order.id != orders.prefix(4).last?.id { Divider() }
                }
                if orders.isEmpty { Text("No assigned work orders yet.").font(.subheadline).foregroundStyle(AppTheme.textSecondary(for: selectedTheme)) }
            }
        }
    }
}

struct SwipeToDeleteWorkOrderRow: View {
    let order: WorkOrder
    let deleteAction: () -> Void
    @State private var mailDraft: MailDraft?

    var body: some View {
        NavigationLink { WorkOrderDetailView(order: order) } label: { WorkOrderRow(order: order) }
            .buttonStyle(.plain)
            .accessibilityIdentifier(AccessibilityID.workOrder(order.id))
            .accessibilityHint("Opens the work order details")
            .accessibilityAction(named: "Email work order") { presentEmail() }
            .accessibilityAction(named: "Move to Trash", deleteAction)
            .swipeActions(edge: .leading, allowsFullSwipe: false) {
                Button { presentEmail() } label: { Label("Email", systemImage: "envelope") }
                    .tint(.blue)
            }
            .swipeActions(edge: .trailing, allowsFullSwipe: true) {
                Button(role: .destructive, action: deleteAction) { Label("Delete", systemImage: "trash") }
            }
            .contextMenu {
                Button { presentEmail() } label: { Label("Email", systemImage: "envelope") }
                Button(role: .destructive, action: deleteAction) { Label("Move to Trash", systemImage: "trash") }
            }
            .sheet(item: $mailDraft) { draft in
                if MFMailComposeViewController.canSendMail() {
                    MailComposerView(draft: draft)
                } else {
                    ShareSheet(items: [draft.shareText])
                }
            }
    }

    private func presentEmail() {
        mailDraft = EmailHelper.draft(order: order)
    }
}

struct HeaderCard: View {
    @AppStorage(AppTheme.storageKey) private var selectedThemeRaw = VisualTheme.defaultTheme.rawValue
    let personName: String
    let buildingName: String
    let total: Int

    private var selectedTheme: VisualTheme { VisualTheme(rawValue: selectedThemeRaw) ?? .defaultTheme }

    var body: some View {
        if AppTheme.usesLegacyHero(for: selectedTheme) {
            LegacyHeaderCard(personName: personName, buildingName: buildingName, total: total)
        } else {
            ModernCard(padding: 18) {
                HStack(alignment: .top, spacing: 14) {
                    Image(systemName: "building.2.crop.circle.fill").font(.largeTitle).foregroundStyle(.blue)
                    VStack(alignment: .leading, spacing: 5) {
                        Text(personName.isEmpty ? "Superintendent" : personName).font(.headline).foregroundStyle(.secondary)
                        Text(buildingName.isEmpty ? "Building" : buildingName).font(.title2.weight(.bold)).lineLimit(2)
                        Text("\(total) active work orders").font(.subheadline.weight(.medium)).foregroundStyle(.blue)
                    }
                    Spacer()
                }
            }
            .accessibilityIdentifier("theme.surface.default")
        }
    }
}

struct LegacyHeaderCard: View {
    @EnvironmentObject private var store: AppStore
    @Environment(\.accessibilityReduceTransparency) private var reduceTransparency
    @AppStorage(AppTheme.storageKey) private var selectedThemeRaw = VisualTheme.defaultTheme.rawValue
    let personName: String
    let buildingName: String
    let total: Int

    private var selectedTheme: VisualTheme { VisualTheme(rawValue: selectedThemeRaw) ?? .defaultTheme }

    var body: some View {
        if selectedTheme == .design2 {
            designTwoHero
        } else {
            designThreeHero
        }
    }

    private var displayName: String { personName.isEmpty ? "Superintendent" : personName }
    private var displayBuilding: String { buildingName.isEmpty ? "Building" : buildingName }

    private var syncStatusTitle: String {
        switch store.cloudSyncState {
        case .disabled: return "Local Only"
        case .paused: return "iCloud Paused"
        case .idle: return store.profile.iCloudEnabled ? "iCloud Ready" : "Local Only"
        case .checkingAccount: return "Checking iCloud"
        case .syncing: return "Syncing"
        case .synced: return "iCloud Synced"
        case .offline: return "Waiting for Network"
        case .noAccount: return "iCloud Sign-In Needed"
        case .restricted: return "iCloud Restricted"
        case .failed: return "Sync Needs Attention"
        }
    }

    private var syncStatusIcon: String {
        switch store.cloudSyncState {
        case .disabled: return "internaldrive"
        case .idle, .synced: return "checkmark.icloud.fill"
        case .checkingAccount, .syncing: return "arrow.triangle.2.circlepath.icloud.fill"
        case .paused: return "pause.icloud.fill"
        case .offline: return "wifi.slash"
        case .noAccount, .restricted: return "icloud.slash.fill"
        case .failed: return "exclamationmark.icloud.fill"
        }
    }

    private var syncStatusTint: Color {
        switch store.cloudSyncState {
        case .idle, .synced: return .green
        case .checkingAccount, .syncing: return .blue
        case .paused, .offline, .noAccount, .restricted: return .orange
        case .failed: return .red
        case .disabled: return .secondary
        }
    }

    private var designTwoHero: some View {
        VStack(alignment: .leading, spacing: 18) {
            HStack(alignment: .top) {
                VStack(alignment: .leading, spacing: 8) {
                    Text("iWorkOrder")
                        .font(.caption.weight(.black))
                        .tracking(3.2)
                        .foregroundStyle(.white.opacity(0.58))
                    Text(displayBuilding + " - " + displayName)
                        .font(.system(.largeTitle, design: .rounded).weight(.black))
                        .foregroundStyle(.white)
                        .lineLimit(3)
                        .minimumScaleFactor(0.68)
                    Text("\(total) active work orders")
                        .font(.subheadline.weight(.bold))
                        .foregroundStyle(.white.opacity(0.72))
                }
                Spacer(minLength: 12)
                Image(systemName: syncStatusIcon)
                    .font(.headline.weight(.black))
                    .foregroundStyle(syncStatusTint)
                    .frame(width: 56, height: 56)
                    .background(
                        reduceTransparency
                            ? AnyShapeStyle(Color.white)
                            : AnyShapeStyle(.thinMaterial),
                        in: Circle()
                    )
                    .overlay(Circle().stroke(syncStatusTint.opacity(0.35), lineWidth: 1))
                    .accessibilityLabel(syncStatusTitle)
            }
            HStack(spacing: 10) {
                Label(syncStatusTitle, systemImage: syncStatusIcon)
                    .lineLimit(2)
                    .fixedSize(horizontal: false, vertical: true)
                Spacer()
                Text(Date.now.shortDateTime)
            }
            .font(.caption.weight(.bold))
            .foregroundStyle(.white.opacity(0.72))
        }
        .padding(20)
        .frame(maxWidth: .infinity, alignment: .leading)
        .background(AppTheme.heroGradient(for: selectedTheme), in: RoundedRectangle(cornerRadius: 34, style: .continuous))
        .overlay(alignment: .topTrailing) { Circle().fill(.white.opacity(0.10)).frame(width: 190, height: 190).offset(x: 64, y: -86).accessibilityHidden(true) }
        .overlay(alignment: .bottomLeading) { Circle().fill(Color.green.opacity(0.18)).frame(width: 136, height: 136).offset(x: -78, y: 72).accessibilityHidden(true) }
        .clipShape(RoundedRectangle(cornerRadius: 34, style: .continuous))
        .shadow(color: Color.blue.opacity(0.20), radius: 26, x: 0, y: 16)
    }

    private var designThreeHero: some View {
        VStack(alignment: .leading, spacing: 18) {
            HStack(alignment: .top) {
                VStack(alignment: .leading, spacing: 12) {
                    Text("WORKFLOW")
                        .font(.caption.weight(.black))
                        .tracking(3.4)
                        .foregroundStyle(.white.opacity(0.65))
                    Text(displayBuilding)
                        .font(.system(.largeTitle, design: .rounded).weight(.black))
                        .foregroundStyle(.white)
                        .lineLimit(2)
                        .minimumScaleFactor(0.70)
                    Text(displayName + "  •  \(total) active")
                        .font(.subheadline.weight(.bold))
                        .foregroundStyle(.white.opacity(0.80))
                        .lineLimit(2)
                }
                Spacer()
                Image(systemName: "plus")
                    .font(.largeTitle.weight(.bold))
                    .foregroundStyle(AppTheme.accent(for: selectedTheme))
                    .frame(width: 70, height: 70)
                    .background(.white.opacity(0.95), in: RoundedRectangle(cornerRadius: 24, style: .continuous))
            }
            HStack {
                Label(syncStatusTitle, systemImage: syncStatusIcon)
                    .font(.caption.weight(.bold))
                    .lineLimit(2)
                    .fixedSize(horizontal: false, vertical: true)
                Spacer()
                Label("Command", systemImage: "square.grid.2x2")
                    .font(.caption.weight(.black))
                    .padding(.horizontal, 16)
                    .padding(.vertical, 9)
                    .background(.white.opacity(0.20), in: Capsule())
            }
            .foregroundStyle(.white.opacity(0.82))
        }
        .padding(22)
        .frame(maxWidth: .infinity, alignment: .leading)
        .background(AppTheme.heroGradient(for: selectedTheme), in: RoundedRectangle(cornerRadius: 34, style: .continuous))
        .overlay(alignment: .topTrailing) { Circle().fill(.white.opacity(0.18)).frame(width: 170, height: 170).offset(x: 64, y: -82).accessibilityHidden(true) }
        .clipShape(RoundedRectangle(cornerRadius: 34, style: .continuous))
        .shadow(color: Color.purple.opacity(0.20), radius: 24, x: 0, y: 15)
    }
}

struct StatusFilterChip: View {
    @AppStorage(AppTheme.storageKey) private var selectedThemeRaw = VisualTheme.defaultTheme.rawValue
    @ScaledMetric(relativeTo: .body) private var regularWidth: CGFloat = 148
    @ScaledMetric(relativeTo: .body) private var legacyWidth: CGFloat = 122
    let status: WorkOrderStatus
    let count: Int
    let isSelected: Bool
    let action: () -> Void
    private var selectedTheme: VisualTheme { VisualTheme(rawValue: selectedThemeRaw) ?? .defaultTheme }

    var body: some View {
        Button(action: action) {
            VStack(alignment: .leading, spacing: 8) { HStack { Image(systemName: AppTheme.statusIcon(status)); Text("\(count)").font(.headline) }; Text(status.rawValue).font(.caption.weight(.semibold)).lineLimit(1) }
                .foregroundStyle(isSelected ? .white : AppTheme.statusTint(status)).padding(14).frame(width: AppTheme.usesLegacyHero(for: selectedTheme) ? legacyWidth : regularWidth, alignment: .leading)
                .background(isSelected ? AppTheme.statusTint(status) : AppTheme.statusTint(status).opacity(AppTheme.usesLegacyHero(for: selectedTheme) ? 0.14 : 0.12), in: RoundedRectangle(cornerRadius: AppTheme.usesLegacyHero(for: selectedTheme) ? 24 : 18, style: .continuous))
                .overlay(RoundedRectangle(cornerRadius: AppTheme.usesLegacyHero(for: selectedTheme) ? 24 : 18, style: .continuous).stroke(AppTheme.statusTint(status).opacity(AppTheme.usesLegacyHero(for: selectedTheme) ? 0.16 : 0), lineWidth: 1))
        }
        .buttonStyle(.plain)
        .accessibilityIdentifier(AccessibilityID.statusFilter(status))
        .accessibilityLabel("\(status.rawValue) work orders")
        .accessibilityValue("\(count), \(isSelected ? "selected" : "not selected")")
        .accessibilityAddTraits(isSelected ? .isSelected : [])
    }
}

struct EmptyWorkOrderState: View {
    let status: WorkOrderStatus
    var body: some View { ModernCard { VStack(spacing: 12) { Image(systemName: "tray").font(.largeTitle).foregroundStyle(.secondary); Text("No \(status.rawValue.lowercased()) items").font(.headline); Text("New work orders will appear here when they match this status and filters.").font(.subheadline).foregroundStyle(.secondary).multilineTextAlignment(.center) }.frame(maxWidth: .infinity).padding(.vertical, 20) } }
}

private struct WorkOrderDateLabel: View {
    @AppStorage(AppTheme.storageKey) private var selectedThemeRaw = VisualTheme.defaultTheme.rawValue
    let date: Date
    private var selectedTheme: VisualTheme { VisualTheme(rawValue: selectedThemeRaw) ?? .defaultTheme }

    var body: some View {
        Label(date.shortDateTime, systemImage: "calendar")
            .font(.caption)
            .foregroundStyle(AppTheme.textSecondary(for: selectedTheme))
            .lineLimit(2)
            .fixedSize(horizontal: false, vertical: true)
            .layoutPriority(1)
    }
}

private struct WorkOrderEditedLabel: View {
    var body: some View {
        Label("Edited", systemImage: "exclamationmark.triangle.fill")
            .font(.caption.weight(.semibold))
            .foregroundStyle(.orange)
            .lineLimit(1)
            .fixedSize(horizontal: true, vertical: false)
    }
}

private struct WorkOrderBadgeCluster: View {
    let priority: WorkOrderPriority
    let status: WorkOrderStatus

    var body: some View {
        ViewThatFits(in: .horizontal) {
            HStack(spacing: 8) {
                PriorityBadge(priority: priority)
                StatusBadge(status: status)
            }

            VStack(alignment: .trailing, spacing: 6) {
                PriorityBadge(priority: priority)
                StatusBadge(status: status)
            }
        }
    }
}

struct WorkOrderRow: View {
    @AppStorage(AppTheme.storageKey) private var selectedThemeRaw = VisualTheme.defaultTheme.rawValue
    let order: WorkOrder
    private var selectedTheme: VisualTheme { VisualTheme(rawValue: selectedThemeRaw) ?? .defaultTheme }

    var body: some View {
        ModernCard(padding: 16) {
            VStack(alignment: .leading, spacing: 12) {
                HStack(alignment: .top, spacing: 12) {
                    VStack(alignment: .leading, spacing: 5) {
                        Text(order.originalEntry.area)
                            .font(.title3.weight(.bold))
                            .foregroundStyle(AppTheme.textPrimary(for: selectedTheme))
                        Text(order.title)
                            .font(.subheadline)
                            .foregroundStyle(AppTheme.textSecondary(for: selectedTheme))
                            .lineLimit(3)
                            .fixedSize(horizontal: false, vertical: true)
                    }
                    Spacer()
                    Image(systemName: "chevron.right")
                        .foregroundStyle(.tertiary)
                        .accessibilityHidden(true)
                }
                ViewThatFits(in: .horizontal) {
                    HStack(spacing: 8) {
                        WorkOrderDateLabel(date: order.createdAt)
                        Spacer(minLength: 8)
                        if order.wasEdited { WorkOrderEditedLabel() }
                        WorkOrderBadgeCluster(priority: order.latestEntry.priority, status: order.status)
                    }

                    VStack(alignment: .leading, spacing: 8) {
                        HStack(alignment: .firstTextBaseline, spacing: 8) {
                            WorkOrderDateLabel(date: order.createdAt)
                            Spacer(minLength: 8)
                            if order.wasEdited { WorkOrderEditedLabel() }
                        }
                        WorkOrderBadgeCluster(priority: order.latestEntry.priority, status: order.status)
                            .frame(maxWidth: .infinity, alignment: .trailing)
                    }
                }
            }
        }
        .overlay(
            RoundedRectangle(cornerRadius: 22, style: .continuous)
                .stroke(order.latestEntry.priority == .emergency ? Color.red : Color.clear, lineWidth: order.latestEntry.priority == .emergency ? 4 : 0)
        )
        .accessibilityElement(children: .ignore)
        .accessibilityLabel("\(order.originalEntry.area), \(order.title)")
        .accessibilityValue("\(order.latestEntry.priority.rawValue) priority, \(order.status.rawValue), created \(order.createdAt.shortDateTime)")
    }
}

struct QuickAddView: View {
    @AppStorage(AppTheme.storageKey) private var selectedThemeRaw = VisualTheme.defaultTheme.rawValue
    @EnvironmentObject private var store: AppStore
    @Environment(\.dismiss) private var dismiss
    @State private var area = ""
    @State private var description = ""
    private var selectedTheme: VisualTheme { VisualTheme(rawValue: selectedThemeRaw) ?? .defaultTheme }

    var body: some View {
        NavigationStack {
            ScreenBackground { SwiftUI.ScrollView(.vertical, showsIndicators: true) { VStack(alignment: .leading, spacing: 18) {
                SectionHeader(title: "Quick Add", subtitle: "Capture a work order fast. Add photos, reminders, and notes later from full view.")
                LegalBanner(kind: .audit)
                ModernCard {
                    VStack(spacing: 14) {
                        TextField("Apt, floor, or area", text: $area)
                            .appRoundedTextFieldStyle()
                            .accessibilityIdentifier(AccessibilityID.quickAddArea)
                        TextField("Issue description", text: $description, axis: .vertical)
                            .appRoundedTextFieldStyle()
                            .accessibilityIdentifier(AccessibilityID.quickAddDescription)
                        PrimaryActionButton(title: "Done", systemImage: "checkmark") {
                            if store.addQuick(area: area, description: description) {
                                dismiss()
                            }
                        }
                        .disabled(
                            area.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty ||
                            description.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty
                        )
                        .accessibilityIdentifier(AccessibilityID.quickAddSave)
                        Text("To add pictures, reminders, notes, priority, asset tags, and signatures, open the work order in full view.")
                            .font(.caption)
                            .foregroundStyle(.secondary)
                            .multilineTextAlignment(.center)
                    }
                }
            }.padding(AppTheme.horizontalPadding(for: selectedTheme)) } }
            .keyboardDismissable()
            .accessibilityIdentifier(AccessibilityID.quickAddScreen)
            .navigationTitle("Quick Add")
            .toolbar {
                ToolbarItem(placement: .topBarTrailing) {
                    Button("Cancel") { dismiss() }
                        .accessibilityIdentifier(AccessibilityID.quickAddCancel)
                }
            }
        }
    }
}

struct NewWorkOrderView: View {
    @EnvironmentObject private var store: AppStore
    @Environment(\.dismiss) private var dismiss
    @State private var entry = WorkOrderEntry()
    @State private var didSave = false
    @State private var activePhotoImports = 0

    var body: some View {
        NavigationStack {
            WorkOrderEntryForm(entry: $entry, activePhotoImports: $activePhotoImports, includeSignature: false, preserveCurrentCategory: false)
                .navigationTitle("New Work Order")
                .accessibilityIdentifier(AccessibilityID.newWorkOrderScreen)
                .toolbar {
                    ToolbarItem(placement: .topBarLeading) {
                        Button("Cancel") {
                            cleanupUncommittedImages()
                            dismiss()
                        }
                        .accessibilityIdentifier(AccessibilityID.newOrderCancel)
                    }
                    ToolbarItem(placement: .topBarTrailing) {
                        Button("Save") {
                            guard activePhotoImports == 0 else { return }
                            if entry.handymanName.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty,
                               store.profile.role == .handyman {
                                entry.handymanName = store.profile.personName
                            }
                            if store.addFull(entry: entry) {
                                didSave = true
                                dismiss()
                            }
                        }
                        .disabled(!entry.hasRequiredFields || activePhotoImports > 0)
                        .accessibilityIdentifier(AccessibilityID.newOrderSave)
                    }
                }
                .onDisappear {
                    if !didSave {
                        cleanupUncommittedImages()
                    }
                }
        }
    }

    private func cleanupUncommittedImages() {
        for image in entry.images {
            _ = ImageStorageService.delete(image)
        }
        entry.images.removeAll()
    }
}

struct WorkOrderEvidenceThumbnail: View {
    let image: WorkOrderImage
    @State private var thumbnail: UIImage?
    @State private var didFinishLoading = false

    var body: some View {
        VStack(spacing: 6) {
            Group {
                if let thumbnail {
                    Image(uiImage: thumbnail)
                        .resizable()
                        .scaledToFill()
                } else if didFinishLoading {
                    Image(systemName: "photo.badge.exclamationmark")
                        .font(.title2)
                        .foregroundStyle(.secondary)
                } else {
                    ProgressView()
                }
            }
            .frame(width: 90, height: 90)
            .background(Color(.secondarySystemBackground), in: RoundedRectangle(cornerRadius: 12, style: .continuous))
            .clipShape(RoundedRectangle(cornerRadius: 12, style: .continuous))

            Text(image.kind.rawValue)
                .font(.caption)
                .foregroundStyle(.secondary)
        }
        .accessibilityElement(children: .ignore)
        .accessibilityLabel("\(image.kind.rawValue) evidence photo")
        .accessibilityValue(image.createdAt.shortDateTime)
        .task(id: image.filename) {
            thumbnail = nil
            didFinishLoading = false
            let data = await WorkOrderImageThumbnailCache.shared.data(for: image, maxPixelSize: 240)
            guard !Task.isCancelled else { return }
            await MainActor.run {
                thumbnail = data.flatMap(UIImage.init(data:))
                didFinishLoading = true
            }
        }
    }
}

struct WorkOrderEntryForm: View {
    @AppStorage(AppTheme.storageKey) private var selectedThemeRaw = VisualTheme.defaultTheme.rawValue
    @EnvironmentObject private var store: AppStore
    @Environment(\.scenePhase) private var scenePhase
    @Environment(\.accessibilityReduceTransparency) private var reduceTransparency
    @Binding var entry: WorkOrderEntry
    @Binding var activePhotoImports: Int
    let includeSignature: Bool
    var preserveCurrentCategory = true
    @State private var beforeItem: PhotosPickerItem?
    @State private var afterItem: PhotosPickerItem?
    @State private var torchOn = false
    @State private var torchOperationInProgress = false
    @State private var isFormVisible = false
    @State private var evidenceError: String?
    @State private var pendingPhotoDeletion: WorkOrderImage?
    private var selectedTheme: VisualTheme { VisualTheme(rawValue: selectedThemeRaw) ?? .defaultTheme }

    var body: some View {
        ScreenBackground {
            SwiftUI.ScrollView(.vertical, showsIndicators: true) { VStack(alignment: .leading, spacing: 16) {
                LegalBanner(kind: .audit)
                ModernCard { VStack(spacing: 12) {
                    TextField("Apt / floor / area", text: $entry.area)
                        .appRoundedTextFieldStyle()
                        .accessibilityIdentifier(AccessibilityID.newOrderArea)
                    TextField("Description", text: $entry.issueDescription, axis: .vertical)
                        .appRoundedTextFieldStyle()
                        .accessibilityIdentifier(AccessibilityID.newOrderDescription)
                    TextField("Assigned handyman", text: $entry.handymanName)
                        .appRoundedTextFieldStyle()
                        .textContentType(.name)
                        .accessibilityIdentifier("newOrder.handyman")
                    Picker("Category", selection: Binding(
                        get: { store.categorySelection(for: entry.managedCategory) },
                        set: { entry.managedCategory = $0 }
                    )) {
                        ForEach(store.categoryOptions(including: preserveCurrentCategory ? entry.managedCategory : nil)) { category in
                            Text(category.rawValue).tag(category)
                        }
                    }
                    Picker("Priority", selection: $entry.priority) { ForEach(WorkOrderPriority.allCases) { Text($0.rawValue).tag($0) } }
                        .pickerStyle(.segmented)
                        .onChange(of: entry.priority) { _, priority in
                            if priority == .emergency { HapticManager.warning() } else { HapticManager.selection() }
                        }
                    Toggle("Entry permitted by tenant", isOn: $entry.entryPermitted)
                    Toggle("Tenant permission confirmed", isOn: Binding(get: { entry.tenantPermission ?? entry.entryPermitted }, set: { entry.tenantPermission = $0; entry.entryPermitted = $0 }))
                    Picker("Entry Method", selection: Binding(get: { entry.entryMethod ?? .notSpecified }, set: { entry.entryMethod = $0 })) {
                        ForEach(EntryMethod.allCases) { Text($0.rawValue).tag($0) }
                    }
                    TextField("Asset tag / QR code value", text: $entry.assetTag).appRoundedTextFieldStyle()
                    TextField("Linked asset ID", text: Binding(get: { entry.assetID ?? "" }, set: { entry.assetID = $0.isEmpty ? nil : $0 })).appRoundedTextFieldStyle()
                } }
                ModernCard { VStack(alignment: .leading, spacing: 12) {
                    SectionHeader(title: "Reminder")
                    Toggle("Alert me", isOn: $entry.reminderEnabled)
                    if entry.reminderEnabled { DatePicker("Date and time", selection: $entry.reminderDate, displayedComponents: [.date, .hourAndMinute]) }
                } }
                ModernCard { VStack(alignment: .leading, spacing: 12) {
                    SectionHeader(title: "Evidence Gallery", subtitle: "Photos are compressed to 1080p before saving.")
                    ViewThatFits(in: .horizontal) {
                        HStack {
                            evidenceControls
                        }
                        VStack(alignment: .leading, spacing: 10) {
                            evidenceControls
                        }
                    }
                    ScrollView(.horizontal, showsIndicators: false) {
                        LazyHStack(spacing: 10) {
                            ForEach(entry.images) { image in
                                ZStack(alignment: .topTrailing) {
                                    WorkOrderEvidenceThumbnail(image: image)

                                    Button {
                                        pendingPhotoDeletion = image
                                    } label: {
                                        Image(systemName: "trash.fill")
                                            .font(.caption.weight(.semibold))
                                            .foregroundStyle(.red)
                                            .frame(width: 36, height: 36)
                                            .background(
                                                reduceTransparency
                                                    ? AnyShapeStyle(Color(.secondarySystemBackground))
                                                    : AnyShapeStyle(.thinMaterial),
                                                in: Circle()
                                            )
                                    }
                                    .buttonStyle(.plain)
                                    .contentShape(Circle())
                                    .accessibilityLabel("Remove \(image.kind.rawValue.lowercased()) photo")
                                    .accessibilityHint("Asks for confirmation before removing this evidence photo")
                                    .padding(4)
                                }
                            }
                        }
                    }
                } }
                ModernCard { VStack(alignment: .leading, spacing: 12) {
                    SectionHeader(title: "Quick Fix", subtitle: "Glove-friendly one-tap work notes.")
                    LazyVGrid(columns: [GridItem(.adaptive(minimum: 108), spacing: 10)], spacing: 10) {
                        ForEach(["Replaced", "Fixed", "Cleaned", "Inspected"], id: \.self) { action in
                            Button(action) { appendActionNote(action); HapticManager.selection() }
                                .buttonStyle(.bordered)
                                .frame(maxWidth: .infinity)
                                .accessibilityLabel("Add quick fix note: \(action)")
                        }
                    }
                } }
                ModernCard { VStack(alignment: .leading, spacing: 12) { SectionHeader(title: "Notes", subtitle: "Use the iOS keyboard microphone for voice-to-text dictation."); TextField("Notes", text: $entry.notes, axis: .vertical).lineLimit(5...10).appRoundedTextFieldStyle() } }
                if includeSignature { LegalBanner(kind: .signature) }
            }.padding(AppTheme.horizontalPadding(for: selectedTheme)).padding(.bottom, 28) }
        }
        .keyboardDismissable()
        .task(id: beforeItem) { await loadPhoto(beforeItem, kind: .before) }
        .task(id: afterItem) { await loadPhoto(afterItem, kind: .after) }
        .onAppear {
            isFormVisible = true
            if !preserveCurrentCategory && !store.containsManagedCategory(entry.managedCategory) {
                entry.managedCategory = store.defaultCategory
            }
        }
        .onChange(of: store.categories) { _, availableCategories in
            if !preserveCurrentCategory && !availableCategories.contains(where: {
                WorkOrderCategory.identityKey($0.rawValue) == WorkOrderCategory.identityKey(entry.managedCategory.rawValue)
            }) {
                entry.managedCategory = store.defaultCategory
            }
        }
        .onChange(of: scenePhase) { _, phase in
            guard phase != .active, torchOn else { return }
            torchOn = false
            Task { _ = await FlashlightService.setTorch(active: false) }
        }
        .onDisappear {
            isFormVisible = false
            torchOperationInProgress = false
            guard torchOn else { return }
            torchOn = false
            Task { _ = await FlashlightService.setTorch(active: false) }
        }
        .alert("Evidence Not Added", isPresented: Binding(
            get: { evidenceError != nil },
            set: { if !$0 { evidenceError = nil } }
        )) {
            Button("OK", role: .cancel) { evidenceError = nil }
        } message: {
            Text(evidenceError ?? "The selected evidence could not be added.")
        }
        .confirmationDialog(
            "Remove Photo?",
            isPresented: Binding(
                get: { pendingPhotoDeletion != nil },
                set: { if !$0 { pendingPhotoDeletion = nil } }
            ),
            titleVisibility: .visible,
            presenting: pendingPhotoDeletion
        ) { image in
            Button("Remove \(image.kind.rawValue) Photo", role: .destructive) {
                removePhoto(image)
            }
            Button("Cancel", role: .cancel) {
                pendingPhotoDeletion = nil
            }
        } message: { image in
            if isPhotoAlreadySaved(image) {
                Text("This removes the photo from the revision you are editing. Earlier saved revisions keep their original evidence history.")
            } else {
                Text("This removes the selected photo from this work order draft.")
            }
        }
    }
    @ViewBuilder
    private var evidenceControls: some View {
        PhotosPicker(selection: $beforeItem, matching: .images) {
            Label("Before Photo", systemImage: "camera")
        }
        .buttonStyle(.bordered)
        .accessibilityHint("Adds a photo showing conditions before the repair")

        PhotosPicker(selection: $afterItem, matching: .images) {
            Label("After Photo", systemImage: "camera.fill")
        }
        .buttonStyle(.bordered)
        .accessibilityHint("Adds a photo showing conditions after the repair")

        Button {
            guard !torchOperationInProgress else { return }
            let requestedState = !torchOn
            torchOperationInProgress = true
            Task {
                let changed = await FlashlightService.setTorch(active: requestedState)
                if requestedState && changed && (!isFormVisible || scenePhase != .active) {
                    _ = await FlashlightService.setTorch(active: false)
                    torchOn = false
                    torchOperationInProgress = false
                    return
                }
                torchOperationInProgress = false
                guard !Task.isCancelled else { return }
                if changed {
                    torchOn = requestedState
                    HapticManager.selection()
                } else {
                    torchOn = false
                    evidenceError = requestedState
                        ? "Camera access is unavailable or the flashlight could not be activated. You can review camera access in iOS Settings."
                        : "The flashlight could not be turned off."
                }
            }
        } label: {
            Label(torchOn ? "Flashlight On" : "Flashlight", systemImage: torchOn ? "flashlight.on.fill" : "flashlight.off.fill")
        }
        .buttonStyle(.bordered)
        .disabled(torchOperationInProgress)
        .accessibilityLabel(torchOn ? "Turn flashlight off" : "Turn flashlight on")
    }

    private func isPhotoAlreadySaved(_ image: WorkOrderImage) -> Bool {
        store.workOrders.contains { order in
            order.entries.contains { entry in
                entry.images.contains { $0.filename == image.filename }
            }
        }
    }

    private func removePhoto(_ image: WorkOrderImage) {
        guard let index = entry.images.firstIndex(where: { $0.id == image.id }) else {
            pendingPhotoDeletion = nil
            return
        }

        let isReferencedBySavedRevision = isPhotoAlreadySaved(image)
        entry.images.remove(at: index)
        let isStillReferencedByDraft = entry.images.contains { $0.filename == image.filename }
        pendingPhotoDeletion = nil
        HapticManager.selection()

        // A newly selected, unsaved attachment can be deleted immediately.
        // Evidence already referenced by a saved revision remains on disk because
        // earlier revision history is intentionally preserved. The next saved
        // revision simply omits it from the current evidence gallery.
        if !isReferencedBySavedRevision,
           !isStillReferencedByDraft,
           !ImageStorageService.delete(image) {
            evidenceError = "The photo was removed from the draft, but its local attachment file could not be deleted. iWorkOrder will retry attachment cleanup automatically."
        }
    }

    private func appendActionNote(_ action: String) {
        let line = "\(action) - \(Date().shortDateTime)"
        entry.notes = entry.notes.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty ? line : entry.notes + "\n" + line
    }
    private func loadPhoto(_ item: PhotosPickerItem?, kind: WorkOrderImage.ImageKind) async {
        guard let item else { return }
        activePhotoImports += 1
        defer { activePhotoImports = max(0, activePhotoImports - 1) }
        guard let data = try? await item.loadTransferable(type: Data.self), !Task.isCancelled else {
            if !Task.isCancelled {
                evidenceError = "The selected photo could not be read."
                if kind == .before { beforeItem = nil } else { afterItem = nil }
            }
            return
        }

        let stored = await Task.detached(priority: .userInitiated) {
            ImageStorageService.saveCompressed(data: data, kind: kind)
        }.value
        guard let stored else {
            if !Task.isCancelled {
                evidenceError = "The selected photo could not be converted or written to protected app storage."
                if kind == .before { beforeItem = nil } else { afterItem = nil }
            }
            return
        }

        // SwiftUI cancels `.task(id:)` work when the selection changes or the
        // form disappears. If cancellation races with the final disk write,
        // remove the just-created file instead of leaving private evidence
        // unreferenced after the draft screen has already cleaned up.
        if Task.isCancelled {
            ImageStorageService.delete(stored)
            return
        }
        await MainActor.run {
            if Task.isCancelled {
                ImageStorageService.delete(stored)
            } else {
                entry.images.append(stored)
                if kind == .before { beforeItem = nil } else { afterItem = nil }
            }
        }
    }
}

struct WorkOrderDetailView: View {
    @AppStorage(AppTheme.storageKey) private var selectedThemeRaw = VisualTheme.defaultTheme.rawValue
    @EnvironmentObject private var store: AppStore
    let order: WorkOrder
    @State private var status: WorkOrderStatus
    @State private var draft: WorkOrderEntry
    @State private var baseRevisionID: UUID
    @State private var activePhotoImports = 0
    @State private var confirmEditCompleted = false
    @State private var showSignature = false
    @State private var shareURL: URL?
    @State private var mailDraft: MailDraft?

    init(order: WorkOrder) {
        self.order = order
        _status = State(initialValue: order.status)
        _draft = State(initialValue: order.latestEntry)
        _baseRevisionID = State(initialValue: order.latestEntry.id)
    }

    var freshOrder: WorkOrder { store.workOrders.first(where: { $0.id == order.id }) ?? order }
    var isLockedCompleted: Bool { freshOrder.status == .completed && !confirmEditCompleted }

    private var selectedTheme: VisualTheme { VisualTheme(rawValue: selectedThemeRaw) ?? .defaultTheme }

    var body: some View {
        ScreenBackground { SwiftUI.ScrollView(.vertical, showsIndicators: true) { VStack(alignment: .leading, spacing: 16) {
            SectionHeader(title: freshOrder.originalEntry.area, subtitle: freshOrder.title)
            ModernCard { VStack(alignment: .leading, spacing: 10) {
                Picker("Status", selection: $status) { ForEach(WorkOrderStatus.allCases) { Text($0.rawValue).tag($0) } }
                    .disabled(isLockedCompleted)
                    .accessibilityIdentifier("workOrder.status")
                if isLockedCompleted {
                    Text("Completed work orders are locked. Tap Making Changes to create a new revision without editing original evidence.")
                        .font(.caption)
                        .foregroundStyle(.secondary)
                    Button("Making Changes") { confirmEditCompleted = true }
                        .buttonStyle(.bordered)
                }
                Button("Email Work Order") { mailDraft = EmailHelper.draft(order: freshOrder) }
                    .buttonStyle(.bordered)
                LegalBanner(kind: .export)
                Button("Export PDF") { shareURL = store.reportPDFURL(orders: [freshOrder], title: "Work Order") }
                    .buttonStyle(.borderedProminent)
            } }
            if !isLockedCompleted {
                WorkOrderEntryForm(entry: $draft, activePhotoImports: $activePhotoImports, includeSignature: status == .completed)
                if !draft.hasRequiredFields {
                    Text("An area and issue description are required before this revision can be saved.")
                        .font(.caption)
                        .foregroundStyle(.red)
                }
            } else {
                ReadOnlyWorkOrderView(order: freshOrder)
            }
            ModernCard { VStack(alignment: .leading, spacing: 8) { SectionHeader(title: "Activity Log", subtitle: "Timestamped audit trail."); ForEach(freshOrder.auditLog) { event in Text("\(event.date.shortDateTime) - \(event.message)").font(.caption) } } }
            if !isLockedCompleted {
                PrimaryActionButton(title: status == .completed ? "Sign and Save" : "Save", systemImage: "checkmark.seal") {
                    if status == .completed {
                        showSignature = true
                    } else {
                        _ = save()
                    }
                }
                .disabled(!draft.hasRequiredFields || activePhotoImports > 0)
                .accessibilityIdentifier(status == .completed ? "workOrder.signAndSave" : "workOrder.save")
            }
        }.padding(AppTheme.horizontalPadding(for: selectedTheme)).padding(.bottom, 28) } }
        .navigationTitle("Work Order")
        .onAppear { store.addAudit(to: freshOrder, message: "Work order opened") }
        .onDisappear { cleanupUncommittedAttachments() }
        .sheet(isPresented: $showSignature) { SignatureCaptureView(entry: $draft) { save() } }
        .sheet(item: $mailDraft) { draft in
            if MFMailComposeViewController.canSendMail() {
                MailComposerView(draft: draft)
            } else {
                ShareSheet(items: [draft.shareText as Any] + draft.attachmentURLs.map { $0 as Any })
            }
        }
        .sheet(item: Binding(get: { shareURL.map { IdentifiableURL(url: $0) } }, set: { _ in shareURL = nil })) { ShareSheet(items: [$0.url]) }
    }

    @discardableResult
    private func save() -> Bool {
        guard activePhotoImports == 0 else { return false }
        let saved = store.update(
            order: freshOrder,
            expectedLatestEntryID: baseRevisionID,
            newEntry: draft,
            status: status
        )
        guard saved,
              let current = store.workOrders.first(where: { $0.id == order.id }) else {
            return false
        }
        draft = current.latestEntry
        status = current.status
        baseRevisionID = current.latestEntry.id
        confirmEditCompleted = false
        return true
    }

    private func cleanupUncommittedAttachments() {
        let referencedImages = Set(store.workOrders.flatMap { order in
            order.entries.flatMap { $0.images.map(\.filename) }
        })
        for image in draft.images where !referencedImages.contains(image.filename) {
            ImageStorageService.delete(image)
        }

        let referencedSignatures = Set(store.workOrders.flatMap { order in
            order.entries.compactMap(\.signatureFilename)
        })
        if let filename = draft.signatureFilename,
           !referencedSignatures.contains(filename) {
            SignatureStorageService.delete(filename: filename)
        }
    }
}

struct ReadOnlyWorkOrderView: View {
    let order: WorkOrder
    var body: some View { ModernCard { VStack(alignment: .leading, spacing: 8) { InfoLine(title: "Area", value: order.latestEntry.area); InfoLine(title: "Category", value: order.latestEntry.managedCategory.rawValue); InfoLine(title: "Priority", value: order.latestEntry.priority.rawValue); InfoLine(title: "Handyman", value: order.latestEntry.handymanName.isEmpty ? "Unassigned" : order.latestEntry.handymanName); InfoLine(title: "Entry Permitted", value: order.latestEntry.entryPermitted ? "Yes" : "No"); InfoLine(title: "Tenant Permission", value: (order.latestEntry.tenantPermission ?? order.latestEntry.entryPermitted) ? "Yes" : "No"); InfoLine(title: "Entry Method", value: order.latestEntry.entryMethod?.rawValue ?? "Not specified"); InfoLine(title: "Asset", value: order.latestEntry.assetTag.isEmpty ? "None" : order.latestEntry.assetTag); InfoLine(title: "Asset ID", value: order.latestEntry.assetID ?? "None"); Text(order.latestEntry.notes).font(.subheadline).foregroundStyle(.secondary) } } }
}

struct IdentifiableURL: Identifiable {
    let url: URL
    var id: String { url.absoluteString }
}

struct MailAttachment {
    let data: Data
    let mimeType: String
    let filename: String
    let fileURL: URL?

    init(data: Data, mimeType: String, filename: String, fileURL: URL? = nil) {
        self.data = data
        self.mimeType = mimeType
        self.filename = filename
        self.fileURL = fileURL
    }
}

struct MailDraft: Identifiable {
    let id = UUID()
    let recipients: [String]
    let subject: String
    let body: String
    let attachments: [MailAttachment]

    init(
        recipients: [String] = [],
        subject: String,
        body: String,
        attachments: [MailAttachment] = []
    ) {
        self.recipients = recipients
        self.subject = subject
        self.body = body
        self.attachments = attachments
    }

    var shareText: String {
        "\(subject)\n\n\(body)"
    }

    var attachmentURLs: [URL] {
        attachments.compactMap(\.fileURL)
    }
}

@MainActor
struct MailComposerView: UIViewControllerRepresentable {
    let draft: MailDraft
    @Environment(\.dismiss) private var dismiss

    func makeCoordinator() -> Coordinator {
        Coordinator { dismiss() }
    }

    func makeUIViewController(context: Context) -> MFMailComposeViewController {
        let controller = MFMailComposeViewController()
        controller.mailComposeDelegate = context.coordinator
        if !draft.recipients.isEmpty {
            controller.setToRecipients(draft.recipients)
        }
        controller.setSubject(draft.subject)
        controller.setMessageBody(draft.body, isHTML: false)
        for attachment in draft.attachments {
            controller.addAttachmentData(
                attachment.data,
                mimeType: attachment.mimeType,
                fileName: attachment.filename
            )
        }
        return controller
    }

    func updateUIViewController(_ uiViewController: MFMailComposeViewController, context: Context) {}

    final class Coordinator: NSObject, MFMailComposeViewControllerDelegate {
        private let dismissAction: @MainActor @Sendable () -> Void

        init(dismiss: @escaping @MainActor @Sendable () -> Void) {
            self.dismissAction = dismiss
        }

        nonisolated func mailComposeController(
            _ controller: MFMailComposeViewController,
            didFinishWith result: MFMailComposeResult,
            error: Error?
        ) {
            let dismissAction = dismissAction
            Task { @MainActor in
                dismissAction()
            }
        }
    }
}

enum EmailHelper {
    static func draft(order: WorkOrder) -> MailDraft {
        let entry = order.latestEntry
        let subject = "Work Order - \(order.originalEntry.area)"
        let body = [
            "Work Order: \(order.title)",
            "Status: \(order.status.rawValue)",
            "Area: \(entry.area)",
            "Category: \(entry.managedCategory.rawValue)",
            "Priority: \(entry.priority.rawValue)",
            "Created: \(order.createdAt.shortDateTime)",
            "Entry Method: \(entry.entryMethod?.rawValue ?? "Not specified")",
            "Tenant Permission: \((entry.tenantPermission ?? entry.entryPermitted) ? "Yes" : "No")",
            "Notes: \(entry.notes)"
        ].joined(separator: "\n")
        return MailDraft(subject: subject, body: body)
    }

    static func supportDraft(diagnosticsURL: URL? = nil) -> MailDraft {
        var attachments: [MailAttachment] = []
        if let diagnosticsURL,
           let data = try? Data(contentsOf: diagnosticsURL) {
            attachments.append(
                MailAttachment(
                    data: data,
                    mimeType: diagnosticsURL.pathExtension.lowercased() == "iworkordersupport" ? "application/json" : "text/plain",
                    filename: diagnosticsURL.lastPathComponent,
                    fileURL: diagnosticsURL
                )
            )
        }

        let attachmentDescription: String
        if let diagnosticsURL {
            attachmentDescription = diagnosticsURL.pathExtension.lowercased() == "iworkordersupport"
                ? "A verified privacy-safe support bundle is attached. It excludes work-order content and personal information."
                : "A privacy-safe diagnostics file is attached. It excludes work-order content and personal information."
        } else {
            attachmentDescription = "No diagnostics file is attached."
        }

        return MailDraft(
            recipients: [LegalContent.supportEmail],
            subject: "iWorkOrder Support - \(AppBuildInfo.displayVersion)",
            body: [
                "Describe what happened and the steps that led to the problem.",
                "",
                attachmentDescription
            ].joined(separator: "\n"),
            attachments: attachments
        )
    }

    @MainActor
    static func openSupportEmail() {
        var components = URLComponents()
        components.scheme = "mailto"
        components.path = LegalContent.supportEmail
        components.queryItems = [URLQueryItem(name: "subject", value: "iWorkOrder Support")]
        guard let url = components.url else { return }
        UIApplication.shared.open(url)
    }
}

// MARK: - Design 2 isolated Orders UI

enum Theme2StatusFilter: String, CaseIterable, Identifiable {
    case open = "Open"
    case completed = "Completed"
    case overdue = "Overdue"
    case all = "All"
    var id: String { rawValue }
}

struct Theme2OrdersHomeView: View {
    @EnvironmentObject private var store: AppStore
    @State private var quickAdd = false
    @State private var newOrder = false
    @State private var selectedDeepLink: WorkOrder?
    @State private var selectedTheme2Status: Theme2StatusFilter = .open

    private var theme2FilteredWorkOrders: [WorkOrder] {
        store.activeWorkOrders.filter { order in
            switch selectedTheme2Status {
            case .open:
                return order.status != .completed
            case .completed:
                return order.status == .completed
            case .overdue:
                return order.status != .completed &&
                    order.latestEntry.reminderEnabled &&
                    order.latestEntry.reminderDate < Date()
            case .all:
                return true
            }
        }
    }

    private var openCount: Int { store.activeWorkOrders.filter { $0.status != .completed }.count }
    private var completedCount: Int { store.activeWorkOrders.filter { $0.status == .completed }.count }
    private var overdueCount: Int {
        store.activeWorkOrders.filter {
            $0.status != .completed &&
            $0.latestEntry.reminderEnabled &&
            $0.latestEntry.reminderDate < Date()
        }.count
    }
    private var workerCount: Int {
        Set(store.activeWorkOrders.map {
            $0.latestEntry.handymanName.trimmingCharacters(in: .whitespacesAndNewlines)
        }.filter { !$0.isEmpty }).count
    }

    var body: some View {
        NavigationStack {
            Theme2Background {
                ScrollView(showsIndicators: false) {
                    VStack(alignment: .leading, spacing: 18) {
                        Theme2OrdersHero(total: store.activeWorkOrders.count)
                            .environmentObject(store)
                        Theme2HorizontalStats(
                            open: openCount,
                            completed: completedCount,
                            overdue: overdueCount,
                            workers: workerCount
                        )
                        HStack {
                            Button { quickAdd = true } label: {
                                Label("Quick Add", systemImage: "bolt.fill")
                                    .font(.headline.weight(.bold))
                                    .foregroundStyle(.blue)
                                    .padding(.horizontal, 18)
                                    .padding(.vertical, 10)
                                    .background(Color.blue.opacity(0.10), in: Capsule())
                                    .overlay(Capsule().stroke(Color.blue.opacity(0.22), lineWidth: 1))
                            }
                            Spacer()
                            Button { newOrder = true } label: {
                                Label("Full Order", systemImage: "square.and.pencil")
                                    .font(.headline.weight(.bold))
                                    .foregroundStyle(Color.black.opacity(0.88))
                                    .padding(.horizontal, 18)
                                    .padding(.vertical, 10)
                                    .background(Color.white.opacity(0.78), in: Capsule())
                                    .overlay(Capsule().stroke(Color.black.opacity(0.10), lineWidth: 1))
                            }
                        }
                        .padding(.top, 2)

                        Theme2StatusPicker(selection: $selectedTheme2Status)


                        if theme2FilteredWorkOrders.isEmpty {
                            Theme2EmptyCard(title: "No work orders", subtitle: "Orders matching this filter will show here.", icon: "tray")
                        } else {
                            LazyVStack(spacing: 12) {
                                ForEach(theme2FilteredWorkOrders) { order in
                                    NavigationLink { WorkOrderDetailView(order: order) } label: {
                                        Theme2OrderRow(order: order)
                                    }
                                    .buttonStyle(.plain)
                                }
                            }
                        }
                    }
                    .padding(.horizontal, 18)
                    .padding(.top, 18)
                    .padding(.bottom, 110)
                }
            }
            .navigationBarTitleDisplayMode(.inline)
            .toolbar(.hidden, for: .navigationBar)
            .accessibilityIdentifier(AccessibilityID.workOrdersScreen)
            .sheet(isPresented: $quickAdd) { QuickAddView() }
            .sheet(isPresented: $newOrder) { NewWorkOrderView() }
            .onAppear { openDeepLinkedOrderIfNeeded() }
            .onChange(of: store.deepLinkedOrderID) { _, _ in openDeepLinkedOrderIfNeeded() }
            .onChange(of: store.activeWorkOrders.map(\.id)) { _, _ in openDeepLinkedOrderIfNeeded() }
            .navigationDestination(item: $selectedDeepLink) { WorkOrderDetailView(order: $0) }
        }
    }

    private func openDeepLinkedOrderIfNeeded() {
        guard let id = store.deepLinkedOrderID, let order = store.activeWorkOrders.first(where: { $0.id == id }) else { return }
        selectedDeepLink = order
        store.deepLinkedOrderID = nil
    }
}

struct Theme2Background<Content: View>: View {
    @ViewBuilder var content: Content
    var body: some View {
        ZStack {
            LinearGradient(colors: [Color(red: 0.94, green: 0.96, blue: 1.0), Color(red: 0.98, green: 0.98, blue: 1.0), Color(red: 0.86, green: 0.96, blue: 0.97)], startPoint: .topLeading, endPoint: .bottomTrailing)
                .ignoresSafeArea()
            Circle().fill(Color.blue.opacity(0.10)).frame(width: 260, height: 260).blur(radius: 70).offset(x: -160, y: -290).accessibilityHidden(true)
            Circle().fill(Color.cyan.opacity(0.12)).frame(width: 360, height: 360).blur(radius: 80).offset(x: 165, y: 360).accessibilityHidden(true)
            content
        }
    }
}

struct Theme2OrdersHero: View {
    @EnvironmentObject private var store: AppStore
    let total: Int
    var body: some View {
        VStack(alignment: .leading, spacing: 16) {
            HStack(alignment: .top) {
                VStack(alignment: .leading, spacing: 8) {
                    Text("iWorkOrder")
                        .font(.caption.weight(.black))
                        .tracking(3.0)
                        .foregroundStyle(.white.opacity(0.55))
                    Text("\(store.profile.buildingName.isEmpty ? "Building" : store.profile.buildingName) - \(store.profile.personName.isEmpty ? "User" : store.profile.personName)")
                        .font(.system(.title, design: .monospaced).weight(.black))
                        .foregroundStyle(.white)
                        .lineLimit(3)
                        .minimumScaleFactor(0.62)
                    Text(store.profile.buildingAddress.isEmpty ? "\(total) active work orders" : store.profile.buildingAddress)
                        .font(.subheadline.weight(.bold))
                        .foregroundStyle(.white.opacity(0.72))
                        .lineLimit(2)
                }
            }
        }
        .padding(20)
        .frame(maxWidth: .infinity, alignment: .leading)
        .background(AppTheme.heroGradient(for: .design2), in: RoundedRectangle(cornerRadius: 20, style: .continuous))
        .overlay(alignment: .topTrailing) {
            HStack(spacing: 5) {
                Circle().fill(Color.green).frame(width: 7, height: 7)
                Circle().fill(Color.cyan).frame(width: 7, height: 7)
                Circle().fill(Color.white.opacity(0.32)).frame(width: 7, height: 7)
            }
            .padding(16)
            .accessibilityHidden(true)
        }
        .overlay(RoundedRectangle(cornerRadius: 20, style: .continuous).stroke(Color.cyan.opacity(0.20), lineWidth: 1))
        .clipShape(RoundedRectangle(cornerRadius: 20, style: .continuous))
        .accessibilityIdentifier("theme.surface.design2")
    }
}

struct Theme2HorizontalStats: View {
    let open: Int
    let completed: Int
    let overdue: Int
    let workers: Int

    var body: some View {
        ScrollView(.horizontal, showsIndicators: false) {
            HStack(spacing: 14) {
                Theme2MiniStat(title: "Open", value: "\(open)", icon: "tray.full.fill", tint: .orange)
                Theme2MiniStat(title: "Completed", value: "\(completed)", icon: "checkmark.seal.fill", tint: .green)
                Theme2MiniStat(title: "Overdue", value: "\(overdue)", icon: "clock.badge.exclamationmark.fill", tint: .red)
                Theme2MiniStat(title: "Workers", value: "\(workers)", icon: "person.2.fill", tint: .purple)
            }
        }
    }
}

struct Theme2MiniStat: View {
    @ScaledMetric(relativeTo: .body) private var tileWidth: CGFloat = 152
    let title: String
    let value: String
    let icon: String
    let tint: Color
    var body: some View {
        HStack(spacing: 12) {
            Image(systemName: icon)
                .font(.headline.weight(.bold))
                .foregroundStyle(tint)
                .frame(width: 42, height: 42)
                .background(tint.opacity(0.14), in: RoundedRectangle(cornerRadius: 8, style: .continuous))
            VStack(alignment: .leading, spacing: 2) {
                Text(value).font(.system(.title2, design: .monospaced).weight(.black)).foregroundStyle(.black)
                Text(title.uppercased()).font(.system(.caption2, design: .monospaced).weight(.black)).tracking(1.5).foregroundStyle(.gray)
            }
        }
        .padding(12)
        .frame(width: tileWidth, alignment: .leading)
        .background(Color.white.opacity(0.94), in: RoundedRectangle(cornerRadius: 14, style: .continuous))
        .overlay(RoundedRectangle(cornerRadius: 14, style: .continuous).stroke(Color.black.opacity(0.08), lineWidth: 1))
    }
}

struct Theme2StatusPicker: View {
    @Binding var selection: Theme2StatusFilter
    var body: some View {
        Picker("Status", selection: $selection) {
            ForEach(Theme2StatusFilter.allCases) { filter in
                Text(filter.rawValue).tag(filter)
            }
        }
        .pickerStyle(.segmented)
        .padding(4)
        .background(Color.white.opacity(0.82), in: RoundedRectangle(cornerRadius: 12, style: .continuous))
    }
}

struct Theme2OrderRow: View {
    let order: WorkOrder

    private var statusTitle: String {
        switch order.status {
        case .new: return "New"
        case .pending: return "Pending"
        case .inProgress: return "In progress"
        case .completed: return "Completed"
        }
    }

    private var statusColor: Color {
        switch order.status {
        case .completed: return .green
        case .inProgress: return .blue
        case .new, .pending: return .orange
        }
    }

    var body: some View {
        VStack(alignment: .leading, spacing: 9) {
            HStack(alignment: .top) {
                VStack(alignment: .leading, spacing: 5) {
                    Text(order.originalEntry.area).font(.system(.title3, design: .monospaced).weight(.black)).foregroundStyle(.black)
                    Text(order.title).font(.subheadline.weight(.semibold)).foregroundStyle(.black)
                }
                Spacer()
                Text(statusTitle.uppercased())
                    .font(.system(.caption2, design: .monospaced).weight(.black))
                    .foregroundStyle(statusColor)
                    .padding(.horizontal, 12)
                    .padding(.vertical, 6)
                    .background(statusColor.opacity(0.12), in: Capsule())
            }
            HStack(spacing: 10) {
                Label(order.latestEntry.managedCategory.rawValue, systemImage: "folder.fill")
                    .font(.caption.weight(.bold))
                    .lineLimit(1)
                    .foregroundStyle(.gray)
                    .padding(.horizontal, 10)
                    .padding(.vertical, 6)
                    .background(Color.white.opacity(0.65), in: Capsule())
                Spacer()
            }
            Text(order.latestEntry.priority.rawValue)
                .font(.subheadline.weight(.black))
                .foregroundStyle(.orange)
        }
        .padding(16)
        .overlay(alignment: .leading) { RoundedRectangle(cornerRadius: 4).fill(Color.orange).frame(width: 5).padding(.vertical, 12) }
        .background(Color.white.opacity(0.96), in: RoundedRectangle(cornerRadius: 14, style: .continuous))
        .overlay(RoundedRectangle(cornerRadius: 14, style: .continuous).stroke(Color.black.opacity(0.09), lineWidth: 1))
    }
}

struct Theme2EmptyCard: View {
    let title: String
    let subtitle: String
    let icon: String
    var body: some View {
        VStack(spacing: 12) {
            Image(systemName: icon).font(.largeTitle).foregroundStyle(.gray)
            Text(title).font(.title2.weight(.black)).foregroundStyle(.black)
            Text(subtitle).font(.headline).foregroundStyle(.gray).multilineTextAlignment(.center)
        }
        .frame(maxWidth: .infinity)
        .padding(.vertical, 42)
        .padding(.horizontal, 18)
        .background(Color.white.opacity(0.96), in: RoundedRectangle(cornerRadius: 16, style: .continuous))
    }
}


// MARK: - Design 3 field-deck theme

struct Theme3OrdersHomeView: View {
    @EnvironmentObject private var store: AppStore
    @State private var quickAdd = false
    @State private var newOrder = false
    @State private var selectedDeepLink: WorkOrder?
    @State private var theme3Status: Theme3StatusFilter = .open

    private var filteredTheme3Orders: [WorkOrder] {
        var orders = store.activeWorkOrders
        switch theme3Status {
        case .open:
            orders = orders.filter { $0.status != .completed }
        case .completed:
            orders = orders.filter { $0.status == .completed }
        case .overdue:
            orders = orders.filter {
                $0.status != .completed && $0.latestEntry.reminderEnabled && $0.latestEntry.reminderDate < Date()
            }
        case .all:
            break
        }

        let filters = store.filters
        let unit = filters.unit.trimmingCharacters(in: .whitespacesAndNewlines)
        let handyman = filters.handyman.trimmingCharacters(in: .whitespacesAndNewlines)
        let query = filters.searchText.trimmingCharacters(in: .whitespacesAndNewlines)

        return orders.filter { order in
            let entry = order.latestEntry
            if filters.emergencyOnly && entry.priority != .emergency { return false }
            if let category = filters.category,
               WorkOrderCategory.identityKey(entry.managedCategory.rawValue) != WorkOrderCategory.identityKey(category.rawValue) {
                return false
            }
            if !unit.isEmpty && !entry.area.localizedCaseInsensitiveContains(unit) { return false }
            if !handyman.isEmpty && !entry.handymanName.localizedCaseInsensitiveContains(handyman) { return false }
            if !query.isEmpty {
                let haystack = [
                    entry.area,
                    order.title,
                    entry.issueDescription,
                    entry.notes,
                    entry.assetTag,
                    entry.assetID ?? "",
                    entry.handymanName,
                    entry.managedCategory.rawValue,
                    entry.priority.rawValue
                ].joined(separator: " ")
                if !haystack.localizedCaseInsensitiveContains(query) { return false }
            }
            return true
        }
        .sorted { lhs, rhs in
            if lhs.latestEntry.priority == .emergency && rhs.latestEntry.priority != .emergency { return true }
            if rhs.latestEntry.priority == .emergency && lhs.latestEntry.priority != .emergency { return false }
            return lhs.createdAt > rhs.createdAt
        }
    }

    private var theme3Units: [String] {
        Array(Set(store.activeWorkOrders.map {
            $0.latestEntry.area.trimmingCharacters(in: .whitespacesAndNewlines)
        }.filter { !$0.isEmpty })).sorted()
    }

    private var theme3Workers: [String] {
        Array(Set(store.activeWorkOrders.map {
            $0.latestEntry.handymanName.trimmingCharacters(in: .whitespacesAndNewlines)
        }.filter { !$0.isEmpty })).sorted()
    }

    private var openCount: Int { store.activeWorkOrders.filter { $0.status != .completed }.count }
    private var doneCount: Int { store.activeWorkOrders.filter { $0.status == .completed }.count }
    private var lateCount: Int {
        store.activeWorkOrders.filter {
            $0.status != .completed && $0.latestEntry.reminderEnabled && $0.latestEntry.reminderDate < Date()
        }.count
    }

    var body: some View {
        NavigationStack {
            Theme3Background {
                SwiftUI.ScrollView(.vertical, showsIndicators: true) {
                    VStack(alignment: .leading, spacing: 14) {
                        Theme3OrdersHero(total: openCount) { newOrder = true }
                        Theme3SearchBar()
                        Theme3StatStrip(open: openCount, done: doneCount, late: lateCount)
                        Theme3FilterCard(selection: $theme3Status, units: theme3Units, workers: theme3Workers)

                        AdaptiveButtonPair {
                            Theme3ActionPill(title: "Quick Capture", icon: "bolt.fill", isPrimary: false) { quickAdd = true }
                        } second: {
                            Theme3ActionPill(title: "New Work Order", icon: "plus", isPrimary: true) { newOrder = true }
                        }

                        Theme3ListHeader(count: filteredTheme3Orders.count, filter: theme3Status)

                        if filteredTheme3Orders.isEmpty {
                            Theme3EmptyOrdersCard()
                        } else {
                            LazyVStack(spacing: 10) {
                                ForEach(filteredTheme3Orders) { order in
                                    NavigationLink { WorkOrderDetailView(order: order) } label: {
                                        Theme3OrderRow(order: order)
                                    }
                                    .buttonStyle(.plain)
                                }
                            }
                        }
                    }
                    .padding(.horizontal, 16)
                    .padding(.top, 10)
                    .padding(.bottom, 110)
                }
            }
            .navigationTitle("Field")
            .navigationBarTitleDisplayMode(.inline)
            .accessibilityIdentifier(AccessibilityID.workOrdersScreen)
            .sheet(isPresented: $quickAdd) { QuickAddView() }
            .sheet(isPresented: $newOrder) { NewWorkOrderView() }
            .onAppear { openDeepLinkedOrderIfNeeded() }
            .onChange(of: store.deepLinkedOrderID) { _, _ in openDeepLinkedOrderIfNeeded() }
            .onChange(of: store.activeWorkOrders.map(\.id)) { _, _ in openDeepLinkedOrderIfNeeded() }
            .navigationDestination(item: $selectedDeepLink) { WorkOrderDetailView(order: $0) }
        }
    }

    private func openDeepLinkedOrderIfNeeded() {
        guard let id = store.deepLinkedOrderID,
              let order = store.activeWorkOrders.first(where: { $0.id == id }) else { return }
        selectedDeepLink = order
        store.deepLinkedOrderID = nil
    }
}

struct Theme3Background<Content: View>: View {
    @ViewBuilder var content: Content

    var body: some View {
        ZStack {
            AppTheme.background(for: .design3)
                .ignoresSafeArea()

            VStack(spacing: 28) {
                ForEach(0..<24, id: \.self) { _ in
                    Rectangle()
                        .fill(Color.white.opacity(0.026))
                        .frame(height: 1)
                }
            }
            .ignoresSafeArea()
            .accessibilityHidden(true)

            LinearGradient(
                colors: [AppTheme.accent(for: .design3).opacity(0.12), Color.clear],
                startPoint: .topTrailing,
                endPoint: .center
            )
            .ignoresSafeArea()
            .accessibilityHidden(true)

            content
        }
    }
}

struct Theme3SearchBar: View {
    @EnvironmentObject private var store: AppStore

    var body: some View {
        HStack(spacing: 11) {
            Image(systemName: "magnifyingglass")
                .font(.headline.weight(.heavy))
                .foregroundStyle(AppTheme.accent(for: .design3))
                .frame(width: 28)
            TextField("Search unit, worker, issue", text: $store.filters.searchText)
                .font(.body.weight(.medium))
                .foregroundStyle(AppTheme.textPrimary(for: .design3))
                .tint(AppTheme.accent(for: .design3))
        }
        .padding(.horizontal, 14)
        .frame(minHeight: 48)
        .background(Color(red: 0.055, green: 0.085, blue: 0.090), in: RoundedRectangle(cornerRadius: 9, style: .continuous))
        .overlay(
            RoundedRectangle(cornerRadius: 9, style: .continuous)
                .stroke(AppTheme.cardStroke(for: .design3), lineWidth: 1)
        )
    }
}

struct Theme3OrdersHero: View {
    @EnvironmentObject private var store: AppStore
    let total: Int
    let addAction: () -> Void

    private var displayBuilding: String {
        let name = store.profile.buildingName.trimmingCharacters(in: .whitespacesAndNewlines)
        return name.isEmpty ? "Building" : name
    }

    private var displayName: String {
        let name = store.profile.personName.trimmingCharacters(in: .whitespacesAndNewlines)
        return name.isEmpty ? "User" : name
    }

    var body: some View {
        HStack(alignment: .top, spacing: 14) {
            VStack(alignment: .leading, spacing: 8) {
                HStack(spacing: 7) {
                    RoundedRectangle(cornerRadius: 2)
                        .fill(AppTheme.accent(for: .design3))
                        .frame(width: 8, height: 8)
                    Text("FIELD DECK / ACTIVE")
                        .font(.caption2.weight(.heavy))
                        .tracking(1.7)
                        .foregroundStyle(AppTheme.accent(for: .design3))
                }

                Text(displayBuilding)
                    .font(.title.weight(.heavy))
                    .foregroundStyle(AppTheme.textPrimary(for: .design3))
                    .lineLimit(3)
                    .minimumScaleFactor(0.74)
                    .fixedSize(horizontal: false, vertical: true)

                Text("\(displayName)  •  \(total) open")
                    .font(.subheadline.weight(.semibold))
                    .foregroundStyle(AppTheme.textSecondary(for: .design3))
                    .lineLimit(2)
            }

            Spacer(minLength: 8)

            Button(action: addAction) {
                Image(systemName: "plus")
                    .font(.headline.weight(.heavy))
                    .foregroundStyle(Color(red: 0.03, green: 0.08, blue: 0.08))
                    .frame(width: 44, height: 44)
                    .background(AppTheme.accent(for: .design3), in: RoundedRectangle(cornerRadius: 8, style: .continuous))
            }
            .accessibilityLabel("New Work Order")
        }
        .padding(18)
        .frame(maxWidth: .infinity, minHeight: 150, alignment: .leading)
        .background(Color(red: 0.045, green: 0.075, blue: 0.080), in: RoundedRectangle(cornerRadius: 10, style: .continuous))
        .overlay(alignment: .top) {
            Rectangle()
                .fill(AppTheme.accent(for: .design3))
                .frame(height: 3)
                .padding(.horizontal, 14)
                .accessibilityHidden(true)
        }
        .overlay(
            RoundedRectangle(cornerRadius: 10, style: .continuous)
                .stroke(Color.white.opacity(0.07), lineWidth: 1)
        )
        .accessibilityIdentifier("theme.surface.design3")
    }
}

struct Theme3StatStrip: View {
    let open: Int
    let done: Int
    let late: Int

    var body: some View {
        LazyVGrid(columns: [GridItem(.adaptive(minimum: 100), spacing: 8)], spacing: 8) {
            Theme3MiniStat(title: "OPEN", value: "\(open)", icon: "tray.full.fill", tint: AppTheme.accent(for: .design3))
            Theme3MiniStat(title: "DONE", value: "\(done)", icon: "checkmark", tint: .green)
            Theme3MiniStat(title: "LATE", value: "\(late)", icon: "exclamationmark", tint: .orange)
        }
    }
}

struct Theme3MiniStat: View {
    let title: String
    let value: String
    let icon: String
    let tint: Color

    var body: some View {
        VStack(alignment: .leading, spacing: 8) {
            HStack {
                Text(title)
                    .font(.caption2.weight(.heavy))
                    .tracking(1.1)
                    .foregroundStyle(AppTheme.textSecondary(for: .design3))
                Spacer(minLength: 4)
                Image(systemName: icon)
                    .font(.caption.weight(.heavy))
                    .foregroundStyle(tint)
            }
            Text(value)
                .font(.title2.weight(.heavy))
                .foregroundStyle(AppTheme.textPrimary(for: .design3))
                .contentTransition(.numericText())
        }
        .padding(12)
        .frame(maxWidth: .infinity, alignment: .leading)
        .background(Color(red: 0.055, green: 0.085, blue: 0.090), in: RoundedRectangle(cornerRadius: 8, style: .continuous))
        .overlay(alignment: .bottom) {
            Rectangle().fill(tint.opacity(0.72)).frame(height: 2).padding(.horizontal, 8)
        }
    }
}

enum Theme3StatusFilter: String, CaseIterable, Identifiable {
    case open = "Open"
    case completed = "Completed"
    case overdue = "Overdue"
    case all = "All"
    var id: String { rawValue }
}

struct Theme3FilterCard: View {
    @EnvironmentObject private var store: AppStore
    @Binding var selection: Theme3StatusFilter
    let units: [String]
    let workers: [String]

    private var unitTitle: String {
        let value = store.filters.unit.trimmingCharacters(in: .whitespacesAndNewlines)
        return value.isEmpty ? "Unit" : value
    }

    private var workerTitle: String {
        let value = store.filters.handyman.trimmingCharacters(in: .whitespacesAndNewlines)
        return value.isEmpty ? "Worker" : value
    }

    private var categoryTitle: String { store.filters.category?.rawValue ?? "Category" }

    private var hasFieldFilters: Bool {
        !store.filters.unit.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty ||
        !store.filters.handyman.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty ||
        store.filters.category != nil ||
        store.filters.emergencyOnly
    }

    var body: some View {
        VStack(alignment: .leading, spacing: 12) {
            HStack {
                Text("QUEUE FILTER")
                    .font(.caption2.weight(.heavy))
                    .tracking(1.3)
                    .foregroundStyle(AppTheme.accent(for: .design3))
                Spacer()
                if hasFieldFilters {
                    Button("Reset") { store.filters = WorkOrderFilters() }
                        .font(.caption.weight(.bold))
                        .foregroundStyle(AppTheme.accent(for: .design3))
                }
            }

            SwiftUI.ScrollView(.horizontal, showsIndicators: false) {
                HStack(spacing: 7) {
                    ForEach(Theme3StatusFilter.allCases) { filter in
                        Button {
                            selection = filter
                        } label: {
                            Text(filter.rawValue.uppercased())
                                .font(.caption2.weight(.heavy))
                                .tracking(0.8)
                                .foregroundStyle(selection == filter ? Color(red: 0.03, green: 0.08, blue: 0.08) : AppTheme.textSecondary(for: .design3))
                                .padding(.horizontal, 11)
                                .frame(minHeight: 34)
                                .background(selection == filter ? AppTheme.accent(for: .design3) : Color.white.opacity(0.055), in: RoundedRectangle(cornerRadius: 6, style: .continuous))
                        }
                        .buttonStyle(.plain)
                    }
                }
            }

            LazyVGrid(columns: [GridItem(.adaptive(minimum: 140), spacing: 8)], spacing: 8) {
                Menu {
                    Button("All Units") { store.filters.unit = "" }
                    ForEach(units, id: \.self) { unit in
                        Button(unit) { store.filters.unit = unit }
                    }
                } label: {
                    Theme3Pill(title: unitTitle, icon: "building.2", isActive: !store.filters.unit.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty)
                }

                Menu {
                    Button("All Workers") { store.filters.handyman = "" }
                    ForEach(workers, id: \.self) { worker in
                        Button(worker) { store.filters.handyman = worker }
                    }
                } label: {
                    Theme3Pill(title: workerTitle, icon: "person.crop.circle", isActive: !store.filters.handyman.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty)
                }

                Menu {
                    Button("All Categories") { store.filters.category = nil }
                    ForEach(store.filterCategories) { category in
                        Button(category.rawValue) { store.filters.category = category }
                    }
                } label: {
                    Theme3Pill(title: categoryTitle, icon: "tag", isActive: store.filters.category != nil)
                }

                Button {
                    store.filters.emergencyOnly.toggle()
                } label: {
                    Theme3Pill(title: "Emergency", icon: "exclamationmark.triangle.fill", isActive: store.filters.emergencyOnly, trailingIcon: store.filters.emergencyOnly ? "checkmark" : "circle")
                }
                .buttonStyle(.plain)
                .accessibilityLabel("Emergency work orders only")
                .accessibilityValue(store.filters.emergencyOnly ? "On" : "Off")
            }
        }
        .padding(13)
        .background(Color(red: 0.045, green: 0.070, blue: 0.075), in: RoundedRectangle(cornerRadius: 9, style: .continuous))
        .overlay(RoundedRectangle(cornerRadius: 9, style: .continuous).stroke(Color.white.opacity(0.07), lineWidth: 1))
    }
}

struct Theme3Pill: View {
    let title: String
    let icon: String
    var isActive: Bool = false
    var trailingIcon: String = "chevron.down"

    var body: some View {
        HStack(spacing: 7) {
            Image(systemName: icon)
                .font(.caption.weight(.heavy))
            Text(title)
                .font(.caption.weight(.semibold))
                .lineLimit(1)
                .minimumScaleFactor(0.78)
            Spacer(minLength: 2)
            Image(systemName: trailingIcon)
                .font(.caption2.weight(.heavy))
        }
        .foregroundStyle(isActive ? AppTheme.accent(for: .design3) : AppTheme.textSecondary(for: .design3))
        .padding(.horizontal, 10)
        .frame(maxWidth: .infinity, minHeight: 38)
        .background(isActive ? AppTheme.accent(for: .design3).opacity(0.10) : Color.white.opacity(0.045), in: RoundedRectangle(cornerRadius: 6, style: .continuous))
        .overlay(
            RoundedRectangle(cornerRadius: 6, style: .continuous)
                .stroke(isActive ? AppTheme.accent(for: .design3).opacity(0.34) : Color.white.opacity(0.07), lineWidth: 1)
        )
    }
}

struct Theme3ActionPill: View {
    let title: String
    let icon: String
    var isPrimary: Bool
    let action: () -> Void

    var body: some View {
        Button(action: action) {
            HStack(spacing: 8) {
                Image(systemName: icon)
                    .font(.subheadline.weight(.heavy))
                Text(title)
                    .font(.subheadline.weight(.heavy))
                    .lineLimit(2)
            }
            .foregroundStyle(isPrimary ? Color(red: 0.03, green: 0.08, blue: 0.08) : AppTheme.accent(for: .design3))
            .frame(maxWidth: .infinity, minHeight: 48)
            .padding(.horizontal, 12)
            .background(isPrimary ? AppTheme.accent(for: .design3) : Color.white.opacity(0.045), in: RoundedRectangle(cornerRadius: 8, style: .continuous))
            .overlay(
                RoundedRectangle(cornerRadius: 8, style: .continuous)
                    .stroke(AppTheme.accent(for: .design3).opacity(isPrimary ? 0 : 0.36), lineWidth: 1)
            )
        }
        .buttonStyle(.plain)
    }
}

struct Theme3ListHeader: View {
    let count: Int
    let filter: Theme3StatusFilter

    var body: some View {
        HStack(spacing: 8) {
            Rectangle()
                .fill(AppTheme.accent(for: .design3))
                .frame(width: 18, height: 2)
            Text("\(filter.rawValue.uppercased()) QUEUE")
                .font(.caption2.weight(.heavy))
                .tracking(1.4)
                .foregroundStyle(AppTheme.textSecondary(for: .design3))
            Spacer()
            Text("\(count)")
                .font(.caption.weight(.heavy))
                .foregroundStyle(AppTheme.accent(for: .design3))
        }
        .padding(.top, 4)
    }
}

struct Theme3OrderRow: View {
    let order: WorkOrder

    private var priorityTint: Color {
        switch order.latestEntry.priority {
        case .emergency: return .red
        case .high: return .orange
        case .normal: return AppTheme.accent(for: .design3)
        case .low: return .cyan
        }
    }

    private var statusTitle: String {
        switch order.status {
        case .completed: return "DONE"
        case .inProgress: return "ACTIVE"
        case .pending: return "HOLD"
        case .new: return "NEW"
        }
    }

    private var statusTint: Color {
        switch order.status {
        case .completed: return .green
        case .inProgress: return AppTheme.accent(for: .design3)
        case .pending: return .orange
        case .new: return .cyan
        }
    }

    var body: some View {
        VStack(alignment: .leading, spacing: 9) {
            HStack(alignment: .firstTextBaseline, spacing: 8) {
                Text(order.latestEntry.area.isEmpty ? "AREA" : order.latestEntry.area)
                    .font(.headline.weight(.heavy))
                    .foregroundStyle(AppTheme.textPrimary(for: .design3))
                    .lineLimit(2)
                Spacer(minLength: 8)
                Text(statusTitle)
                    .font(.caption2.weight(.heavy))
                    .tracking(0.9)
                    .foregroundStyle(statusTint)
                    .padding(.horizontal, 8)
                    .padding(.vertical, 5)
                    .background(statusTint.opacity(0.11), in: RoundedRectangle(cornerRadius: 5, style: .continuous))
            }

            Text(order.title)
                .font(.subheadline.weight(.medium))
                .foregroundStyle(AppTheme.textSecondary(for: .design3))
                .lineLimit(3)
                .fixedSize(horizontal: false, vertical: true)

            HStack(spacing: 8) {
                Label(order.latestEntry.managedCategory.rawValue, systemImage: "folder")
                    .font(.caption2.weight(.semibold))
                    .foregroundStyle(AppTheme.textSecondary(for: .design3))
                    .lineLimit(1)
                Spacer(minLength: 6)
                Text(order.latestEntry.priority.rawValue.uppercased())
                    .font(.caption2.weight(.heavy))
                    .foregroundStyle(priorityTint)
                    .lineLimit(1)
            }
        }
        .padding(13)
        .padding(.leading, 4)
        .frame(maxWidth: .infinity, alignment: .leading)
        .background(Color(red: 0.052, green: 0.080, blue: 0.084), in: RoundedRectangle(cornerRadius: 8, style: .continuous))
        .clipShape(RoundedRectangle(cornerRadius: 8, style: .continuous))
        .overlay(alignment: .leading) {
            Rectangle()
                .fill(priorityTint)
                .frame(width: 4)
                .accessibilityHidden(true)
        }
        .overlay(
            RoundedRectangle(cornerRadius: 8, style: .continuous)
                .stroke(Color.white.opacity(0.065), lineWidth: 1)
        )
    }
}

struct Theme3EmptyOrdersCard: View {
    var body: some View {
        VStack(alignment: .leading, spacing: 10) {
            HStack {
                Image(systemName: "checkmark.seal.fill")
                    .font(.title2)
                    .foregroundStyle(AppTheme.accent(for: .design3))
                Spacer()
                Text("CLEAR")
                    .font(.caption2.weight(.heavy))
                    .tracking(1.3)
                    .foregroundStyle(AppTheme.accent(for: .design3))
            }
            Text("No matching work orders")
                .font(.title3.weight(.heavy))
                .foregroundStyle(AppTheme.textPrimary(for: .design3))
            Text("Change the queue filter or clear search and field filters to show more work.")
                .font(.subheadline)
                .foregroundStyle(AppTheme.textSecondary(for: .design3))
                .fixedSize(horizontal: false, vertical: true)
        }
        .frame(maxWidth: .infinity, alignment: .leading)
        .padding(18)
        .background(Color(red: 0.045, green: 0.070, blue: 0.075), in: RoundedRectangle(cornerRadius: 9, style: .continuous))
        .overlay(RoundedRectangle(cornerRadius: 9, style: .continuous).stroke(AppTheme.cardStroke(for: .design3), lineWidth: 1))
    }
}

