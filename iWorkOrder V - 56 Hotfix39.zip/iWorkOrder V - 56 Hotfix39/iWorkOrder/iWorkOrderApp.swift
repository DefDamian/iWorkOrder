import SwiftUI
import UIKit

@MainActor
final class AppDelegate: NSObject, UIApplicationDelegate {
    func application(_ application: UIApplication, didFinishLaunchingWithOptions launchOptions: [UIApplication.LaunchOptionsKey: Any]? = nil) -> Bool {
        NotificationService.shared.configure()
        RuntimeReliabilityService.beginSession()
        return true
    }

    func applicationDidReceiveMemoryWarning(_ application: UIApplication) {
        RuntimeReliabilityService.noteMemoryWarning()
    }
}


private struct AppPrivacyShieldView: View {
    @Environment(\.colorScheme) private var colorScheme
    @Environment(\.accessibilityReduceTransparency) private var reduceTransparency

    var body: some View {
        ZStack {
            if reduceTransparency {
                Color("LaunchBackground")
            } else {
                Rectangle()
                    .fill(.regularMaterial)

                Color.black
                    .opacity(colorScheme == .dark ? 0.20 : 0.05)
            }

            Image("LaunchLogo")
                .resizable()
                .scaledToFit()
                .frame(width: 58, height: 58)
                .padding(18)
                .background(
                    reduceTransparency
                        ? AnyShapeStyle(Color(.secondarySystemBackground))
                        : AnyShapeStyle(.thinMaterial),
                    in: Circle()
                )
                .overlay {
                    Circle()
                        .strokeBorder(
                            reduceTransparency
                                ? Color.secondary
                                : Color.white.opacity(colorScheme == .dark ? 0.12 : 0.45),
                            lineWidth: 0.75
                        )
                }
                .shadow(color: .black.opacity(colorScheme == .dark ? 0.22 : 0.08), radius: 18, y: 8)
        }
        .ignoresSafeArea()
        .accessibilityHidden(true)
        .allowsHitTesting(false)
    }
}

@main
@MainActor
struct iWorkOrderApp: App {
    @UIApplicationDelegateAdaptor(AppDelegate.self) private var appDelegate
    @StateObject private var store = AppStore()
    @StateObject private var appLock = AppLockState()
    @Environment(\.scenePhase) private var scenePhase
    @State private var hasBeenActive = false

    var body: some Scene {
        WindowGroup {
            SplashRootView()
                .environmentObject(store)
                .environmentObject(appLock)
                .preferredColorScheme(nil)
                .privacySensitive()
                .blur(radius: hasBeenActive && scenePhase != .active ? 24 : 0, opaque: true)
                .saturation(hasBeenActive && scenePhase != .active ? 0.20 : 1)
                .accessibilityHidden(hasBeenActive && scenePhase != .active)
                .overlay {
                    if hasBeenActive && scenePhase != .active {
                        AppPrivacyShieldView()
                            .zIndex(10_000)
                    }
                }
                .onAppear {
                    NotificationService.shared.configure()
                    store.load()
                    if scenePhase == .active {
                        hasBeenActive = true
                    }
                }
                .onOpenURL { url in
                    NotificationService.shared.route(url: url)
                }
                .onChange(of: scenePhase) { _, phase in
                    switch phase {
                    case .inactive:
                        RuntimeReliabilityService.transition(to: .inactive)
                    case .background:
                        store.persistLifecycleCheckpoint()
                        RuntimeReliabilityService.transition(to: .background)
                        appLock.applicationDidEnterBackground(lockEnabled: store.profile.faceIDEnabled)
                    case .active:
                        hasBeenActive = true
                        RuntimeReliabilityService.transition(to: .active)
                        appLock.applicationDidBecomeActive(lockEnabled: store.profile.faceIDEnabled)
                        Task { await store.refreshNotificationAuthorization() }
                    @unknown default:
                        break
                    }
                }
        }
    }
}
