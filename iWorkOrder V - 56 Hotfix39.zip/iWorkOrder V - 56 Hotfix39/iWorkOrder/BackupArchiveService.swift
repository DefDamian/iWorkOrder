import Foundation
import CryptoKit

private enum BackupArchiveConstants {
    static let magic = Data("IWOBKP48".utf8)
    static let formatIdentifier = "com.damiancedeno.iworkorder.backup"
    static let formatVersion: UInt32 = 1
    static let snapshotSchemaVersion = AppDataSchema.currentVersion
    static let footerLength = 32
    static let maximumManifestLength = 8 * 1024 * 1024
    static let maximumItemCount = 100_000
    static let streamChunkSize = 1 * 1024 * 1024
    static let maximumLegacyJSONLength: UInt64 = 250 * 1024 * 1024
    static let maximumArchiveLength: UInt64 = 20 * 1024 * 1024 * 1024
    static let storageReserveBytes: Int64 = 64 * 1024 * 1024
    static let importDirectoryName = "iWorkOrderBackupImports"
    static let exportDirectoryName = "iWorkOrderBackupExports"
    static let safetyDirectoryName = "iWorkOrderRestoreSafetyBackups"
}

enum BackupItemKind: String, Codable, Sendable {
    case snapshot
    case image
    case signature
}

struct BackupItemDescriptor: Codable, Hashable, Sendable {
    var path: String
    var filename: String
    var kind: BackupItemKind
    var byteCount: Int64
    var sha256: String
    var modifiedAt: Date?
}

struct BackupCounts: Codable, Equatable, Sendable {
    var workOrders: Int
    var activeWorkOrders: Int
    var trashedWorkOrders: Int
    var revisions: Int
    var assets: Int
    var tenants: Int
    var photos: Int
    var signatures: Int
}

struct BackupManifest: Codable, Sendable {
    var formatIdentifier: String
    var formatVersion: Int
    var snapshotSchemaVersion: Int
    var exportID: UUID
    var createdAt: Date
    var appVersion: String
    var appBuild: String
    var sourceDeviceID: String
    var sourceSaveRevision: Int
    var sourceSnapshotSavedAt: Date?
    var counts: BackupCounts
    var items: [BackupItemDescriptor]
    var totalPayloadBytes: Int64
}

enum BackupSourceFormat: String, Sendable {
    case portableArchive = "iWorkOrder Backup"
    case legacyJSON = "Legacy JSON"
}

struct BackupExportResult: Sendable {
    var url: URL
    var manifest: BackupManifest
    var warnings: [String] = []
}

struct BackupRestoreCandidate: Identifiable, Sendable {
    var id: UUID { manifest.exportID }
    var manifest: BackupManifest
    var snapshot: AppSnapshot
    var stagingDirectory: URL
    var sourceFormat: BackupSourceFormat
    var warnings: [String]

    var summary: String {
        let counts = manifest.counts
        return "\(counts.workOrders) work order(s), \(counts.photos) photo(s), \(counts.signatures) signature(s), \(counts.assets) asset(s), and \(counts.tenants) tenant contact(s)"
    }
}

enum BackupRestoreMode: String, Codable, Sendable {
    case merge
    case replace
}

struct BackupRestoreResult: Sendable {
    var mode: BackupRestoreMode
    var restoredCounts: BackupCounts
    var safetyBackupURL: URL
    var warningCount: Int
}

enum BackupArchiveError: LocalizedError, Sendable {
    case missingAttachment(String)
    case invalidFilename(String)
    case invalidAttachmentContent(String)
    case unableToCreateArchive
    case archiveTooSmall
    case archiveTooLarge
    case insufficientStorage(requiredBytes: Int64, availableBytes: Int64?)
    case invalidArchiveHeader
    case unsupportedArchiveVersion(Int)
    case invalidManifest
    case manifestTooLarge
    case tooManyItems
    case invalidItemPath(String)
    case duplicateItemPath(String)
    case invalidItemChecksum(String)
    case invalidItemLength(String)
    case archiveLengthMismatch
    case archiveChecksumMismatch
    case itemChecksumMismatch(String)
    case snapshotMissing
    case snapshotUnreadable
    case invalidWorkOrderRevisionHistory(Int)
    case snapshotManifestMismatch
    case attachmentManifestMismatch
    case legacyBackupTooLarge
    case legacyBackupUnreadable
    case attachmentCollision(String)
    case stagingDataMissing
    case attachmentRollbackIncomplete(String)
    case restoreTransactionFailed(String)

    var errorDescription: String? {
        switch self {
        case .missingAttachment(let filename):
            return "The backup could not be created because a referenced photo or signature is missing: \(filename)."
        case .invalidFilename(let filename):
            return "The backup contains an unsafe attachment filename: \(filename)."
        case .invalidAttachmentContent(let filename):
            return "The backup contains a photo or signature that cannot be decoded as an image: \(filename)."
        case .unableToCreateArchive:
            return "The backup archive could not be created. Check available device storage and try again."
        case .archiveTooSmall:
            return "The selected file is too small to be an iWorkOrder backup."
        case .archiveTooLarge:
            return "The selected backup exceeds the 20 GB safety limit and was rejected before processing."
        case .insufficientStorage(let requiredBytes, let availableBytes):
            let required = ByteCountFormatter.string(fromByteCount: requiredBytes, countStyle: .file)
            if let availableBytes {
                let available = ByteCountFormatter.string(fromByteCount: availableBytes, countStyle: .file)
                return "Not enough free storage is available for this operation. Approximately \(required) is required and \(available) is available."
            }
            return "Available storage could not be confirmed for an operation requiring approximately \(required). Free device storage and try again."
        case .invalidArchiveHeader:
            return "The selected file is not a valid iWorkOrder backup archive."
        case .unsupportedArchiveVersion(let version):
            return "This backup uses unsupported format version \(version). Update iWorkOrder before restoring it."
        case .invalidManifest:
            return "The backup manifest is missing or invalid. No app data was changed."
        case .manifestTooLarge:
            return "The backup manifest is unreasonably large and was rejected."
        case .tooManyItems:
            return "The backup contains too many files and was rejected."
        case .invalidItemPath(let path):
            return "The backup contains an unsafe file path: \(path)."
        case .duplicateItemPath(let path):
            return "The backup contains a duplicate file entry: \(path)."
        case .invalidItemChecksum(let path):
            return "The backup contains invalid checksum metadata for \(path)."
        case .invalidItemLength(let path):
            return "The backup contains invalid file length metadata for \(path)."
        case .archiveLengthMismatch:
            return "The backup file length does not match its manifest. The archive may be incomplete."
        case .archiveChecksumMismatch:
            return "The backup integrity checksum failed. The archive may be damaged or modified."
        case .itemChecksumMismatch(let path):
            return "A backup item failed checksum verification: \(path). No app data was changed."
        case .snapshotMissing:
            return "The backup does not contain its required app-data snapshot."
        case .snapshotUnreadable:
            return "The backup app-data snapshot could not be decoded. No app data was changed."
        case .invalidWorkOrderRevisionHistory(let count):
            return "The backup contains \(count) work-order record(s) with missing revision history. Restore was stopped and no app data was changed."
        case .snapshotManifestMismatch:
            return "The backup summary does not match the enclosed app data. No app data was changed."
        case .attachmentManifestMismatch:
            return "The backup attachment list does not match the work-order records. No app data was changed."
        case .legacyBackupTooLarge:
            return "The selected legacy JSON backup is too large to import safely."
        case .legacyBackupUnreadable:
            return "The selected file is neither a valid iWorkOrder backup nor a supported legacy JSON backup."
        case .attachmentCollision(let filename):
            return "Merge restore stopped because the current app and backup contain different files with the same name: \(filename). Use Replace Current Data only after confirming the backup is correct."
        case .stagingDataMissing:
            return "The validated backup staging data is no longer available. Select the backup again."
        case .attachmentRollbackIncomplete(let detail):
            return "Attachment installation failed and rollback could not complete safely. Restart the app so protected recovery can retry before making further changes. \(detail)"
        case .restoreTransactionFailed(let detail):
            return "The restore transaction failed and the prior data was preserved. \(detail)"
        }
    }
}

private struct BackupTransactionTarget: Codable, Hashable, Sendable {
    var kind: BackupItemKind
    var filename: String
}

private struct BackupTransactionReplacement: Codable, Hashable, Sendable {
    var target: BackupTransactionTarget
    var savedCopyFilename: String
}

private struct BackupTransactionJournal: Codable, Sendable {
    enum State: String, Codable, Sendable {
        case installing
        case snapshotCommitted
    }

    var transactionID: UUID
    var mode: BackupRestoreMode
    var expectedSaveRevision: Int
    var expectedSnapshotSHA256: String? = nil
    var snapshotEncodingVersion: Int? = nil
    var state: State
    var createdTargets: [BackupTransactionTarget]
    var replacements: [BackupTransactionReplacement]
}

struct InterruptedRestoreRecoveryResult: Sendable {
    var finalizedTransactions: Int = 0
    var rolledBackTransactions: Int = 0
    var warnings: [String] = []
    var requiresWriteBlock = false
}

final class BackupAttachmentTransaction: @unchecked Sendable {
    private let transactionDirectory: URL
    private let journalURL: URL
    private var journal: BackupTransactionJournal
    private var isComplete = false

    fileprivate init(
        mode: BackupRestoreMode,
        transactionDirectory: URL,
        expectedSaveRevision: Int
    ) throws {
        self.transactionDirectory = transactionDirectory
        journalURL = transactionDirectory.appendingPathComponent("transaction.json")
        journal = BackupTransactionJournal(
            transactionID: UUID(),
            mode: mode,
            expectedSaveRevision: expectedSaveRevision,
            state: .installing,
            createdTargets: [],
            replacements: []
        )
        try FileManager.default.createDirectory(at: transactionDirectory, withIntermediateDirectories: true)
        try persistJournal()
    }

    private init(transactionDirectory: URL, journal: BackupTransactionJournal) {
        self.transactionDirectory = transactionDirectory
        journalURL = transactionDirectory.appendingPathComponent("transaction.json")
        self.journal = journal
    }

    fileprivate static func load(from transactionDirectory: URL) throws -> BackupAttachmentTransaction {
        let journalURL = transactionDirectory.appendingPathComponent("transaction.json")
        let data = try Data(contentsOf: journalURL)
        let journal = try JSONDecoder.iso8601.decode(BackupTransactionJournal.self, from: data)
        if let version = journal.snapshotEncodingVersion, version != 1,
           version != SnapshotFingerprintEncoding.currentVersion {
            throw BackupArchiveError.restoreTransactionFailed("A newer restore journal was preserved. Use a compatible app version to finish recovery.")
        }
        return BackupAttachmentTransaction(transactionDirectory: transactionDirectory, journal: journal)
    }

    fileprivate var expectedSaveRevision: Int { journal.expectedSaveRevision }

    func prepareSnapshotCommit(_ snapshot: AppSnapshot) throws {
        guard snapshot.saveRevision == journal.expectedSaveRevision else {
            throw BackupArchiveError.restoreTransactionFailed(
                "The prepared restore snapshot revision no longer matches its attachment transaction."
            )
        }
        journal.snapshotEncodingVersion = SnapshotFingerprintEncoding.currentVersion
        journal.expectedSnapshotSHA256 = try Self.snapshotFingerprint(snapshot)
        try persistJournal()
    }

    fileprivate func matchesCommittedSnapshot(_ snapshot: AppSnapshot) -> Bool {
        let currentRevision = snapshot.saveRevision ?? -1

        // A durable post-save commit marker remains authoritative even if later
        // legitimate saves changed the snapshot fingerprint and revision.
        if journal.state == .snapshotCommitted {
            return true
        }

        if let expectedSnapshotSHA256 = journal.expectedSnapshotSHA256 {
            guard currentRevision == journal.expectedSaveRevision,
                  let currentFingerprint = try? Self.snapshotFingerprint(
                    snapshot, encodingVersion: journal.snapshotEncodingVersion
                  ) else {
                return false
            }
            return currentFingerprint == expectedSnapshotSHA256
        }

        // Backward compatibility for journals created before exact snapshot
        // fingerprints existed. New journals never use revision-only inference.
        return currentRevision >= journal.expectedSaveRevision
    }

    fileprivate func recordCreated(kind: BackupItemKind, filename: String) throws {
        let target = BackupTransactionTarget(kind: kind, filename: filename)
        guard !journal.createdTargets.contains(target) else { return }
        journal.createdTargets.append(target)
        try persistJournal()
    }

    fileprivate func recordReplacement(
        kind: BackupItemKind,
        filename: String,
        savedCopyFilename: String
    ) throws {
        let replacement = BackupTransactionReplacement(
            target: BackupTransactionTarget(kind: kind, filename: filename),
            savedCopyFilename: savedCopyFilename
        )
        guard !journal.replacements.contains(replacement) else { return }
        journal.replacements.append(replacement)
        try persistJournal()
    }

    @discardableResult
    func markSnapshotCommitted() -> Bool {
        guard !isComplete else { return true }
        let previousState = journal.state
        journal.state = .snapshotCommitted
        do {
            try persistJournal()
            return true
        } catch {
            journal.state = previousState
            return false
        }
    }

    fileprivate var hasDurableCommitMarker: Bool {
        journal.state == .snapshotCommitted
    }

    @discardableResult
    func rollback() -> Bool {
        guard !isComplete else { return true }
        let manager = FileManager.default
        var rollbackSucceeded = true

        for target in journal.createdTargets.reversed() {
            let targetURL = Self.url(for: target)
            guard manager.fileExists(atPath: targetURL.path) else { continue }
            do {
                try manager.removeItem(at: targetURL)
            } catch {
                rollbackSucceeded = false
            }
        }

        for replacement in journal.replacements.reversed() {
            let targetURL = Self.url(for: replacement.target)
            let savedCopy = transactionDirectory.appendingPathComponent(replacement.savedCopyFilename)
            guard manager.fileExists(atPath: savedCopy.path) else {
                // The recovery copy is mandatory until the replacement has been
                // restored successfully. Keep the transaction journal so launch
                // recovery can report/retry instead of silently discarding it.
                rollbackSucceeded = false
                continue
            }

            let rollbackStage = targetURL.deletingLastPathComponent()
                .appendingPathComponent(".iworkorder-rollback-\(UUID().uuidString).tmp")
            do {
                try manager.createDirectory(at: targetURL.deletingLastPathComponent(), withIntermediateDirectories: true)
                try? manager.removeItem(at: rollbackStage)
                try manager.copyItem(at: savedCopy, to: rollbackStage)
                if manager.fileExists(atPath: targetURL.path) {
                    _ = try manager.replaceItemAt(targetURL, withItemAt: rollbackStage)
                } else {
                    try manager.moveItem(at: rollbackStage, to: targetURL)
                }
            } catch {
                rollbackSucceeded = false
                try? manager.removeItem(at: rollbackStage)
            }
        }

        guard rollbackSucceeded else { return false }
        do {
            try manager.removeItem(at: transactionDirectory)
            isComplete = true
            return true
        } catch {
            // The original files are restored, but retaining the journal is safer
            // than claiming cleanup completed when the transaction directory could
            // not be removed. A later launch can finalize cleanup idempotently.
            return false
        }
    }

    @discardableResult
    func finalize(referencedImages: Set<String>, referencedSignatures: Set<String>) -> Bool {
        guard !isComplete else { return true }
        if journal.mode == .replace {
            let imagesClean = Self.removeUnreferencedFiles(
                in: ImageStorageService.imageDirectory,
                keeping: referencedImages
            )
            let signaturesClean = Self.removeUnreferencedFiles(
                in: SignatureStorageService.signatureDirectory,
                keeping: referencedSignatures
            )
            guard imagesClean && signaturesClean else {
                // Preserve the journal and rollback copies so startup can retry
                // privacy cleanup rather than falsely declaring finalization done.
                return false
            }
        }
        do {
            try FileManager.default.removeItem(at: transactionDirectory)
            isComplete = true
            return true
        } catch {
            return false
        }
    }

    private func persistJournal() throws {
        let data = try JSONEncoder.pretty.encode(journal)
        try data.write(to: journalURL, options: [.atomic, .completeFileProtectionUntilFirstUserAuthentication])
    }

    private static func snapshotFingerprint(
        _ snapshot: AppSnapshot, encodingVersion: Int? = SnapshotFingerprintEncoding.currentVersion
    ) throws -> String {
        let data = try SnapshotFingerprintEncoding.encode(snapshot, version: encodingVersion)
        return SHA256.hash(data: data).map { String(format: "%02x", $0) }.joined()
    }

    private static func url(for target: BackupTransactionTarget) -> URL {
        switch target.kind {
        case .image:
            return ImageStorageService.url(forFilename: target.filename)
        case .signature:
            return SignatureStorageService.url(forFilename: target.filename)
        case .snapshot:
            return transactionFallbackURL(filename: target.filename)
        }
    }

    private static func transactionFallbackURL(filename: String) -> URL {
        BackupArchiveService.restoreTransactionDirectory.appendingPathComponent("invalid-\(filename)")
    }

    private static func removeUnreferencedFiles(in directory: URL, keeping filenames: Set<String>) -> Bool {
        guard let files = try? FileManager.default.contentsOfDirectory(
            at: directory,
            includingPropertiesForKeys: [.isRegularFileKey],
            options: [.skipsHiddenFiles]
        ) else { return false }

        var succeeded = true
        for file in files {
            let isRegular = (try? file.resourceValues(forKeys: [.isRegularFileKey]).isRegularFile) ?? false
            guard isRegular, !filenames.contains(file.lastPathComponent) else { continue }
            do {
                try FileManager.default.removeItem(at: file)
                if FileManager.default.fileExists(atPath: file.path) {
                    succeeded = false
                }
            } catch {
                succeeded = false
            }
        }
        return succeeded
    }
}

enum BackupArchiveService {
    static var safetyBackupDirectory: URL {
        let base = FileManager.default.urls(for: .applicationSupportDirectory, in: .userDomainMask)[0]
        return base.appendingPathComponent(BackupArchiveConstants.safetyDirectoryName, isDirectory: true)
    }

    static var restoreTransactionDirectory: URL {
        let base = FileManager.default.urls(for: .applicationSupportDirectory, in: .userDomainMask)[0]
        return base.appendingPathComponent("iWorkOrderRestoreTransactions", isDirectory: true)
    }

    static func createPortableBackup(snapshot: AppSnapshot) throws -> BackupExportResult {
        cleanupTemporaryItems()
        let directory = FileManager.default.temporaryDirectory
            .appendingPathComponent(BackupArchiveConstants.exportDirectoryName, isDirectory: true)
        try FileManager.default.createDirectory(at: directory, withIntermediateDirectories: true)
        let filename = portableBackupFilename(profile: snapshot.profile)
        let outputURL = directory.appendingPathComponent(filename)
        return try createArchive(snapshot: snapshot, outputURL: outputURL, verifyAfterWriting: true)
    }

    static func createSafetyBackup(snapshot: AppSnapshot) throws -> BackupExportResult {
        try FileManager.default.createDirectory(at: safetyBackupDirectory, withIntermediateDirectories: true)
        let stamp = compactTimestamp(Date())
        let outputURL = safetyBackupDirectory.appendingPathComponent("pre-restore-\(stamp)-\(UUID().uuidString.prefix(8)).iworkorderbackup")

        do {
            let result = try createArchive(snapshot: snapshot, outputURL: outputURL, verifyAfterWriting: true)
            pruneSafetyBackups(keeping: 3)
            return result
        } catch let error as BackupArchiveError {
            switch error {
            case .missingAttachment, .invalidAttachmentContent, .invalidFilename:
                var recoverableSnapshot = snapshot
                let removedCount = stripUnrecoverableSafetyAttachments(from: &recoverableSnapshot)
                guard removedCount > 0 else { throw error }
                var result = try createArchive(
                    snapshot: recoverableSnapshot,
                    outputURL: outputURL,
                    verifyAfterWriting: true
                )
                result.warnings = [
                    "The pre-restore safety backup omitted \(removedCount) attachment reference(s) whose files were already missing, unsafe, or unreadable. Recoverable records and attachments were preserved and the safety archive was verified."
                ]
                pruneSafetyBackups(keeping: 3)
                return result
            default:
                throw error
            }
        }
    }

    static func prepareImport(from sourceURL: URL) throws -> BackupRestoreCandidate {
        cleanupTemporaryItems()
        let accessed = sourceURL.startAccessingSecurityScopedResource()
        defer { if accessed { sourceURL.stopAccessingSecurityScopedResource() } }

        let handle = try FileHandle(forReadingFrom: sourceURL)
        defer { try? handle.close() }
        let prefix = try handle.read(upToCount: BackupArchiveConstants.magic.count) ?? Data()

        if prefix == BackupArchiveConstants.magic {
            return try preparePortableArchiveImport(from: sourceURL)
        }
        return try prepareLegacyJSONImport(from: sourceURL)
    }

    static func discard(_ candidate: BackupRestoreCandidate) {
        try? FileManager.default.removeItem(at: candidate.stagingDirectory)
    }

    /// Removes app-controlled temporary backup copies. These folders can contain
    /// a complete imported or exported dataset, so Erase All Data must verify
    /// their removal just like the primary snapshot and attachment directories.
    @discardableResult
    static func deleteTemporaryData() -> Bool {
        let manager = FileManager.default
        let directories = [
            importRootDirectory(),
            manager.temporaryDirectory.appendingPathComponent(BackupArchiveConstants.exportDirectoryName, isDirectory: true)
        ]
        var succeeded = true
        for directory in directories where manager.fileExists(atPath: directory.path) {
            do {
                try manager.removeItem(at: directory)
            } catch {
                succeeded = false
            }
        }
        if directories.contains(where: { manager.fileExists(atPath: $0.path) }) {
            succeeded = false
        }
        return succeeded
    }

    static func beginAttachmentInstall(
        candidate: BackupRestoreCandidate,
        mode: BackupRestoreMode,
        expectedSaveRevision: Int
    ) throws -> BackupAttachmentTransaction {
        guard FileManager.default.fileExists(atPath: candidate.stagingDirectory.path) else {
            throw BackupArchiveError.stagingDataMissing
        }

        let attachmentBytes = candidate.manifest.items
            .filter { $0.kind != .snapshot }
            .reduce(Int64(0)) { total, item in
                total > Int64.max - item.byteCount ? Int64.max : total + item.byteCount
            }
        let installationBytes = attachmentBytes > (Int64.max - BackupArchiveConstants.storageReserveBytes) / 2
            ? Int64.max
            : attachmentBytes * 2 + BackupArchiveConstants.storageReserveBytes
        try ensureAvailableCapacity(requiredBytes: installationBytes, near: ImageStorageService.imageDirectory)

        let transactionDirectory = restoreTransactionDirectory
            .appendingPathComponent("restore-\(UUID().uuidString)", isDirectory: true)
        let transaction = try BackupAttachmentTransaction(
            mode: mode,
            transactionDirectory: transactionDirectory,
            expectedSaveRevision: expectedSaveRevision
        )

        do {
            for item in candidate.manifest.items where item.kind != .snapshot {
                let stagedURL = candidate.stagingDirectory.appendingPathComponent(item.path)
                guard FileManager.default.fileExists(atPath: stagedURL.path) else {
                    throw BackupArchiveError.stagingDataMissing
                }
                guard AttachmentContentPolicy.isReadableImage(at: stagedURL) else {
                    throw BackupArchiveError.invalidAttachmentContent(item.filename)
                }
                let stagedMetadata = try checksumAndLength(of: stagedURL)
                guard stagedMetadata.sha256 == item.sha256, stagedMetadata.byteCount == item.byteCount else {
                    throw BackupArchiveError.itemChecksumMismatch(item.path)
                }

                let targetURL: URL
                switch item.kind {
                case .image:
                    targetURL = ImageStorageService.url(forFilename: item.filename)
                case .signature:
                    targetURL = SignatureStorageService.url(forFilename: item.filename)
                case .snapshot:
                    continue
                }

                try FileManager.default.createDirectory(at: targetURL.deletingLastPathComponent(), withIntermediateDirectories: true)
                if FileManager.default.fileExists(atPath: targetURL.path) {
                    let existingMetadata = try checksumAndLength(of: targetURL)
                    if existingMetadata.sha256 == item.sha256 && existingMetadata.byteCount == item.byteCount {
                        try FileManager.default.setAttributes(
                            [.protectionKey: FileProtectionType.completeUntilFirstUserAuthentication],
                            ofItemAtPath: targetURL.path
                        )
                        continue
                    }
                    if mode == .merge {
                        throw BackupArchiveError.attachmentCollision(item.filename)
                    }
                    let savedCopy = transactionDirectory.appendingPathComponent("replaced-\(UUID().uuidString)-\(item.filename)")
                    try FileManager.default.copyItem(at: targetURL, to: savedCopy)
                    try transaction.recordReplacement(
                        kind: item.kind,
                        filename: item.filename,
                        savedCopyFilename: savedCopy.lastPathComponent
                    )
                    try FileManager.default.removeItem(at: targetURL)
                } else {
                    try transaction.recordCreated(kind: item.kind, filename: item.filename)
                }

                try FileManager.default.copyItem(at: stagedURL, to: targetURL)
                try FileManager.default.setAttributes(
                    [.protectionKey: FileProtectionType.completeUntilFirstUserAuthentication],
                    ofItemAtPath: targetURL.path
                )
            }
            return transaction
        } catch {
            let originalError = (error as? LocalizedError)?.errorDescription ?? error.localizedDescription
            guard transaction.rollback() else {
                throw BackupArchiveError.attachmentRollbackIncomplete(originalError)
            }
            throw error
        }
    }

    static func recoverInterruptedRestores(currentSnapshot: AppSnapshot?) -> InterruptedRestoreRecoveryResult {
        var result = InterruptedRestoreRecoveryResult()
        guard let directories = try? FileManager.default.contentsOfDirectory(
            at: restoreTransactionDirectory,
            includingPropertiesForKeys: [.isDirectoryKey],
            options: [.skipsHiddenFiles]
        ) else { return result }

        for directory in directories {
            let isDirectory = (try? directory.resourceValues(forKeys: [.isDirectoryKey]).isDirectory) ?? false
            guard isDirectory else { continue }
            do {
                let transaction = try BackupAttachmentTransaction.load(from: directory)
                let snapshotContainsRestore = currentSnapshot.map { transaction.matchesCommittedSnapshot($0) } ?? false
                if snapshotContainsRestore, let currentSnapshot {
                    let references = referencedAttachmentFilenames(in: currentSnapshot)
                    if transaction.finalize(
                        referencedImages: references.images,
                        referencedSignatures: references.signatures
                    ) {
                        result.finalizedTransactions += 1
                    } else {
                        result.warnings.append("A committed restore still has protected cleanup data at \(directory.lastPathComponent). It was retained and cleanup will be retried on the next launch.")
                        if !transaction.hasDurableCommitMarker {
                            result.requiresWriteBlock = true
                        }
                    }
                } else if transaction.rollback() {
                    result.rolledBackTransactions += 1
                } else {
                    result.requiresWriteBlock = true
                    result.warnings.append("An interrupted restore could not finish rolling back attachments at \(directory.lastPathComponent). Recovery copies were retained and local changes are blocked until recovery succeeds.")
                }
            } catch {
                result.requiresWriteBlock = true
                result.warnings.append("An interrupted restore journal could not be read at \(directory.lastPathComponent). The files were preserved for manual recovery and local changes are blocked to prevent attachment corruption.")
            }
        }
        return result
    }

    static func referencedAttachmentFilenames(in snapshot: AppSnapshot) -> (images: Set<String>, signatures: Set<String>) {
        var images = Set<String>()
        var signatures = Set<String>()
        for order in snapshot.workOrders {
            for entry in order.entries {
                images.formUnion(entry.images.map(\.filename))
                if let signature = entry.signatureFilename, !signature.isEmpty {
                    signatures.insert(signature)
                }
            }
        }
        return (images, signatures)
    }

    static func counts(for snapshot: AppSnapshot) -> BackupCounts {
        let photoCount = snapshot.workOrders.reduce(0) { total, order in
            total + order.entries.reduce(0) { $0 + $1.images.count }
        }
        let signatureCount = snapshot.workOrders.reduce(0) { total, order in
            total + order.entries.reduce(0) { partial, entry in
                partial + ((entry.signatureFilename?.isEmpty == false) ? 1 : 0)
            }
        }
        return BackupCounts(
            workOrders: snapshot.workOrders.count,
            activeWorkOrders: snapshot.workOrders.filter { !$0.isDeleted }.count,
            trashedWorkOrders: snapshot.workOrders.filter(\.isDeleted).count,
            revisions: snapshot.workOrders.reduce(0) { $0 + $1.entries.count },
            assets: snapshot.assets?.count ?? 0,
            tenants: snapshot.tenants?.count ?? 0,
            photos: photoCount,
            signatures: signatureCount
        )
    }

    static func safetyBackupsSize() -> Int64 {
        directorySize(safetyBackupDirectory)
    }

    static func latestSafetyBackupURL() -> URL? {
        guard let files = try? FileManager.default.contentsOfDirectory(
            at: safetyBackupDirectory,
            includingPropertiesForKeys: [.isRegularFileKey, .contentModificationDateKey],
            options: [.skipsHiddenFiles]
        ) else { return nil }

        return files
            .filter { url in
                guard url.pathExtension.lowercased() == "iworkorderbackup" else { return false }
                return (try? url.resourceValues(forKeys: [.isRegularFileKey]).isRegularFile) == true
            }
            .max { lhs, rhs in
                let lhsDate = (try? lhs.resourceValues(forKeys: [.contentModificationDateKey]).contentModificationDate) ?? .distantPast
                let rhsDate = (try? rhs.resourceValues(forKeys: [.contentModificationDateKey]).contentModificationDate) ?? .distantPast
                return lhsDate < rhsDate
            }
    }

    private static func createArchive(
        snapshot: AppSnapshot,
        outputURL: URL,
        verifyAfterWriting: Bool
    ) throws -> BackupExportResult {
        let emptyWorkOrderCount = snapshot.workOrders.reduce(into: 0) { count, order in
            if order.entries.isEmpty { count += 1 }
        }
        guard emptyWorkOrderCount == 0 else {
            throw BackupArchiveError.invalidWorkOrderRevisionHistory(emptyWorkOrderCount)
        }

        let workDirectory = FileManager.default.temporaryDirectory
            .appendingPathComponent("iWorkOrderBackupBuild-\(UUID().uuidString)", isDirectory: true)
        try FileManager.default.createDirectory(at: workDirectory, withIntermediateDirectories: true)
        defer { try? FileManager.default.removeItem(at: workDirectory) }

        let snapshotURL = workDirectory.appendingPathComponent("snapshot.json")
        let snapshotData = try JSONEncoder.pretty.encode(snapshot)
        try snapshotData.write(to: snapshotURL, options: [.atomic, .completeFileProtectionUntilFirstUserAuthentication])

        var sourceItems: [(descriptor: BackupItemDescriptor, url: URL)] = []
        let snapshotMetadata = try checksumAndLength(of: snapshotURL)
        sourceItems.append((
            BackupItemDescriptor(
                path: "snapshot.json",
                filename: "snapshot.json",
                kind: .snapshot,
                byteCount: snapshotMetadata.byteCount,
                sha256: snapshotMetadata.sha256,
                modifiedAt: snapshot.snapshotSavedAt
            ),
            snapshotURL
        ))

        let references = try attachmentReferences(in: snapshot)
        for reference in references {
            let url = reference.kind == .image
                ? ImageStorageService.url(forFilename: reference.filename)
                : SignatureStorageService.url(forFilename: reference.filename)
            guard FileManager.default.fileExists(atPath: url.path) else {
                throw BackupArchiveError.missingAttachment(reference.filename)
            }
            guard AttachmentContentPolicy.isReadableImage(at: url) else {
                throw BackupArchiveError.invalidAttachmentContent(reference.filename)
            }
            let metadata = try checksumAndLength(of: url)
            let folder = reference.kind == .image ? "images" : "signatures"
            sourceItems.append((
                BackupItemDescriptor(
                    path: "\(folder)/\(reference.filename)",
                    filename: reference.filename,
                    kind: reference.kind,
                    byteCount: metadata.byteCount,
                    sha256: metadata.sha256,
                    modifiedAt: modificationDate(of: url)
                ),
                url
            ))
        }

        let manifest = BackupManifest(
            formatIdentifier: BackupArchiveConstants.formatIdentifier,
            formatVersion: Int(BackupArchiveConstants.formatVersion),
            snapshotSchemaVersion: BackupArchiveConstants.snapshotSchemaVersion,
            exportID: UUID(),
            createdAt: Date(),
            appVersion: Bundle.main.object(forInfoDictionaryKey: "CFBundleShortVersionString") as? String ?? "Development",
            appBuild: Bundle.main.object(forInfoDictionaryKey: "CFBundleVersion") as? String ?? "Unnumbered",
            sourceDeviceID: snapshot.deviceID ?? DeviceIdentity.current,
            sourceSaveRevision: snapshot.saveRevision ?? 0,
            sourceSnapshotSavedAt: snapshot.snapshotSavedAt,
            counts: counts(for: snapshot),
            items: sourceItems.map(\.descriptor),
            totalPayloadBytes: sourceItems.reduce(0) { $0 + $1.descriptor.byteCount }
        )
        let manifestData = try JSONEncoder.pretty.encode(manifest)
        guard manifestData.count <= BackupArchiveConstants.maximumManifestLength else {
            throw BackupArchiveError.manifestTooLarge
        }
        let fixedBytes = Int64(BackupArchiveConstants.magic.count + MemoryLayout<UInt32>.size + MemoryLayout<UInt64>.size + BackupArchiveConstants.footerLength + manifestData.count)
        let requiredBytes = manifest.totalPayloadBytes > Int64.max - fixedBytes - BackupArchiveConstants.storageReserveBytes
            ? Int64.max
            : manifest.totalPayloadBytes + fixedBytes + BackupArchiveConstants.storageReserveBytes
        try ensureAvailableCapacity(requiredBytes: requiredBytes, near: outputURL.deletingLastPathComponent())

        try FileManager.default.createDirectory(at: outputURL.deletingLastPathComponent(), withIntermediateDirectories: true)
        try? FileManager.default.removeItem(at: outputURL)
        guard FileManager.default.createFile(atPath: outputURL.path, contents: nil) else {
            throw BackupArchiveError.unableToCreateArchive
        }

        let outputHandle = try FileHandle(forWritingTo: outputURL)
        var archiveHasher = SHA256()
        do {
            try writeAndHash(BackupArchiveConstants.magic, to: outputHandle, hasher: &archiveHasher)
            try writeAndHash(integerData(BackupArchiveConstants.formatVersion), to: outputHandle, hasher: &archiveHasher)
            try writeAndHash(integerData(UInt64(manifestData.count)), to: outputHandle, hasher: &archiveHasher)
            try writeAndHash(manifestData, to: outputHandle, hasher: &archiveHasher)

            for item in sourceItems {
                try streamFile(item.url, to: outputHandle, hasher: &archiveHasher)
            }
            let footer = Data(archiveHasher.finalize())
            try outputHandle.write(contentsOf: footer)
            try outputHandle.synchronize()
            try outputHandle.close()
            try FileManager.default.setAttributes(
                [.protectionKey: FileProtectionType.completeUntilFirstUserAuthentication],
                ofItemAtPath: outputURL.path
            )
        } catch {
            try? outputHandle.close()
            try? FileManager.default.removeItem(at: outputURL)
            throw error
        }

        if verifyAfterWriting {
            let verified = try preparePortableArchiveImport(from: outputURL)
            discard(verified)
        }
        return BackupExportResult(url: outputURL, manifest: manifest)
    }

    private static func preparePortableArchiveImport(from sourceURL: URL) throws -> BackupRestoreCandidate {
        let attributes = try FileManager.default.attributesOfItem(atPath: sourceURL.path)
        let archiveLength = (attributes[.size] as? NSNumber)?.uint64Value ?? 0
        let minimumLength = UInt64(BackupArchiveConstants.magic.count + MemoryLayout<UInt32>.size + MemoryLayout<UInt64>.size + BackupArchiveConstants.footerLength)
        guard archiveLength >= minimumLength else { throw BackupArchiveError.archiveTooSmall }
        guard archiveLength <= BackupArchiveConstants.maximumArchiveLength else { throw BackupArchiveError.archiveTooLarge }
        try verifyArchiveChecksum(sourceURL)

        let handle = try FileHandle(forReadingFrom: sourceURL)
        defer { try? handle.close() }
        guard try readExactly(BackupArchiveConstants.magic.count, from: handle) == BackupArchiveConstants.magic else {
            throw BackupArchiveError.invalidArchiveHeader
        }
        let headerVersion = Int(decodeUInt32(try readExactly(MemoryLayout<UInt32>.size, from: handle)))
        guard headerVersion == Int(BackupArchiveConstants.formatVersion) else {
            throw BackupArchiveError.unsupportedArchiveVersion(headerVersion)
        }
        let manifestLengthValue = decodeUInt64(try readExactly(MemoryLayout<UInt64>.size, from: handle))
        guard manifestLengthValue <= UInt64(BackupArchiveConstants.maximumManifestLength), manifestLengthValue <= UInt64(Int.max) else {
            throw BackupArchiveError.manifestTooLarge
        }
        let manifestData = try readExactly(Int(manifestLengthValue), from: handle)
        guard let manifest = try? JSONDecoder.iso8601.decode(BackupManifest.self, from: manifestData) else {
            throw BackupArchiveError.invalidManifest
        }
        try validateManifest(manifest)
        guard manifest.formatVersion == headerVersion else { throw BackupArchiveError.invalidManifest }

        let expectedLength = UInt64(BackupArchiveConstants.magic.count + MemoryLayout<UInt32>.size + MemoryLayout<UInt64>.size)
            + manifestLengthValue
            + UInt64(manifest.totalPayloadBytes)
            + UInt64(BackupArchiveConstants.footerLength)
        guard archiveLength == expectedLength else { throw BackupArchiveError.archiveLengthMismatch }
        let stagingBytes = manifest.totalPayloadBytes > Int64.max - BackupArchiveConstants.storageReserveBytes
            ? Int64.max
            : manifest.totalPayloadBytes + BackupArchiveConstants.storageReserveBytes
        try ensureAvailableCapacity(requiredBytes: stagingBytes, near: importRootDirectory())

        let stagingDirectory = importRootDirectory().appendingPathComponent(manifest.exportID.uuidString, isDirectory: true)
        try? FileManager.default.removeItem(at: stagingDirectory)
        try FileManager.default.createDirectory(at: stagingDirectory, withIntermediateDirectories: true)

        do {
            for item in manifest.items {
                let target = stagingDirectory.appendingPathComponent(item.path)
                try FileManager.default.createDirectory(at: target.deletingLastPathComponent(), withIntermediateDirectories: true)
                guard FileManager.default.createFile(atPath: target.path, contents: nil) else {
                    throw BackupArchiveError.restoreTransactionFailed("A staging file could not be created.")
                }
                let targetHandle = try FileHandle(forWritingTo: target)
                var itemHasher = SHA256()
                var remaining = item.byteCount
                do {
                    while remaining > 0 {
                        let request = Int(min(Int64(BackupArchiveConstants.streamChunkSize), remaining))
                        let chunk = try readExactly(request, from: handle)
                        itemHasher.update(data: chunk)
                        try targetHandle.write(contentsOf: chunk)
                        remaining -= Int64(chunk.count)
                    }
                    try targetHandle.close()
                } catch {
                    try? targetHandle.close()
                    throw error
                }
                let digest = hexDigest(itemHasher.finalize())
                guard digest == item.sha256 else {
                    throw BackupArchiveError.itemChecksumMismatch(item.path)
                }
                try FileManager.default.setAttributes(
                    [.protectionKey: FileProtectionType.completeUntilFirstUserAuthentication],
                    ofItemAtPath: target.path
                )
            }

            for item in manifest.items where item.kind != .snapshot {
                let stagedURL = stagingDirectory.appendingPathComponent(item.path)
                guard AttachmentContentPolicy.isReadableImage(at: stagedURL) else {
                    throw BackupArchiveError.invalidAttachmentContent(item.filename)
                }
            }

            guard handle.offsetInFile == archiveLength - UInt64(BackupArchiveConstants.footerLength) else {
                throw BackupArchiveError.archiveLengthMismatch
            }

            guard let snapshotItem = manifest.items.first(where: { $0.kind == .snapshot }) else {
                throw BackupArchiveError.snapshotMissing
            }
            let snapshotURL = stagingDirectory.appendingPathComponent(snapshotItem.path)
            let snapshotData = try Data(contentsOf: snapshotURL, options: [.mappedIfSafe])
            let snapshot = try decodeSnapshotWithMigration(snapshotData)
            try validateSnapshot(snapshot, against: manifest)

            return BackupRestoreCandidate(
                manifest: manifest,
                snapshot: snapshot,
                stagingDirectory: stagingDirectory,
                sourceFormat: .portableArchive,
                warnings: []
            )
        } catch {
            try? FileManager.default.removeItem(at: stagingDirectory)
            throw error
        }
    }

    private static func prepareLegacyJSONImport(from sourceURL: URL) throws -> BackupRestoreCandidate {
        let attributes = try FileManager.default.attributesOfItem(atPath: sourceURL.path)
        let byteCount = (attributes[.size] as? NSNumber)?.uint64Value ?? 0
        guard byteCount <= BackupArchiveConstants.maximumLegacyJSONLength else {
            throw BackupArchiveError.legacyBackupTooLarge
        }
        let legacyStagingBytes = byteCount > UInt64(Int64.max - BackupArchiveConstants.storageReserveBytes)
            ? Int64.max
            : Int64(byteCount) + BackupArchiveConstants.storageReserveBytes
        try ensureAvailableCapacity(requiredBytes: legacyStagingBytes, near: importRootDirectory())
        guard let data = try? Data(contentsOf: sourceURL, options: [.mappedIfSafe]) else {
            throw BackupArchiveError.legacyBackupUnreadable
        }

        var snapshot: AppSnapshot
        do {
            snapshot = try decodeSnapshotWithMigration(data)
        } catch {
            throw BackupArchiveError.legacyBackupUnreadable
        }

        let stripped = stripUnavailableLegacyAttachments(from: &snapshot)
        snapshot.lastSynced = nil
        snapshot.snapshotSavedAt = Date()
        snapshot.deviceID = DeviceIdentity.current

        let stagingDirectory = importRootDirectory().appendingPathComponent("legacy-\(UUID().uuidString)", isDirectory: true)
        try FileManager.default.createDirectory(at: stagingDirectory, withIntermediateDirectories: true)
        let stagedSnapshotURL = stagingDirectory.appendingPathComponent("snapshot.json")
        let migratedData = try JSONEncoder.pretty.encode(snapshot)
        try migratedData.write(to: stagedSnapshotURL, options: [.atomic, .completeFileProtectionUntilFirstUserAuthentication])
        let metadata = try checksumAndLength(of: stagedSnapshotURL)
        let manifest = BackupManifest(
            formatIdentifier: BackupArchiveConstants.formatIdentifier,
            formatVersion: Int(BackupArchiveConstants.formatVersion),
            snapshotSchemaVersion: BackupArchiveConstants.snapshotSchemaVersion,
            exportID: UUID(),
            createdAt: modificationDate(of: sourceURL),
            appVersion: "Legacy",
            appBuild: "Legacy",
            sourceDeviceID: snapshot.deviceID ?? "Unknown",
            sourceSaveRevision: snapshot.saveRevision ?? 0,
            sourceSnapshotSavedAt: snapshot.snapshotSavedAt,
            counts: counts(for: snapshot),
            items: [BackupItemDescriptor(
                path: "snapshot.json",
                filename: "snapshot.json",
                kind: .snapshot,
                byteCount: metadata.byteCount,
                sha256: metadata.sha256,
                modifiedAt: snapshot.snapshotSavedAt
            )],
            totalPayloadBytes: metadata.byteCount
        )
        var warnings = ["This is a legacy JSON backup. It was migrated to the current data model before restore."]
        if stripped > 0 {
            warnings.append("The legacy format could not contain attachment files. \(stripped) unavailable photo or signature reference(s) were removed and recorded in the affected audit trails.")
        }
        return BackupRestoreCandidate(
            manifest: manifest,
            snapshot: snapshot,
            stagingDirectory: stagingDirectory,
            sourceFormat: .legacyJSON,
            warnings: warnings
        )
    }

    private static func validateManifest(_ manifest: BackupManifest) throws {
        guard manifest.formatIdentifier == BackupArchiveConstants.formatIdentifier else {
            throw BackupArchiveError.invalidManifest
        }
        guard manifest.formatVersion == Int(BackupArchiveConstants.formatVersion) else {
            throw BackupArchiveError.unsupportedArchiveVersion(manifest.formatVersion)
        }
        guard manifest.snapshotSchemaVersion <= BackupArchiveConstants.snapshotSchemaVersion else {
            throw BackupArchiveError.unsupportedArchiveVersion(manifest.snapshotSchemaVersion)
        }
        guard !manifest.items.isEmpty else { throw BackupArchiveError.snapshotMissing }
        guard manifest.items.count <= BackupArchiveConstants.maximumItemCount else { throw BackupArchiveError.tooManyItems }
        guard manifest.items.filter({ $0.kind == .snapshot }).count == 1 else { throw BackupArchiveError.snapshotMissing }

        var paths = Set<String>()
        var calculatedPayloadBytes: Int64 = 0
        for item in manifest.items {
            guard isSafeArchivePath(item.path), item.filename == (item.filename as NSString).lastPathComponent else {
                throw BackupArchiveError.invalidItemPath(item.path)
            }
            guard paths.insert(item.path).inserted else { throw BackupArchiveError.duplicateItemPath(item.path) }
            guard item.byteCount >= 0 else { throw BackupArchiveError.invalidItemLength(item.path) }
            guard item.sha256.count == 64, item.sha256.allSatisfy({ $0.isHexDigit }) else {
                throw BackupArchiveError.invalidItemChecksum(item.path)
            }
            guard calculatedPayloadBytes <= Int64.max - item.byteCount else {
                throw BackupArchiveError.invalidItemLength(item.path)
            }
            calculatedPayloadBytes += item.byteCount

            switch item.kind {
            case .snapshot:
                guard item.path == "snapshot.json", item.filename == "snapshot.json" else {
                    throw BackupArchiveError.invalidItemPath(item.path)
                }
            case .image:
                guard item.path == "images/\(item.filename)", isSafeFilename(item.filename) else {
                    throw BackupArchiveError.invalidItemPath(item.path)
                }
            case .signature:
                guard item.path == "signatures/\(item.filename)", isSafeFilename(item.filename) else {
                    throw BackupArchiveError.invalidItemPath(item.path)
                }
            }
        }
        guard calculatedPayloadBytes == manifest.totalPayloadBytes else {
            throw BackupArchiveError.archiveLengthMismatch
        }
    }

    private static func validateSnapshot(_ snapshot: AppSnapshot, against manifest: BackupManifest) throws {
        let emptyWorkOrderCount = snapshot.workOrders.reduce(into: 0) { count, order in
            if order.entries.isEmpty { count += 1 }
        }
        guard emptyWorkOrderCount == 0 else {
            throw BackupArchiveError.invalidWorkOrderRevisionHistory(emptyWorkOrderCount)
        }
        guard counts(for: snapshot) == manifest.counts else {
            throw BackupArchiveError.snapshotManifestMismatch
        }
        let references = referencedAttachmentFilenames(in: snapshot)
        let manifestImages = Set(manifest.items.filter { $0.kind == .image }.map(\.filename))
        let manifestSignatures = Set(manifest.items.filter { $0.kind == .signature }.map(\.filename))
        guard references.images == manifestImages, references.signatures == manifestSignatures else {
            throw BackupArchiveError.attachmentManifestMismatch
        }
    }

    private static func verifyArchiveChecksum(_ url: URL) throws {
        let attributes = try FileManager.default.attributesOfItem(atPath: url.path)
        let size = (attributes[.size] as? NSNumber)?.uint64Value ?? 0
        guard size >= UInt64(BackupArchiveConstants.footerLength) else { throw BackupArchiveError.archiveTooSmall }

        let handle = try FileHandle(forReadingFrom: url)
        defer { try? handle.close() }
        var remaining = size - UInt64(BackupArchiveConstants.footerLength)
        var hasher = SHA256()
        while remaining > 0 {
            let request = Int(min(UInt64(BackupArchiveConstants.streamChunkSize), remaining))
            let chunk = try readExactly(request, from: handle)
            hasher.update(data: chunk)
            remaining -= UInt64(chunk.count)
        }
        let expected = try readExactly(BackupArchiveConstants.footerLength, from: handle)
        let actual = Data(hasher.finalize())
        guard expected == actual else { throw BackupArchiveError.archiveChecksumMismatch }
    }

    private static func attachmentReferences(in snapshot: AppSnapshot) throws -> [(filename: String, kind: BackupItemKind)] {
        var references = Set<String>()
        var output: [(filename: String, kind: BackupItemKind)] = []
        for order in snapshot.workOrders {
            for entry in order.entries {
                for image in entry.images {
                    guard isSafeFilename(image.filename) else { throw BackupArchiveError.invalidFilename(image.filename) }
                    let key = "image|\(image.filename)"
                    if references.insert(key).inserted { output.append((image.filename, .image)) }
                }
                if let signature = entry.signatureFilename, !signature.isEmpty {
                    guard isSafeFilename(signature) else { throw BackupArchiveError.invalidFilename(signature) }
                    let key = "signature|\(signature)"
                    if references.insert(key).inserted { output.append((signature, .signature)) }
                }
            }
        }
        return output.sorted {
            $0.kind.rawValue == $1.kind.rawValue ? $0.filename < $1.filename : $0.kind.rawValue < $1.kind.rawValue
        }
    }

    private static func decodeSnapshotWithMigration(_ data: Data) throws -> AppSnapshot {
        do {
            try SnapshotFormatPolicy.validateSchema(in: data)
        } catch DataMigrationError.unsupportedFutureVersion(let version) {
            throw BackupArchiveError.unsupportedArchiveVersion(version)
        } catch DataMigrationError.unsupportedLegacyVersion(let version) {
            throw BackupArchiveError.unsupportedArchiveVersion(version)
        } catch {
            throw BackupArchiveError.snapshotUnreadable
        }
        if let snapshot = try? JSONDecoder.iso8601.decode(AppSnapshot.self, from: data) {
            return try migrateDecodedSnapshot(snapshot)
        }
        let migrated = try migrateLegacySnapshotJSON(data)
        guard let snapshot = try? JSONDecoder.iso8601.decode(AppSnapshot.self, from: migrated) else {
            throw BackupArchiveError.snapshotUnreadable
        }
        return try migrateDecodedSnapshot(snapshot)
    }

    private static func migrateDecodedSnapshot(_ snapshot: AppSnapshot) throws -> AppSnapshot {
        do {
            return try MaintenanceService.migrate(snapshot).snapshot
        } catch DataMigrationError.unsupportedFutureVersion(let version) {
            throw BackupArchiveError.unsupportedArchiveVersion(version)
        } catch DataMigrationError.unsupportedLegacyVersion(let version) {
            throw BackupArchiveError.unsupportedArchiveVersion(version)
        } catch DataMigrationError.invalidWorkOrderRevisionHistory(let count) {
            throw BackupArchiveError.invalidWorkOrderRevisionHistory(count)
        } catch {
            throw BackupArchiveError.snapshotUnreadable
        }
    }

    private static func migrateLegacySnapshotJSON(_ data: Data) throws -> Data {
        do {
            try SnapshotFormatPolicy.validateLegacyStructure(in: data)
        } catch {
            throw BackupArchiveError.snapshotUnreadable
        }
        guard var root = try JSONSerialization.jsonObject(with: data) as? [String: Any] else {
            throw BackupArchiveError.snapshotUnreadable
        }

        if var profile = root["profile"] as? [String: Any] {
            applyDefaults(&profile, defaults: [
                "personName": "",
                "propertyManagerCompanyName": "",
                "buildingAddress": "",
                "notificationsEnabled": false,
                "legalAccepted": false,
                "iCloudEnabled": true,
                "faceIDEnabled": false,
                "role": UserRole.superintendent.rawValue,
                "storageChoice": StorageChoice.iCloud.rawValue,
                "firstBuildingUnits": [],
                "emergencyNotificationsEnabled": true
            ])
            root["profile"] = profile
        } else {
            root["profile"] = try jsonObject(for: UserProfile())
        }

        var migratedOrders: [[String: Any]] = []
        for rawOrder in root["workOrders"] as? [[String: Any]] ?? [] {
            var order = rawOrder
            applyDefaults(&order, defaults: [
                "id": UUID().uuidString,
                "createdAt": ISO8601DateFormatter().string(from: Date()),
                "status": WorkOrderStatus.inProgress.rawValue,
                "auditLog": [],
                "isDeleted": false
            ])

            var rawEntries = order["entries"] as? [[String: Any]]
            if rawEntries == nil {
                var reconstructed: [String: Any] = [:]
                let entryKeys = [
                    "id", "createdAt", "area", "issueDescription", "notes", "handymanName", "category", "priority",
                    "entryPermitted", "tenantPermission", "entryMethod", "assetTag", "assetID", "reminderEnabled",
                    "reminderDate", "images", "signatureFilename", "signatureSignerName",
                    "signatureCapturedAt", "signatureConsentVersion"
                ]
                for key in entryKeys where order[key] != nil { reconstructed[key] = order[key] }
                rawEntries = reconstructed.isEmpty ? [] : [reconstructed]
            }

            var migratedEntries: [[String: Any]] = []
            for rawEntry in rawEntries ?? [] {
                var entry = rawEntry
                applyDefaults(&entry, defaults: [
                    "id": UUID().uuidString,
                    "createdAt": order["createdAt"] ?? ISO8601DateFormatter().string(from: Date()),
                    "area": "",
                    "issueDescription": "",
                    "notes": "",
                    "handymanName": "",
                    "category": WorkOrderCategory.other.rawValue,
                    "priority": WorkOrderPriority.normal.rawValue,
                    "entryPermitted": false,
                    "assetTag": "",
                    "reminderEnabled": false,
                    "reminderDate": ISO8601DateFormatter().string(from: Date()),
                    "images": []
                ])

                var migratedImages: [[String: Any]] = []
                for rawImage in entry["images"] as? [[String: Any]] ?? [] {
                    var image = rawImage
                    applyDefaults(&image, defaults: [
                        "id": UUID().uuidString,
                        "filename": "",
                        "kind": WorkOrderImage.ImageKind.before.rawValue,
                        "compressed": true,
                        "createdAt": entry["createdAt"] ?? ISO8601DateFormatter().string(from: Date())
                    ])
                    migratedImages.append(image)
                }
                entry["images"] = migratedImages
                migratedEntries.append(entry)
            }
            order["entries"] = migratedEntries

            var migratedAudit: [[String: Any]] = []
            for rawAudit in order["auditLog"] as? [[String: Any]] ?? [] {
                var audit = rawAudit
                applyDefaults(&audit, defaults: [
                    "id": UUID().uuidString,
                    "date": order["createdAt"] ?? ISO8601DateFormatter().string(from: Date()),
                    "message": "Legacy audit entry"
                ])
                migratedAudit.append(audit)
            }
            order["auditLog"] = migratedAudit

            if let rawStatus = order["statusEntries"] as? [[String: Any]] {
                var migratedStatus: [[String: Any]] = []
                for rawEntry in rawStatus {
                    var status = rawEntry
                    applyDefaults(&status, defaults: [
                        "id": UUID().uuidString,
                        "kind": StatusEventKind.created.rawValue,
                        "date": order["createdAt"] ?? ISO8601DateFormatter().string(from: Date()),
                        "detail": "Legacy status entry"
                    ])
                    migratedStatus.append(status)
                }
                order["statusEntries"] = migratedStatus
            }
            migratedOrders.append(order)
        }
        root["workOrders"] = migratedOrders

        var migratedAssets: [[String: Any]] = []
        for rawAsset in root["assets"] as? [[String: Any]] ?? [] {
            var asset = rawAsset
            applyDefaults(&asset, defaults: [
                "id": UUID().uuidString,
                "tag": "",
                "name": "",
                "location": "",
                "notes": "",
                "createdAt": ISO8601DateFormatter().string(from: Date())
            ])
            migratedAssets.append(asset)
        }
        root["assets"] = migratedAssets

        var migratedTenants: [[String: Any]] = []
        for rawTenant in root["tenants"] as? [[String: Any]] ?? [] {
            var tenant = rawTenant
            applyDefaults(&tenant, defaults: [
                "id": UUID().uuidString,
                "unit": "",
                "name": "",
                "phone": "",
                "email": "",
                "entryPermission": false
            ])
            migratedTenants.append(tenant)
        }
        root["tenants"] = migratedTenants

        return try JSONSerialization.data(withJSONObject: root, options: [.sortedKeys])
    }

    private static func stripUnrecoverableSafetyAttachments(from snapshot: inout AppSnapshot) -> Int {
        var removed = 0
        let message = "Pre-restore safety backup omitted attachment references whose files were already missing or unreadable"

        for orderIndex in snapshot.workOrders.indices {
            var affected = false
            for entryIndex in snapshot.workOrders[orderIndex].entries.indices {
                let originalImages = snapshot.workOrders[orderIndex].entries[entryIndex].images
                let recoverableImages = originalImages.filter { image in
                    guard AttachmentFilenamePolicy.isSafe(image.filename),
                          let url = ImageStorageService.safeURL(forFilename: image.filename),
                          FileManager.default.fileExists(atPath: url.path),
                          AttachmentContentPolicy.isReadableImage(at: url) else {
                        return false
                    }
                    return true
                }
                let removedImages = originalImages.count - recoverableImages.count
                if removedImages > 0 {
                    removed += removedImages
                    affected = true
                    snapshot.workOrders[orderIndex].entries[entryIndex].images = recoverableImages
                }

                if let signature = snapshot.workOrders[orderIndex].entries[entryIndex].signatureFilename,
                   !signature.isEmpty {
                    let readable = AttachmentFilenamePolicy.isSafe(signature)
                        && SignatureStorageService.safeURL(forFilename: signature).map { url in
                            FileManager.default.fileExists(atPath: url.path)
                                && AttachmentContentPolicy.isReadableImage(at: url)
                        } == true
                    if !readable {
                        snapshot.workOrders[orderIndex].entries[entryIndex].signatureFilename = nil
                        removed += 1
                        affected = true
                    }
                }
            }

            if affected {
                if !snapshot.workOrders[orderIndex].auditLog.contains(where: { $0.message == message }) {
                    snapshot.workOrders[orderIndex].auditLog.append(AuditEvent(date: Date(), message: message))
                }
                var statusEntries = snapshot.workOrders[orderIndex].statusEntries ?? []
                if !statusEntries.contains(where: { $0.kind == .integrityNotice && $0.detail == message }) {
                    statusEntries.append(StatusEntry(kind: .integrityNotice, date: Date(), detail: message))
                }
                snapshot.workOrders[orderIndex].statusEntries = statusEntries
            }
        }
        return removed
    }

    private static func stripUnavailableLegacyAttachments(from snapshot: inout AppSnapshot) -> Int {
        var stripped = 0
        let message = "Legacy backup imported without unavailable photo or signature files"
        for orderIndex in snapshot.workOrders.indices {
            var affected = false
            for entryIndex in snapshot.workOrders[orderIndex].entries.indices {
                stripped += snapshot.workOrders[orderIndex].entries[entryIndex].images.count
                if !snapshot.workOrders[orderIndex].entries[entryIndex].images.isEmpty { affected = true }
                snapshot.workOrders[orderIndex].entries[entryIndex].images.removeAll()
                if snapshot.workOrders[orderIndex].entries[entryIndex].signatureFilename != nil {
                    stripped += 1
                    affected = true
                    snapshot.workOrders[orderIndex].entries[entryIndex].signatureFilename = nil
                }
            }
            if affected {
                if !snapshot.workOrders[orderIndex].auditLog.contains(where: { $0.message == message }) {
                    snapshot.workOrders[orderIndex].auditLog.append(AuditEvent(date: Date(), message: message))
                }
                var statusEntries = snapshot.workOrders[orderIndex].statusEntries ?? []
                if !statusEntries.contains(where: { $0.kind == .integrityNotice && $0.detail == message }) {
                    statusEntries.append(StatusEntry(kind: .integrityNotice, date: Date(), detail: message))
                }
                snapshot.workOrders[orderIndex].statusEntries = statusEntries
            }
        }
        return stripped
    }

    private static func applyDefaults(_ object: inout [String: Any], defaults: [String: Any]) {
        for (key, value) in defaults where object[key] == nil || object[key] is NSNull {
            object[key] = value
        }
    }

    private static func jsonObject<T: Encodable>(for value: T) throws -> Any {
        let data = try JSONEncoder.pretty.encode(value)
        return try JSONSerialization.jsonObject(with: data)
    }

    private static func checksumAndLength(of url: URL) throws -> (sha256: String, byteCount: Int64) {
        let handle = try FileHandle(forReadingFrom: url)
        defer { try? handle.close() }
        var hasher = SHA256()
        var total: Int64 = 0
        while let data = try handle.read(upToCount: BackupArchiveConstants.streamChunkSize), !data.isEmpty {
            hasher.update(data: data)
            total += Int64(data.count)
        }
        return (hexDigest(hasher.finalize()), total)
    }

    private static func streamFile(_ sourceURL: URL, to output: FileHandle, hasher: inout SHA256) throws {
        let input = try FileHandle(forReadingFrom: sourceURL)
        defer { try? input.close() }
        while let data = try input.read(upToCount: BackupArchiveConstants.streamChunkSize), !data.isEmpty {
            try writeAndHash(data, to: output, hasher: &hasher)
        }
    }

    private static func writeAndHash(_ data: Data, to handle: FileHandle, hasher: inout SHA256) throws {
        hasher.update(data: data)
        try handle.write(contentsOf: data)
    }

    private static func readExactly(_ count: Int, from handle: FileHandle) throws -> Data {
        guard count >= 0 else { throw BackupArchiveError.archiveLengthMismatch }
        var result = Data()
        result.reserveCapacity(count)
        while result.count < count {
            let needed = count - result.count
            guard let chunk = try handle.read(upToCount: needed), !chunk.isEmpty else {
                throw BackupArchiveError.archiveLengthMismatch
            }
            result.append(chunk)
        }
        return result
    }

    private static func integerData<T: FixedWidthInteger>(_ value: T) -> Data {
        var bigEndian = value.bigEndian
        return withUnsafeBytes(of: &bigEndian) { Data($0) }
    }

    private static func decodeUInt32(_ data: Data) -> UInt32 {
        data.reduce(UInt32(0)) { ($0 << 8) | UInt32($1) }
    }

    private static func decodeUInt64(_ data: Data) -> UInt64 {
        data.reduce(UInt64(0)) { ($0 << 8) | UInt64($1) }
    }

    private static func hexDigest<D: Sequence>(_ digest: D) -> String where D.Element == UInt8 {
        digest.map { String(format: "%02x", $0) }.joined()
    }

    private static func isSafeFilename(_ filename: String) -> Bool {
        AttachmentFilenamePolicy.isSafe(filename)
    }

    private static func isSafeArchivePath(_ path: String) -> Bool {
        guard !path.isEmpty, !path.hasPrefix("/"), !path.contains("\\") else { return false }
        let components = path.split(separator: "/", omittingEmptySubsequences: false)
        return !components.isEmpty && components.allSatisfy { !$0.isEmpty && $0 != "." && $0 != ".." }
    }

    private static func importRootDirectory() -> URL {
        FileManager.default.temporaryDirectory.appendingPathComponent(BackupArchiveConstants.importDirectoryName, isDirectory: true)
    }

    private static func cleanupTemporaryItems() {
        let cutoff = Date().addingTimeInterval(-24 * 60 * 60)
        for directory in [importRootDirectory(), FileManager.default.temporaryDirectory.appendingPathComponent(BackupArchiveConstants.exportDirectoryName, isDirectory: true)] {
            guard let items = try? FileManager.default.contentsOfDirectory(
                at: directory,
                includingPropertiesForKeys: [.contentModificationDateKey],
                options: [.skipsHiddenFiles]
            ) else { continue }
            for item in items {
                let date = (try? item.resourceValues(forKeys: [.contentModificationDateKey]).contentModificationDate) ?? .distantPast
                if date < cutoff { try? FileManager.default.removeItem(at: item) }
            }
        }
    }

    private static func pruneSafetyBackups(keeping limit: Int) {
        guard let files = try? FileManager.default.contentsOfDirectory(
            at: safetyBackupDirectory,
            includingPropertiesForKeys: [.contentModificationDateKey],
            options: [.skipsHiddenFiles]
        ) else { return }
        let sorted = files.sorted {
            let lhs = (try? $0.resourceValues(forKeys: [.contentModificationDateKey]).contentModificationDate) ?? .distantPast
            let rhs = (try? $1.resourceValues(forKeys: [.contentModificationDateKey]).contentModificationDate) ?? .distantPast
            return lhs > rhs
        }
        for file in sorted.dropFirst(max(0, limit)) { try? FileManager.default.removeItem(at: file) }
    }

    private static func ensureAvailableCapacity(requiredBytes: Int64, near url: URL) throws {
        guard requiredBytes >= 0 else {
            throw BackupArchiveError.insufficientStorage(requiredBytes: Int64.max, availableBytes: nil)
        }
        let probe = FileManager.default.fileExists(atPath: url.path) ? url : url.deletingLastPathComponent()
        let attributes = try? FileManager.default.attributesOfFileSystem(forPath: probe.path)
        let available = (attributes?[.systemFreeSize] as? NSNumber)?.int64Value
        guard let available else { return }
        guard available >= requiredBytes else {
            throw BackupArchiveError.insufficientStorage(requiredBytes: requiredBytes, availableBytes: available)
        }
    }

    private static func directorySize(_ directory: URL) -> Int64 {
        var total: Int64 = 0
        if let enumerator = FileManager.default.enumerator(at: directory, includingPropertiesForKeys: [.fileSizeKey], options: [.skipsHiddenFiles]) {
            for case let file as URL in enumerator {
                total += Int64((try? file.resourceValues(forKeys: [.fileSizeKey]).fileSize) ?? 0)
            }
        }
        return total
    }

    private static func modificationDate(of url: URL) -> Date {
        let attributes = try? FileManager.default.attributesOfItem(atPath: url.path)
        return attributes?[.modificationDate] as? Date ?? Date()
    }

    private static func portableBackupFilename(profile: UserProfile) -> String {
        let base = profile.buildingName.trimmingCharacters(in: .whitespacesAndNewlines)
        let label = base.isEmpty ? "iWorkOrder" : base
        let safe = label
            .components(separatedBy: CharacterSet.alphanumerics.inverted)
            .filter { !$0.isEmpty }
            .joined(separator: "-")
            .prefix(48)
        return "\(safe.isEmpty ? "iWorkOrder" : String(safe))-backup-\(compactTimestamp(Date()))-\(UUID().uuidString.prefix(6)).iworkorderbackup"
    }

    private static func compactTimestamp(_ date: Date) -> String {
        let formatter = DateFormatter()
        formatter.locale = Locale(identifier: "en_US_POSIX")
        formatter.calendar = Calendar(identifier: .gregorian)
        formatter.timeZone = .current
        formatter.dateFormat = "yyyyMMdd-HHmmss"
        return formatter.string(from: date)
    }
}
