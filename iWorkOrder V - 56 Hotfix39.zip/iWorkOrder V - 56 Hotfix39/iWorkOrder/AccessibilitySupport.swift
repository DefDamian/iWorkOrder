import Foundation
import SwiftUI

/// Stable identifiers used by Voice Control and XCUITest. Keep these values stable across releases.
enum AccessibilityID {
    static let onboardingScreen = "screen.onboarding"
    static let lockScreen = "screen.lock"
    static let workOrdersScreen = "screen.workOrders"
    static let calendarScreen = "screen.calendar"
    static let hubScreen = "screen.hub"
    static let settingsScreen = "screen.settings"
    static let supportScreen = "screen.support"
#if DEBUG
    static let maintenanceRecoveryScreen = "screen.maintenanceRecovery"
#endif
    static let dataCompatibilityScreen = "screen.dataCompatibility"
    static let quickAddScreen = "screen.quickAdd"
    static let newWorkOrderScreen = "screen.newWorkOrder"
    static let legalUpdateSplash = "screen.legalUpdate"
    static let permissionSetupScreen = "screen.permissionSetup"

    static let quickAddButton = "workOrders.quickAdd"
    static let newWorkOrderButton = "workOrders.new"
    static let searchField = "workOrders.search"
    static let filterButton = "workOrders.filter"
    static let quickAddArea = "quickAdd.area"
    static let quickAddDescription = "quickAdd.description"
    static let quickAddSave = "quickAdd.save"
    static let quickAddCancel = "quickAdd.cancel"
    static let newOrderArea = "newOrder.area"
    static let newOrderDescription = "newOrder.description"
    static let newOrderSave = "newOrder.save"
    static let newOrderCancel = "newOrder.cancel"
    static let emailSupport = "support.email"
    static let exportSupportPackage = "support.exportPackage"
#if DEBUG
    static let runMaintenanceHealthCheck = "maintenance.runHealthCheck"
    static let cloudRecoveryPause = "maintenance.cloudRecoveryPause"
    static let exportMaintenanceReport = "maintenance.exportReport"
    static let clearMaintenanceHistory = "maintenance.clearHistory"
#endif
    static let legalUpdateReview = "legal.update.review"
    static let permissionRequestAll = "permissions.requestAll"
    static let permissionContinue = "permissions.continue"

    static func mainTab(_ tab: MainTab) -> String { "main.tab.\(tab.rawValue)" }
    static func statusFilter(_ status: WorkOrderStatus) -> String { "workOrders.status.\(status.accessibilityKey)" }
    static func workOrder(_ id: UUID) -> String { "workOrder.\(id.uuidString.lowercased())" }
}

extension WorkOrderStatus {
    fileprivate var accessibilityKey: String {
        switch self {
        case .new: return "new"
        case .pending: return "pending"
        case .inProgress: return "inProgress"
        case .completed: return "completed"
        }
    }
}

/// Keeps paired actions horizontal when they fit and stacks them for large text or narrow windows.
struct AdaptiveButtonPair<First: View, Second: View>: View {
    private let first: First
    private let second: Second

    init(@ViewBuilder first: () -> First, @ViewBuilder second: () -> Second) {
        self.first = first()
        self.second = second()
    }

    var body: some View {
        ViewThatFits(in: .horizontal) {
            HStack(spacing: 12) {
                first
                second
            }
            VStack(spacing: 12) {
                first
                second
            }
        }
    }
}

#if DEBUG
enum UITestingConfiguration {
    private static let arguments = ProcessInfo.processInfo.arguments

    static let isEnabled = arguments.contains("-ui-testing")
    static let startsOnboarding = arguments.contains("-ui-testing-onboarding")
    static let startsBackupRecovery = arguments.contains("-ui-testing-backup-recovery")
    static let seedsWorkOrders = arguments.contains("-ui-testing-seeded")
    static let startsLegalUpdate = arguments.contains("-ui-testing-legal-update")
    static let startsPermissionSetup = arguments.contains("-ui-testing-permission-setup")
    static let skipsSplash = isEnabled
}
#endif
