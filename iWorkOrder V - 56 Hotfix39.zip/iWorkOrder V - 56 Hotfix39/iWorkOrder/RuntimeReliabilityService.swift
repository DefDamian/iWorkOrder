import Foundation
import OSLog

/// A coarse lifecycle marker used only to identify a possible interrupted app session.
/// It does not claim that a crash occurred because iOS does not guarantee a termination callback.
enum RuntimeLifecycleState: String, Codable, CaseIterable, Sendable {
    case launching
    case active
    case inactive
    case background
}

struct RuntimeSessionCheckpoint: Codable, Equatable, Sendable {
    var sessionStartedAt: Date
    var lastUpdatedAt: Date
    var lifecycleState: RuntimeLifecycleState
    var buildVersion: String
    var schemaVersion: Int
    var memoryWarningCount: Int
}

struct RuntimeReliabilitySummary: Codable, Equatable, Sendable {
    var generatedAt: Date
    var previousSessionPossiblyInterrupted: Bool
    var interruptedSessionCount7Days: Int
    var memoryWarningCount7Days: Int
    var currentSessionMemoryWarningCount: Int
    var currentLifecycleState: RuntimeLifecycleState?
    var currentSessionStartedAt: Date?
    var lastCheckpointAt: Date?
    var cloudSyncPausedForRecovery: Bool
}

enum RuntimeReliabilityService {
    private static let logger = Logger(
        subsystem: "com.damiancedeno.SedgwickWorkOrders",
        category: "runtime-reliability"
    )
    private static let cloudSyncPauseKey = "iWorkOrder.reliability.cloudSyncPaused"
    private static let previousInterruptionKey = "iWorkOrder.reliability.previousSessionInterrupted"

    static var checkpointURL: URL {
        MaintenanceService.maintenanceDirectory.appendingPathComponent("runtime-session.json")
    }

    static var isCloudSyncPaused: Bool {
        UserDefaults.standard.bool(forKey: cloudSyncPauseKey)
    }

    @discardableResult
    static func beginSession(at date: Date = Date()) -> RuntimeReliabilitySummary {
        let previous = checkpoint()
        let possiblyInterrupted = previous.map { checkpoint in
            checkpoint.lifecycleState != .background
        } ?? false

        UserDefaults.standard.set(possiblyInterrupted, forKey: previousInterruptionKey)
        if possiblyInterrupted {
            MaintenanceService.record(kind: .sessionInterrupted, outcome: .warning)
            logger.warning("A previous app session may have ended before a background checkpoint was written")
        }

        writeCheckpoint(
            RuntimeSessionCheckpoint(
                sessionStartedAt: date,
                lastUpdatedAt: date,
                lifecycleState: .launching,
                buildVersion: AppBuildInfo.displayVersion,
                schemaVersion: AppDataSchema.currentVersion,
                memoryWarningCount: 0
            )
        )
        return summary(at: date)
    }

    static func transition(to state: RuntimeLifecycleState, at date: Date = Date()) {
        var value = checkpoint() ?? RuntimeSessionCheckpoint(
            sessionStartedAt: date,
            lastUpdatedAt: date,
            lifecycleState: state,
            buildVersion: AppBuildInfo.displayVersion,
            schemaVersion: AppDataSchema.currentVersion,
            memoryWarningCount: 0
        )
        value.lifecycleState = state
        value.lastUpdatedAt = date
        value.buildVersion = AppBuildInfo.displayVersion
        value.schemaVersion = AppDataSchema.currentVersion
        writeCheckpoint(value)
    }

    static func noteMemoryWarning(at date: Date = Date()) {
        var value = checkpoint() ?? RuntimeSessionCheckpoint(
            sessionStartedAt: date,
            lastUpdatedAt: date,
            lifecycleState: .active,
            buildVersion: AppBuildInfo.displayVersion,
            schemaVersion: AppDataSchema.currentVersion,
            memoryWarningCount: 0
        )
        value.memoryWarningCount += 1
        value.lastUpdatedAt = date
        writeCheckpoint(value)
        MaintenanceService.record(kind: .memoryPressure, outcome: .warning, itemCount: value.memoryWarningCount)
        logger.warning("The application received a system memory-pressure warning")
    }

    static func setCloudSyncPaused(_ paused: Bool) {
        let changed = paused != isCloudSyncPaused
        UserDefaults.standard.set(paused, forKey: cloudSyncPauseKey)
        if changed {
            MaintenanceService.record(
                kind: .recoverySyncPauseChanged,
                outcome: paused ? .warning : .success,
                itemCount: paused ? 1 : 0
            )
        }
    }

    static func summary(at date: Date = Date()) -> RuntimeReliabilitySummary {
        let cutoff = Calendar.current.date(byAdding: .day, value: -7, to: date) ?? .distantPast
        let recent = MaintenanceService.events().filter { $0.date >= cutoff }
        let current = checkpoint()
        return RuntimeReliabilitySummary(
            generatedAt: date,
            previousSessionPossiblyInterrupted: UserDefaults.standard.bool(forKey: previousInterruptionKey),
            interruptedSessionCount7Days: recent.filter { $0.kind == .sessionInterrupted }.count,
            memoryWarningCount7Days: recent.filter { $0.kind == .memoryPressure }.count,
            currentSessionMemoryWarningCount: current?.memoryWarningCount ?? 0,
            currentLifecycleState: current?.lifecycleState,
            currentSessionStartedAt: current?.sessionStartedAt,
            lastCheckpointAt: current?.lastUpdatedAt,
            cloudSyncPausedForRecovery: isCloudSyncPaused
        )
    }

    static func deleteAll() {
        try? FileManager.default.removeItem(at: checkpointURL)
        UserDefaults.standard.removeObject(forKey: cloudSyncPauseKey)
        UserDefaults.standard.removeObject(forKey: previousInterruptionKey)
    }

    static func checkpoint() -> RuntimeSessionCheckpoint? {
        guard let data = try? Data(contentsOf: checkpointURL) else { return nil }
        return try? JSONDecoder.iso8601.decode(RuntimeSessionCheckpoint.self, from: data)
    }

    private static func writeCheckpoint(_ checkpoint: RuntimeSessionCheckpoint) {
        do {
            try FileManager.default.createDirectory(
                at: MaintenanceService.maintenanceDirectory,
                withIntermediateDirectories: true
            )
            let data = try JSONEncoder.pretty.encode(checkpoint)
            try data.write(
                to: checkpointURL,
                options: [.atomic, .completeFileProtectionUntilFirstUserAuthentication]
            )
        } catch {
            logger.error("Unable to persist the local runtime session checkpoint")
        }
    }
}
