import Foundation
import SwiftUI

struct UserProfile: Codable, Equatable, Hashable, Sendable {
    var personName: String = ""
    var propertyManagerCompanyName: String = ""
    var buildingAddress: String = ""
    var buildingName: String { buildingAddress.components(separatedBy: ",").first ?? buildingAddress }
    var notificationsEnabled: Bool = false
    var legalAccepted: Bool = false
    var legalAcceptedDate: Date?
    var legalAcceptedVersion: String?
    var iCloudEnabled: Bool = true
    var iCloudDisabledDate: Date?
    var faceIDEnabled: Bool = false
    var role: UserRole = .superintendent
    var storageChoice: StorageChoice = .iCloud
    var firstBuildingUnits: [String] = []
    var emergencyNotificationsEnabled: Bool = true
}

enum UserRole: String, CaseIterable, Identifiable, Codable, Hashable, Sendable {
    case superintendent = "Superintendent"
    case handyman = "Handyman"
    var id: String { rawValue }
}

enum StorageChoice: String, CaseIterable, Identifiable, Codable, Hashable, Sendable {
    case iCloud = "iCloud Sync"
    case localOnly = "Local Only"
    var id: String { rawValue }
}

enum WorkOrderStatus: String, CaseIterable, Identifiable, Codable, Hashable, Sendable {
    case new = "New Work Order"
    case pending = "Pending"
    case inProgress = "In-progress"
    case completed = "Completed"
    var id: String { rawValue }
}

enum LegacyWorkOrderCategory: String, CaseIterable, Identifiable, Codable, Hashable, Sendable {
    case plumbing = "Plumbing"
    case electric = "Electrical"
    case hvac = "HVAC"
    case appliances = "Appliances"
    case locks = "Locks / Doors"
    case pest = "Pest Control"
    case paint = "Paint / Walls"
    case roof = "Roof"
    case landscaping = "Landscaping"
    case pool = "Pool"
    case other = "Other"
    var id: String { rawValue }
}

struct WorkOrderCategory: RawRepresentable, Identifiable, Codable, Hashable, Sendable {
    let rawValue: String

    init(rawValue: String) {
        self.rawValue = rawValue
    }

    var id: String { rawValue }

    static let plumbing = WorkOrderCategory(rawValue: "Plumbing")
    static let electric = WorkOrderCategory(rawValue: "Electrical")
    static let hvac = WorkOrderCategory(rawValue: "HVAC")
    static let appliances = WorkOrderCategory(rawValue: "Appliances")
    static let locks = WorkOrderCategory(rawValue: "Locks / Doors")
    static let pest = WorkOrderCategory(rawValue: "Pest Control")
    static let paint = WorkOrderCategory(rawValue: "Paint / Walls")
    static let roof = WorkOrderCategory(rawValue: "Roof")
    static let landscaping = WorkOrderCategory(rawValue: "Landscaping")
    static let pool = WorkOrderCategory(rawValue: "Pool")
    static let other = WorkOrderCategory(rawValue: "Other")

    static let defaultCategories: [WorkOrderCategory] = [
        .plumbing, .electric, .hvac, .appliances, .locks, .pest,
        .paint, .roof, .landscaping, .pool, .other
    ]

    static func normalizedName(_ value: String) -> String {
        value
            .split(whereSeparator: { $0.isWhitespace })
            .joined(separator: " ")
            .trimmingCharacters(in: .whitespacesAndNewlines)
    }

    /// Stable identity used for category deduplication across devices.
    /// Never use Locale.current here: CloudKit peers can have different locales.
    static func identityKey(_ value: String) -> String {
        normalizedName(value)
            .folding(
                options: [.caseInsensitive, .diacriticInsensitive, .widthInsensitive],
                locale: Locale(identifier: "en_US_POSIX")
            )
    }

    static func reordered(
        _ values: [WorkOrderCategory],
        moving source: IndexSet,
        to destination: Int
    ) -> [WorkOrderCategory] {
        let validOffsets = source.filter { values.indices.contains($0) }.sorted()
        guard !validOffsets.isEmpty else { return values }
        let movingValues = validOffsets.map { values[$0] }
        var remaining = values.enumerated()
            .filter { !source.contains($0.offset) }
            .map(\.element)
        let removedBeforeDestination = validOffsets.filter { $0 < destination }.count
        let insertionIndex = max(0, min(remaining.count, destination - removedBeforeDestination))
        remaining.insert(contentsOf: movingValues, at: insertionIndex)
        return remaining
    }

    init(from decoder: Decoder) throws {
        let container = try decoder.singleValueContainer()
        rawValue = try container.decode(String.self)
    }

    func encode(to encoder: Encoder) throws {
        var container = encoder.singleValueContainer()
        try container.encode(rawValue)
    }
}

enum WorkOrderPriority: String, CaseIterable, Identifiable, Codable, Hashable, Sendable {
    case emergency = "Emergency"
    case high = "High"
    case normal = "Normal"
    case low = "Low"
    var id: String { rawValue }
    var sortValue: Int {
        switch self {
        case .emergency: return 0
        case .high: return 1
        case .normal: return 2
        case .low: return 3
        }
    }
}



enum EntryMethod: String, CaseIterable, Identifiable, Codable, Hashable, Sendable {
    case notSpecified = "Not specified"
    case masterKey = "Master Key"
    case tenantLetIn = "Tenant Let In"
    case superintendentLetIn = "Superintendent Let In"
    case vendorAccess = "Vendor Access"
    case other = "Other"
    var id: String { rawValue }
}

enum StatusEventKind: String, Codable, CaseIterable, Identifiable, Hashable, Sendable {
    case created = "Created"
    case started = "Started"
    case statusChanged = "Status Changed"
    case photoAdded = "Photo Added"
    case reminderScheduled = "Reminder Scheduled"
    case signed = "Signed"
    case completed = "Completed"
    case edited = "Edited"
    case deleted = "Deleted"
    case recovered = "Recovered"
    case redacted = "Redacted"
    case integrityNotice = "Integrity Notice"
    var id: String { rawValue }
}

struct StatusEntry: Identifiable, Codable, Equatable, Hashable, Sendable {
    var id = UUID()
    var kind: StatusEventKind = .created
    var date = Date()
    var detail: String = ""
}

struct WorkOrderImage: Identifiable, Codable, Equatable, Hashable, Sendable {
    var id = UUID()
    var filename: String
    var kind: ImageKind
    var compressed: Bool = true
    var createdAt: Date = Date()

    enum ImageKind: String, Codable, CaseIterable, Identifiable, Hashable, Sendable {
        case before = "Before"
        case after = "After"
        var id: String { rawValue }
    }
}

struct AuditEvent: Identifiable, Codable, Equatable, Hashable, Sendable {
    var id = UUID()
    var date = Date()
    var message: String
}

struct AssetRecord: Identifiable, Codable, Equatable, Hashable, Sendable {
    var id = UUID()
    var tag: String = ""
    var name: String = ""
    var location: String = ""
    var notes: String = ""
    var createdAt = Date()
}

struct TenantContact: Identifiable, Codable, Equatable, Hashable, Sendable {
    var id = UUID()
    var unit: String = ""
    var name: String = ""
    var phone: String = ""
    var email: String = ""
    var entryPermission: Bool = false
}

struct WorkOrderEntry: Identifiable, Codable, Equatable, Hashable, Sendable {
    var id = UUID()
    var createdAt = Date()
    var area: String = ""
    var issueDescription: String = ""
    var notes: String = ""
    var handymanName: String = ""
    var category: LegacyWorkOrderCategory = .other
    var customCategoryName: String? = nil
    var priority: WorkOrderPriority = .normal
    var entryPermitted: Bool = false
    var tenantPermission: Bool? = nil
    var entryMethod: EntryMethod? = nil
    var assetTag: String = ""
    var assetID: String? = nil
    var reminderEnabled: Bool = false
    var reminderDate: Date = Date()
    var images: [WorkOrderImage] = []
    var signatureFilename: String?
    var signatureSignerName: String?
    var signatureCapturedAt: Date?
    var signatureConsentVersion: String?
}

extension WorkOrderEntry {
    var managedCategory: WorkOrderCategory {
        get {
            if let customCategoryName {
                let normalized = WorkOrderCategory.normalizedName(customCategoryName)
                if !normalized.isEmpty {
                    return WorkOrderCategory(rawValue: normalized)
                }
            }
            return WorkOrderCategory(rawValue: category.rawValue)
        }
        set {
            let normalized = WorkOrderCategory.normalizedName(newValue.rawValue)
            if let legacy = LegacyWorkOrderCategory(rawValue: normalized) {
                category = legacy
                customCategoryName = nil
            } else {
                category = .other
                customCategoryName = normalized.isEmpty ? nil : normalized
            }
        }
    }

    var trimmedArea: String {
        area.trimmingCharacters(in: .whitespacesAndNewlines)
    }

    var trimmedIssueDescription: String {
        issueDescription.trimmingCharacters(in: .whitespacesAndNewlines)
    }

    var hasRequiredFields: Bool {
        !trimmedArea.isEmpty && !trimmedIssueDescription.isEmpty
    }

    mutating func normalizeUserEnteredText() {
        area = trimmedArea
        issueDescription = trimmedIssueDescription
        handymanName = handymanName.trimmingCharacters(in: .whitespacesAndNewlines)
        assetTag = assetTag.trimmingCharacters(in: .whitespacesAndNewlines)
        if let customCategoryName {
            let cleanCategoryName = WorkOrderCategory.normalizedName(customCategoryName)
            self.customCategoryName = cleanCategoryName.isEmpty ? nil : cleanCategoryName
        }
        if let assetID {
            let cleanAssetID = assetID.trimmingCharacters(in: .whitespacesAndNewlines)
            self.assetID = cleanAssetID.isEmpty ? nil : cleanAssetID
        }
    }
}

struct WorkOrder: Identifiable, Codable, Equatable, Hashable, Sendable {
    var id = UUID()
    var createdAt = Date()
    var status: WorkOrderStatus = .inProgress
    var entries: [WorkOrderEntry]
    var auditLog: [AuditEvent] = []
    var statusEntries: [StatusEntry]? = []
    var isDeleted = false
    var deletedAt: Date?

    var originalEntry: WorkOrderEntry { entries.first ?? WorkOrderEntry() }
    var latestEntry: WorkOrderEntry { entries.last ?? WorkOrderEntry() }
    var wasEdited: Bool { entries.count > 1 }
    var title: String { originalEntry.issueDescription.isEmpty ? "Untitled Work Order" : originalEntry.issueDescription }
    var isEmergency: Bool { latestEntry.priority == .emergency }
    var isSignedAndLocked: Bool {
        guard status == .completed, let filename = latestEntry.signatureFilename else { return false }
        return !filename.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty
    }
}

struct WorkOrderReport: Identifiable, Hashable, Sendable {
    let id = UUID()
    let month: Date
    let workOrders: [WorkOrder]
}

struct WorkOrderFilters: Codable, Equatable, Hashable, Sendable {
    var searchText: String = ""
    var unit: String = ""
    var handyman: String = ""
    var emergencyOnly: Bool = false
    var category: WorkOrderCategory? = nil
}
