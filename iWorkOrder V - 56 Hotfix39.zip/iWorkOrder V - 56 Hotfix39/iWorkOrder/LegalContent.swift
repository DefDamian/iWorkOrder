import Foundation

enum LegalContent {
    static let currentVersion = "2026.09.16.56"
    static let effectiveDate = "September 16, 2026"
    static let region = "United States"
    static let supportEmail = "damianced@icloud.com"
    static let updateSummary = [
        "First-use device permission review and restored-device permission handling were added.",
        "Notification, torch-only camera, PhotosPicker, location, Contacts, Calendar, microphone, and app-lock permission boundaries were clarified.",
        "Privacy, Apple-service, backup, export, recovery, and device-permission disclosures were refreshed.",
        "Normal app access requires acceptance of this legal version before the permission review and protected app access.",
    ]

    static func isCurrentAcceptance(_ profile: UserProfile) -> Bool {
        profile.legalAccepted && profile.legalAcceptedDate != nil && profile.legalAcceptedVersion == currentVersion
    }

    static let privacy = """
Privacy Policy - iWorkOrder
Effective Date: September 16, 2026
Legal Version: 2026.09.16.56
United States Only

This Privacy Policy explains how information is handled by the iWorkOrder mobile application. iWorkOrder is a property-maintenance and work-order documentation tool intended for adult workplace use in the United States.

1. Scope and contact

iWorkOrder does not require a developer-operated account. The app is designed so that operational records remain under the user's control on the device and, when enabled, in the user's private Apple iCloud/CloudKit account. Questions about this policy may be sent to damianced@icloud.com.

2. Information the app handles

The app may handle information that the user chooses to enter, import, select, create, or attach, including names, property-management company details, building addresses, unit or area labels, tenant or contractor contact details, work-order descriptions, notes, categories, priorities, access and permission information, reminders, asset information, photos selected by the user, electronic-signature drawings and signer names, revision history, and audit activity.

Users should enter only information reasonably necessary for the maintenance task and are responsible for obtaining any notice, consent, authorization, or permission required for tenant information, photographs, property access, electronic signatures, and other records.

3. How information enters the app

Information may be entered manually, imported from user-provided text or backup files, selected through Apple system pickers, created by the app as work-order or audit metadata, or restored from a user-controlled backup or the user's private CloudKit database. Photo attachments are selected through Apple's system PhotosPicker, which gives the app access only to the items the user chooses and does not require full Photo Library authorization. The app does not capture camera images or video, record microphone audio, read the device Contacts or Calendar databases, or collect the device's precise location. The optional flashlight control uses Apple camera-hardware APIs only to control the device torch and does not start a media-capture session.

4. Local storage and private iCloud/CloudKit

iWorkOrder stores operational data in the app's protected container on the device. If the user enables iCloud Sync, the app also stores a work-order snapshot, photos, and signatures in the user's private Apple CloudKit database. A limited onboarding-completion preference may also be stored through Apple's iCloud key-value service.

The developer does not operate a separate work-order server and does not receive the user's work-order content, tenant notes, photos, signatures, or audit records through a developer-operated backend. Apple processes iCloud and CloudKit data under Apple's applicable terms, privacy policies, and platform security controls.

5. Apple platform services and service providers

User-requested features may use Apple platform services, including iCloud/CloudKit, local notification services, the system PhotosPicker, Files and share-sheet services, Mail, biometric or device-owner authentication, the rear-camera torch hardware used by the optional flashlight control, and Apple's geocoding service. When the user chooses Verify Address, the address text entered by the user may be submitted to Apple's geocoding service so the app can validate and format that address. iWorkOrder does not request device-location authorization for address verification and does not use that feature to collect the device's precise location in the foreground or background.

iWorkOrder does not share user data with third-party advertising, attribution, or analytics providers. If a future service provider is given access to personal information on behalf of iWorkOrder, that provider will be required to protect the information consistently with this policy, applicable law, and applicable Apple requirements, and this policy will be updated before that use where required.

6. Developer collection, tracking, sale, and advertising

iWorkOrder does not include advertising SDKs, third-party analytics SDKs, cross-app tracking, data-broker integrations, or developer-operated telemetry endpoints. The app does not sell or rent personal information and does not use personal information for targeted advertising.

The developer receives information only when the user intentionally sends it, for example by emailing support or deliberately sharing an exported diagnostics report or support bundle. The app does not automatically transmit those support files to the developer.

7. How information is used

Information is used to create, edit, organize, search, and document work orders; maintain revisions and audit activity; display reminders and emergency follow-ups; manage assets and contacts; verify a user-entered address; synchronize and restore data through iCloud when enabled; create PDFs and portable backups; perform local integrity, migration, storage, and reliability checks; and create user-controlled diagnostics and support exports.

8. Photos, signatures, and attachments

Photos are stored only when the user selects them for a work order. Signature drawings, signer names, timestamps, and the applicable legal-consent version are stored only when a user completes a signature flow. These items may be included in work-order records, CloudKit synchronization, PDF exports, and portable backup archives. iWorkOrder does not verify a signer's identity, authority, legal capacity, or the enforceability of an electronic signature.

9. Audit and revision information

The app creates timestamped revision and audit entries for certain work-order activity. Generated entries are designed to preserve an operational history during normal editing, but they are not guaranteed to be permanent, immutable, complete, independently verified, or legally admissible. Records may be deleted, restored, redacted through an authorized feature, repaired for integrity, or removed through Erase All Data.

10. Notifications, authentication, and permissions

On a new installation, new device, or other first-use state in which the device-local permission review has not been completed, iWorkOrder presents a permission review after required onboarding/legal steps. The review may request iOS notification authorization for work-order reminders and emergency-priority follow-ups and camera authorization solely so the optional rear flashlight can control the device torch. Camera authorization is not used by iWorkOrder to capture or record photos or video.

Photo attachments use Apple's system PhotosPicker, so iWorkOrder does not request broad Photo Library authorization. iWorkOrder does not request device Contacts access, Calendar database access, microphone access, precise-location access, or App Tracking Transparency authorization for the features in this version. Keyboard dictation, if the user invokes it, is an iOS keyboard service rather than audio recording performed by iWorkOrder.

If the user enables app locking, iWorkOrder may use Face ID, Touch ID, or device-passcode authentication through Apple system services. Device-owner authentication is requested only when the protected app-lock feature requires it; it is not required for normal unlocked use. iOS permission decisions are device-local and are not restored by an iWorkOrder backup. The user may change permissions in iOS Settings. Denying an optional permission may limit only the related feature and does not authorize unrelated data collection.

11. Portable backups, PDFs, diagnostics, and support exports

PDF exports and .iworkorderbackup archives are user-controlled files and may contain names, property details, tenant or contractor contacts, photos, signatures, asset records, work-order content, and audit history. Privacy-safe diagnostics, maintenance reports, and .iworkordersupport bundles contain technical state, fixed event categories, aggregate counts, integrity information, and other limited troubleshooting data described in the app. They are not sent automatically.

Once a user exports or shares a file outside the app container, the user is responsible for the destination, retention, access controls, and any further disclosure of that file.

12. Local operational and reliability records

For maintenance and release troubleshooting, iWorkOrder may retain a local privacy-safe operational history of up to 250 events for up to 30 days. These records use fixed technical categories, outcomes, durations, schema/build values, and aggregate counts. The app also keeps a replaceable runtime checkpoint containing lifecycle state, timestamps, build/schema information, and a memory-warning count. These records exclude user-entered work-order text, names, addresses, tenant contacts, audit messages, photos, signatures, attachment filenames, and device identifiers.

13. Retention and deletion

Operational data remains in the app until the user deletes records, restores different data, uses Erase All Data, removes app storage, or otherwise causes the data to be replaced. The app may retain up to five protected pre-migration recovery copies and up to three verified pre-restore safety backups to reduce the risk of data loss. Temporary backup, restore, CloudKit-staging, PDF, diagnostics, and support-export files are app-controlled and are subject to cleanup and Erase All Data.

Cloud data remains in the user's private CloudKit database until it is replaced or deleted through iWorkOrder or Apple services. Erase All Data removes app-controlled local operational data and related recovery/support state. If private CloudKit deletion cannot finish because the device is offline or Apple services are unavailable, deletion remains pending and is retried when the app can complete it. Files already exported to Files, Mail, another app, or another location are outside iWorkOrder's control and are not removed automatically.

14. Privacy choices and requests

Users can review and correct operational information in the app, delete individual records, disable iCloud Sync, change notification and authentication settings, export data, and use Erase All Data. iWorkOrder does not create a separate developer account, so there is no developer-hosted account to delete. Depending on applicable law, individuals may have additional privacy rights. Requests concerning information actually received by the developer may be sent to the support address below.

15. Security

iWorkOrder uses iOS application-container isolation, Apple Data Protection, protected file attributes for sensitive app-controlled files, optional device-owner authentication, integrity checks for portable backups and support bundles, and Apple's private CloudKit services when enabled. No storage, synchronization, backup, or transmission method can be guaranteed completely secure or error-free.

16. Children

iWorkOrder is intended for adult workplace and property-maintenance use and is not directed to children under 18. The app should not be used to intentionally collect information from children.

17. Regional limitation and legal requirements

The app is designed for United States use. Privacy, housing, employment, tenant-access, electronic-signature, building, safety, evidentiary, and record-retention requirements can vary by state, locality, property type, employer, and use case. Users are responsible for determining the requirements that apply to their activities.

18. Changes to this Privacy Policy

When a material legal or privacy change is released, iWorkOrder assigns a new legal version. Existing users must review and accept the current legal package before normal app access resumes. The app displays the effective date and legal version in Legal & About.

19. Contact

Support and privacy contact: damianced@icloud.com
"""

    static let terms = """
Terms & Conditions - iWorkOrder
Effective Date: September 16, 2026
Legal Version: 2026.09.16.56
United States Only

These Terms & Conditions govern use of iWorkOrder's features. They are in addition to any App Store license terms that apply to the application. If Apple's Standard Licensed Application End User License Agreement applies to the download, that license remains applicable unless a valid custom license agreement has replaced it.

1. Acceptance and renewed acceptance

By selecting I Understand and Agree, you agree to these Terms & Conditions, the Privacy Policy, and the Data & Liability Disclaimer for the legal version shown in the app. If a material legal update is released, normal app access may be blocked until you review and accept the new version. If you do not agree, do not continue using iWorkOrder.

2. Eligibility and intended use

iWorkOrder is intended for adults using a property-maintenance organization, documentation, reminder, export, backup, and restoration tool in the United States. You must use the app only for lawful purposes and only when you have authority to handle the information and property involved.

3. App Store license

iWorkOrder is licensed, not sold. Your right to use the app is subject to the applicable App Store usage rules and license terms. Nothing in these Terms expands the device or distribution rights granted through the App Store.

4. User responsibility

You are responsible for information entered, imported, restored, attached, signed, exported, or shared through the app; the accuracy and completeness of records; device and Apple-account security; lawful property access; required notices and permissions; tenant and worker privacy; contractor and employment compliance; safety procedures; insurance requirements; and retention obligations.

5. User content and permissions

You retain responsibility for and any rights you hold in user-provided content. You grant iWorkOrder only the limited permission necessary for the app and Apple platform services to store, process, display, synchronize, back up, restore, and export that content at your direction. You must not enter or share content that you do not have the right or authority to use.

A first-use device permission review may ask iOS for notification authorization and camera authorization used only by the optional rear flashlight. You may allow or deny those optional permissions. Photo selection uses Apple's system PhotosPicker rather than broad Photo Library access. This version does not request device Contacts, Calendar, microphone, precise-location, or App Tracking Transparency authorization for normal app features. Device-owner authentication is requested only if App Lock is enabled or restored as enabled.

6. No legal, safety, engineering, or repair advice

iWorkOrder provides organizational and documentation functionality only. It does not provide legal, engineering, architectural, code-compliance, accounting, insurance, medical, emergency, or repair advice and does not replace an attorney, licensed contractor, design professional, inspector, property manager, insurer, government agency, manufacturer instructions, emergency service, or required safety system.

7. Property access and tenant or workplace obligations

The app does not authorize entry into an apartment, unit, office, roof, equipment room, or other area. You are responsible for lawful access, required notice, consent, key control, photography rules, tenant rights, workplace rules, confidentiality obligations, and any restrictions imposed by law, lease, contract, employer policy, or property procedure.

8. Electronic signatures

A signature flow may store a signer name, time, consent-version identifier, and signature drawing associated with a work-order revision. iWorkOrder does not verify identity, authority, intent, legal capacity, consent, witness requirements, attribution, or enforceability. You are responsible for determining whether an electronic signature is appropriate and for obtaining any disclosure, consent, authentication, witness, record-retention, or other evidence required by applicable law or contract.

9. Storage, CloudKit, synchronization, and recovery

The app stores data locally and may synchronize data through the user's private Apple CloudKit database when iCloud Sync is enabled. Sync, upload, download, conflict resolution, deletion, backup, migration, and restoration can be delayed, unavailable, interrupted, or incomplete because of device, storage, network, Apple-account, Apple-service, software, corruption, or user conditions. The app includes recovery and integrity safeguards but cannot guarantee against every data-loss scenario. Maintain independent verified backups appropriate to the importance of your records.

10. Audit and revision records

The app may create timestamped revisions and audit entries. They are operational records, not independent proof. They may be affected by deletion, backup restoration, authorized redaction, integrity repair, migration, or Erase All Data. No audit or revision record is guaranteed to be tamper-proof, complete, authentic, legally admissible, or accepted by any court, agency, employer, landlord, tenant, insurer, or other party.

11. Notifications and emergency conditions

Reminders and emergency-priority follow-ups are convenience features. Delivery can fail or be delayed because of iOS settings, notification authorization, Focus modes, device state, software conditions, or Apple services. iWorkOrder is not an emergency alarm, monitoring system, life-safety system, dispatch service, or sole method of communicating urgent conditions. For immediate danger, call 911 or the appropriate emergency service and follow the property's emergency procedures.

12. Exports and backup files

PDFs, .iworkorderbackup archives, diagnostics, maintenance reports, and support bundles are user-controlled files. Verify their contents before relying on them and protect files that contain personal, property, tenant, contractor, photograph, signature, or audit information. Integrity checks may detect certain corruption or modification but do not certify the truth, authorship, chain of custody, completeness, or legal sufficiency of the contents.

13. Apple and other services

Certain features depend on Apple services such as iCloud/CloudKit, geocoding of user-entered addresses, notifications, the system PhotosPicker, Files, Mail, sharing, camera hardware authorization for the optional torch, and device authentication when App Lock is enabled. Those services are governed by Apple's own terms and policies and may change, restrict, or discontinue availability. iWorkOrder is not responsible for Apple service outages, device permission settings, or account restrictions outside the app's control.

14. Prohibited use

You may not use iWorkOrder to violate law, invade privacy, bypass lawful access restrictions, falsify records, misrepresent another person's identity or authority, interfere with the app's security or integrity, or use exported information in a manner that you are not authorized to use.

15. No warranty

To the fullest extent permitted by law, iWorkOrder is provided "as is" and "as available" without warranties of accuracy, completeness, merchantability, fitness for a particular purpose, title, noninfringement, availability, successful synchronization, successful restoration, uninterrupted operation, or legal sufficiency.

16. Limitation of liability

To the fullest extent permitted by law, the developer is not liable for data loss, corrupted or incomplete records, missed notifications, failed sync, failed backup or restoration, unauthorized disclosure caused by user-controlled sharing or device/account practices, property damage, personal injury, business interruption, tenant or contractor disputes, regulatory or legal outcomes, lost profits, or indirect, incidental, special, exemplary, or consequential damages arising from use of or inability to use the app.

Some jurisdictions do not allow certain warranty disclaimers or liability limitations. In those jurisdictions, these provisions apply only to the maximum extent permitted by law and do not limit rights that cannot lawfully be waived.

17. Compliance and regional limitation

You are responsible for compliance with applicable federal, state, and local law and with contracts, policies, permits, licenses, notices, and professional requirements that apply to your work. iWorkOrder is intended for United States use and does not guarantee compliance in any jurisdiction or for any specific property, employer, profession, or transaction.

18. Changes to these Terms

Material legal changes are assigned a new legal version and require renewed in-app acceptance before normal app access resumes. The updated effective date and legal version are displayed in Legal & About.

19. Contact

Support: damianced@icloud.com
"""

    static let liability = """
Data & Liability Disclaimer - iWorkOrder
Effective Date: September 16, 2026
Legal Version: 2026.09.16.56
United States Only

Important: iWorkOrder is a documentation and workflow tool. It does not perform repairs, inspect property, verify identity, determine lawful entry, confirm code or legal compliance, dispatch emergency services, or certify that any record is accurate, complete, authentic, admissible, or legally sufficient.

1. User-controlled information

The user controls the information entered, imported, restored, photographed or selected, signed, exported, and shared through iWorkOrder. The developer does not review, approve, correct, authenticate, or certify work orders, tenant or contractor information, property details, photos, signatures, asset information, revision history, or audit records.

2. Property access and privacy

iWorkOrder does not authorize entry into apartments, units, offices, roofs, equipment rooms, or other property. Users are responsible for lawful access, required notice, privacy, photography, key control, tenant rights, confidentiality, workplace rules, and any lease, contract, employer, or property requirements.

3. Repairs, hazards, and safety

The app is not an emergency service, safety control, alarm, inspection system, dispatch system, or substitute for trained and licensed professionals. Follow applicable emergency procedures, permits, manufacturer instructions, lockout/tagout procedures, personal-protective-equipment requirements, and building, fire, electrical, plumbing, environmental, occupational-safety, and other applicable rules.

4. Data storage and availability

Data is stored on the user's device and, when enabled, in the user's private Apple CloudKit database. Device failure, account changes, insufficient storage, network interruptions, Apple-service conditions, software defects, corruption, deletion, migration failure, version incompatibility, failed rollback, or user error may affect availability. Recovery copies, transactional safeguards, and integrity checks reduce risk but cannot eliminate every failure mode. Users should maintain independent verified backups appropriate to the importance of their records.

5. Audit and revision limitations

Generated audit and revision entries document app activity and user-entered statements. They are not independent verification and are not guaranteed to be immutable, complete, tamper-proof, legally admissible, or sufficient to establish notice, consent, work completion, condition, causation, damages, or any other fact.

6. Electronic-signature limitations

A captured signer name and signature drawing are user-provided attestations associated with a work-order revision. iWorkOrder does not verify identity, authority, legal capacity, intent, consent, witness requirements, authenticity, or enforceability. Users must determine whether an electronic signature is appropriate and preserve any additional authentication, disclosure, witness, or retention evidence required for the transaction.

7. Notification limitations

Reminders and emergency-priority follow-ups may be delayed, suppressed, or not delivered, including when notification authorization is denied or restricted by iOS. They must not be used as the only method for life-safety warnings, emergency dispatch, legally required notices, code-required monitoring, or other time-critical communications.

8. Export and backup limitations

PDFs, portable backups, diagnostics, maintenance reports, and support bundles reflect app data and technical state at the time they are created. Checksums and integrity validation can detect certain changes or corruption but cannot establish truth, authorship, chain of custody, completeness, or legal admissibility. Preserve original communications, photographs, notices, invoices, receipts, permits, inspection records, and other independent evidence when needed.

9. Apple service dependencies

Optional iCloud/CloudKit synchronization, address geocoding, notifications, PhotosPicker selection, sharing, Mail, Files, camera authorization for the torch-only flashlight feature, and device authentication for App Lock depend on Apple services, device configuration, permission settings, and Apple-account status. iWorkOrder does not request broad Photo Library, Contacts, Calendar, microphone, precise-location, or App Tracking Transparency authorization for the features in this version. Availability and behavior of Apple services and device permission controls are outside iWorkOrder's control.

10. Jurisdictional differences

Laws and procedures differ by state, locality, property type, employer, contract, profession, and use case. iWorkOrder cannot determine or guarantee compliance with every housing, privacy, employment, electronic-signature, construction, contractor, consumer-protection, insurance, evidence, safety, or record-retention requirement.

11. No warranty and limitation of liability

The app is provided "as is" and "as available." To the fullest extent permitted by law, the developer disclaims warranties and liability for inaccurate or incomplete records, data loss, failed sync or restoration, missed reminders, unauthorized user sharing, property damage, personal injury, business interruption, disputes, regulatory action, or legal outcomes arising from use of or inability to use the app.

Nothing in this disclaimer excludes or limits liability that cannot legally be excluded or limited.

12. Emergencies

iWorkOrder is not an emergency service. Call 911 or the appropriate emergency service and follow the property's emergency procedures whenever immediate danger exists.

13. Changes and renewed acceptance

Material changes to this disclaimer are assigned a new legal version. Existing users must review and accept the current legal package before normal app access resumes.

14. Contact

Support: damianced@icloud.com
"""

    static var agreement: String {
        [privacy, terms, liability].joined(separator: "\n\n")
    }
}

enum AppBuildInfo {
    static var marketingVersion: String {
        Bundle.main.object(forInfoDictionaryKey: "CFBundleShortVersionString") as? String ?? "1.0"
    }

    static var buildNumber: String {
        Bundle.main.object(forInfoDictionaryKey: "CFBundleVersion") as? String ?? "1"
    }

    static var displayVersion: String {
        "\(marketingVersion) (\(buildNumber))"
    }
}
