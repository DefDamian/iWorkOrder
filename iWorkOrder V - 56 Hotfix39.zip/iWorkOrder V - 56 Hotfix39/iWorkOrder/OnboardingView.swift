import SwiftUI
import UniformTypeIdentifiers
import UserNotifications
import AVFoundation


@MainActor
struct InitialDataRecoveryView: View {
    @AppStorage(AppTheme.storageKey) private var selectedThemeRaw = VisualTheme.defaultTheme.rawValue
    @EnvironmentObject private var store: AppStore
    @State private var isImporterPresented = false
    @State private var isWorking = false
    @State private var statusMessage: String?
    @State private var restoreCandidate: BackupRestoreCandidate?
    @State private var showRestoreConfirmation = false
    private var selectedTheme: VisualTheme { VisualTheme(rawValue: selectedThemeRaw) ?? .defaultTheme }

    var body: some View {
        NavigationStack {
            ScreenBackground {
                SwiftUI.ScrollView(.vertical, showsIndicators: true) {
                    VStack(alignment: .leading, spacing: 20) {
                        VStack(alignment: .leading, spacing: 10) {
                            Label("iWorkOrder", systemImage: "building.2.crop.circle.fill")
                                .font(.headline)
                                .foregroundStyle(.blue)
                            Text("Do you already have an iWorkOrder backup?")
                                .font(.largeTitle.weight(.bold))
                            Text("Restore your existing data first and you will not have to complete onboarding again. If no backup exists, continue with a new setup.")
                                .font(.subheadline)
                                .foregroundStyle(.secondary)
                        }
                        .padding(.top, 16)

                        ModernCard {
                            VStack(alignment: .leading, spacing: 14) {
                                SectionHeader(
                                    title: "Restore Existing Data",
                                    subtitle: "Use a portable backup file or your private iCloud data."
                                )

                                Button {
                                    isImporterPresented = true
                                } label: {
                                    Label("Restore Backup File", systemImage: "externaldrive.badge.checkmark")
                                        .frame(maxWidth: .infinity)
                                }
                                .buttonStyle(.borderedProminent)
                                .controlSize(.large)
                                .disabled(isWorking || store.isBackupOperationInProgress)
                                .accessibilityIdentifier("recovery.restoreFile")

                                Button {
                                    restoreFromICloud()
                                } label: {
                                    Label("Restore from iCloud", systemImage: "icloud.and.arrow.down")
                                        .frame(maxWidth: .infinity)
                                }
                                .buttonStyle(.bordered)
                                .controlSize(.large)
                                .disabled(isWorking || store.isBackupOperationInProgress)
                                .accessibilityIdentifier("recovery.restoreICloud")

                                Text("A successful restore brings back the saved profile and app data, then skips onboarding. If the backup used an older legal agreement, only the updated agreement will need to be accepted.")
                                    .font(.caption)
                                    .foregroundStyle(.secondary)
                            }
                        }

                        ModernCard {
                            VStack(alignment: .leading, spacing: 12) {
                                SectionHeader(
                                    title: "No Backup",
                                    subtitle: "Choose this only when you want to configure iWorkOrder as a new setup."
                                )
                                Button {
                                    store.beginFreshOnboarding()
                                } label: {
                                    Label("I Don't Have a Backup", systemImage: "arrow.right.circle")
                                        .frame(maxWidth: .infinity)
                                }
                                .buttonStyle(.bordered)
                                .controlSize(.large)
                                .disabled(isWorking || store.isBackupOperationInProgress)
                                .accessibilityIdentifier("recovery.startNew")
                            }
                        }

                        if isWorking {
                            HStack(spacing: 10) {
                                ProgressView()
                                Text("Checking and restoring your data...")
                                    .font(.caption)
                                    .foregroundStyle(.secondary)
                            }
                        }

                        if let statusMessage {
                            Text(statusMessage)
                                .font(.caption)
                                .foregroundStyle(.secondary)
                                .textSelection(.enabled)
                        }
                    }
                    .padding(.horizontal, AppTheme.horizontalPadding(for: selectedTheme))
                    .padding(.bottom, 28)
                }
            }
            .accessibilityIdentifier("screen.backupRecovery")
            .fileImporter(
                isPresented: $isImporterPresented,
                allowedContentTypes: [.data, .json],
                allowsMultipleSelection: false
            ) { result in
                switch result {
                case .success(let urls):
                    guard let url = urls.first else { return }
                    inspectBackup(url)
                case .failure(let error):
                    statusMessage = "Backup selection failed: \(error.localizedDescription)"
                }
            }
            .confirmationDialog(
                "Restore This Backup?",
                isPresented: $showRestoreConfirmation,
                presenting: restoreCandidate
            ) { candidate in
                Button("Restore Backup") {
                    restore(candidate)
                }
                Button("Cancel", role: .cancel) {
                    store.discardBackupCandidate(candidate)
                    restoreCandidate = nil
                }
            } message: { candidate in
                let warningText = candidate.warnings.isEmpty
                    ? "All archive checks passed."
                    : candidate.warnings.joined(separator: " ")
                Text("\(candidate.sourceFormat.rawValue): \(candidate.summary). \(warningText) Restoring this backup will replace the empty setup on this device and skip onboarding.")
            }
        }
    }

    private func inspectBackup(_ url: URL) {
        Task {
            isWorking = true
            statusMessage = nil
            defer { isWorking = false }
            if let candidate = await store.inspectBackup(at: url) {
                restoreCandidate = candidate
                showRestoreConfirmation = true
                statusMessage = "Backup verification passed. Confirm restore to continue."
            } else {
                statusMessage = store.lastErrorMessage ?? "Backup validation failed."
            }
        }
    }

    private func restore(_ candidate: BackupRestoreCandidate) {
        Task {
            isWorking = true
            statusMessage = nil
            defer {
                isWorking = false
                restoreCandidate = nil
            }
            if let result = await store.restoreBackup(candidate, mode: .replace) {
                let warnings = result.warningCount == 0
                    ? ""
                    : " \(result.warningCount) restore warning(s) were recorded."
                statusMessage = "Backup restored with \(result.restoredCounts.workOrders) work order(s). Onboarding was skipped.\(warnings)"
            } else {
                statusMessage = store.lastErrorMessage ?? "Backup restore failed. No onboarding data was changed."
            }
        }
    }

    private func restoreFromICloud() {
        Task {
            isWorking = true
            statusMessage = nil
            defer { isWorking = false }
            if await store.restoreFromICloudBeforeOnboarding() {
                statusMessage = "iCloud data restored. Onboarding was skipped."
            } else {
                statusMessage = store.lastErrorMessage ?? store.cloudSyncDetail
            }
        }
    }
}

@MainActor
struct OnboardingView: View {
    @AppStorage(AppTheme.storageKey) private var selectedThemeRaw = VisualTheme.defaultTheme.rawValue
    @EnvironmentObject private var store: AppStore
    @StateObject private var verifier = AddressVerifier()
    @State private var showLegal = false
    @State private var showNotificationDenied = false
    @State private var isUpdatingNotifications = false
    @State private var isFinishingSetup = false
    @State private var csvText = ""

    private var selectedTheme: VisualTheme { VisualTheme(rawValue: selectedThemeRaw) ?? .defaultTheme }

    private var completeAllowed: Bool {
        !store.profile.personName.trimmingCharacters(in: .whitespaces).isEmpty &&
        !store.profile.propertyManagerCompanyName.trimmingCharacters(in: .whitespaces).isEmpty &&
        verifier.isVerified && store.hasCurrentLegalAcceptance
    }

    var body: some View {
        NavigationStack {
            ScreenBackground {
                SwiftUI.ScrollView(.vertical, showsIndicators: true) {
                    VStack(alignment: .leading, spacing: 18) {
                        VStack(alignment: .leading, spacing: 10) {
                            Label("iWorkOrder", systemImage: "building.2.crop.circle.fill").font(.headline).foregroundStyle(.blue)
                            Text("Set up your work order system.").font(.largeTitle.weight(.bold))
                            Text("Pick your role, verify the building with Apple Maps, choose storage, and start with units ready to use.").font(.subheadline).foregroundStyle(.secondary)
                        }.padding(.top, 16)

                        ModernCard {
                            VStack(alignment: .leading, spacing: 14) {
                                SectionHeader(title: "Role", subtitle: "This changes the main experience.")
                                Picker("Role", selection: $store.profile.role) {
                                    ForEach(UserRole.allCases) { Text($0.rawValue).tag($0) }
                                }.pickerStyle(.segmented)
                                .onChange(of: store.profile.role) { _, _ in HapticManager.selection() }
                                Text(store.profile.role == .superintendent ? "Supers see dashboards, reports, directory, and admin tools." : "Handymen see a priority queue and task-focused work orders.")
                                    .font(.caption).foregroundStyle(.secondary)
                            }
                        }

                        ModernCard {
                            VStack(alignment: .leading, spacing: 14) {
                                SectionHeader(title: "Profile", subtitle: "Used on reports and exports.")
                                TextField("Your name", text: $store.profile.personName)
                                    .textInputAutocapitalization(.words)
                                    .textContentType(.name)
                                    .accessibilityIdentifier("onboarding.name")
                                    .appInputFieldChrome()
                                TextField("Property Manager Company Name", text: $store.profile.propertyManagerCompanyName)
                                    .textInputAutocapitalization(.words)
                                    .accessibilityIdentifier("onboarding.company")
                                    .appInputFieldChrome()
                                TextField("Building address", text: $store.profile.buildingAddress)
                                    .textInputAutocapitalization(.words)
                                    .textContentType(.fullStreetAddress)
                                    .accessibilityIdentifier("onboarding.address")
                                    .appInputFieldChrome()
                                    .onChange(of: store.profile.buildingAddress) { _, newValue in verifier.resetIfNeeded(for: newValue) }
                                    .onSubmit { verifyAndFormatAddress() }
                                ViewThatFits(in: .horizontal) {
                                    HStack(spacing: 12) {
                                        verifyAddressButton
                                        Spacer()
                                        verificationStatus
                                    }
                                    VStack(alignment: .leading, spacing: 10) {
                                        verifyAddressButton
                                        verificationStatus
                                    }
                                }
                            }
                        }

                        ModernCard {
                            VStack(alignment: .leading, spacing: 14) {
                                SectionHeader(title: "Data Storage", subtitle: "All data stays with you. iCloud sync restores after reinstall when available.")
                                Picker("Storage", selection: Binding(
                                    get: { store.profile.storageChoice },
                                    set: { choice in
                                        Task { @MainActor in
                                            await Task.yield()
                                            HapticManager.selection()
                                            store.setStorageChoice(choice)
                                        }
                                    }
                                )) {
                                    ForEach(StorageChoice.allCases) { Text($0.rawValue).tag($0) }
                                }
                                .pickerStyle(.segmented)

                                Toggle("Use iCloud Sync", isOn: Binding(
                                    get: { store.profile.iCloudEnabled && store.profile.storageChoice == .iCloud },
                                    set: { enabled in
                                        Task { @MainActor in
                                            await Task.yield()
                                            store.setICloudEnabled(enabled)
                                        }
                                    }
                                ))
                                Text(store.profile.storageChoice == .iCloud ? "Work orders, compressed photos, and signatures sync through your private iCloud database." : "Local only means data stays on this device and may not restore after reinstall.")
                                    .font(.caption).foregroundStyle(.secondary)
                            }
                        }

                        ModernCard {
                            VStack(alignment: .leading, spacing: 12) {
                                SectionHeader(title: "Permissions", subtitle: "A device-permission review follows setup.")
                                Text("Photos are selected with Apple's system picker, so iWorkOrder does not request full Photo Library access. Notifications can be enabled here, and the first-use permission review also covers camera hardware access used only by the optional flashlight.")
                                    .font(.caption).foregroundStyle(.secondary)
                                Toggle(isOn: Binding(
                                    get: { store.profile.notificationsEnabled },
                                    set: { enabled in
                                        Task { @MainActor in
                                            await Task.yield()
                                            updateNotificationPreference(enabled)
                                        }
                                    }
                                )) {
                                    Text("Enable Notifications").font(.headline)
                                }
                                .disabled(isUpdatingNotifications || isFinishingSetup)
                            }
                        }

                        ModernCard {
                            VStack(alignment: .leading, spacing: 12) {
                                SectionHeader(title: "Initial Building Quick Start", subtitle: "Add units or paste CSV-style values.")
                                TextField("Example: 1A, 1B, Lobby, Roof", text: $csvText, axis: .vertical).lineLimit(2...4).appInputFieldChrome()
                                Button {
                                    if store.importUnits(CSVHelper.parseUnits(from: csvText)) {
                                        csvText = ""
                                    }
                                } label: { Label("Import Units / Areas", systemImage: "square.and.arrow.down") }.buttonStyle(.bordered)
                                if !store.profile.firstBuildingUnits.isEmpty {
                                    Text(store.profile.firstBuildingUnits.prefix(12).joined(separator: ", ")).font(.caption).foregroundStyle(.secondary)
                                }
                            }
                        }

                        ModernCard {
                            VStack(alignment: .leading, spacing: 12) {
                                SectionHeader(title: "Legal Agreement", subtitle: "Required before using the app.")
                                Button { showLegal = true } label: {
                                    Label(store.hasCurrentLegalAcceptance ? "Agreement Accepted" : "Review and Accept", systemImage: store.hasCurrentLegalAcceptance ? "checkmark.seal.fill" : "doc.text.magnifyingglass").frame(maxWidth: .infinity)
                                }.buttonStyle(.bordered).controlSize(.large)
                            }
                        }

                        if completeAllowed {
                            Button { Task { await finishSetup() } } label: { Label("Complete Setup", systemImage: "arrow.right.circle.fill").font(.headline).frame(maxWidth: .infinity).padding(.vertical, 14) }
                                .buttonStyle(.borderedProminent).controlSize(.large)
                                .disabled(isUpdatingNotifications || isFinishingSetup)
                        }
                    }.padding(.horizontal, AppTheme.horizontalPadding(for: selectedTheme)).padding(.bottom, 28)
                }
            }
            .keyboardDismissable()
            .accessibilityIdentifier(AccessibilityID.onboardingScreen)
            .sheet(isPresented: $showLegal) { LegalAgreementView() }
            .alert("Notifications Not Enabled", isPresented: $showNotificationDenied) { Button("OK", role: .cancel) {} } message: { Text("You can enable them later in device Settings.") }
        }
    }

    private var verifyAddressButton: some View {
        Button { verifyAndFormatAddress() } label: {
            Label("Verify Address", systemImage: "location.magnifyingglass")
        }
        .buttonStyle(.borderedProminent)
        .disabled(verifier.isChecking)
        .accessibilityIdentifier("onboarding.verifyAddress")
    }

    private var verificationStatus: some View {
        Label(verifier.status, systemImage: verifier.isVerified ? "checkmark.circle.fill" : (verifier.isChecking ? "clock.arrow.circlepath" : "exclamationmark.circle"))
            .font(.caption.weight(.semibold))
            .foregroundStyle(verifier.isVerified ? .green : .secondary)
            .accessibilityLabel("Address verification")
            .accessibilityValue(verifier.status)
    }

    private func verifyAndFormatAddress() {
        verifier.verify(store.profile.buildingAddress) { formatted in
            let originalAddress = store.profile.buildingAddress
            store.profile.buildingAddress = formatted
            if !store.save() {
                store.profile.buildingAddress = originalAddress
            }
        }
    }
    private func updateNotificationPreference(_ enabled: Bool) {
        guard !isUpdatingNotifications, enabled != store.profile.notificationsEnabled else { return }
        if !enabled {
            let previousProfile = store.profile
            store.profile.notificationsEnabled = false
            _ = store.applyNotificationPreferences(previousProfile: previousProfile)
            return
        }

        isUpdatingNotifications = true
        Task {
            defer { isUpdatingNotifications = false }
            let granted = await store.notifications.requestPermission()
            guard !Task.isCancelled else { return }
            if granted {
                let previousProfile = store.profile
                store.profile.notificationsEnabled = true
                _ = store.applyNotificationPreferences(previousProfile: previousProfile)
            } else {
                // No profile mutation occurred before the permission prompt.
                showNotificationDenied = true
            }
            await store.refreshNotificationAuthorization()
        }
    }

    private func finishSetup() async {
        guard !isFinishingSetup, !isUpdatingNotifications, completeAllowed else { return }
        isFinishingSetup = true
        defer { isFinishingSetup = false }
        guard verifier.isVerified else { verifyAndFormatAddress(); return }
        if store.profile.notificationsEnabled {
            let granted = await store.notifications.requestPermission()
            guard !Task.isCancelled, completeAllowed else { return }
            if !granted {
                // Preserve a previously synced preference; authorization is local
                // to this device and must not be pushed back as a global disable.
                showNotificationDenied = true
            }
            store.completeOnboarding()
            await store.refreshNotificationAuthorization()
        } else {
            store.completeOnboarding()
        }
    }
}

@MainActor
struct PermissionSetupView: View {
    @AppStorage(AppTheme.storageKey) private var selectedThemeRaw = VisualTheme.defaultTheme.rawValue
    @EnvironmentObject private var store: AppStore
    @Environment(\.openURL) private var openURL
    @State private var notificationStatus: UNAuthorizationStatus = .notDetermined
    @State private var cameraStatus: AVAuthorizationStatus = .notDetermined
    @State private var isRequesting = false

    private var permissionsReviewed: Bool {
        notificationStatus != .notDetermined && cameraStatus != .notDetermined
    }

    private var selectedTheme: VisualTheme { VisualTheme(rawValue: selectedThemeRaw) ?? .defaultTheme }

    var body: some View {
        NavigationStack {
            ScreenBackground {
                SwiftUI.ScrollView(.vertical, showsIndicators: true) {
                    VStack(alignment: .leading, spacing: 18) {
                        VStack(alignment: .leading, spacing: 10) {
                            Label("Device Permissions", systemImage: "checkmark.shield.fill")
                                .font(.headline)
                                .foregroundStyle(.blue)
                            Text("Review iWorkOrder permissions.")
                                .font(.largeTitle.weight(.bold))
                            Text("These permissions are local to this iPhone or iPad. Restoring a backup does not restore iOS permission decisions, so a new device or reinstall reviews them again.")
                                .font(.subheadline)
                                .foregroundStyle(.secondary)
                        }
                        .padding(.top, 16)

                        ModernCard {
                            VStack(alignment: .leading, spacing: 14) {
                                SectionHeader(title: "iOS Permission Requests", subtitle: "iWorkOrder requests only protected access used by app features.")
                                permissionRow(
                                    title: "Notifications",
                                    detail: "Used for work-order reminders and emergency-priority follow-ups.",
                                    systemImage: "bell.badge",
                                    status: notificationStatusText
                                )
                                Divider()
                                permissionRow(
                                    title: "Camera Hardware",
                                    detail: "Used only to control the optional rear flashlight. iWorkOrder does not capture photos or video with the camera.",
                                    systemImage: "flashlight.on.fill",
                                    status: cameraStatusText
                                )

                                Button {
                                    Task { await requestAppPermissions() }
                                } label: {
                                    Label(requestButtonTitle, systemImage: "hand.raised.fill")
                                        .frame(maxWidth: .infinity)
                                }
                                .buttonStyle(.borderedProminent)
                                .controlSize(.large)
                                .disabled(isRequesting || permissionsReviewed)
                                .accessibilityIdentifier(AccessibilityID.permissionRequestAll)

                                if isRequesting {
                                    HStack(spacing: 10) {
                                        ProgressView()
                                        Text("Waiting for iOS permission decisions...")
                                            .font(.caption)
                                            .foregroundStyle(.secondary)
                                    }
                                }

                                if needsSettingsLink {
                                    Button("Open iOS Settings") {
                                        guard let url = URL(string: UIApplication.openSettingsURLString) else { return }
                                        openURL(url)
                                    }
                                    .buttonStyle(.bordered)
                                }
                            }
                        }

                        ModernCard {
                            VStack(alignment: .leading, spacing: 12) {
                                SectionHeader(title: "No Broad Permission Needed", subtitle: "These features use privacy-preserving Apple system controls.")
                                informationalRow(title: "Photos", text: "The system PhotosPicker grants only the photos you choose. Full Photo Library permission is not requested.", icon: "photo.on.rectangle")
                                informationalRow(title: "Location", text: "iWorkOrder does not request device location. Address verification uses only the address text you enter.", icon: "location.slash")
                                informationalRow(title: "Contacts & Calendar", text: "iWorkOrder does not request access to your device Contacts or Calendar databases.", icon: "person.crop.circle.badge.xmark")
                                informationalRow(title: "Microphone", text: "iWorkOrder does not request microphone access. Keyboard dictation, if used, is provided by iOS.", icon: "mic.slash")
                                informationalRow(title: "App Lock", text: appLockDetail, icon: "faceid")
                                informationalRow(title: "Files & iCloud", text: "Files are selected through Apple pickers and iCloud data stays in your private Apple account when sync is enabled.", icon: "icloud")
                            }
                        }

                        Button {
                            store.completePermissionSetup()
                        } label: {
                            Label("Continue to iWorkOrder", systemImage: "arrow.right.circle.fill")
                                .font(.headline)
                                .frame(maxWidth: .infinity)
                                .padding(.vertical, 12)
                        }
                        .buttonStyle(.borderedProminent)
                        .controlSize(.large)
                        .disabled(!permissionsReviewed || isRequesting)
                        .accessibilityIdentifier(AccessibilityID.permissionContinue)

                        if !permissionsReviewed {
                            Text("Respond to both iOS permission requests before continuing. You can allow or deny either permission; denying one only limits the related feature.")
                                .font(.caption)
                                .foregroundStyle(.secondary)
                        }
                    }
                    .padding(.horizontal, AppTheme.horizontalPadding(for: selectedTheme))
                    .padding(.bottom, 28)
                }
            }
            .accessibilityIdentifier(AccessibilityID.permissionSetupScreen)
            .task { await refreshPermissionStatuses() }
            .onReceive(NotificationCenter.default.publisher(for: UIApplication.didBecomeActiveNotification)) { _ in
                Task { await refreshPermissionStatuses() }
            }
        }
    }

    @ViewBuilder
    private func permissionRow(title: String, detail: String, systemImage: String, status: String) -> some View {
        HStack(alignment: .top, spacing: 12) {
            Image(systemName: systemImage)
                .font(.title3)
                .frame(width: 28)
                .foregroundStyle(.blue)
                .accessibilityHidden(true)
            VStack(alignment: .leading, spacing: 4) {
                HStack {
                    Text(title).font(.headline)
                    Spacer()
                    Text(status)
                        .font(.caption.weight(.semibold))
                        .foregroundStyle(.secondary)
                }
                Text(detail)
                    .font(.caption)
                    .foregroundStyle(.secondary)
            }
        }
    }

    @ViewBuilder
    private func informationalRow(title: String, text: String, icon: String) -> some View {
        HStack(alignment: .top, spacing: 12) {
            Image(systemName: icon)
                .frame(width: 24)
                .foregroundStyle(.secondary)
                .accessibilityHidden(true)
            VStack(alignment: .leading, spacing: 3) {
                Text(title).font(.subheadline.weight(.semibold))
                Text(text).font(.caption).foregroundStyle(.secondary)
            }
        }
    }

    private var requestButtonTitle: String {
        permissionsReviewed ? "Permissions Reviewed" : "Request iOS Permissions"
    }

    private var notificationStatusText: String {
        switch notificationStatus {
        case .notDetermined: return "Not Asked"
        case .denied: return "Denied"
        case .authorized: return "Allowed"
        case .provisional: return "Provisional"
        case .ephemeral: return "Allowed"
        @unknown default: return "Unknown"
        }
    }

    private var cameraStatusText: String {
        switch cameraStatus {
        case .notDetermined: return "Not Asked"
        case .restricted: return "Restricted"
        case .denied: return "Denied"
        case .authorized: return "Allowed"
        @unknown default: return "Unknown"
        }
    }

    private var needsSettingsLink: Bool {
        notificationStatus == .denied || cameraStatus == .denied || cameraStatus == .restricted
    }

    private var appLockDetail: String {
        if store.profile.faceIDEnabled {
            return "App Lock is enabled in your profile. iOS will require Face ID, Touch ID, or the device passcode before protected app access."
        }
        return "Device-owner authentication is requested only if you enable App Lock. It is not required for normal app use."
    }

    private func refreshPermissionStatuses() async {
        notificationStatus = await store.notifications.authorizationStatus()
        cameraStatus = FlashlightService.cameraAuthorizationStatus
        await store.refreshNotificationAuthorization()
    }

    private func requestAppPermissions() async {
        guard !isRequesting else { return }
        isRequesting = true
        defer { isRequesting = false }

        await refreshPermissionStatuses()

        if notificationStatus == .notDetermined {
            let granted = await store.notifications.requestPermission()
            if granted && !store.profile.notificationsEnabled {
                let previousProfile = store.profile
                store.profile.notificationsEnabled = true
                _ = store.applyNotificationPreferences(previousProfile: previousProfile)
            }
            guard !Task.isCancelled else { return }
            await refreshPermissionStatuses()
        }

        if cameraStatus == .notDetermined {
            _ = await FlashlightService.requestCameraPermission()
            guard !Task.isCancelled else { return }
            await refreshPermissionStatuses()
        }
    }
}

@MainActor
struct LegalAgreementView: View {
    @EnvironmentObject private var store: AppStore
    @Environment(\.dismiss) private var dismiss
    var body: some View {
        NavigationStack {
            LegalDocumentView(
                title: "Legal Agreement",
                document: .agreement,
                showAccept: true,
                accept: {
                    store.acceptCurrentLegalAgreement()
                    guard store.hasCurrentLegalAcceptance else { return }
                    dismiss()
                }
            )
            .toolbar { ToolbarItem(placement: .topBarTrailing) { Button("Close") { dismiss() } } }
        }
    }
}
