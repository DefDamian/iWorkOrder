import Foundation
@preconcurrency import CloudKit
import CryptoKit
import Network

struct CloudSyncOutcome: Sendable {
    var snapshot: AppSnapshot
    var syncedAt: Date
    var uploadedAttachmentCount: Int
    var downloadedAttachmentCount: Int
}

enum CloudSyncState: Equatable, Sendable {
    case disabled
    case paused
    case idle
    case checkingAccount
    case syncing
    case synced(Date)
    case offline
    case noAccount
    case restricted
    case failed(String)

    var title: String {
        switch self {
        case .disabled: return "Off"
        case .paused: return "Paused for Recovery"
        case .idle: return "Ready"
        case .checkingAccount: return "Checking iCloud"
        case .syncing: return "Syncing"
        case .synced: return "Synced"
        case .offline: return "Waiting for Network"
        case .noAccount: return "iCloud Account Required"
        case .restricted: return "iCloud Restricted"
        case .failed: return "Sync Failed"
        }
    }

    var isBusy: Bool {
        switch self {
        case .checkingAccount, .syncing: return true
        default: return false
        }
    }
}

enum CloudSyncError: LocalizedError, Sendable {
    case noNetwork
    case accountUnavailable
    case accountRestricted
    case accountStatusUnknown
    case cloudSnapshotMissingAsset
    case cloudSnapshotUnreadable
    case incompatibleDataSchema(Int)
    case invalidAttachmentMetadata(String)
    case attachmentContentConflict(String)
    case missingLocalAttachments([String])
    case incompleteCloudAttachments([String])
    case cloudErasePending
    case cloudReplacementPending
    case cloudKit(String)

    var errorDescription: String? {
        switch self {
        case .noNetwork:
            return "No network connection is available. Your changes remain saved on this device."
        case .accountUnavailable:
            return "Sign in to iCloud in Settings to sync iWorkOrder."
        case .accountRestricted:
            return "This device restricts access to iCloud. Your changes remain saved locally."
        case .accountStatusUnknown:
            return "iCloud account status could not be determined. Try again after checking Settings and the network connection."
        case .cloudSnapshotMissingAsset:
            return "The iCloud work-order snapshot is missing its data file. Local data was not replaced."
        case .cloudSnapshotUnreadable:
            return "The iCloud work-order snapshot could not be decoded. Local data was not replaced."
        case .incompatibleDataSchema(let version):
            return "The iCloud snapshot uses newer data schema \(version). Update iWorkOrder before syncing so newer cloud data is not overwritten."
        case .invalidAttachmentMetadata(let filename):
            return "An iCloud attachment has invalid metadata: \(filename)."
        case .attachmentContentConflict(let filename):
            return "Cloud sync stopped because the local and iCloud copies of attachment \(filename) have different readable contents. Neither copy was overwritten. Use a verified backup or authoritative cloud replacement after confirming which copy is correct."
        case .missingLocalAttachments(let filenames):
            return "Cloud sync stopped because \(filenames.count) referenced local attachment(s) are missing: \(Self.preview(filenames))."
        case .incompleteCloudAttachments(let filenames):
            return "Cloud restore stopped because \(filenames.count) referenced attachment(s) are missing from iCloud: \(Self.preview(filenames))."
        case .cloudErasePending:
            return "Cloud data deletion is pending. Sync and restore remain blocked until deletion finishes."
        case .cloudReplacementPending:
            return "A verified backup is waiting to replace the private iCloud dataset. Cloud restore and normal merge sync remain blocked until replacement finishes."
        case .cloudKit(let message):
            return message
        }
    }

    private static func preview(_ values: [String]) -> String {
        let visible = values.prefix(3).joined(separator: ", ")
        return values.count > 3 ? "\(visible), and \(values.count - 3) more" : visible
    }
}

final class NetworkStatusService {
    private let monitor = NWPathMonitor()
    private let queue = DispatchQueue(label: "iWorkOrder.NetworkStatus")
    private var hasStarted = false
    var statusChanged: (@Sendable (Bool) -> Void)?

    func start() {
        guard !hasStarted else { return }
        hasStarted = true
        let callback = statusChanged
        monitor.pathUpdateHandler = { path in
            callback?(path.status == .satisfied)
        }
        monitor.start(queue: queue)
    }

    deinit {
        monitor.cancel()
    }
}

actor CloudSyncService {
    private enum RecordType {
        static let snapshot = "IWorkOrderSnapshot"
        static let attachment = "IWorkOrderAttachment"
    }

    private enum Field {
        static let payload = "payload"
        static let savedAt = "savedAt"
        static let schemaVersion = "schemaVersion"
        static let deviceID = "deviceID"
        static let saveRevision = "saveRevision"
        static let file = "file"
        static let filename = "filename"
        static let kind = "kind"
        static let sha256 = "sha256"
        static let byteCount = "byteCount"
        static let modifiedAt = "modifiedAt"
    }

    private enum AttachmentKind: String {
        case image
        case signature
    }

    private struct AttachmentDescriptor: Hashable {
        let filename: String
        let kind: AttachmentKind

        var recordName: String {
            let key = "\(kind.rawValue)|\(filename)"
            let digest = SHA256.hash(data: Data(key.utf8))
            return "attachment-" + digest.map { String(format: "%02x", $0) }.joined()
        }

        var localURL: URL {
            switch kind {
            case .image: return ImageStorageService.url(forFilename: filename)
            case .signature: return SignatureStorageService.url(forFilename: filename)
            }
        }
    }

    private struct RemoteSnapshotEnvelope {
        var snapshot: AppSnapshot
        var attachmentRecordNames: Set<String>
    }

    private struct PreparedReplacementAttachment {
        let descriptor: AttachmentDescriptor
        let stagedURL: URL
        let sha256: String
        let byteCount: Int
        let modifiedAt: Date
    }

    private struct PreparedCloudReplacement {
        let directory: URL
        let snapshotURL: URL
        let attachments: [PreparedReplacementAttachment]
    }

    private static let legacySnapshotKey = "iWorkOrder.cloud.snapshot"
    private static let legacyLastSyncKey = "iWorkOrder.cloud.lastSync"
    private static let lastSuccessfulSyncKey = "iWorkOrder.cloudkit.lastSuccessfulSync"
    private static let cloudErasePendingKey = "iWorkOrder.cloudkit.erasePending"
    private static let cloudReplacementPendingKey = "iWorkOrder.cloudkit.replacementPending"

    private let container: CKContainer
    private let database: CKDatabase
    private let zoneID: CKRecordZone.ID
    private let snapshotRecordID: CKRecord.ID
    private var operationInProgress = false
    private var operationWaiters: [CheckedContinuation<Void, Never>] = []

    init(containerIdentifier: String = "iCloud.com.damiancedeno.SedgwickWorkOrders") {
        let resolvedZoneID = CKRecordZone.ID(zoneName: "iWorkOrderZone", ownerName: CKCurrentUserDefaultName)
        container = CKContainer(identifier: containerIdentifier)
        database = container.privateCloudDatabase
        zoneID = resolvedZoneID
        snapshotRecordID = CKRecord.ID(recordName: "iworkorder-single-user-snapshot-v2", zoneID: resolvedZoneID)
    }

    nonisolated func loadLegacySnapshot() -> AppSnapshot? {
        let store = NSUbiquitousKeyValueStore.default
        store.synchronize()
        guard let data = store.data(forKey: Self.legacySnapshotKey) else { return nil }
        return try? JSONDecoder.iso8601.decode(AppSnapshot.self, from: data)
    }

    nonisolated func lastSuccessfulSyncDate() -> Date? {
        UserDefaults.standard.object(forKey: Self.lastSuccessfulSyncKey) as? Date
    }

    nonisolated func isCloudErasePending() -> Bool {
        UserDefaults.standard.bool(forKey: Self.cloudErasePendingKey)
    }

    nonisolated func isCloudReplacementPending() -> Bool {
        UserDefaults.standard.bool(forKey: Self.cloudReplacementPendingKey)
    }

    nonisolated func beginCloudReplacement() {
        UserDefaults.standard.set(true, forKey: Self.cloudReplacementPendingKey)
        UserDefaults.standard.removeObject(forKey: Self.lastSuccessfulSyncKey)
    }

    nonisolated func cancelCloudReplacement() {
        UserDefaults.standard.removeObject(forKey: Self.cloudReplacementPendingKey)
    }

    nonisolated func beginCloudErase() {
        UserDefaults.standard.set(true, forKey: Self.cloudErasePendingKey)
        UserDefaults.standard.removeObject(forKey: Self.cloudReplacementPendingKey)
        UserDefaults.standard.removeObject(forKey: Self.lastSuccessfulSyncKey)
        clearLegacySnapshot()
    }

    func beginExclusiveLocalDataAccess() async {
        await acquireOperation()
    }

    func endExclusiveLocalDataAccess() {
        releaseOperation()
    }

    func synchronize(snapshot localSnapshot: AppSnapshot) async throws -> CloudSyncOutcome {
        await acquireOperation()
        defer { releaseOperation() }
        try Task.checkCancellation()
        guard !isCloudErasePending() else { throw CloudSyncError.cloudErasePending }
        guard !isCloudReplacementPending() else { throw CloudSyncError.cloudReplacementPending }
        try await verifyAccountAvailability()
        try await ensureZone()

        let remote = try await fetchRemoteSnapshotIfAvailable()
        var merged = ConflictMergeService.merge(local: localSnapshot, cloud: remote?.snapshot) ?? localSnapshot
        let syncedAt = Date()
        merged.lastSynced = syncedAt
        merged.deviceID = DeviceIdentity.current

        // Snapshot metadata alone cannot reveal an attachment record orphaned by
        // a crash after snapshot upload but before obsolete-record deletion. Use
        // the actual zone inventory when CloudKit can provide it, but fall back
        // to the snapshot-derived manifest so cleanup never blocks normal sync.
        let remoteAttachmentManifest = await attachmentRecordNamesInZone(
            fallback: remote?.attachmentRecordNames ?? []
        )
        let descriptors = try attachmentDescriptors(in: merged)
        let downloadedCount = try await restoreAttachments(
            descriptors,
            verifyRecordNames: remoteAttachmentManifest
        )
        let uploadedCount = try await uploadAttachments(descriptors)
        let newManifest = Set(descriptors.map(\.recordName))

        try await uploadSnapshot(merged, savedAt: syncedAt)
        try await deleteAttachmentRecords(remoteAttachmentManifest.subtracting(newManifest))

        recordSuccessfulSync(syncedAt)
        clearLegacySnapshot()
        return CloudSyncOutcome(
            snapshot: merged,
            syncedAt: syncedAt,
            uploadedAttachmentCount: uploadedCount,
            downloadedAttachmentCount: downloadedCount
        )
    }

    func downloadFromCloud() async throws -> CloudSyncOutcome? {
        await acquireOperation()
        defer { releaseOperation() }
        try Task.checkCancellation()
        guard !isCloudErasePending() else { throw CloudSyncError.cloudErasePending }
        guard !isCloudReplacementPending() else { throw CloudSyncError.cloudReplacementPending }
        try await verifyAccountAvailability()
        try await ensureZone()
        guard let remote = try await fetchRemoteSnapshotIfAvailable() else { return nil }

        let descriptors = try attachmentDescriptors(in: remote.snapshot)
        let downloadedCount = try await restoreAttachments(
            descriptors,
            verifyRecordNames: Set(descriptors.map(\.recordName))
        )
        let syncedAt = remote.snapshot.lastSynced ?? remote.snapshot.snapshotSavedAt ?? Date()
        recordSuccessfulSync(syncedAt)

        return CloudSyncOutcome(
            snapshot: remote.snapshot,
            syncedAt: syncedAt,
            uploadedAttachmentCount: 0,
            downloadedAttachmentCount: downloadedCount
        )
    }

    func replaceCloudData(with localSnapshot: AppSnapshot) async throws -> CloudSyncOutcome {
        await acquireOperation()
        defer { releaseOperation() }
        try Task.checkCancellation()
        guard !isCloudErasePending() else { throw CloudSyncError.cloudErasePending }
        guard isCloudReplacementPending() else { throw CloudSyncError.cloudReplacementPending }
        try await verifyAccountAvailability()

        var replacement = localSnapshot
        let syncedAt = Date()
        replacement.lastSynced = syncedAt
        replacement.deviceID = DeviceIdentity.current

        // Build and verify the complete replacement payload before deleting the
        // existing CloudKit zone. A missing/corrupt local attachment must never
        // turn a recoverable replacement error into destructive cloud data loss.
        let prepared = try prepareCloudReplacement(replacement)
        defer { try? FileManager.default.removeItem(at: prepared.directory) }

        try await deleteZoneIfPresent()
        try await ensureZone()

        let uploadedCount = try await uploadPreparedAttachments(prepared.attachments)
        try await uploadSnapshot(replacement, savedAt: syncedAt, preparedPayloadURL: prepared.snapshotURL)

        recordSuccessfulSync(syncedAt)
        UserDefaults.standard.removeObject(forKey: Self.cloudReplacementPendingKey)
        clearLegacySnapshot()
        return CloudSyncOutcome(
            snapshot: replacement,
            syncedAt: syncedAt,
            uploadedAttachmentCount: uploadedCount,
            downloadedAttachmentCount: 0
        )
    }

    func deleteCloudData() async throws {
        await acquireOperation()
        defer { releaseOperation() }
        try Task.checkCancellation()
        try await verifyAccountAvailability()
        try await deleteZoneIfPresent()
        UserDefaults.standard.removeObject(forKey: Self.lastSuccessfulSyncKey)
        UserDefaults.standard.removeObject(forKey: Self.cloudErasePendingKey)
        UserDefaults.standard.removeObject(forKey: Self.cloudReplacementPendingKey)
        clearLegacySnapshot()
    }

    private func deleteZoneIfPresent() async throws {
        do {
            _ = try await database.deleteRecordZone(withID: zoneID)
        } catch let error as CKError where error.code == .zoneNotFound || error.code == .unknownItem {
            return
        } catch {
            throw mappedError(error)
        }
    }

    private func acquireOperation() async {
        if !operationInProgress {
            operationInProgress = true
            return
        }
        await withCheckedContinuation { continuation in
            operationWaiters.append(continuation)
        }
    }

    private func releaseOperation() {
        if operationWaiters.isEmpty {
            operationInProgress = false
        } else {
            let next = operationWaiters.removeFirst()
            next.resume()
        }
    }

    private func verifyAccountAvailability() async throws {
        do {
            let status = try await container.accountStatus()
            switch status {
            case .available:
                return
            case .noAccount:
                throw CloudSyncError.accountUnavailable
            case .restricted:
                throw CloudSyncError.accountRestricted
            case .couldNotDetermine, .temporarilyUnavailable:
                throw CloudSyncError.accountStatusUnknown
            @unknown default:
                throw CloudSyncError.accountStatusUnknown
            }
        } catch let error as CloudSyncError {
            throw error
        } catch {
            throw mappedError(error)
        }
    }

    private func ensureZone() async throws {
        do {
            _ = try await database.recordZone(for: zoneID)
        } catch let error as CKError where error.code == .zoneNotFound || error.code == .unknownItem {
            do {
                _ = try await database.save(CKRecordZone(zoneID: zoneID))
            } catch {
                throw mappedError(error)
            }
        } catch {
            throw mappedError(error)
        }
    }

    private func fetchRemoteSnapshotIfAvailable() async throws -> RemoteSnapshotEnvelope? {
        guard let record = try await fetchRecordIfExists(snapshotRecordID) else { return nil }
        guard let asset = record[Field.payload] as? CKAsset, let fileURL = asset.fileURL else {
            throw CloudSyncError.cloudSnapshotMissingAsset
        }
        guard let data = try? Data(contentsOf: fileURL), var snapshot = try? JSONDecoder.iso8601.decode(AppSnapshot.self, from: data) else {
            throw CloudSyncError.cloudSnapshotUnreadable
        }
        do {
            snapshot = try MaintenanceService.migrate(snapshot).snapshot
        } catch DataMigrationError.unsupportedFutureVersion(let version) {
            throw CloudSyncError.incompatibleDataSchema(version)
        } catch DataMigrationError.unsupportedLegacyVersion(let version) {
            throw CloudSyncError.incompatibleDataSchema(version)
        } catch {
            throw CloudSyncError.cloudSnapshotUnreadable
        }

        let cloudSavedAt = record[Field.savedAt] as? Date
        if snapshot.snapshotSavedAt == nil { snapshot.snapshotSavedAt = cloudSavedAt }
        if snapshot.lastSynced == nil { snapshot.lastSynced = cloudSavedAt }

        let descriptors = try attachmentDescriptors(in: snapshot)
        return RemoteSnapshotEnvelope(
            snapshot: snapshot,
            attachmentRecordNames: Set(descriptors.map(\.recordName))
        )
    }

    private func restoreAttachments(
        _ descriptors: [AttachmentDescriptor],
        verifyRecordNames: Set<String>
    ) async throws -> Int {
        var missing: [String] = []
        var downloadedCount = 0

        for descriptor in descriptors {
            let localExists = FileManager.default.fileExists(atPath: descriptor.localURL.path)
            let localReadable = localExists && AttachmentContentPolicy.isReadableImage(at: descriptor.localURL)
            let shouldVerifyRemote = verifyRecordNames.contains(descriptor.recordName)
            if localReadable && !shouldVerifyRemote {
                try enforceDataProtection(at: descriptor.localURL)
                continue
            }

            let recordID = CKRecord.ID(recordName: descriptor.recordName, zoneID: zoneID)
            guard let attachmentRecord = try await fetchRecordIfExists(recordID) else {
                if !localReadable { missing.append(descriptor.filename) }
                continue
            }

            let remoteFilename = attachmentRecord[Field.filename] as? String
            let remoteKind = attachmentRecord[Field.kind] as? String
            guard remoteFilename == descriptor.filename, remoteKind == descriptor.kind.rawValue else {
                throw CloudSyncError.invalidAttachmentMetadata(descriptor.filename)
            }
            guard let asset = attachmentRecord[Field.file] as? CKAsset, let assetURL = asset.fileURL else {
                if !localReadable { missing.append(descriptor.filename) }
                continue
            }

            let data = try Data(contentsOf: assetURL)
            guard AttachmentContentPolicy.isReadableImageData(data) else {
                throw CloudSyncError.invalidAttachmentMetadata(descriptor.filename)
            }
            let expectedHash = attachmentRecord[Field.sha256] as? String
            let downloadedHash = sha256(data)
            if let expectedHash, expectedHash != downloadedHash {
                throw CloudSyncError.invalidAttachmentMetadata(descriptor.filename)
            }

            let localHash = sha256IfPresent(descriptor.localURL)
            if localReadable,
               let localHash,
               localHash != downloadedHash {
                // Attachment filenames are immutable identities. Two readable
                // payloads with the same identity are a conflict, not permission
                // to silently overwrite whichever copy happens to sync first.
                throw CloudSyncError.attachmentContentConflict(descriptor.filename)
            }
            if localHash != downloadedHash {
                try FileManager.default.createDirectory(at: descriptor.localURL.deletingLastPathComponent(), withIntermediateDirectories: true)
                try data.write(to: descriptor.localURL, options: [.atomic, .completeFileProtectionUntilFirstUserAuthentication])
                downloadedCount += 1
            } else if localReadable {
                try enforceDataProtection(at: descriptor.localURL)
            }
        }

        if !missing.isEmpty {
            throw CloudSyncError.incompleteCloudAttachments(missing.sorted())
        }
        return downloadedCount
    }

    private func enforceDataProtection(at url: URL) throws {
        try FileManager.default.setAttributes(
            [.protectionKey: FileProtectionType.completeUntilFirstUserAuthentication],
            ofItemAtPath: url.path
        )
    }

    private func uploadSnapshot(
        _ snapshot: AppSnapshot,
        savedAt: Date,
        preparedPayloadURL: URL? = nil
    ) async throws {
        let temporaryURL: URL
        let ownsTemporaryURL: Bool
        if let preparedPayloadURL {
            temporaryURL = preparedPayloadURL
            ownsTemporaryURL = false
        } else {
            let temporaryDirectory = FileManager.default.temporaryDirectory.appendingPathComponent("iWorkOrderCloudKit", isDirectory: true)
            try FileManager.default.createDirectory(at: temporaryDirectory, withIntermediateDirectories: true)
            temporaryURL = temporaryDirectory.appendingPathComponent("snapshot-\(UUID().uuidString).json")
            let data = try JSONEncoder.pretty.encode(snapshot)
            try data.write(to: temporaryURL, options: [.atomic, .completeFileProtectionUntilFirstUserAuthentication])
            ownsTemporaryURL = true
        }
        defer {
            if ownsTemporaryURL {
                try? FileManager.default.removeItem(at: temporaryURL)
            }
        }

        let record = try await fetchRecordIfExists(snapshotRecordID) ?? CKRecord(recordType: RecordType.snapshot, recordID: snapshotRecordID)
        record[Field.payload] = CKAsset(fileURL: temporaryURL)
        record[Field.savedAt] = savedAt as CKRecordValue
        record[Field.schemaVersion] = NSNumber(value: AppDataSchema.currentVersion)
        record[Field.deviceID] = (snapshot.deviceID ?? DeviceIdentity.current) as NSString
        record[Field.saveRevision] = NSNumber(value: snapshot.saveRevision ?? 0)

        do {
            _ = try await database.save(record)
        } catch {
            throw mappedError(error)
        }
    }

    private func prepareCloudReplacement(_ snapshot: AppSnapshot) throws -> PreparedCloudReplacement {
        let directory = FileManager.default.temporaryDirectory
            .appendingPathComponent("iWorkOrderCloudReplacement-\(UUID().uuidString)", isDirectory: true)
        try FileManager.default.createDirectory(at: directory, withIntermediateDirectories: true)

        do {
            let snapshotURL = directory.appendingPathComponent("snapshot.json", isDirectory: false)
            let snapshotData = try JSONEncoder.pretty.encode(snapshot)
            try snapshotData.write(
                to: snapshotURL,
                options: [.atomic, .completeFileProtectionUntilFirstUserAuthentication]
            )

            let descriptors = try attachmentDescriptors(in: snapshot)
            var preparedAttachments: [PreparedReplacementAttachment] = []
            preparedAttachments.reserveCapacity(descriptors.count)

            for descriptor in descriptors {
                guard FileManager.default.fileExists(atPath: descriptor.localURL.path) else {
                    throw CloudSyncError.missingLocalAttachments([descriptor.filename])
                }
                let data = try Data(contentsOf: descriptor.localURL)
                guard AttachmentContentPolicy.isReadableImageData(data) else {
                    throw CloudSyncError.invalidAttachmentMetadata(descriptor.filename)
                }

                let stagedURL = directory.appendingPathComponent(descriptor.recordName, isDirectory: false)
                try data.write(
                    to: stagedURL,
                    options: [.atomic, .completeFileProtectionUntilFirstUserAuthentication]
                )
                preparedAttachments.append(PreparedReplacementAttachment(
                    descriptor: descriptor,
                    stagedURL: stagedURL,
                    sha256: sha256(data),
                    byteCount: data.count,
                    modifiedAt: fileModificationDate(descriptor.localURL)
                ))
            }

            return PreparedCloudReplacement(
                directory: directory,
                snapshotURL: snapshotURL,
                attachments: preparedAttachments
            )
        } catch {
            try? FileManager.default.removeItem(at: directory)
            throw error
        }
    }

    private func uploadPreparedAttachments(_ attachments: [PreparedReplacementAttachment]) async throws -> Int {
        var uploadedCount = 0
        for prepared in attachments {
            let descriptor = prepared.descriptor
            let recordID = CKRecord.ID(recordName: descriptor.recordName, zoneID: zoneID)
            let record = CKRecord(recordType: RecordType.attachment, recordID: recordID)
            record[Field.file] = CKAsset(fileURL: prepared.stagedURL)
            record[Field.filename] = descriptor.filename as NSString
            record[Field.kind] = descriptor.kind.rawValue as NSString
            record[Field.sha256] = prepared.sha256 as NSString
            record[Field.byteCount] = NSNumber(value: prepared.byteCount)
            record[Field.modifiedAt] = prepared.modifiedAt as CKRecordValue

            do {
                _ = try await database.save(record)
                uploadedCount += 1
            } catch {
                throw mappedError(error)
            }
        }
        return uploadedCount
    }

    private func uploadAttachments(_ descriptors: [AttachmentDescriptor]) async throws -> Int {
        let missing = descriptors.filter { !FileManager.default.fileExists(atPath: $0.localURL.path) }.map(\.filename)
        guard missing.isEmpty else { throw CloudSyncError.missingLocalAttachments(missing.sorted()) }

        var uploadedCount = 0
        for descriptor in descriptors {
            let data = try Data(contentsOf: descriptor.localURL)
            guard AttachmentContentPolicy.isReadableImageData(data) else {
                throw CloudSyncError.invalidAttachmentMetadata(descriptor.filename)
            }
            let digest = sha256(data)
            let recordID = CKRecord.ID(recordName: descriptor.recordName, zoneID: zoneID)
            let record = try await fetchRecordIfExists(recordID) ?? CKRecord(recordType: RecordType.attachment, recordID: recordID)
            let existingHash = record[Field.sha256] as? String
            let existingByteCount = (record[Field.byteCount] as? NSNumber)?.intValue
            if existingHash == digest && existingByteCount == data.count { continue }

            record[Field.file] = CKAsset(fileURL: descriptor.localURL)
            record[Field.filename] = descriptor.filename as NSString
            record[Field.kind] = descriptor.kind.rawValue as NSString
            record[Field.sha256] = digest as NSString
            record[Field.byteCount] = NSNumber(value: data.count)
            record[Field.modifiedAt] = fileModificationDate(descriptor.localURL) as CKRecordValue

            do {
                _ = try await database.save(record)
                uploadedCount += 1
            } catch {
                throw mappedError(error)
            }
        }
        return uploadedCount
    }

    private func attachmentRecordNamesInZone(fallback: Set<String>) async -> Set<String> {
        do {
            let query = CKQuery(recordType: RecordType.attachment, predicate: NSPredicate(value: true))
            var page = try await database.records(
                matching: query,
                inZoneWith: zoneID,
                desiredKeys: [],
                resultsLimit: CKQueryOperation.maximumResults
            )
            var names = Set(page.matchResults.map { $0.0.recordName })

            while let cursor = page.queryCursor {
                page = try await database.records(
                    continuingMatchFrom: cursor,
                    desiredKeys: [],
                    resultsLimit: CKQueryOperation.maximumResults
                )
                names.formUnion(page.matchResults.map { $0.0.recordName })
            }
            return names
        } catch {
            // Query indexes and account/network state can make inventory
            // temporarily unavailable. Snapshot-derived names are still safe
            // for the current sync, and a later sync will retry the full sweep.
            return fallback
        }
    }

    private func deleteAttachmentRecords(_ recordNames: Set<String>) async throws {
        for recordName in recordNames {
            try await deleteRecordIfPresent(CKRecord.ID(recordName: recordName, zoneID: zoneID))
        }
    }

    private func deleteRecordIfPresent(_ recordID: CKRecord.ID) async throws {
        do {
            _ = try await database.deleteRecord(withID: recordID)
        } catch let error as CKError where error.code == .unknownItem || error.code == .zoneNotFound {
            return
        } catch {
            throw mappedError(error)
        }
    }

    private func fetchRecordIfExists(_ recordID: CKRecord.ID) async throws -> CKRecord? {
        do {
            return try await database.record(for: recordID)
        } catch let error as CKError where error.code == .unknownItem || error.code == .zoneNotFound {
            return nil
        } catch {
            throw mappedError(error)
        }
    }

    private func attachmentDescriptors(in snapshot: AppSnapshot) throws -> [AttachmentDescriptor] {
        var descriptors = Set<AttachmentDescriptor>()
        for order in snapshot.workOrders {
            for entry in order.entries {
                for image in entry.images {
                    guard isSafeFilename(image.filename) else {
                        throw CloudSyncError.invalidAttachmentMetadata(image.filename)
                    }
                    descriptors.insert(AttachmentDescriptor(filename: image.filename, kind: .image))
                }
                if let signature = entry.signatureFilename {
                    guard isSafeFilename(signature) else {
                        throw CloudSyncError.invalidAttachmentMetadata(signature)
                    }
                    descriptors.insert(AttachmentDescriptor(filename: signature, kind: .signature))
                }
            }
        }
        return descriptors.sorted {
            $0.kind.rawValue == $1.kind.rawValue ? $0.filename < $1.filename : $0.kind.rawValue < $1.kind.rawValue
        }
    }

    private func isSafeFilename(_ filename: String) -> Bool {
        AttachmentFilenamePolicy.isSafe(filename)
    }

    private func fileModificationDate(_ url: URL) -> Date {
        let attributes = try? FileManager.default.attributesOfItem(atPath: url.path)
        return attributes?[.modificationDate] as? Date ?? Date()
    }

    private func sha256IfPresent(_ url: URL) -> String? {
        guard let data = try? Data(contentsOf: url) else { return nil }
        return sha256(data)
    }

    private func sha256(_ data: Data) -> String {
        SHA256.hash(data: data).map { String(format: "%02x", $0) }.joined()
    }

    nonisolated private func recordSuccessfulSync(_ date: Date) {
        UserDefaults.standard.set(date, forKey: Self.lastSuccessfulSyncKey)
    }

    nonisolated private func clearLegacySnapshot() {
        let store = NSUbiquitousKeyValueStore.default
        store.removeObject(forKey: Self.legacySnapshotKey)
        store.removeObject(forKey: Self.legacyLastSyncKey)
        store.synchronize()
    }

    private func mappedError(_ error: Error) -> CloudSyncError {
        if let cloudError = error as? CloudSyncError { return cloudError }
        guard let ckError = error as? CKError else {
            return .cloudKit("iCloud sync failed: \(error.localizedDescription)")
        }

        switch ckError.code {
        case .networkUnavailable, .networkFailure:
            return .noNetwork
        case .notAuthenticated:
            return .accountUnavailable
        case .permissionFailure:
            return .accountRestricted
        case .quotaExceeded:
            return .cloudKit("iCloud storage is full. Free iCloud space and try again. Your changes remain saved locally.")
        case .serviceUnavailable, .requestRateLimited, .zoneBusy:
            let retry = ckError.retryAfterSeconds.map { " Try again in about \(Int($0)) seconds." } ?? " Try again later."
            return .cloudKit("iCloud is temporarily unavailable.\(retry)")
        case .serverRecordChanged:
            return .cloudKit("The iCloud record changed on another device during sync. Run Sync Now again to merge the latest changes.")
        default:
            return .cloudKit("iCloud sync failed: \(ckError.localizedDescription)")
        }
    }
}
