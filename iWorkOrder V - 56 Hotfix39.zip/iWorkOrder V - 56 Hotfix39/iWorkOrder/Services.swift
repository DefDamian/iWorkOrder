import Foundation
import Combine
@preconcurrency import UserNotifications
@preconcurrency import LocalAuthentication
import UIKit
import ImageIO
import UniformTypeIdentifiers
import PDFKit
import CoreText
import AVFoundation
import MapKit

enum AttachmentFilenamePolicy {
    static func isSafe(_ filename: String) -> Bool {
        guard !filename.isEmpty, filename.utf8.count <= 255 else { return false }
        guard filename != ".", filename != ".." else { return false }
        guard filename == (filename as NSString).lastPathComponent else { return false }
        guard !filename.contains(".."), !filename.contains("/"), !filename.contains("\\") else { return false }
        return filename.rangeOfCharacter(from: .controlCharacters) == nil
    }
}

enum AttachmentContentPolicy {
    static func isReadableImageData(_ data: Data) -> Bool {
        guard !data.isEmpty,
              let source = CGImageSourceCreateWithData(data as CFData, nil) else {
            return false
        }
        return canDecodeImageSource(source)
    }

    static func isReadableImage(at url: URL) -> Bool {
        guard let source = CGImageSourceCreateWithURL(url as CFURL, nil) else {
            return false
        }
        return canDecodeImageSource(source)
    }

    private static func canDecodeImageSource(_ source: CGImageSource) -> Bool {
        guard CGImageSourceGetCount(source) > 0 else { return false }
        let options: [CFString: Any] = [
            kCGImageSourceCreateThumbnailFromImageAlways: true,
            kCGImageSourceCreateThumbnailWithTransform: true,
            kCGImageSourceShouldCacheImmediately: true,
            kCGImageSourceThumbnailMaxPixelSize: 16
        ]
        return CGImageSourceCreateThumbnailAtIndex(source, 0, options as CFDictionary) != nil
    }
}

enum DeviceIdentity {
    private static let key = "iWorkOrder.deviceID"
    static var current: String {
        if let existing = UserDefaults.standard.string(forKey: key) { return existing }
        let id = UUID().uuidString
        UserDefaults.standard.set(id, forKey: key)
        return id
    }

    static func reset() {
        UserDefaults.standard.removeObject(forKey: key)
    }
}

/// Checks the envelope before decoding any version-specific model values.
/// Unknown future enums must not make newer data look like a fresh install.
enum SnapshotFormatPolicy {
    static func validateSchema(in data: Data) throws {
        guard let root = try JSONSerialization.jsonObject(with: data) as? [String: Any] else {
            throw CocoaError(.coderReadCorrupt)
        }
        let version: Int
        if let raw = root["dataSchemaVersion"], !(raw is NSNull) {
            guard let number = raw as? NSNumber,
                  String(cString: number.objCType) != "c",
                  number.doubleValue.isFinite,
                  number.doubleValue.rounded(.towardZero) == number.doubleValue,
                  let integer = Int(number.stringValue) else {
                throw CocoaError(.coderReadCorrupt)
            }
            version = integer
        } else {
            version = AppDataSchema.oldestSupportedVersion
        }
        guard version <= AppDataSchema.currentVersion else {
            throw DataMigrationError.unsupportedFutureVersion(version)
        }
        guard version >= AppDataSchema.oldestSupportedVersion else {
            throw DataMigrationError.unsupportedLegacyVersion(version)
        }
    }

    /// Migration may fill missing legacy fields, but must never silently discard
    /// a malformed array, profile, revision, image list, or audit trail.
    static func validateLegacyStructure(in data: Data) throws {
        guard let root = try JSONSerialization.jsonObject(with: data) as? [String: Any],
              root["profile"] is [String: Any],
              let orders = root["workOrders"] as? [[String: Any]] else {
            throw CocoaError(.coderReadCorrupt)
        }
        func dictionaries(_ value: Any?) throws -> [[String: Any]]? {
            guard let value, !(value is NSNull) else { return nil }
            guard let array = value as? [[String: Any]] else { throw CocoaError(.coderReadCorrupt) }
            return array
        }
        _ = try dictionaries(root["assets"])
        _ = try dictionaries(root["tenants"])
        for order in orders {
            _ = try dictionaries(order["auditLog"])
            _ = try dictionaries(order["statusEntries"])
            if let rawEntries = order["entries"] {
                guard !(rawEntries is NSNull), let entries = try dictionaries(rawEntries) else {
                    throw CocoaError(.coderReadCorrupt)
                }
                for entry in entries {
                    if let images = entry["images"] {
                        guard !(images is NSNull) else { throw CocoaError(.coderReadCorrupt) }
                        _ = try dictionaries(images)
                    }
                }
            } else {
                // The supported flat legacy representation has descriptive
                // work-order fields. An unrelated JSON object is not a backup.
                guard order["area"] is String, order["issueDescription"] is String else {
                    throw CocoaError(.coderReadCorrupt)
                }
                _ = try dictionaries(order["images"])
            }
        }
    }
}

final class StorageService {
    private static let revisionKey = "iWorkOrder.saveRevision"
    static var documentDirectory: URL { FileManager.default.urls(for: .documentDirectory, in: .userDomainMask)[0] }
    static var primarySnapshotURL: URL { documentDirectory.appendingPathComponent("iworkorder-data.json") }
    static var fallbackSnapshotURL: URL { documentDirectory.appendingPathComponent("iworkorder-data.backup.json") }

    private(set) var compatibilityBlockMessage: String?
    private(set) var recoveryNotice: String?

    private let directory: URL
    private var url: URL { directory.appendingPathComponent("iworkorder-data.json") }
    private var backupURL: URL { directory.appendingPathComponent("iworkorder-data.backup.json") }

    init(directory: URL = StorageService.documentDirectory) {
        self.directory = directory
    }

    func load() -> AppSnapshot? {
        compatibilityBlockMessage = nil
        recoveryNotice = nil
        let startedAt = Date()

        if let snapshot = decode(url) {
            return migrateIfNeeded(snapshot, sourceURL: url, startedAt: startedAt)
        }
        // Incompatible data remains in place. Never fall back to an older
        // snapshot just because this app cannot decode a newer model value.
        guard compatibilityBlockMessage == nil else { return nil }
        let primaryWasPresent = FileManager.default.fileExists(atPath: url.path)
        let fallbackWasPresent = FileManager.default.fileExists(atPath: backupURL.path)
        if let snapshot = decode(backupURL) {
            if primaryWasPresent { quarantineUnreadablePrimary() }
            recoveryNotice = "The primary local data file was unreadable. iWorkOrder recovered the fallback snapshot and rebuilt protected local storage."
            guard let migrated = migrateIfNeeded(snapshot, sourceURL: backupURL, startedAt: startedAt) else { return nil }
            guard save(migrated, rotatePrimaryIntoFallback: false) else {
                compatibilityBlockMessage = "The fallback snapshot was readable, but protected local storage could not be rebuilt. Do not erase the app. Free storage and try again."
                MaintenanceService.record(kind: .localRecovery, outcome: .failure)
                return nil
            }
            MaintenanceService.record(kind: .localRecovery, outcome: .success, itemCount: migrated.workOrders.count)
            return migrated
        }

        guard compatibilityBlockMessage == nil else { return nil }
        let quarantineDirectory = MaintenanceService.maintenanceDirectory
            .appendingPathComponent("UnreadableSnapshots", isDirectory: true)
        let quarantinedFiles = (try? FileManager.default.contentsOfDirectory(
            at: quarantineDirectory, includingPropertiesForKeys: nil
        )) ?? []
        let evidenceWithoutSnapshot = ["WorkOrderImages", "WorkOrderSignatures"].contains { name in
            let evidenceDirectory = directory.appendingPathComponent(name, isDirectory: true)
            guard FileManager.default.fileExists(atPath: evidenceDirectory.path) else { return false }
            guard let files = try? FileManager.default.contentsOfDirectory(
                at: evidenceDirectory, includingPropertiesForKeys: nil, options: [.skipsHiddenFiles]
            ) else { return true }
            return !files.isEmpty
        }
        if primaryWasPresent || fallbackWasPresent || evidenceWithoutSnapshot || quarantinedFiles.contains(where: { $0.pathExtension == "json" }) {
            compatibilityBlockMessage = "Saved data could not be read safely. No records or attachments were erased. Unlock the device and restart iWorkOrder. If the problem continues, keep the app installed and contact support."
            MaintenanceService.record(kind: .localLoad, outcome: .blocked)
            return nil
        }
        let duration = Int(Date().timeIntervalSince(startedAt) * 1000)
        MaintenanceService.record(kind: .localLoad, outcome: .success, durationMilliseconds: duration, itemCount: 0)
        return nil
    }

    private func decode(_ url: URL) -> AppSnapshot? {
        guard let data = try? Data(contentsOf: url) else { return nil }
        do {
            try SnapshotFormatPolicy.validateSchema(in: data)
            return try JSONDecoder.iso8601.decode(AppSnapshot.self, from: data)
        } catch let error as DataMigrationError {
            compatibilityBlockMessage = error.errorDescription
            return nil
        } catch {
            return nil
        }
    }

    private func migrateIfNeeded(_ snapshot: AppSnapshot, sourceURL: URL, startedAt: Date) -> AppSnapshot? {
        do {
            let migration = try MaintenanceService.migrate(snapshot)
            if migration.changed {
                _ = try MaintenanceService.createMigrationBackup(
                    sourceURL: sourceURL,
                    sourceVersion: migration.sourceVersion,
                    targetVersion: migration.targetVersion
                )
                let recoveringFromFallback = sourceURL.standardizedFileURL == backupURL.standardizedFileURL
                guard save(migration.snapshot, rotatePrimaryIntoFallback: !recoveringFromFallback) else {
                    compatibilityBlockMessage = "The data migration was prepared, but the migrated snapshot could not be saved. The original recovery copy was preserved."
                    MaintenanceService.record(kind: .dataMigration, outcome: .failure)
                    return nil
                }
                MaintenanceService.record(kind: .dataMigration, outcome: .success, itemCount: migration.snapshot.workOrders.count)
            }
            let duration = Int(Date().timeIntervalSince(startedAt) * 1000)
            MaintenanceService.record(kind: .localLoad, outcome: .success, durationMilliseconds: duration, itemCount: migration.snapshot.workOrders.count)
            return migration.snapshot
        } catch {
            compatibilityBlockMessage = (error as? LocalizedError)?.errorDescription ?? error.localizedDescription
            MaintenanceService.record(kind: .dataMigration, outcome: .blocked)
            return nil
        }
    }

    private func quarantineUnreadablePrimary() {
        let directory = MaintenanceService.maintenanceDirectory.appendingPathComponent("UnreadableSnapshots", isDirectory: true)
        do {
            try FileManager.default.createDirectory(at: directory, withIntermediateDirectories: true)
            let destination = directory.appendingPathComponent(
                "unreadable-primary-\(Int(Date().timeIntervalSince1970))-\(UUID().uuidString).json"
            )
            try FileManager.default.moveItem(at: url, to: destination)
        } catch {
            // Preserve the unreadable primary if quarantine itself fails. The
            // fallback recovery path writes atomically without rotating this
            // file over the known-good fallback copy.
        }
    }

    static func currentSaveRevision() -> Int {
        UserDefaults.standard.integer(forKey: revisionKey)
    }

    static func nextSaveRevisionCandidate() -> Int {
        currentSaveRevision() + 1
    }

    static func commitSaveRevision(_ revision: Int) {
        guard revision > currentSaveRevision() else { return }
        UserDefaults.standard.set(revision, forKey: revisionKey)
    }

    static func resetSaveRevision() {
        UserDefaults.standard.removeObject(forKey: revisionKey)
    }

    @discardableResult
    func save(_ snapshot: AppSnapshot, rotatePrimaryIntoFallback: Bool = true) -> Bool {
        guard let data = try? JSONEncoder.pretty.encode(snapshot) else { return false }
        do {
            try FileManager.default.createDirectory(at: directory, withIntermediateDirectories: true)
            if rotatePrimaryIntoFallback && FileManager.default.fileExists(atPath: url.path) {
                try rotatePrimarySnapshotIntoFallback()
            }
            try data.write(to: url, options: [.atomic, .completeFileProtectionUntilFirstUserAuthentication])
            return true
        } catch {
            return false
        }
    }

    private func rotatePrimarySnapshotIntoFallback() throws {
        let manager = FileManager.default
        let stagedBackup = directory.appendingPathComponent(
            ".iworkorder-data.backup-\(UUID().uuidString).tmp"
        )
        defer { try? manager.removeItem(at: stagedBackup) }

        try manager.copyItem(at: url, to: stagedBackup)
        if manager.fileExists(atPath: backupURL.path) {
            _ = try manager.replaceItemAt(backupURL, withItemAt: stagedBackup)
        } else {
            try manager.moveItem(at: stagedBackup, to: backupURL)
        }
    }

    func localDataSizeText() -> String {
        let paths = [
            url,
            backupURL,
            ImageStorageService.imageDirectory,
            SignatureStorageService.signatureDirectory,
            BackupArchiveService.safetyBackupDirectory,
            BackupArchiveService.restoreTransactionDirectory,
            MaintenanceService.maintenanceDirectory
        ]
        let total = paths.reduce(Int64(0)) { partial, item in
            partial + StorageService.sizeOfItem(at: item)
        }
        return ByteCountFormatter.string(fromByteCount: total, countStyle: .file)
    }

    private static func sizeOfItem(at url: URL) -> Int64 {
        var total: Int64 = 0
        if let attrs = try? FileManager.default.attributesOfItem(atPath: url.path), let size = attrs[.size] as? NSNumber { total += size.int64Value }
        if let enumerator = FileManager.default.enumerator(at: url, includingPropertiesForKeys: [.fileSizeKey], options: []) {
            for case let fileURL as URL in enumerator {
                if let size = try? fileURL.resourceValues(forKeys: [.fileSizeKey]).fileSize { total += Int64(size) }
            }
        }
        return total
    }

    @discardableResult
    func deleteAll() -> Bool {
        let manager = FileManager.default
        let targets = [
            url,
            backupURL,
            ImageStorageService.imageDirectory,
            SignatureStorageService.signatureDirectory,
            BackupArchiveService.safetyBackupDirectory,
            BackupArchiveService.restoreTransactionDirectory
        ]
        var succeeded = true
        for target in targets where manager.fileExists(atPath: target.path) {
            do {
                try manager.removeItem(at: target)
            } catch {
                succeeded = false
            }
        }
        if !MaintenanceService.deleteAll() {
            succeeded = false
        }
        if !BackupArchiveService.deleteTemporaryData() {
            succeeded = false
        }
        if !AppTemporaryDataService.deleteAll() {
            succeeded = false
        }
        // Do not report success merely because removeItem returned. Verify that
        // every protected data location is actually gone before cloud erase is
        // allowed to clear its pending marker.
        if targets.contains(where: { manager.fileExists(atPath: $0.path) }) {
            succeeded = false
        }
        return succeeded
    }
}

enum AppTemporaryDataService {
    /// Removes app-owned temporary artifacts that may contain work-order data.
    /// The app temp directory is private to iWorkOrder, but deletion is limited
    /// to names this app creates so unrelated framework temporary files remain.
    @discardableResult
    static func deleteAll() -> Bool {
        let manager = FileManager.default
        let root = manager.temporaryDirectory
        let exactNames: Set<String> = [
            "iWorkOrderCloudKit",
            "iWorkOrderSupportBundles",
            "iWorkOrderDiagnostics",
            "iWorkOrderPDFExports"
        ]
        let directoryPrefixes = [
            "iWorkOrderCloudReplacement-",
            "iWorkOrderBackupBuild-"
        ]
        let legacyPDFPrefixes = [
            "iWorkOrder_",
            "Work_Order_"
        ]

        guard let items = try? manager.contentsOfDirectory(
            at: root,
            includingPropertiesForKeys: [.isDirectoryKey, .isRegularFileKey],
            options: [.skipsHiddenFiles]
        ) else {
            return false
        }

        let targets = items.filter { item in
            let name = item.lastPathComponent
            if exactNames.contains(name) { return true }
            if directoryPrefixes.contains(where: { name.hasPrefix($0) }) { return true }
            if item.pathExtension.lowercased() == "pdf",
               legacyPDFPrefixes.contains(where: { name.hasPrefix($0) }) {
                return true
            }
            return false
        }

        var succeeded = true
        for target in targets where manager.fileExists(atPath: target.path) {
            do {
                try manager.removeItem(at: target)
            } catch {
                succeeded = false
            }
        }
        if targets.contains(where: { manager.fileExists(atPath: $0.path) }) {
            succeeded = false
        }
        return succeeded
    }
}

final class OnboardingPersistenceService {
    private let completedKey = "iWorkOrder.onboarding.completed"
    private let completedDateKey = "iWorkOrder.onboarding.completedDate"
    private let completedLegalVersionKey = "iWorkOrder.onboarding.legalVersion"

    var hasCompletedOnboarding: Bool {
        UserDefaults.standard.bool(forKey: completedKey) ||
            NSUbiquitousKeyValueStore.default.bool(forKey: completedKey)
    }

    var completedOnboardingDate: Date? {
        if let local = UserDefaults.standard.object(forKey: completedDateKey) as? Date { return local }
        if let cloud = NSUbiquitousKeyValueStore.default.object(forKey: completedDateKey) as? Date { return cloud }
        return nil
    }

    var completedLegalVersion: String? {
        UserDefaults.standard.string(forKey: completedLegalVersionKey) ??
            NSUbiquitousKeyValueStore.default.string(forKey: completedLegalVersionKey)
    }

    func markCompleted(date: Date, legalVersion: String?) {
        UserDefaults.standard.set(true, forKey: completedKey)
        UserDefaults.standard.set(date, forKey: completedDateKey)
        if let legalVersion {
            UserDefaults.standard.set(legalVersion, forKey: completedLegalVersionKey)
        } else {
            UserDefaults.standard.removeObject(forKey: completedLegalVersionKey)
        }

        NSUbiquitousKeyValueStore.default.set(true, forKey: completedKey)
        NSUbiquitousKeyValueStore.default.set(date, forKey: completedDateKey)
        if let legalVersion {
            NSUbiquitousKeyValueStore.default.set(legalVersion, forKey: completedLegalVersionKey)
        } else {
            NSUbiquitousKeyValueStore.default.removeObject(forKey: completedLegalVersionKey)
        }
        NSUbiquitousKeyValueStore.default.synchronize()
    }

    func clearCompletedFlag() {
        UserDefaults.standard.removeObject(forKey: completedKey)
        UserDefaults.standard.removeObject(forKey: completedDateKey)
        UserDefaults.standard.removeObject(forKey: completedLegalVersionKey)
        NSUbiquitousKeyValueStore.default.removeObject(forKey: completedKey)
        NSUbiquitousKeyValueStore.default.removeObject(forKey: completedDateKey)
        NSUbiquitousKeyValueStore.default.removeObject(forKey: completedLegalVersionKey)
        NSUbiquitousKeyValueStore.default.synchronize()
    }
}

final class PermissionSetupPersistenceService {
    private let completedKey = "iWorkOrder.permissions.reviewed.v1"
    private let completedDateKey = "iWorkOrder.permissions.reviewedDate.v1"

    var hasCompletedReview: Bool {
        UserDefaults.standard.bool(forKey: completedKey)
    }

    var completedReviewDate: Date? {
        UserDefaults.standard.object(forKey: completedDateKey) as? Date
    }

    func markCompleted(date: Date = Date()) {
        // Permission grants are device-local, so this completion marker must not
        // sync through iCloud or a portable backup. A reinstall/new device gets
        // a fresh review of the permissions that apply to that device.
        UserDefaults.standard.set(true, forKey: completedKey)
        UserDefaults.standard.set(date, forKey: completedDateKey)
    }

    func clearCompletedReview() {
        UserDefaults.standard.removeObject(forKey: completedKey)
        UserDefaults.standard.removeObject(forKey: completedDateKey)
    }
}

extension JSONEncoder {
    static var pretty: JSONEncoder {
        let encoder = JSONEncoder()
        encoder.outputFormatting = [.prettyPrinted, .sortedKeys]
        // Keep millisecond precision for rapid revisions, profile freshness,
        // and interrupted-restore fingerprints. The decoder also accepts older
        // second-only ISO-8601 values, so existing saved data remains readable.
        encoder.dateEncodingStrategy = .custom { date, encoder in
            let formatter = ISO8601DateFormatter()
            formatter.formatOptions = [.withInternetDateTime, .withFractionalSeconds]
            var container = encoder.singleValueContainer()
            try container.encode(formatter.string(from: date))
        }
        return encoder
    }
}

/// Persist the encoding identity with a restore journal. Otherwise changing
/// date precision would make an older, successfully saved restore look uncommitted.
enum SnapshotFingerprintEncoding {
    static let currentVersion = 2

    static func encode<T: Encodable>(_ snapshot: T, version: Int?) throws -> Data {
        switch version ?? 1 {
        case 1:
            let encoder = JSONEncoder()
            encoder.outputFormatting = [.prettyPrinted, .sortedKeys]
            encoder.dateEncodingStrategy = .iso8601
            return try encoder.encode(snapshot)
        case currentVersion:
            return try JSONEncoder.pretty.encode(snapshot)
        default:
            throw CocoaError(.coderReadCorrupt)
        }
    }
}

extension JSONDecoder {
    static var iso8601: JSONDecoder {
        let decoder = JSONDecoder()
        decoder.dateDecodingStrategy = .custom { decoder in
            let container = try decoder.singleValueContainer()
            let value = try container.decode(String.self)
            let iso = ISO8601DateFormatter()
            iso.formatOptions = [.withInternetDateTime, .withFractionalSeconds]
            if let date = iso.date(from: value) { return date }
            iso.formatOptions = [.withInternetDateTime]
            if let date = iso.date(from: value) { return date }
            throw DecodingError.dataCorruptedError(in: container, debugDescription: "Invalid date string: \(value)")
        }
        return decoder
    }
}

@MainActor
final class AddressVerifier: ObservableObject {
    @Published var status = "Not verified"
    @Published var isVerified = false
    @Published var formattedAddress = ""
    @Published var isChecking = false
    private var verificationGeneration = 0
    private var requestedAddress = ""
    private var cancelActiveLookup: (() -> Void)?

    private enum AddressVerificationResult: Sendable {
        case notFound
        case partialMatch
        case verified(String)
    }

    func resetIfNeeded(for address: String) {
        let current = address.trimmingCharacters(in: .whitespacesAndNewlines)
        let expectedAddress = isChecking ? requestedAddress : formattedAddress
        guard isChecking || isVerified, current != expectedAddress else { return }
        verificationGeneration += 1
        cancelCurrentLookup()
        isChecking = false
        isVerified = false
        requestedAddress = ""
        formattedAddress = ""
        status = "Address changed. Verify again."
    }

    func verify(_ address: String, completion: (@MainActor @Sendable (String) -> Void)? = nil) {
        verificationGeneration += 1
        let generation = verificationGeneration
        let cleanAddress = address.trimmingCharacters(in: .whitespacesAndNewlines)
        requestedAddress = cleanAddress
        cancelCurrentLookup()

        guard cleanAddress.count > 8 else {
            status = "Enter a complete building address."
            isVerified = false
            formattedAddress = ""
            isChecking = false
            return
        }

        status = "Checking Apple Maps..."
        isVerified = false
        formattedAddress = ""
        isChecking = true

        startLookup(cleanAddress, generation: generation, completion: completion)
    }

    private func cancelCurrentLookup() {
        cancelActiveLookup?()
        cancelActiveLookup = nil
    }

    private func startLookup(
        _ cleanAddress: String,
        generation: Int,
        completion: (@MainActor @Sendable (String) -> Void)?
    ) {
        guard let request = MKGeocodingRequest(addressString: cleanAddress) else {
            apply(.notFound, generation: generation, completion: completion)
            return
        }

        cancelActiveLookup = { request.cancel() }
        request.getMapItems { [weak self, completion] mapItems, error in
            let result: AddressVerificationResult
            if error != nil || mapItems?.first == nil {
                result = .notFound
            } else if let mapItem = mapItems?.first,
                      let representations = mapItem.addressRepresentations {
                let formatted = representations
                    .fullAddress(includingRegion: true, singleLine: true)?
                    .trimmingCharacters(in: .whitespacesAndNewlines) ?? ""
                let city = representations.cityName?.trimmingCharacters(in: .whitespacesAndNewlines) ?? ""
                result = !formatted.isEmpty && !city.isEmpty ? .verified(formatted) : .partialMatch
            } else {
                result = .partialMatch
            }

            Task { @MainActor [weak self, completion, result] in
                self?.apply(result, generation: generation, completion: completion)
            }
        }
    }

    private func apply(
        _ result: AddressVerificationResult,
        generation: Int,
        completion: (@MainActor @Sendable (String) -> Void)?
    ) {
        guard generation == verificationGeneration else { return }
        cancelActiveLookup = nil
        isChecking = false
        switch result {
        case .notFound:
            status = "Address not found by Apple Maps."
        case .partialMatch:
            status = "Apple Maps found only a partial match. Enter full street, city, state, and ZIP."
        case .verified(let formatted):
            formattedAddress = formatted
            status = "Verified by Apple Maps"
            isVerified = true
            completion?(formatted)
        }
    }


}

enum WorkOrderNotificationIdentifier {
    static let reminderPrefix = "iworkorder.reminder."
    static let emergencyPrefix = "iworkorder.emergency."

    static func reminder(orderID: UUID) -> String {
        reminderPrefix + orderID.uuidString
    }

    static func emergency(orderID: UUID, entryID: UUID) -> String {
        emergencyPrefix + orderID.uuidString + "." + entryID.uuidString
    }

    static func legacy(orderID: UUID) -> String {
        orderID.uuidString
    }

    static func workOrderID(from identifier: String) -> UUID? {
        if let legacy = UUID(uuidString: identifier) {
            return legacy
        }
        if identifier.hasPrefix(reminderPrefix) {
            return UUID(uuidString: String(identifier.dropFirst(reminderPrefix.count)))
        }
        if identifier.hasPrefix(emergencyPrefix) {
            let suffix = identifier.dropFirst(emergencyPrefix.count)
            guard let first = suffix.split(separator: ".", maxSplits: 1).first else { return nil }
            return UUID(uuidString: String(first))
        }
        return nil
    }
}


enum WorkOrderNotificationPolicy {
    static func reminderDate(for order: WorkOrder, now: Date = Date()) -> Date? {
        guard order.latestEntry.reminderEnabled, order.latestEntry.reminderDate > now else { return nil }
        return order.latestEntry.reminderDate
    }

    static func emergencyFollowUpDate(
        for order: WorkOrder,
        enabled: Bool,
        now: Date = Date()
    ) -> Date? {
        guard enabled else { return nil }
        let date = order.latestEntry.createdAt.addingTimeInterval(10)
        return date > now ? date : nil
    }
}

@MainActor
final class NotificationService: NSObject, UNUserNotificationCenterDelegate {
    static let shared = NotificationService()
    private let center = UNUserNotificationCenter.current()
    private var pendingWorkOrderID: UUID?
    private var reconciliationGeneration = 0
    private var notificationMutationTask: Task<Void, Never>?
    var schedulingError: (@MainActor @Sendable (String) -> Void)?
    var openWorkOrder: (@MainActor @Sendable (UUID) -> Void)? {
        didSet {
            if let pendingID = pendingWorkOrderID {
                pendingWorkOrderID = nil
                openWorkOrder?(pendingID)
            }
        }
    }

    override init() { super.init(); configure() }

    func configure() {
        center.delegate = self
    }

    func clearPendingRoute() {
        pendingWorkOrderID = nil
    }

    func route(url: URL) {
        guard url.scheme?.lowercased() == "iworkorder" else { return }
        let idString: String?
        if url.host?.lowercased() == "workorder" {
            idString = url.pathComponents.dropFirst().first
        } else {
            idString = URLComponents(url: url, resolvingAgainstBaseURL: false)?
                .queryItems?
                .first(where: { $0.name.caseInsensitiveCompare("workOrderID") == .orderedSame })?
                .value
        }
        if let raw = idString, let id = UUID(uuidString: raw) {
            dispatchOrQueue(workOrderID: id)
        }
    }

    private func dispatchOrQueue(workOrderID: UUID) {
        guard let handler = openWorkOrder else {
            pendingWorkOrderID = workOrderID
            return
        }
        handler(workOrderID)
    }

    func authorizationStatus() async -> UNAuthorizationStatus {
        await center.notificationSettings().authorizationStatus
    }

    func requestPermission() async -> Bool {
        (try? await center.requestAuthorization(options: [.alert, .badge, .sound])) ?? false
    }

    private func scheduleRequest(
        identifier: String,
        order: WorkOrder,
        date: Date,
        title: String
    ) async {
        let generation = reconciliationGeneration
        guard date > Date() else { return }
        let content = UNMutableNotificationContent()
        content.title = title
        content.body = "\(order.latestEntry.area): \(order.title)"
        content.sound = .default
        content.userInfo = [
            "workOrderID": order.id.uuidString,
            "deepLink": "iworkorder://workorder/\(order.id.uuidString)"
        ]
        let components = Calendar.current.dateComponents(
            [.calendar, .timeZone, .year, .month, .day, .hour, .minute, .second],
            from: date
        )
        let request = UNNotificationRequest(
            identifier: identifier,
            content: content,
            trigger: UNCalendarNotificationTrigger(dateMatching: components, repeats: false)
        )
        do {
            // Await completion before later remove/add operations. Otherwise a
            // late system add can recreate an alert after it was canceled.
            try await center.add(request)
        } catch {
            guard reconciliationGeneration == generation else { return }
            schedulingError?("iOS could not schedule a work-order reminder: \(error.localizedDescription)")
        }
    }

    /// Schedules the two notification channels independently. Explicit reminders
    /// follow the user-selected due time. Emergency follow-ups are tied to the
    /// current work-order revision and are never recreated from "now" after their
    /// original follow-up window has already passed.
    func scheduleReminder(for order: WorkOrder, emergencyFollowUp: Bool = false) async {
        let generation = reconciliationGeneration
        let now = Date()
        let reminderID = WorkOrderNotificationIdentifier.reminder(orderID: order.id)
        let legacyID = WorkOrderNotificationIdentifier.legacy(orderID: order.id)
        let emergencyID = WorkOrderNotificationIdentifier.emergency(
            orderID: order.id,
            entryID: order.latestEntry.id
        )

        // Remove the pre-Hotfix-21 identifier so an upgrade cannot deliver both
        // the legacy request and the new independently managed requests.
        center.removePendingNotificationRequests(withIdentifiers: [legacyID])
        center.removeDeliveredNotifications(withIdentifiers: [legacyID])

        if let reminderDate = WorkOrderNotificationPolicy.reminderDate(for: order, now: now) {
            await scheduleRequest(
                identifier: reminderID,
                order: order,
                date: reminderDate,
                title: order.latestEntry.priority == .emergency ? "Emergency Work Order Reminder" : "iWorkOrder Reminder"
            )
        } else {
            center.removePendingNotificationRequests(withIdentifiers: [reminderID])
            if !order.latestEntry.reminderEnabled {
                center.removeDeliveredNotifications(withIdentifiers: [reminderID])
            }
        }

        guard reconciliationGeneration == generation else { return }
        if let emergencyDate = WorkOrderNotificationPolicy.emergencyFollowUpDate(
            for: order,
            enabled: emergencyFollowUp,
            now: now
        ) {
            await scheduleRequest(
                identifier: emergencyID,
                order: order,
                date: emergencyDate,
                title: "Emergency Work Order"
            )
        } else {
            center.removePendingNotificationRequests(withIdentifiers: [emergencyID])
        }
    }

    private func enqueueNotificationMutation(
        generation: Int,
        operation: @escaping @MainActor @Sendable () async -> Void
    ) {
        let previousTask = notificationMutationTask
        notificationMutationTask = Task { @MainActor [weak self] in
            await previousTask?.value
            guard let self, self.reconciliationGeneration == generation else { return }
            await operation()
        }
    }

    func cancelAllNotifications() {
        reconciliationGeneration += 1
        let generation = reconciliationGeneration
        center.removeAllPendingNotificationRequests()
        center.removeAllDeliveredNotifications()
        clearPendingRoute()
        // Also clear after any system add already in progress has completed.
        enqueueNotificationMutation(generation: generation) { [weak self] in
            self?.center.removeAllPendingNotificationRequests()
            self?.center.removeAllDeliveredNotifications()
        }
    }

    func reconcile(
        orders: [WorkOrder],
        notificationsEnabled: Bool,
        emergencyNotificationsEnabled: Bool
    ) {
        reconciliationGeneration += 1
        let generation = reconciliationGeneration

        guard notificationsEnabled else {
            cancelAllNotifications()
            return
        }

        enqueueNotificationMutation(generation: generation) { [weak self] in
            guard let self else { return }
            let now = Date()
            let eligibleOrders = orders.filter { !$0.isDeleted && $0.status != .completed }
            var eligibleIdentifiers = Set<String>()

            for order in eligibleOrders {
                guard self.reconciliationGeneration == generation else { return }
                let reminderDate = WorkOrderNotificationPolicy.reminderDate(for: order, now: now)
                if reminderDate != nil {
                    eligibleIdentifiers.insert(WorkOrderNotificationIdentifier.reminder(orderID: order.id))
                }

                let emergencyFollowUp = order.latestEntry.priority == .emergency && emergencyNotificationsEnabled
                let emergencyDate = WorkOrderNotificationPolicy.emergencyFollowUpDate(
                    for: order,
                    enabled: emergencyFollowUp,
                    now: now
                )
                if emergencyDate != nil {
                    eligibleIdentifiers.insert(
                        WorkOrderNotificationIdentifier.emergency(orderID: order.id, entryID: order.latestEntry.id)
                    )
                }

                if reminderDate != nil || emergencyDate != nil {
                    await self.scheduleReminder(for: order, emergencyFollowUp: emergencyFollowUp)
                } else {
                    let reminderID = WorkOrderNotificationIdentifier.reminder(orderID: order.id)
                    self.center.removePendingNotificationRequests(withIdentifiers: [reminderID])
                }
            }

            guard self.reconciliationGeneration == generation else { return }
            let pendingIdentifiers = eligibleIdentifiers
            let deliveredIdentifiers = Set(eligibleOrders.flatMap { order -> [String] in
                var identifiers: [String] = []
                if order.latestEntry.reminderEnabled {
                    identifiers.append(WorkOrderNotificationIdentifier.reminder(orderID: order.id))
                }
                if order.latestEntry.priority == .emergency && emergencyNotificationsEnabled {
                    identifiers.append(WorkOrderNotificationIdentifier.emergency(
                        orderID: order.id, entryID: order.latestEntry.id
                    ))
                }
                return identifiers
            })
            // Use the native async notification APIs so cleanup remains inside
            // this serialized reconciliation task. This avoids completion-handler
            // races, nested weak captures, and Xcode's async-alternative warnings.
            let pendingRequests = await self.center.pendingNotificationRequests()
            guard self.reconciliationGeneration == generation else { return }
            let stalePending = pendingRequests
                .map(\.identifier)
                .filter { identifier in
                    WorkOrderNotificationIdentifier.workOrderID(from: identifier) != nil &&
                        !pendingIdentifiers.contains(identifier)
                }
            if !stalePending.isEmpty {
                self.center.removePendingNotificationRequests(withIdentifiers: stalePending)
            }

            let deliveredNotifications = await self.center.deliveredNotifications()
            guard self.reconciliationGeneration == generation else { return }
            let staleDelivered = deliveredNotifications
                .map { $0.request.identifier }
                .filter { identifier in
                    WorkOrderNotificationIdentifier.workOrderID(from: identifier) != nil &&
                        !deliveredIdentifiers.contains(identifier)
                }
            if !staleDelivered.isEmpty {
                self.center.removeDeliveredNotifications(withIdentifiers: staleDelivered)
            }
        }
    }

    nonisolated func userNotificationCenter(
        _ center: UNUserNotificationCenter,
        willPresent notification: UNNotification
    ) async -> UNNotificationPresentationOptions {
        [.banner, .list, .sound]
    }

    nonisolated func userNotificationCenter(_ center: UNUserNotificationCenter, didReceive response: UNNotificationResponse) async {
        let userInfo = response.notification.request.content.userInfo
        let workOrderID = userInfo["workOrderID"] as? String
        let deepLink = userInfo["deepLink"] as? String
        await MainActor.run { [weak self, workOrderID, deepLink] in
            guard let self else { return }
            if let workOrderID, let id = UUID(uuidString: workOrderID) {
                self.dispatchOrQueue(workOrderID: id)
            } else if let deepLink, let url = URL(string: deepLink) {
                self.route(url: url)
            }
        }
    }
}

enum WorkOrderSearchEngine {
    static func filter(_ orders: [WorkOrder], status: WorkOrderStatus, filters: WorkOrderFilters) -> [WorkOrder] {
        orders.filter { order in
            guard order.status == status else { return false }
            let entry = order.latestEntry
            if filters.emergencyOnly && entry.priority != .emergency { return false }
            if let category = filters.category, WorkOrderCategory.identityKey(entry.managedCategory.rawValue) != WorkOrderCategory.identityKey(category.rawValue) { return false }
            if !filters.unit.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty && !entry.area.localizedCaseInsensitiveContains(filters.unit) { return false }
            if !filters.handyman.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty && !entry.handymanName.localizedCaseInsensitiveContains(filters.handyman) { return false }
            let query = filters.searchText.trimmingCharacters(in: .whitespacesAndNewlines)
            if !query.isEmpty {
                let haystack = [
                    entry.area,
                    order.title,
                    entry.issueDescription,
                    entry.notes,
                    entry.assetTag,
                    entry.assetID ?? "",
                    entry.handymanName,
                    entry.managedCategory.rawValue,
                    entry.priority.rawValue,
                    order.auditLog.map(\.message).joined(separator: " ")
                ].joined(separator: " ")
                return haystack.localizedCaseInsensitiveContains(query)
            }
            return true
        }
    }
}

enum ConflictMergeService {
    static func merge(local: AppSnapshot?, cloud: AppSnapshot?) -> AppSnapshot? {
        switch (local, cloud) {
        case (.none, .none): return nil
        case (.some(let local), .none): return local
        case (.none, .some(let cloud)): return cloud
        case (.some(let local), .some(let cloud)):
            let localDate = local.snapshotSavedAt ?? local.lastSynced ?? .distantPast
            let cloudDate = cloud.snapshotSavedAt ?? cloud.lastSynced ?? .distantPast
            var base = cloudDate > localDate ? cloud : local
            let other = cloudDate > localDate ? local : cloud
            base.workOrders = mergeOrders(primary: base.workOrders, secondary: other.workOrders)
            base.assets = mergeByID(base.assets ?? [], other.assets ?? [])
            base.tenants = mergeByID(base.tenants ?? [], other.tenants ?? [])

            let localProfileDate = local.profileConfigurationUpdatedAt
            let cloudProfileDate = cloud.profileConfigurationUpdatedAt
            switch (localProfileDate, cloudProfileDate) {
            case (.some(let left), .some(let right)) where left > right:
                base.profile = local.profile
                base.profileConfigurationUpdatedAt = left
            case (.some(let left), .some(let right)) where right > left:
                base.profile = cloud.profile
                base.profileConfigurationUpdatedAt = right
            case (.some(let left), .none):
                base.profile = local.profile
                base.profileConfigurationUpdatedAt = left
            case (.none, .some(let right)):
                base.profile = cloud.profile
                base.profileConfigurationUpdatedAt = right
            default:
                if base.profileConfigurationUpdatedAt == nil {
                    base.profileConfigurationUpdatedAt = other.profileConfigurationUpdatedAt
                }
            }

            // Imported building/unit lists are additive. Preserve units learned
            // independently on both devices instead of letting an unrelated
            // profile setting change drop them.
            base.profile.firstBuildingUnits = mergeUnitNames(
                local.profile.firstBuildingUnits,
                cloud.profile.firstBuildingUnits
            )

            let localCategoryDate = local.categoryConfigurationUpdatedAt ?? .distantPast
            let cloudCategoryDate = cloud.categoryConfigurationUpdatedAt ?? .distantPast
            if localCategoryDate > cloudCategoryDate {
                base.categories = local.categories
                base.categoryConfigurationUpdatedAt = local.categoryConfigurationUpdatedAt
            } else if cloudCategoryDate > localCategoryDate {
                base.categories = cloud.categories
                base.categoryConfigurationUpdatedAt = cloud.categoryConfigurationUpdatedAt
            } else if base.categories == nil {
                base.categories = other.categories
                base.categoryConfigurationUpdatedAt = other.categoryConfigurationUpdatedAt
            }

            if !LegalContent.isCurrentAcceptance(base.profile) {
                // Preserve legacy cross-device legal acceptance, but do not let an
                // explicitly older acceptance resurrect after a newer profile has
                // deliberately declined or invalidated the current agreement.
                let acceptedCandidates = [local, cloud].filter { LegalContent.isCurrentAcceptance($0.profile) }
                let acceptanceCandidate = acceptedCandidates.max { left, right in
                    let leftDate = left.profileConfigurationUpdatedAt ?? left.profile.legalAcceptedDate ?? .distantPast
                    let rightDate = right.profileConfigurationUpdatedAt ?? right.profile.legalAcceptedDate ?? .distantPast
                    return leftDate < rightDate
                }
                if let acceptanceCandidate {
                    let selectedProfileDate = base.profileConfigurationUpdatedAt
                    let acceptedEvidenceDate = acceptanceCandidate.profileConfigurationUpdatedAt
                        ?? acceptanceCandidate.profile.legalAcceptedDate
                    let acceptanceIsNotExplicitlyOlder: Bool
                    if let selectedProfileDate {
                        // A selected profile with explicit freshness represents a
                        // deliberate modern state. Compare a legacy acceptance by
                        // its acceptance date when no profile timestamp exists.
                        // With no timestamp evidence at all, the explicit selected
                        // profile wins instead of resurrecting unknown old consent.
                        acceptanceIsNotExplicitlyOlder = acceptedEvidenceDate.map { $0 >= selectedProfileDate } ?? false
                    } else {
                        // If the selected profile is itself legacy, preserve the
                        // established migration behavior and carry current consent.
                        acceptanceIsNotExplicitlyOlder = true
                    }
                    if acceptanceIsNotExplicitlyOlder {
                        base.profile.legalAccepted = true
                        base.profile.legalAcceptedDate = acceptanceCandidate.profile.legalAcceptedDate
                        base.profile.legalAcceptedVersion = acceptanceCandidate.profile.legalAcceptedVersion
                    }
                }
            }
            base.snapshotSavedAt = max(localDate, cloudDate)
            return base
        }
    }

    static func coalesceWorkOrders(_ orders: [WorkOrder]) -> [WorkOrder] {
        mergeOrders(primary: [], secondary: orders)
    }

    private static func mergeOrders(primary: [WorkOrder], secondary: [WorkOrder]) -> [WorkOrder] {
        var result: [WorkOrder] = []
        for incoming in primary + secondary {
            if let index = result.firstIndex(where: { $0.id == incoming.id }) {
                result[index] = mergeOrder(result[index], incoming)
            } else {
                result.append(incoming)
            }
        }
        return result.sorted { $0.createdAt > $1.createdAt }
    }

    private static func mergeOrder(_ a: WorkOrder, _ b: WorkOrder) -> WorkOrder {
        let aLatest = latestDate(for: a)
        let bLatest = latestDate(for: b)
        var merged = bLatest > aLatest ? b : a
        merged.entries = mergeByID(a.entries, b.entries).sorted { $0.createdAt < $1.createdAt }
        merged.auditLog = mergeByID(a.auditLog, b.auditLog).sorted { $0.date < $1.date }
        let leftStatus = a.statusEntries ?? []
        let rightStatus = b.statusEntries ?? []
        merged.statusEntries = mergeByID(leftStatus, rightStatus).sorted { $0.date < $1.date }

        // Resolve workflow status from explicit status transitions, not from the
        // newest unrelated audit event. Merely opening/viewing a stale work order
        // on one device must never roll back a real status change from another.
        let aStatus = statusTransition(for: a)
        let bStatus = statusTransition(for: b)
        switch (aStatus, bStatus) {
        case (.some(let left), .some(let right)):
            if left.date == right.date {
                merged.status = left.status.rawValue <= right.status.rawValue ? left.status : right.status
            } else {
                merged.status = left.date > right.date ? left.status : right.status
            }
        case (.some(let transition), .none), (.none, .some(let transition)):
            merged.status = transition.status
        case (.none, .none):
            break
        }

        // Deletion is a reversible state transition. A permanent OR operation
        // would cause an older trash snapshot to delete an order again after a
        // newer device recovered it. The newest explicit delete/recover event wins.
        let aDeletion = deletionTransition(for: a)
        let bDeletion = deletionTransition(for: b)
        let resolvedDeletion: DeletionTransition?
        switch (aDeletion, bDeletion) {
        case (.some(let left), .some(let right)):
            if left.date == right.date {
                resolvedDeletion = bLatest > aLatest ? right : left
            } else {
                resolvedDeletion = left.date > right.date ? left : right
            }
        case (.some(let transition), .none), (.none, .some(let transition)):
            resolvedDeletion = transition
        case (.none, .none):
            resolvedDeletion = nil
        }

        if let resolvedDeletion {
            merged.isDeleted = resolvedDeletion.isDeleted
            merged.deletedAt = resolvedDeletion.isDeleted ? resolvedDeletion.date : nil
        } else {
            let stateSource = bLatest > aLatest ? b : a
            merged.isDeleted = stateSource.isDeleted
            merged.deletedAt = stateSource.isDeleted ? stateSource.deletedAt : nil
        }
        return merged
    }

    private struct WorkflowStatusTransition {
        let status: WorkOrderStatus
        let date: Date
    }

    private static func statusTransition(for order: WorkOrder) -> WorkflowStatusTransition? {
        let statusTransitions = (order.statusEntries ?? []).compactMap { entry -> WorkflowStatusTransition? in
            switch entry.kind {
            case .statusChanged:
                guard let status = statusFromTransitionMessage(entry.detail) else { return nil }
                return WorkflowStatusTransition(status: status, date: entry.date)
            case .completed:
                return WorkflowStatusTransition(status: .completed, date: entry.date)
            case .started:
                return WorkflowStatusTransition(status: .inProgress, date: entry.date)
            default:
                return nil
            }
        }

        let auditTransitions = order.auditLog.compactMap { event -> WorkflowStatusTransition? in
            if let status = statusFromTransitionMessage(event.message) {
                return WorkflowStatusTransition(status: status, date: event.date)
            }
            if event.message == "Work order opened as in-progress" {
                return WorkflowStatusTransition(status: .inProgress, date: event.date)
            }
            if event.message == "Completed work order locked for legal record" {
                return WorkflowStatusTransition(status: .completed, date: event.date)
            }
            return nil
        }

        return (statusTransitions + auditTransitions).max { left, right in
            if left.date == right.date {
                return left.status.rawValue > right.status.rawValue
            }
            return left.date < right.date
        }
    }

    private static func statusFromTransitionMessage(_ message: String) -> WorkOrderStatus? {
        let prefix = "Status changed to "
        guard message.hasPrefix(prefix) else { return nil }
        return WorkOrderStatus(rawValue: String(message.dropFirst(prefix.count)))
    }

    private struct DeletionTransition {
        let isDeleted: Bool
        let date: Date
    }

    private static func deletionTransition(for order: WorkOrder) -> DeletionTransition? {
        let statusTransition = (order.statusEntries ?? [])
            .filter { $0.kind == .deleted || $0.kind == .recovered }
            .max { $0.date < $1.date }
            .map { DeletionTransition(isDeleted: $0.kind == .deleted, date: $0.date) }

        let auditTransition = order.auditLog
            .compactMap { event -> DeletionTransition? in
                switch event.message {
                case "Moved to trash": return DeletionTransition(isDeleted: true, date: event.date)
                case "Recovered from trash": return DeletionTransition(isDeleted: false, date: event.date)
                default: return nil
                }
            }
            .max { $0.date < $1.date }

        if let statusTransition, let auditTransition {
            return statusTransition.date >= auditTransition.date ? statusTransition : auditTransition
        }
        if let statusTransition { return statusTransition }
        if let auditTransition { return auditTransition }
        if order.isDeleted {
            return DeletionTransition(isDeleted: true, date: order.deletedAt ?? order.createdAt)
        }
        return nil
    }

    private static func latestDate(for order: WorkOrder) -> Date {
        [
            order.createdAt,
            order.deletedAt,
            order.entries.map(\.createdAt).max(),
            order.auditLog.map(\.date).max(),
            (order.statusEntries ?? []).map(\.date).max()
        ].compactMap { $0 }.max() ?? order.createdAt
    }

    private static func mergeUnitNames(_ a: [String], _ b: [String]) -> [String] {
        var seen = Set<String>()
        var result: [String] = []
        for rawValue in a + b {
            let value = rawValue.trimmingCharacters(in: .whitespacesAndNewlines)
            guard !value.isEmpty else { continue }
            let key = unitIdentityKey(value)
            guard seen.insert(key).inserted else { continue }
            result.append(value)
        }
        return result.sorted { unitIdentityKey($0) < unitIdentityKey($1) }
    }

    private static func unitIdentityKey(_ value: String) -> String {
        value
            .trimmingCharacters(in: .whitespacesAndNewlines)
            .folding(
                options: [.caseInsensitive, .diacriticInsensitive, .widthInsensitive],
                locale: Locale(identifier: "en_US_POSIX")
            )
    }

    private static func mergeByID<T: Identifiable & Hashable>(_ a: [T], _ b: [T]) -> [T] where T.ID: Hashable {
        var seen = Set<T.ID>()
        var merged: [T] = []
        for item in a + b where !seen.contains(item.id) {
            seen.insert(item.id)
            merged.append(item)
        }
        return merged
    }
}

struct SecurityService: Sendable {
    func authenticate(reason: String = "Unlock iWorkOrder") async -> Bool {
        let context = LAContext(); context.localizedCancelTitle = "Cancel"
        var error: NSError?
        guard context.canEvaluatePolicy(.deviceOwnerAuthentication, error: &error) else { return false }
        return ((try? await context.evaluatePolicy(.deviceOwnerAuthentication, localizedReason: reason)) ?? false)
    }
}

@MainActor final class AppLockState: ObservableObject {
    // Start closed; RootView applies the persisted policy before showing data.
    @Published private(set) var isLocked = true
    @Published private(set) var isAuthenticating = false
    private var authenticationToken: UUID?

    func requireUnlock() {
        authenticationToken = nil
        isAuthenticating = false
        isLocked = true
    }

    func unlock() {
        authenticationToken = nil
        isAuthenticating = false
        isLocked = false
    }

    func beginAuthentication() -> UUID? {
        guard isLocked, !isAuthenticating else { return nil }
        let token = UUID()
        authenticationToken = token
        isAuthenticating = true
        return token
    }

    func completeAuthentication(token: UUID, succeeded: Bool) {
        guard authenticationToken == token else { return }
        authenticationToken = nil
        isAuthenticating = false
        if succeeded { isLocked = false }
    }

    func applicationDidEnterBackground(lockEnabled: Bool) {
        if lockEnabled { requireUnlock() }
    }

    func applicationDidBecomeActive(lockEnabled: Bool) {
        if !lockEnabled { unlock() }
    }
}

@MainActor
enum HapticManager {
    static func success() {
        UINotificationFeedbackGenerator().notificationOccurred(.success)
    }

    static func warning() {
        let generator = UIImpactFeedbackGenerator(style: .heavy)
        generator.prepare()
        generator.impactOccurred(intensity: 1.0)
        Task { @MainActor in
            try? await Task.sleep(for: .milliseconds(120))
            generator.impactOccurred(intensity: 1.0)
            try? await Task.sleep(for: .milliseconds(120))
            generator.impactOccurred(intensity: 1.0)
        }
    }

    static func selection() {
        UISelectionFeedbackGenerator().selectionChanged()
    }
}

enum ImageStorageService {
    static var imageDirectory: URL {
        let url = FileManager.default.urls(for: .documentDirectory, in: .userDomainMask)[0].appendingPathComponent("WorkOrderImages", isDirectory: true)
        try? FileManager.default.createDirectory(at: url, withIntermediateDirectories: true)
        return url
    }

    static func downsample(_ image: UIImage, maxDimension: CGFloat = 1080) -> UIImage {
        image.resized(maxDimension: maxDimension)
    }

    static func saveCompressed(image: UIImage, kind: WorkOrderImage.ImageKind) -> WorkOrderImage? {
        let resized = downsample(image, maxDimension: 1080)
        guard let data = resized.jpegData(compressionQuality: 0.74) else { return nil }
        return writeCompressedJPEGData(data, kind: kind)
    }

    /// Converts picker-provided image bytes to a bounded JPEG using ImageIO.
    /// This path is safe to run away from the UI actor so importing a large
    /// HEIC/JPEG does not synchronously decode and redraw the full image in SwiftUI.
    static func saveCompressed(data sourceData: Data, kind: WorkOrderImage.ImageKind, maxPixelSize: Int = 1080) -> WorkOrderImage? {
        guard maxPixelSize > 0,
              !sourceData.isEmpty,
              let source = CGImageSourceCreateWithData(sourceData as CFData, nil) else {
            return nil
        }

        let thumbnailOptions: [CFString: Any] = [
            kCGImageSourceCreateThumbnailFromImageAlways: true,
            kCGImageSourceCreateThumbnailWithTransform: true,
            kCGImageSourceShouldCacheImmediately: true,
            kCGImageSourceThumbnailMaxPixelSize: maxPixelSize
        ]
        guard let image = CGImageSourceCreateThumbnailAtIndex(source, 0, thumbnailOptions as CFDictionary),
              let outputData = CFDataCreateMutable(nil, 0),
              let destination = CGImageDestinationCreateWithData(
                outputData,
                UTType.jpeg.identifier as CFString,
                1,
                nil
              ) else {
            return nil
        }

        CGImageDestinationAddImage(
            destination,
            image,
            [kCGImageDestinationLossyCompressionQuality: 0.74] as CFDictionary
        )
        guard CGImageDestinationFinalize(destination) else { return nil }
        return writeCompressedJPEGData(outputData as Data, kind: kind)
    }

    private static func writeCompressedJPEGData(_ data: Data, kind: WorkOrderImage.ImageKind) -> WorkOrderImage? {
        guard AttachmentContentPolicy.isReadableImageData(data) else { return nil }
        let filename = "\(UUID().uuidString).jpg"
        let url = imageDirectory.appendingPathComponent(filename)
        do {
            try data.write(to: url, options: [.atomic, .completeFileProtectionUntilFirstUserAuthentication])
            return WorkOrderImage(filename: filename, kind: kind, compressed: true)
        } catch {
            return nil
        }
    }

    static func safeURL(forFilename filename: String) -> URL? {
        guard AttachmentFilenamePolicy.isSafe(filename) else { return nil }
        return imageDirectory.appendingPathComponent(filename, isDirectory: false)
    }

    static func url(forFilename filename: String) -> URL {
        safeURL(forFilename: filename)
            ?? imageDirectory.appendingPathComponent(".invalid-attachment-reference", isDirectory: false)
    }

    static func load(_ image: WorkOrderImage) -> UIImage? {
        guard let url = safeURL(forFilename: image.filename) else { return nil }
        return UIImage(contentsOfFile: url.path)
    }

    /// Generates a display-size JPEG without decoding the full attachment into the UI process.
    /// This is used by evidence galleries so scrolling does not repeatedly decode 1080p originals.
    static func thumbnailData(_ image: WorkOrderImage, maxPixelSize: Int = 240) -> Data? {
        guard maxPixelSize > 0, let url = safeURL(forFilename: image.filename) else { return nil }
        guard let source = CGImageSourceCreateWithURL(url as CFURL, nil) else { return nil }

        let options: [CFString: Any] = [
            kCGImageSourceCreateThumbnailFromImageAlways: true,
            kCGImageSourceCreateThumbnailWithTransform: true,
            kCGImageSourceShouldCacheImmediately: true,
            kCGImageSourceThumbnailMaxPixelSize: maxPixelSize
        ]
        guard let thumbnail = CGImageSourceCreateThumbnailAtIndex(source, 0, options as CFDictionary) else { return nil }

        guard let data = CFDataCreateMutable(nil, 0) else { return nil }
        guard let destination = CGImageDestinationCreateWithData(
            data,
            UTType.jpeg.identifier as CFString,
            1,
            nil
        ) else { return nil }
        CGImageDestinationAddImage(
            destination,
            thumbnail,
            [kCGImageDestinationLossyCompressionQuality: 0.82] as CFDictionary
        )
        guard CGImageDestinationFinalize(destination) else { return nil }
        return data as Data
    }

    struct CleanupResult {
        let removedCount: Int
        let failedFilenames: [String]
    }

    @discardableResult
    static func delete(_ image: WorkOrderImage) -> Bool {
        guard let url = safeURL(forFilename: image.filename) else { return false }
        guard FileManager.default.fileExists(atPath: url.path) else {
            let filename = image.filename
            Task { await WorkOrderImageThumbnailCache.shared.remove(filename: filename) }
            return true
        }
        do {
            try FileManager.default.removeItem(at: url)
            let removed = !FileManager.default.fileExists(atPath: url.path)
            if removed {
                let filename = image.filename
                Task { await WorkOrderImageThumbnailCache.shared.remove(filename: filename) }
            }
            return removed
        } catch {
            return false
        }
    }

    static func deleteUnreferenced(keeping retainedFilenames: Set<String>) -> CleanupResult {
        let fileManager = FileManager.default
        let directory = imageDirectory
        let contents: [URL]
        do {
            contents = try fileManager.contentsOfDirectory(
                at: directory,
                includingPropertiesForKeys: [.isRegularFileKey],
                options: [.skipsHiddenFiles]
            )
        } catch {
            return CleanupResult(removedCount: 0, failedFilenames: [directory.lastPathComponent])
        }

        var removedCount = 0
        var removedFilenames: [String] = []
        var failedFilenames: [String] = []
        for url in contents {
            let filename = url.lastPathComponent
            guard AttachmentFilenamePolicy.isSafe(filename), !retainedFilenames.contains(filename) else { continue }
            let values = try? url.resourceValues(forKeys: [.isRegularFileKey])
            guard values?.isRegularFile != false else { continue }
            do {
                try fileManager.removeItem(at: url)
                if fileManager.fileExists(atPath: url.path) {
                    failedFilenames.append(filename)
                } else {
                    removedCount += 1
                    removedFilenames.append(filename)
                }
            } catch {
                failedFilenames.append(filename)
            }
        }
        if !removedFilenames.isEmpty {
            Task {
                for filename in removedFilenames {
                    await WorkOrderImageThumbnailCache.shared.remove(filename: filename)
                }
            }
        }
        return CleanupResult(removedCount: removedCount, failedFilenames: failedFilenames)
    }
}

enum FlashlightService {
    static var cameraAuthorizationStatus: AVAuthorizationStatus {
        AVCaptureDevice.authorizationStatus(for: .video)
    }

    static func requestCameraPermission() async -> Bool {
        switch cameraAuthorizationStatus {
        case .authorized:
            return true
        case .notDetermined:
            return await AVCaptureDevice.requestAccess(for: .video)
        case .denied, .restricted:
            return false
        @unknown default:
            return false
        }
    }

    @discardableResult
    static func setTorch(active: Bool) async -> Bool {
        if active {
            guard await requestCameraPermission(), !Task.isCancelled else { return false }
        }
        return configureTorch(active: active)
    }

    @discardableResult
    private static func configureTorch(active: Bool) -> Bool {
        guard let device = AVCaptureDevice.default(for: .video), device.hasTorch else { return false }
        if active {
            guard device.isTorchAvailable, device.isTorchModeSupported(.on) else { return false }
        }
        do {
            try device.lockForConfiguration()
            defer { device.unlockForConfiguration() }
            device.torchMode = active ? .on : .off
            return true
        } catch {
            return false
        }
    }
}

extension UIImage {
    func resized(maxDimension: CGFloat) -> UIImage {
        let longest = max(size.width, size.height)
        guard longest > maxDimension else { return self }
        let scale = maxDimension / longest
        let newSize = CGSize(width: size.width * scale, height: size.height * scale)
        let renderer = UIGraphicsImageRenderer(size: newSize)
        return renderer.image { _ in self.draw(in: CGRect(origin: .zero, size: newSize)) }
    }
}

enum CSVHelper {
    static func parseUnits(from text: String) -> [String] {
        text.split(whereSeparator: { $0 == "\n" || $0 == "," || $0 == ";" })
            .map { String($0).trimmingCharacters(in: .whitespacesAndNewlines) }
            .filter { !$0.isEmpty }
    }
}


actor WorkOrderImageThumbnailCache {
    static let shared = WorkOrderImageThumbnailCache()

    private var cachedData: [String: Data] = [:]
    private var accessOrder: [String] = []
    private let maxEntries = 64

    func data(for image: WorkOrderImage, maxPixelSize: Int = 240) -> Data? {
        guard let url = ImageStorageService.safeURL(forFilename: image.filename) else { return nil }
        let values = try? url.resourceValues(forKeys: [.fileSizeKey, .contentModificationDateKey])
        let fileSize = values?.fileSize ?? -1
        let modified = values?.contentModificationDate?.timeIntervalSinceReferenceDate ?? -1
        let key = "\(image.filename)#\(maxPixelSize)#\(fileSize)#\(modified)"
        if let cached = cachedData[key] {
            touch(key)
            return cached
        }

        guard let data = ImageStorageService.thumbnailData(image, maxPixelSize: maxPixelSize) else {
            return nil
        }
        cachedData[key] = data
        touch(key)
        trimIfNeeded()
        return data
    }

    func remove(filename: String) {
        let prefix = "\(filename)#"
        let matchingKeys = cachedData.keys.filter { $0.hasPrefix(prefix) }
        for key in matchingKeys {
            cachedData.removeValue(forKey: key)
        }
        accessOrder.removeAll { $0.hasPrefix(prefix) }
    }

    func removeAll() {
        cachedData.removeAll(keepingCapacity: false)
        accessOrder.removeAll(keepingCapacity: false)
    }

    private func touch(_ key: String) {
        accessOrder.removeAll { $0 == key }
        accessOrder.append(key)
    }

    private func trimIfNeeded() {
        while accessOrder.count > maxEntries {
            let oldest = accessOrder.removeFirst()
            cachedData.removeValue(forKey: oldest)
        }
    }
}

enum SignatureStorageService {
    struct CleanupResult {
        let removedCount: Int
        let failedFilenames: [String]
    }

    static var signatureDirectory: URL {
        let url = FileManager.default.urls(for: .documentDirectory, in: .userDomainMask)[0].appendingPathComponent("WorkOrderSignatures", isDirectory: true)
        try? FileManager.default.createDirectory(at: url, withIntermediateDirectories: true)
        return url
    }

    static func save(data: Data) -> String? {
        let filename = "signature-\(UUID().uuidString).png"
        let url = signatureDirectory.appendingPathComponent(filename)
        do {
            try data.write(to: url, options: [.atomic, .completeFileProtectionUntilFirstUserAuthentication])
            return filename
        } catch {
            return nil
        }
    }

    static func safeURL(forFilename filename: String) -> URL? {
        guard AttachmentFilenamePolicy.isSafe(filename) else { return nil }
        return signatureDirectory.appendingPathComponent(filename, isDirectory: false)
    }

    static func url(forFilename filename: String) -> URL {
        safeURL(forFilename: filename)
            ?? signatureDirectory.appendingPathComponent(".invalid-attachment-reference", isDirectory: false)
    }

    static func fileExists(filename: String?) -> Bool {
        guard let filename, let url = safeURL(forFilename: filename) else { return false }
        return FileManager.default.fileExists(atPath: url.path)
    }

    static func isReadableImage(filename: String?) -> Bool {
        guard let filename, let url = safeURL(forFilename: filename) else { return false }
        return AttachmentContentPolicy.isReadableImage(at: url)
    }

    static func image(named filename: String?) -> UIImage? {
        guard let filename, let url = safeURL(forFilename: filename) else { return nil }
        return UIImage(contentsOfFile: url.path)
    }

    @discardableResult
    static func delete(filename: String?) -> Bool {
        guard let filename, let url = safeURL(forFilename: filename) else { return false }
        guard FileManager.default.fileExists(atPath: url.path) else { return true }
        do {
            try FileManager.default.removeItem(at: url)
            return !FileManager.default.fileExists(atPath: url.path)
        } catch {
            return false
        }
    }

    static func deleteUnreferenced(keeping retainedFilenames: Set<String>) -> CleanupResult {
        let fileManager = FileManager.default
        let directory = signatureDirectory
        let contents: [URL]
        do {
            contents = try fileManager.contentsOfDirectory(
                at: directory,
                includingPropertiesForKeys: [.isRegularFileKey],
                options: [.skipsHiddenFiles]
            )
        } catch {
            return CleanupResult(removedCount: 0, failedFilenames: [directory.lastPathComponent])
        }

        var removedCount = 0
        var failedFilenames: [String] = []
        for url in contents {
            let filename = url.lastPathComponent
            guard AttachmentFilenamePolicy.isSafe(filename), !retainedFilenames.contains(filename) else { continue }
            let values = try? url.resourceValues(forKeys: [.isRegularFileKey])
            guard values?.isRegularFile != false else { continue }
            do {
                try fileManager.removeItem(at: url)
                if fileManager.fileExists(atPath: url.path) {
                    failedFilenames.append(filename)
                } else {
                    removedCount += 1
                }
            } catch {
                failedFilenames.append(filename)
            }
        }
        return CleanupResult(removedCount: removedCount, failedFilenames: failedFilenames)
    }
}

enum PDFExportService {
    static func makeWorkOrderPDF(profile: UserProfile, orders: [WorkOrder], title: String = "iWorkOrder Report") -> URL? {
        let allowed = CharacterSet.alphanumerics.union(CharacterSet(charactersIn: "_-"))
        let safeTitle = String(title.unicodeScalars.map { allowed.contains($0) ? String($0) : "_" }.joined().prefix(80))
        let cleanTitle = safeTitle.isEmpty ? "iWorkOrder_Report" : safeTitle
        let directory = FileManager.default.temporaryDirectory
            .appendingPathComponent("iWorkOrderPDFExports", isDirectory: true)
        do {
            try FileManager.default.createDirectory(at: directory, withIntermediateDirectories: true)
        } catch {
            return nil
        }
        let exportID = UUID().uuidString
        let url = directory.appendingPathComponent("\(cleanTitle)_\(exportID).pdf")
        var layoutFailed = false
        let renderer = UIGraphicsPDFRenderer(bounds: CGRect(x: 0, y: 0, width: 612, height: 792))
        do {
            try renderer.writePDF(to: url) { context in
                var y: CGFloat = 36
                let pageWidth: CGFloat = 612
                let margin: CGFloat = 36
                let contentWidth: CGFloat = pageWidth - (margin * 2)

                var pageNumber = 0
                func drawFooter() {
                    let footer = "iWorkOrder legal record export • Export ID: \(exportID) • Page \(pageNumber)"
                    footer.draw(at: CGPoint(x: margin, y: 768), withAttributes: [.font: UIFont.systemFont(ofSize: 8), .foregroundColor: UIColor.darkGray])
                }

                func newPage() {
                    if pageNumber > 0 { drawFooter() }
                    context.beginPage()
                    pageNumber += 1
                    y = margin
                }

                func ensureSpace(_ height: CGFloat) {
                    if y + height > 748 { newPage() }
                }

                func drawLine(_ text: String, font: UIFont = .systemFont(ofSize: 11), bold: Bool = false) {
                    let usedFont = bold ? UIFont.boldSystemFont(ofSize: font.pointSize) : font
                    guard !layoutFailed, !text.isEmpty else { return }
                    let attributed = NSAttributedString(string: text, attributes: [
                        .font: usedFont, .foregroundColor: UIColor.black
                    ])
                    let framesetter = CTFramesetterCreateWithAttributedString(attributed as CFAttributedString)
                    var offset = 0
                    while offset < attributed.length {
                        ensureSpace(ceil(usedFont.lineHeight) + 6)
                        let availableHeight = max(1, 748 - y - 6)
                        let path = CGPath(rect: CGRect(x: 0, y: 0, width: contentWidth, height: availableHeight), transform: nil)
                        let frame = CTFramesetterCreateFrame(framesetter, CFRange(location: offset, length: 0), path, nil)
                        let visible = CTFrameGetVisibleStringRange(frame)
                        guard visible.length > 0 else {
                            if y > margin { newPage(); continue }
                            // Never return a success URL for an incomplete PDF.
                            layoutFailed = true
                            return
                        }
                        let graphics = context.cgContext
                        graphics.saveGState()
                        graphics.textMatrix = .identity
                        graphics.translateBy(x: margin, y: y + availableHeight)
                        graphics.scaleBy(x: 1, y: -1)
                        CTFrameDraw(frame, graphics)
                        graphics.restoreGState()
                        let used = CTFramesetterSuggestFrameSizeWithConstraints(
                            framesetter, visible, nil,
                            CGSize(width: contentWidth, height: CGFloat.greatestFiniteMagnitude), nil
                        )
                        y += ceil(used.height) + 6
                        offset = visible.location + visible.length
                        if offset < attributed.length { newPage() }
                    }
                }

                func drawImage(_ image: UIImage, label: String) {
                    guard image.size.width > 0, image.size.height > 0 else {
                        drawLine("Evidence unavailable: " + label)
                        return
                    }
                    let maxSize = CGSize(width: 160, height: 120)
                    let scale = min(maxSize.width / image.size.width, maxSize.height / image.size.height, 1)
                    let size = CGSize(width: image.size.width * scale, height: image.size.height * scale)
                    ensureSpace(size.height + 28)
                    drawLine(label, font: .systemFont(ofSize: 10), bold: true)
                    ensureSpace(size.height + 8)
                    image.draw(in: CGRect(x: margin, y: y, width: size.width, height: size.height))
                    y += size.height + 8
                }

                newPage()
                drawLine(title, font: .systemFont(ofSize: 20), bold: true)
                drawLine("Export ID: \(exportID)", font: .systemFont(ofSize: 10), bold: true)
                drawLine("Generated: \(Date().shortDateTime)")
                drawLine("Legal baseline: \(LegalContent.effectiveDate) | Version: \(LegalContent.currentVersion) | Region: United States only", font: .systemFont(ofSize: 9))
                drawLine("Prepared for: \(profile.personName.isEmpty ? "Unspecified user" : profile.personName)")
                drawLine("Company / building manager: \(profile.propertyManagerCompanyName.isEmpty ? "Not provided" : profile.propertyManagerCompanyName)")
                drawLine("Building address: \(profile.buildingAddress.isEmpty ? "Not provided" : profile.buildingAddress)")
                drawLine("Record Source: This PDF was generated from data stored on the user's device and/or the user's Apple iCloud account. The developer does not operate an external work-order server and does not verify user-entered content.", font: .systemFont(ofSize: 9))
                drawLine("Legal Notice: This export is a user-generated maintenance record. Review all dates, descriptions, photos, signatures, and audit entries before legal, insurance, housing, employment, or business use. This document is not legal advice and does not guarantee admissibility.", font: .systemFont(ofSize: 9))
                drawLine("Chain-of-Custody Note: Preserve the original app data, source photos, messages, invoices, notices, and any signed records when legal proof is required. Re-exporting later may produce a different file if app data changes.", font: .systemFont(ofSize: 9))
                y += 8

                for order in orders.sorted(by: { $0.createdAt > $1.createdAt }) {
                    ensureSpace(130)
                    drawLine("\(order.latestEntry.area) - \(order.title)", font: .systemFont(ofSize: 14), bold: true)
                    drawLine("Work Order ID: \(order.id.uuidString)", font: .systemFont(ofSize: 9))
                    drawLine("Status: \(order.status.rawValue) | Priority: \(order.latestEntry.priority.rawValue) | Category: \(order.latestEntry.managedCategory.rawValue)")
                    drawLine("Created: \(order.createdAt.shortDateTime) | Revisions: \(order.entries.count) | Handyman: \(order.latestEntry.handymanName.isEmpty ? "Unassigned" : order.latestEntry.handymanName)")
                    drawLine("Entry permitted: \(order.latestEntry.entryPermitted ? "Yes" : "No") | Tenant permission: \((order.latestEntry.tenantPermission ?? order.latestEntry.entryPermitted) ? "Yes" : "No") | Entry method: \(order.latestEntry.entryMethod?.rawValue ?? "Not specified")")
                    drawLine("Asset tag: \(order.latestEntry.assetTag.isEmpty ? "None" : order.latestEntry.assetTag) | Asset ID: \(order.latestEntry.assetID ?? "None")")
                    drawLine("Description: \(order.latestEntry.issueDescription)")
                    drawLine("Notes: \(order.latestEntry.notes.isEmpty ? "None" : order.latestEntry.notes)")

                    for entry in order.entries {
                        for imageRecord in entry.images {
                            if let image = ImageStorageService.load(imageRecord) {
                                drawImage(image, label: "\(imageRecord.kind.rawValue) photo - \(imageRecord.createdAt.shortDateTime)")
                            } else {
                                drawLine("Evidence unavailable: \(imageRecord.kind.rawValue) photo from \(imageRecord.createdAt.shortDateTime). The source attachment could not be read.", font: .systemFont(ofSize: 9))
                            }
                        }
                        if let signature = SignatureStorageService.image(named: entry.signatureFilename) {
                            let signer = entry.signatureSignerName?.trimmingCharacters(in: .whitespacesAndNewlines)
                            let captured = entry.signatureCapturedAt?.shortDateTime ?? "Time not recorded"
                            let consent = entry.signatureConsentVersion ?? "Legacy signature"
                            let signerText = (signer?.isEmpty == false ? signer : nil) ?? "Name not recorded"
                            drawImage(signature, label: "Electronic signature attestation - \(signerText) - \(captured) - Consent \(consent)")
                        } else if let filename = entry.signatureFilename, !filename.isEmpty {
                            drawLine("Evidence unavailable: a recorded signature attachment could not be read.", font: .systemFont(ofSize: 9))
                        }
                    }

                    drawLine("Audit Trail (timestamped activity record)", font: .systemFont(ofSize: 12), bold: true)
                    let statusEntries = order.statusEntries ?? []
                    if statusEntries.isEmpty && order.auditLog.isEmpty {
                        drawLine("No audit entries recorded.")
                    } else {
                        for entry in statusEntries {
                            drawLine("• \(entry.date.shortDateTime) - \(entry.kind.rawValue): \(entry.detail)", font: .systemFont(ofSize: 9))
                        }
                        if statusEntries.isEmpty {
                            for event in order.auditLog {
                                drawLine("• \(event.date.shortDateTime) - \(event.message)", font: .systemFont(ofSize: 9))
                            }
                        }
                    }
                    ensureSpace(12)
                    UIColor.lightGray.setStroke()
                    UIBezierPath(rect: CGRect(x: margin, y: y, width: contentWidth, height: 1)).stroke()
                    y += 12
                }
                ensureSpace(80)
                y += 8
                drawLine("Export Certification", font: .systemFont(ofSize: 12), bold: true)
                drawLine("This PDF was generated by iWorkOrder on \(Date().shortDateTime) from user-controlled app data. The user is responsible for verifying accuracy and preserving supporting evidence. Export ID: \(exportID)", font: .systemFont(ofSize: 9))
                drawFooter()
            }
            guard !layoutFailed else {
                try? FileManager.default.removeItem(at: url)
                return nil
            }
            try FileManager.default.setAttributes(
                [.protectionKey: FileProtectionType.completeUntilFirstUserAuthentication],
                ofItemAtPath: url.path
            )
            return url
        } catch {
            try? FileManager.default.removeItem(at: url)
            return nil
        }
    }
}

