import Foundation
import OSLog

enum AppDataSchema {
    static let currentVersion = 3
    static let oldestSupportedVersion = 1
}

enum MaintenanceEventKind: String, Codable, CaseIterable, Sendable {
    case appLaunch
    case appUpgrade
    case localLoad
    case localSave
    case localRecovery
    case dataMigration
    case cloudSync
    case backupExport
    case backupRestore
    case healthCheck
    case sessionInterrupted
    case memoryPressure
    case recoverySyncPauseChanged
    case supportBundleExport
    case maintenanceHistoryCleared
}

enum MaintenanceOutcome: String, Codable, CaseIterable, Sendable {
    case success
    case warning
    case failure
    case blocked
}

struct MaintenanceEvent: Identifiable, Codable, Equatable, Sendable {
    var id = UUID()
    var date = Date()
    var kind: MaintenanceEventKind
    var outcome: MaintenanceOutcome
    var durationMilliseconds: Int?
    var itemCount: Int?
    var schemaVersion: Int = AppDataSchema.currentVersion
    var buildVersion: String = AppBuildInfo.displayVersion
}

struct DataMigrationResult: Sendable {
    var snapshot: AppSnapshot
    var sourceVersion: Int
    var targetVersion: Int
    var changed: Bool
}

enum DataMigrationError: LocalizedError, Equatable {
    case unsupportedFutureVersion(Int)
    case unsupportedLegacyVersion(Int)
    case invalidWorkOrderRevisionHistory(Int)
    case backupCreationFailed

    var errorDescription: String? {
        switch self {
        case .unsupportedFutureVersion(let version):
            return "This data was created by a newer iWorkOrder data format (schema \(version)). Install the newer app version before opening or changing this data."
        case .unsupportedLegacyVersion(let version):
            return "This data uses unsupported legacy schema \(version). Restore a verified portable backup or contact support before changing the data."
        case .invalidWorkOrderRevisionHistory(let count):
            return "Saved data contains \(count) work-order record(s) with missing revision history. iWorkOrder stopped before changing the data so the original recovery evidence remains intact."
        case .backupCreationFailed:
            return "A protected pre-migration recovery copy could not be created, so the data migration was stopped."
        }
    }
}

struct MaintenanceHealthReport: Equatable, Sendable {
    var generatedAt: Date
    var schemaVersion: Int
    var snapshotSchemaVersion: Int
    var primarySnapshotPresent: Bool
    var fallbackSnapshotPresent: Bool
    var migrationBackupCount: Int
    var safetyBackupCount: Int
    var missingPhotoCount: Int
    var missingSignatureCount: Int
    var orphanPhotoCount: Int
    var orphanSignatureCount: Int
    var duplicateRevisionIDCount: Int
    var emptyWorkOrderCount: Int
    var cloudReplacementPending: Bool
    var cloudErasePending: Bool
    var recentFailureCount: Int
    var possibleInterruptedSessionCount7Days: Int
    var memoryPressureCount7Days: Int
    var cloudSyncPausedForRecovery: Bool
    var lastKnownGoodBuild: String?

    var criticalIssueCount: Int {
        missingPhotoCount + missingSignatureCount + duplicateRevisionIDCount + emptyWorkOrderCount + (snapshotSchemaVersion > schemaVersion ? 1 : 0)
    }

    var warningCount: Int {
        orphanPhotoCount + orphanSignatureCount + recentFailureCount + possibleInterruptedSessionCount7Days + memoryPressureCount7Days + (cloudReplacementPending ? 1 : 0) + (cloudErasePending ? 1 : 0) + (cloudSyncPausedForRecovery ? 1 : 0)
    }

    var isHealthy: Bool { criticalIssueCount == 0 }
}

enum MaintenanceService {
    static let eventRetentionDays = 30
    static let maximumEventCount = 250
    static let maximumMigrationBackupCount = 5

    private static let logger = Logger(subsystem: "com.damiancedeno.SedgwickWorkOrders", category: "maintenance")
    private static let lastBuildKey = "iWorkOrder.maintenance.lastBuild"
    private static let lastKnownGoodBuildKey = "iWorkOrder.maintenance.lastKnownGoodBuild"

    static var maintenanceDirectory: URL {
        FileManager.default.urls(for: .applicationSupportDirectory, in: .userDomainMask)[0]
            .appendingPathComponent("iWorkOrderMaintenance", isDirectory: true)
    }

    static var eventLogURL: URL {
        maintenanceDirectory.appendingPathComponent("operational-events.json")
    }

    static var migrationBackupDirectory: URL {
        maintenanceDirectory.appendingPathComponent("MigrationBackups", isDirectory: true)
    }

    static func noteLaunch() {
        let current = AppBuildInfo.displayVersion
        let previous = UserDefaults.standard.string(forKey: lastBuildKey)
        record(
            kind: previous == nil || previous == current ? .appLaunch : .appUpgrade,
            outcome: .success,
            itemCount: nil
        )
        UserDefaults.standard.set(current, forKey: lastBuildKey)
    }

    static func record(
        kind: MaintenanceEventKind,
        outcome: MaintenanceOutcome,
        durationMilliseconds: Int? = nil,
        itemCount: Int? = nil
    ) {
        let event = MaintenanceEvent(
            kind: kind,
            outcome: outcome,
            durationMilliseconds: durationMilliseconds.map { max(0, $0) },
            itemCount: itemCount.map { max(0, $0) }
        )
        var retained = events()
        retained.append(event)
        let cutoff = Calendar.current.date(byAdding: .day, value: -eventRetentionDays, to: Date()) ?? .distantPast
        retained = retained
            .filter { $0.date >= cutoff }
            .suffix(maximumEventCount)
            .map { $0 }
        writeEvents(retained)
        logger.log("event=\(kind.rawValue, privacy: .public) outcome=\(outcome.rawValue, privacy: .public)")
    }

    static func events() -> [MaintenanceEvent] {
        guard let data = try? Data(contentsOf: eventLogURL),
              let decoded = try? JSONDecoder.iso8601.decode([MaintenanceEvent].self, from: data) else {
            return []
        }
        return decoded.sorted { $0.date < $1.date }
    }

    static func clearHistory() {
        try? FileManager.default.removeItem(at: eventLogURL)
        record(kind: .maintenanceHistoryCleared, outcome: .success)
    }

    static func migrate(_ snapshot: AppSnapshot) throws -> DataMigrationResult {
        let sourceVersion = snapshot.dataSchemaVersion ?? 1
        guard sourceVersion <= AppDataSchema.currentVersion else {
            throw DataMigrationError.unsupportedFutureVersion(sourceVersion)
        }
        guard sourceVersion >= AppDataSchema.oldestSupportedVersion else {
            throw DataMigrationError.unsupportedLegacyVersion(sourceVersion)
        }

        var migrated = snapshot
        var changed = false
        var version = sourceVersion

        if version == 1 {
            migrated.assets = migrated.assets ?? []
            migrated.tenants = migrated.tenants ?? []
            migrated.workOrders = migrated.workOrders.map { order in
                var order = order
                if order.statusEntries == nil { order.statusEntries = [] }
                return order
            }
            version = 2
            changed = true
        }

        if version == 2 {
            if migrated.categories == nil {
                migrated.categories = WorkOrderCategory.defaultCategories
            }
            version = 3
            changed = true
        }

        if migrated.dataSchemaVersion != AppDataSchema.currentVersion {
            migrated.dataSchemaVersion = AppDataSchema.currentVersion
            changed = true
        }

        let emptyWorkOrderCount = migrated.workOrders.reduce(into: 0) { count, order in
            if order.entries.isEmpty { count += 1 }
        }
        guard emptyWorkOrderCount == 0 else {
            throw DataMigrationError.invalidWorkOrderRevisionHistory(emptyWorkOrderCount)
        }

        return DataMigrationResult(
            snapshot: migrated,
            sourceVersion: sourceVersion,
            targetVersion: version,
            changed: changed
        )
    }

    static func createMigrationBackup(sourceURL: URL, sourceVersion: Int, targetVersion: Int) throws -> URL {
        let manager = FileManager.default
        do {
            try manager.createDirectory(at: migrationBackupDirectory, withIntermediateDirectories: true)
            let timestamp = Int(Date().timeIntervalSince1970 * 1000)
            let destination = migrationBackupDirectory.appendingPathComponent(
                "pre-migration-v\(sourceVersion)-to-v\(targetVersion)-\(timestamp).json"
            )
            try manager.copyItem(at: sourceURL, to: destination)
            try (try Data(contentsOf: destination)).write(
                to: destination,
                options: [.atomic, .completeFileProtectionUntilFirstUserAuthentication]
            )
            pruneMigrationBackups()
            return destination
        } catch {
            throw DataMigrationError.backupCreationFailed
        }
    }

    static func migrationBackupCount() -> Int {
        (try? FileManager.default.contentsOfDirectory(
            at: migrationBackupDirectory,
            includingPropertiesForKeys: nil,
            options: [.skipsHiddenFiles]
        ).filter { $0.pathExtension.lowercased() == "json" }.count) ?? 0
    }

    static func healthReport(
        snapshot: AppSnapshot,
        cloudReplacementPending: Bool,
        cloudErasePending: Bool,
        generatedAt: Date = Date()
    ) -> MaintenanceHealthReport {
        let imageReferences = Set(snapshot.workOrders.flatMap(\.entries).flatMap(\.images).map(\.filename))
        let signatureReferences = Set(snapshot.workOrders.flatMap(\.entries).compactMap(\.signatureFilename))
        let imageFiles = filenames(in: ImageStorageService.imageDirectory)
        let signatureFiles = filenames(in: SignatureStorageService.signatureDirectory)

        var seenRevisionIDs = Set<UUID>()
        var duplicateRevisionIDCount = 0
        for entry in snapshot.workOrders.flatMap(\.entries) {
            if !seenRevisionIDs.insert(entry.id).inserted { duplicateRevisionIDCount += 1 }
        }

        let recentCutoff = Calendar.current.date(byAdding: .day, value: -7, to: generatedAt) ?? .distantPast
        let recentEvents = events().filter { $0.date >= recentCutoff }
        let recentFailures = recentEvents.filter {
            $0.outcome == .failure || $0.outcome == .blocked
        }.count
        let possibleInterruptedSessions = recentEvents.filter { $0.kind == .sessionInterrupted }.count
        let memoryPressureEvents = recentEvents.filter { $0.kind == .memoryPressure }.count

        return MaintenanceHealthReport(
            generatedAt: generatedAt,
            schemaVersion: AppDataSchema.currentVersion,
            snapshotSchemaVersion: snapshot.dataSchemaVersion ?? 1,
            primarySnapshotPresent: StorageService.primarySnapshotURL.fileExists,
            fallbackSnapshotPresent: StorageService.fallbackSnapshotURL.fileExists,
            migrationBackupCount: migrationBackupCount(),
            safetyBackupCount: directoryFileCount(at: BackupArchiveService.safetyBackupDirectory),
            missingPhotoCount: imageReferences.subtracting(imageFiles).count,
            missingSignatureCount: signatureReferences.subtracting(signatureFiles).count,
            orphanPhotoCount: imageFiles.subtracting(imageReferences).count,
            orphanSignatureCount: signatureFiles.subtracting(signatureReferences).count,
            duplicateRevisionIDCount: duplicateRevisionIDCount,
            emptyWorkOrderCount: snapshot.workOrders.filter { $0.entries.isEmpty }.count,
            cloudReplacementPending: cloudReplacementPending,
            cloudErasePending: cloudErasePending,
            recentFailureCount: recentFailures,
            possibleInterruptedSessionCount7Days: possibleInterruptedSessions,
            memoryPressureCount7Days: memoryPressureEvents,
            cloudSyncPausedForRecovery: RuntimeReliabilityService.isCloudSyncPaused,
            lastKnownGoodBuild: UserDefaults.standard.string(forKey: lastKnownGoodBuildKey)
        )
    }

    static func markCurrentBuildHealthy() {
        UserDefaults.standard.set(AppBuildInfo.displayVersion, forKey: lastKnownGoodBuildKey)
    }

    static func reportText(health: MaintenanceHealthReport, recentEvents: [MaintenanceEvent]? = nil) -> String {
        let iso = ISO8601DateFormatter()
        iso.formatOptions = [.withInternetDateTime, .withFractionalSeconds]
        let eventsToWrite = recentEvents ?? Array(events().suffix(50))
        var lines = [
            "iWorkOrder Local Maintenance Report",
            "Generated: \(iso.string(from: health.generatedAt))",
            "Application Version: \(AppBuildInfo.displayVersion)",
            "Current Data Schema: \(health.schemaVersion)",
            "Stored Data Schema: \(health.snapshotSchemaVersion)",
            "Health: \(health.isHealthy ? "Pass" : "Attention Required")",
            "Critical Issues: \(health.criticalIssueCount)",
            "Warnings: \(health.warningCount)",
            "Primary Snapshot Present: \(health.primarySnapshotPresent ? "Yes" : "No")",
            "Fallback Snapshot Present: \(health.fallbackSnapshotPresent ? "Yes" : "No")",
            "Migration Recovery Copies: \(health.migrationBackupCount)",
            "Portable Safety Backups: \(health.safetyBackupCount)",
            "Missing Photos: \(health.missingPhotoCount)",
            "Missing Signatures: \(health.missingSignatureCount)",
            "Orphan Photos: \(health.orphanPhotoCount)",
            "Orphan Signatures: \(health.orphanSignatureCount)",
            "Duplicate Revision IDs: \(health.duplicateRevisionIDCount)",
            "Empty Work Orders: \(health.emptyWorkOrderCount)",
            "Cloud Replacement Pending: \(health.cloudReplacementPending ? "Yes" : "No")",
            "Cloud Erase Pending: \(health.cloudErasePending ? "Yes" : "No")",
            "Failures or Blocks in Last 7 Days: \(health.recentFailureCount)",
            "Possible Interrupted Sessions in Last 7 Days: \(health.possibleInterruptedSessionCount7Days)",
            "Memory-Pressure Warnings in Last 7 Days: \(health.memoryPressureCount7Days)",
            "Cloud Sync Paused for Recovery: \(health.cloudSyncPausedForRecovery ? "Yes" : "No")",
            "Last Known Good Build: \(health.lastKnownGoodBuild ?? "Not recorded")",
            "",
            "Recent Structured Events"
        ]
        if eventsToWrite.isEmpty {
            lines.append("None")
        } else {
            for event in eventsToWrite {
                let duration = event.durationMilliseconds.map { " durationMs=\($0)" } ?? ""
                let count = event.itemCount.map { " count=\($0)" } ?? ""
                lines.append("\(iso.string(from: event.date)) kind=\(event.kind.rawValue) outcome=\(event.outcome.rawValue) schema=\(event.schemaVersion)\(duration)\(count)")
            }
        }
        lines.append(contentsOf: [
            "",
            "Privacy Notice",
            "This local report contains only fixed operational event categories, outcomes, durations, schema versions, and aggregate counts. It excludes names, addresses, tenant contacts, work-order text, notes, audit messages, filenames, photos, signatures, and device identifiers.",
            ""
        ])
        return lines.joined(separator: "\n")
    }

    static func writeReport(health: MaintenanceHealthReport) throws -> URL {
        let formatter = DateFormatter()
        formatter.locale = Locale(identifier: "en_US_POSIX")
        formatter.timeZone = TimeZone(secondsFromGMT: 0)
        formatter.dateFormat = "yyyyMMdd-HHmmss"
        let directory = FileManager.default.temporaryDirectory
            .appendingPathComponent("iWorkOrderMaintenanceReports", isDirectory: true)
        try FileManager.default.createDirectory(at: directory, withIntermediateDirectories: true)
        let output = directory.appendingPathComponent("iWorkOrder-Maintenance-\(formatter.string(from: health.generatedAt)).txt")
        guard let data = reportText(health: health).data(using: .utf8) else {
            throw CocoaError(.fileWriteInapplicableStringEncoding)
        }
        try data.write(to: output, options: [.atomic, .completeFileProtectionUntilFirstUserAuthentication])
        return output
    }

    @discardableResult
    static func deleteAll() -> Bool {
        var succeeded = true
        if FileManager.default.fileExists(atPath: maintenanceDirectory.path) {
            do {
                try FileManager.default.removeItem(at: maintenanceDirectory)
            } catch {
                succeeded = false
            }
        }
        UserDefaults.standard.removeObject(forKey: lastBuildKey)
        UserDefaults.standard.removeObject(forKey: lastKnownGoodBuildKey)
        if FileManager.default.fileExists(atPath: maintenanceDirectory.path) {
            succeeded = false
        }
        return succeeded
    }

    private static func writeEvents(_ events: [MaintenanceEvent]) {
        do {
            try FileManager.default.createDirectory(at: maintenanceDirectory, withIntermediateDirectories: true)
            let data = try JSONEncoder.pretty.encode(events)
            try data.write(to: eventLogURL, options: [.atomic, .completeFileProtectionUntilFirstUserAuthentication])
        } catch {
            logger.error("Unable to persist the privacy-safe maintenance event log")
        }
    }

    private static func pruneMigrationBackups() {
        guard let files = try? FileManager.default.contentsOfDirectory(
            at: migrationBackupDirectory,
            includingPropertiesForKeys: [.contentModificationDateKey],
            options: [.skipsHiddenFiles]
        ) else { return }
        let sorted = files.sorted {
            let left = (try? $0.resourceValues(forKeys: [.contentModificationDateKey]).contentModificationDate) ?? .distantPast
            let right = (try? $1.resourceValues(forKeys: [.contentModificationDateKey]).contentModificationDate) ?? .distantPast
            return left > right
        }
        for file in sorted.dropFirst(maximumMigrationBackupCount) {
            try? FileManager.default.removeItem(at: file)
        }
    }

    private static func filenames(in directory: URL) -> Set<String> {
        Set((try? FileManager.default.contentsOfDirectory(
            at: directory,
            includingPropertiesForKeys: nil,
            options: [.skipsHiddenFiles]
        ).map(\.lastPathComponent)) ?? [])
    }

    private static func directoryFileCount(at directory: URL) -> Int {
        (try? FileManager.default.contentsOfDirectory(
            at: directory,
            includingPropertiesForKeys: nil,
            options: [.skipsHiddenFiles]
        ).count) ?? 0
    }
}

private extension URL {
    var fileExists: Bool { FileManager.default.fileExists(atPath: path) }
}
