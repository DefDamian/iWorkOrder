import SwiftUI

struct SplashScreenView: View {
    var body: some View {
        ZStack {
            Color("LaunchBackground")
                .ignoresSafeArea()

            Image("LaunchLogo")
                .resizable()
                .scaledToFit()
                .frame(width: 170, height: 170)
                .accessibilityHidden(true)
        }
        .accessibilityHidden(true)
    }
}

struct SplashRootView: View {
    @EnvironmentObject private var store: AppStore
    @Environment(\.accessibilityReduceMotion) private var reduceMotion
#if DEBUG
    @State private var showSplash = !UITestingConfiguration.skipsSplash
#else
    @State private var showSplash = true
#endif

    var body: some View {
        ZStack {
            RootView()
                .environmentObject(store)
                .opacity(showSplash ? 0 : 1)

            if showSplash {
                SplashScreenView()
                    .transition(.opacity)
                    .zIndex(1)
            }
        }
        .task {
#if DEBUG
            guard !UITestingConfiguration.skipsSplash else { return }
#endif
            try? await Task.sleep(nanoseconds: reduceMotion ? 60_000_000 : 320_000_000)
            if reduceMotion {
                showSplash = false
            } else {
                withAnimation(.easeOut(duration: 0.18)) {
                    showSplash = false
                }
            }
        }
    }
}
