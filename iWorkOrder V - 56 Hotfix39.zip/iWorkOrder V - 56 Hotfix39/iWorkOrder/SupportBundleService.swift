import Foundation
import CryptoKit

struct SupportBundleContent: Codable, Equatable, Sendable {
    var formatIdentifier: String
    var formatVersion: Int
    var reportID: UUID
    var generatedAt: Date
    var applicationVersion: String
    var dataSchemaVersion: Int
    var legalVersion: String
    var diagnosticReport: String
    var maintenanceReport: String
    var reliabilitySummary: RuntimeReliabilitySummary
    var recentEvents: [MaintenanceEvent]
}

struct SupportBundleEnvelope: Codable, Equatable, Sendable {
    var content: SupportBundleContent
    var contentSHA256: String
}

enum SupportBundleError: LocalizedError, Equatable {
    case unableToEncode
    case unreadableBundle
    case unsupportedFormat
    case checksumMismatch

    var errorDescription: String? {
        switch self {
        case .unableToEncode:
            return "The privacy-safe support bundle could not be created."
        case .unreadableBundle:
            return "The support bundle could not be read."
        case .unsupportedFormat:
            return "The selected file is not a supported iWorkOrder support bundle."
        case .checksumMismatch:
            return "The support bundle failed its integrity check and should not be shared."
        }
    }
}

enum SupportBundleService {
    static let formatIdentifier = "com.damiancedeno.iworkorder.support"
    static let formatVersion = 1
    static let maximumRecentEventCount = 100

    @MainActor
    static func writeBundle(for store: AppStore, generatedAt: Date = Date()) throws -> URL {
        let diagnostics = DiagnosticReportService.context(for: store, generatedAt: generatedAt)
        let health = store.runMaintenanceHealthCheck()
        let content = SupportBundleContent(
            formatIdentifier: formatIdentifier,
            formatVersion: formatVersion,
            reportID: UUID(),
            generatedAt: generatedAt,
            applicationVersion: AppBuildInfo.displayVersion,
            dataSchemaVersion: AppDataSchema.currentVersion,
            legalVersion: LegalContent.currentVersion,
            diagnosticReport: DiagnosticReportService.reportText(for: diagnostics),
            maintenanceReport: MaintenanceService.reportText(health: health),
            reliabilitySummary: RuntimeReliabilityService.summary(at: generatedAt),
            recentEvents: Array(MaintenanceService.events().suffix(maximumRecentEventCount))
        )

        do {
            let envelope = try makeEnvelope(content: content)
            let outputData = try JSONEncoder.pretty.encode(envelope)
            let output = try outputURL(generatedAt: generatedAt)
            try outputData.write(
                to: output,
                options: [.atomic, .completeFileProtectionUntilFirstUserAuthentication]
            )
            _ = try validateBundle(at: output)
            MaintenanceService.record(kind: .supportBundleExport, outcome: .success, itemCount: content.recentEvents.count)
            return output
        } catch let error as SupportBundleError {
            MaintenanceService.record(kind: .supportBundleExport, outcome: .failure)
            throw error
        } catch {
            MaintenanceService.record(kind: .supportBundleExport, outcome: .failure)
            throw SupportBundleError.unableToEncode
        }
    }

    static func makeEnvelope(content: SupportBundleContent) throws -> SupportBundleEnvelope {
        guard let contentData = try? JSONEncoder.pretty.encode(content) else {
            throw SupportBundleError.unableToEncode
        }
        return SupportBundleEnvelope(
            content: content,
            contentSHA256: sha256(contentData)
        )
    }

    static func validateBundle(at url: URL) throws -> SupportBundleEnvelope {
        guard let data = try? Data(contentsOf: url),
              let envelope = try? JSONDecoder.iso8601.decode(SupportBundleEnvelope.self, from: data) else {
            throw SupportBundleError.unreadableBundle
        }
        guard envelope.content.formatIdentifier == formatIdentifier,
              envelope.content.formatVersion == formatVersion else {
            throw SupportBundleError.unsupportedFormat
        }
        guard let contentData = try? JSONEncoder.pretty.encode(envelope.content) else {
            throw SupportBundleError.unreadableBundle
        }
        guard sha256(contentData) == envelope.contentSHA256 else {
            throw SupportBundleError.checksumMismatch
        }
        return envelope
    }

    private static func outputURL(generatedAt: Date) throws -> URL {
        let formatter = DateFormatter()
        formatter.locale = Locale(identifier: "en_US_POSIX")
        formatter.timeZone = TimeZone(secondsFromGMT: 0)
        formatter.dateFormat = "yyyyMMdd-HHmmss"
        let directory = FileManager.default.temporaryDirectory
            .appendingPathComponent("iWorkOrderSupportBundles", isDirectory: true)
        try FileManager.default.createDirectory(at: directory, withIntermediateDirectories: true)

        if let existing = try? FileManager.default.contentsOfDirectory(
            at: directory,
            includingPropertiesForKeys: nil,
            options: [.skipsHiddenFiles]
        ) {
            for file in existing where file.pathExtension.lowercased() == "iworkordersupport" {
                try? FileManager.default.removeItem(at: file)
            }
        }

        return directory.appendingPathComponent(
            "iWorkOrder-Support-\(formatter.string(from: generatedAt)).iworkordersupport"
        )
    }

    private static func sha256(_ data: Data) -> String {
        SHA256.hash(data: data).map { String(format: "%02x", $0) }.joined()
    }
}
