import Foundation
import SwiftUI
import UserNotifications
import UIKit

@MainActor
final class AppStore: ObservableObject {
    @Published var profile = UserProfile()
    @Published var workOrders: [WorkOrder] = []
    @Published var assets: [AssetRecord] = []
    @Published var tenants: [TenantContact] = []
    @Published private(set) var categories: [WorkOrderCategory] = WorkOrderCategory.defaultCategories
    @Published var selectedStatus: WorkOrderStatus = .inProgress
    @Published var filters = WorkOrderFilters()
    @Published var lastSynced: Date?
    @Published var isOnline = false
    @Published var cloudSyncState: CloudSyncState = .idle
    @Published var cloudSyncDetail = "iCloud sync has not run yet."
    @Published var deepLinkedOrderID: UUID?
    @Published var lastErrorMessage: String?
    @Published private(set) var notificationPermissionNeedsAttention = false
    @Published private(set) var isBackupOperationInProgress = false
    @Published private(set) var cloudSyncPausedForRecovery = RuntimeReliabilityService.isCloudSyncPaused
    @Published private(set) var isOnboardingComplete = false
    @Published private(set) var shouldOfferInitialDataRecovery = false
    @Published private(set) var hasCompletedPermissionSetup = false
    @Published private(set) var dataCompatibilityMessage: String?
    private var didLoad = false
    private var pendingRevisionRepairOrderIDs = Set<UUID>()
    private var pendingCloudSyncTask: Task<Void, Never>?
    private var cloudSyncGeneration = 0
    private var isErasingCloudData = false
    private var categoryConfigurationUpdatedAt: Date?
    private var profileConfigurationUpdatedAt: Date?
    private var lastCommittedProfile = UserProfile()
    /// Timestamp of the most recent committed content mutation. This must not
    /// advance merely because the app launches, checkpoints, or syncs.
    private var contentModifiedAt: Date?
    /// True after this device has a recoverable local snapshot. Pre-onboarding
    /// iCloud download is only safe when no local state exists yet.
    private var hasPersistedLocalState = false
    /// Set only when restore recovery cannot prove whether attachment rollback
    /// completed. Further writes stay blocked so later revisions cannot destroy
    /// the evidence needed to resolve the transaction safely on restart.
    private var restoreRecoveryWriteBlocked = false

    private let storage = StorageService()
    private let onboardingPersistence = OnboardingPersistenceService()
    private let permissionSetupPersistence = PermissionSetupPersistenceService()
    private let networkStatus = NetworkStatusService()
    let cloud = CloudSyncService()
    let notifications = NotificationService.shared

    init() {
        hasCompletedPermissionSetup = permissionSetupPersistence.hasCompletedReview
        notifications.openWorkOrder = { [weak self] id in self?.deepLinkedOrderID = id }
        notifications.schedulingError = { [weak self] message in
            self?.lastErrorMessage = message
        }
        networkStatus.statusChanged = { [weak self] online in
            Task { @MainActor in self?.networkStatusChanged(online) }
        }
#if DEBUG
        if !UITestingConfiguration.isEnabled {
            networkStatus.start()
        }
#else
        networkStatus.start()
#endif
        load()
    }

    var activeWorkOrders: [WorkOrder] { workOrders.filter { !$0.isDeleted }.sorted { $0.createdAt > $1.createdAt } }
    var priorityQueue: [WorkOrder] { activeWorkOrders.sorted { $0.latestEntry.priority.sortValue == $1.latestEntry.priority.sortValue ? $0.createdAt > $1.createdAt : $0.latestEntry.priority.sortValue < $1.latestEntry.priority.sortValue } }
    var trash: [WorkOrder] { workOrders.filter { $0.isDeleted }.sorted { ($0.deletedAt ?? $0.createdAt) > ($1.deletedAt ?? $1.createdAt) } }
    var reminderWorkOrders: [WorkOrder] { activeWorkOrders.filter { $0.latestEntry.reminderEnabled }.sorted { $0.latestEntry.reminderDate < $1.latestEntry.reminderDate } }
    var defaultCategory: WorkOrderCategory { categories.first ?? .other }
    var filterCategories: [WorkOrderCategory] {
        var result = categories
        var knownNames = Set(categories.map { categoryNameKey($0.rawValue) })
        for order in activeWorkOrders {
            let category = order.latestEntry.managedCategory
            let key = categoryNameKey(category.rawValue)
            if !knownNames.contains(key) {
                knownNames.insert(key)
                result.append(category)
            }
        }
        return result
    }

    func categoryOptions(including current: WorkOrderCategory? = nil) -> [WorkOrderCategory] {
        var options = categories
        if let current,
           !options.contains(where: { categoryNamesEqual($0.rawValue, current.rawValue) }) {
            options.append(current)
        }
        return options
    }

    func categorySelection(for current: WorkOrderCategory) -> WorkOrderCategory {
        categories.first(where: { categoryNamesEqual($0.rawValue, current.rawValue) }) ?? current
    }

    func containsManagedCategory(_ category: WorkOrderCategory) -> Bool {
        categories.contains(where: { categoryNamesEqual($0.rawValue, category.rawValue) })
    }

    @discardableResult
    func addCategory(named proposedName: String) -> Bool {
        let name = WorkOrderCategory.normalizedName(proposedName)
        guard !name.isEmpty else {
            lastErrorMessage = "Enter a category name before adding it."
            return false
        }
        guard name.count <= 60 else {
            lastErrorMessage = "Category names must be 60 characters or fewer."
            return false
        }
        guard !categories.contains(where: { categoryNamesEqual($0.rawValue, name) }) else {
            lastErrorMessage = "A category with that name already exists."
            return false
        }
        var updated = categories
        updated.append(WorkOrderCategory(rawValue: name))
        return persistCategoryConfiguration(updated)
    }

    @discardableResult
    func deleteCategories(at offsets: IndexSet) -> Bool {
        let selected = offsets.compactMap { categories.indices.contains($0) ? categories[$0] : nil }
        return deleteCategories(selected)
    }

    /// Deletes the categories the user actually selected, rather than deleting
    /// whatever happens to occupy the same list indexes after a sync or reorder.
    @discardableResult
    func deleteCategories(_ categoriesToDelete: [WorkOrderCategory]) -> Bool {
        guard !categoriesToDelete.isEmpty else { return true }
        let keysToDelete = Set(categoriesToDelete.map { categoryNameKey($0.rawValue) })
        let deleted = categories.filter { keysToDelete.contains(categoryNameKey($0.rawValue)) }
        guard !deleted.isEmpty else { return true }

        let updated = categories.filter { !keysToDelete.contains(categoryNameKey($0.rawValue)) }
        guard !updated.isEmpty else {
            lastErrorMessage = "At least one category must remain available."
            return false
        }
        guard persistCategoryConfiguration(updated) else { return false }
        if let selected = filters.category,
           keysToDelete.contains(categoryNameKey(selected.rawValue)),
           !activeWorkOrders.contains(where: { categoryNamesEqual($0.latestEntry.managedCategory.rawValue, selected.rawValue) }) {
            filters.category = nil
        }
        return true
    }

    @discardableResult
    func moveCategories(from source: IndexSet, to destination: Int) -> Bool {
        guard !source.isEmpty else { return true }
        let updated = WorkOrderCategory.reordered(categories, moving: source, to: destination)
        return persistCategoryConfiguration(updated)
    }

    func categoryUsageCount(_ category: WorkOrderCategory) -> Int {
        workOrders.filter { order in
            order.entries.contains(where: {
                categoryNamesEqual($0.managedCategory.rawValue, category.rawValue)
            })
        }.count
    }

    private func persistCategoryConfiguration(_ proposed: [WorkOrderCategory]) -> Bool {
        let normalized = normalizedCategories(proposed)
        guard !normalized.isEmpty else {
            lastErrorMessage = "At least one category must remain available."
            return false
        }
        let originalCategories = categories
        let originalUpdatedAt = categoryConfigurationUpdatedAt
        categories = normalized
        categoryConfigurationUpdatedAt = Date()
        guard save() else {
            categories = originalCategories
            categoryConfigurationUpdatedAt = originalUpdatedAt
            return false
        }
        return true
    }

    private func normalizedCategories(_ source: [WorkOrderCategory]?) -> [WorkOrderCategory] {
        let values = source ?? WorkOrderCategory.defaultCategories
        var result: [WorkOrderCategory] = []
        var seen = Set<String>()
        for category in values {
            let name = WorkOrderCategory.normalizedName(category.rawValue)
            guard !name.isEmpty, name.count <= 60 else { continue }
            let key = categoryNameKey(name)
            guard seen.insert(key).inserted else { continue }
            result.append(WorkOrderCategory(rawValue: name))
        }
        return result.isEmpty ? WorkOrderCategory.defaultCategories : result
    }

    private func categoryNamesEqual(_ left: String, _ right: String) -> Bool {
        categoryNameKey(left) == categoryNameKey(right)
    }

    private func categoryNameKey(_ value: String) -> String {
        WorkOrderCategory.identityKey(value)
    }

    private func unitIdentityKey(_ value: String) -> String {
        value
            .trimmingCharacters(in: .whitespacesAndNewlines)
            .folding(
                options: [.caseInsensitive, .diacriticInsensitive, .widthInsensitive],
                locale: Locale(identifier: "en_US_POSIX")
            )
    }

    var hasCurrentLegalAcceptance: Bool { LegalContent.isCurrentAcceptance(profile) }
    var isDataCompatibilityBlocked: Bool { dataCompatibilityMessage != nil }

    var filteredWorkOrders: [WorkOrder] {
        WorkOrderSearchEngine.filter(activeWorkOrders, status: selectedStatus, filters: filters)
    }

    func load() {
        guard !didLoad else { return }
        didLoad = true
        dataCompatibilityMessage = nil
        shouldOfferInitialDataRecovery = false
        hasCompletedPermissionSetup = permissionSetupPersistence.hasCompletedReview

#if DEBUG
        if UITestingConfiguration.isEnabled {
            loadUITestingState()
            return
        }
#else
        // Recovery pause was previously exposed as an internal troubleshooting
        // control. Public builds must not inherit a hidden manual pause state.
        if cloudSyncPausedForRecovery {
            RuntimeReliabilityService.setCloudSyncPaused(false)
            cloudSyncPausedForRecovery = false
        }
#endif

        MaintenanceService.noteLaunch()
        let cloudErasePending = cloud.isCloudErasePending()
        let cloudReplacementPending = cloud.isCloudReplacementPending()
        if cloudErasePending {
            storage.deleteAll()
            onboardingPersistence.clearCompletedFlag()
            profile = UserProfile()
            profile.iCloudEnabled = false
            profile.storageChoice = .localOnly
            profile.iCloudDisabledDate = Date()
            workOrders.removeAll()
            assets.removeAll()
            tenants.removeAll()
            categories = WorkOrderCategory.defaultCategories
            categoryConfigurationUpdatedAt = nil
            profileConfigurationUpdatedAt = nil
            contentModifiedAt = nil
            hasPersistedLocalState = false
            lastCommittedProfile = profile
            lastSynced = nil
            isOnboardingComplete = false
        } else {
            let loadedLocalSnapshot = storage.load()
            hasPersistedLocalState = loadedLocalSnapshot != nil
            if let compatibilityBlockMessage = storage.compatibilityBlockMessage {
                dataCompatibilityMessage = compatibilityBlockMessage
                lastErrorMessage = compatibilityBlockMessage
                cloudSyncState = .failed(compatibilityBlockMessage)
                cloudSyncDetail = "Local data is protected from changes until a compatible app version is installed."
                isOnboardingComplete = true
                shouldOfferInitialDataRecovery = false
                refreshNotifications()
                return
            }
            if let recoveryNotice = storage.recoveryNotice {
                lastErrorMessage = recoveryNotice
            }
            let recovery = BackupArchiveService.recoverInterruptedRestores(currentSnapshot: loadedLocalSnapshot)
            restoreRecoveryWriteBlocked = recovery.requiresWriteBlock
            if !recovery.warnings.isEmpty {
                lastErrorMessage = recovery.warnings.joined(separator: " ")
            }
            let localSnapshot = normalizedRevisionSnapshot(loadedLocalSnapshot)
            // Recover the local monotonic save counter from the snapshot itself.
            // A crash can occur after the atomic snapshot write but before the
            // UserDefaults counter is committed. Never let a later launch move
            // the counter backwards in that window.
            StorageService.commitSaveRevision(localSnapshot?.saveRevision ?? 0)
            let legacyCloudSnapshot = normalizedRevisionSnapshot(cloud.loadLegacySnapshot())
            if isDataCompatibilityBlocked {
                cloudSyncState = .failed(dataCompatibilityMessage ?? "Data compatibility check failed.")
                cloudSyncDetail = "Local and cloud changes are blocked until a compatible app version is installed."
                isOnboardingComplete = true
                shouldOfferInitialDataRecovery = false
                refreshNotifications()
                return
            }
            let preferredSnapshot = mergedSnapshot(localSnapshot, legacyCloudSnapshot)
            if let saved = preferredSnapshot {
                applySnapshotContents(saved)
                lastSynced = saved.lastSynced ?? cloud.lastSuccessfulSyncDate()
                if repairAndPersistLoadedState() {
                    hasPersistedLocalState = true
                }
            } else {
                lastSynced = cloud.lastSuccessfulSyncDate()
            }

            if !restoreRecoveryWriteBlocked {
                cleanupOrphanedLocalAttachments()
            }

            let recoveredPersistedSnapshot = preferredSnapshot != nil
            isOnboardingComplete = recoveredPersistedSnapshot && onboardingPersistence.hasCompletedOnboarding
            shouldOfferInitialDataRecovery = !recoveredPersistedSnapshot && !isOnboardingComplete
            if recoveredPersistedSnapshot, profile.legalAcceptedDate == nil {
                profile.legalAcceptedDate = onboardingPersistence.completedOnboardingDate
            }
            if recoveredPersistedSnapshot,
               profile.legalAcceptedVersion == nil,
               profile.legalAccepted,
               onboardingPersistence.completedLegalVersion == LegalContent.currentVersion {
                profile.legalAcceptedVersion = LegalContent.currentVersion
            }
        }

        if cloudErasePending {
            cloudSyncState = .offline
            cloudSyncDetail = "Cloud deletion is pending. Sync and restore are blocked until the network is available."
            if isOnline { Task { await completePendingCloudErase() } }
        } else if cloudReplacementPending {
            cloudSyncState = isOnline ? .idle : .offline
            cloudSyncDetail = isOnline
                ? "A restored backup is waiting to replace the private iCloud dataset."
                : "Backup restore is complete locally. Cloud replacement will resume when the network returns."
            if isOnline { Task { await completePendingCloudReplacement() } }
        } else if cloudSyncPausedForRecovery {
            cloudSyncState = .paused
            cloudSyncDetail = "Automatic and manual iCloud sync are paused. Local saves remain available."
        } else {
            cloudSyncState = profile.iCloudEnabled && profile.storageChoice == .iCloud ? .idle : .disabled
            if shouldOfferInitialDataRecovery {
                cloudSyncDetail = "Choose whether to restore existing data or start a new setup."
            } else if profile.iCloudEnabled && profile.storageChoice == .iCloud {
                Task { await bootstrapCloudSync() }
            }
        }
        refreshNotifications()
    }

    private func cleanupOrphanedLocalAttachments() {
        let referencedImages = Set(workOrders.flatMap { order in
            order.entries.flatMap { $0.images.map(\.filename) }
        })
        let referencedSignatures = Set(workOrders.flatMap { order in
            order.entries.compactMap(\.signatureFilename)
        })
        let imageCleanup = ImageStorageService.deleteUnreferenced(keeping: referencedImages)
        let signatureCleanup = SignatureStorageService.deleteUnreferenced(keeping: referencedSignatures)
        let failureCount = imageCleanup.failedFilenames.count + signatureCleanup.failedFilenames.count
        guard failureCount > 0 else { return }
        let warning = "Some unreferenced attachment files could not be removed. Cleanup will be retried on the next launch."
        if let existing = lastErrorMessage, !existing.isEmpty {
            lastErrorMessage = existing + " " + warning
        } else {
            lastErrorMessage = warning
        }
    }

#if DEBUG
    private func loadUITestingState() {
        invalidatePendingCloudSync()
        notifications.cancelAllNotifications()
        storage.deleteAll()
        onboardingPersistence.clearCompletedFlag()
        permissionSetupPersistence.clearCompletedReview()
        hasCompletedPermissionSetup = false
        StorageService.resetSaveRevision()
        AppTheme.selected = .defaultTheme
        RuntimeReliabilityService.setCloudSyncPaused(false)
        cloudSyncPausedForRecovery = false

        profile = UserProfile()
        profile.personName = "UI Test Superintendent"
        profile.propertyManagerCompanyName = "UI Test Property Management"
        profile.buildingAddress = "100 Test Avenue, New York, NY"
        profile.iCloudEnabled = false
        profile.iCloudDisabledDate = Date()
        profile.storageChoice = .localOnly
        profile.notificationsEnabled = false
        profile.emergencyNotificationsEnabled = false
        profile.faceIDEnabled = false
        workOrders.removeAll()
        assets.removeAll()
        tenants.removeAll()
        categories = WorkOrderCategory.defaultCategories
        categoryConfigurationUpdatedAt = nil
        profileConfigurationUpdatedAt = nil
        contentModifiedAt = nil
        hasPersistedLocalState = false
        lastCommittedProfile = profile
        selectedStatus = .inProgress
        filters = WorkOrderFilters()
        isOnline = false
        lastSynced = nil
        cloudSyncState = .disabled
        cloudSyncDetail = "Cloud sync is disabled during UI testing."
        lastErrorMessage = nil
        dataCompatibilityMessage = nil

        if UITestingConfiguration.startsBackupRecovery {
            profile.legalAccepted = false
            profile.legalAcceptedDate = nil
            profile.legalAcceptedVersion = nil
            isOnboardingComplete = false
            shouldOfferInitialDataRecovery = true
            return
        }

        if UITestingConfiguration.startsOnboarding {
            profile.legalAccepted = false
            profile.legalAcceptedDate = nil
            profile.legalAcceptedVersion = nil
            isOnboardingComplete = false
            shouldOfferInitialDataRecovery = false
            return
        }

        profile.legalAccepted = true
        profile.legalAcceptedDate = Date()
        profile.legalAcceptedVersion = UITestingConfiguration.startsLegalUpdate
            ? "ui-test-previous-legal-version"
            : LegalContent.currentVersion
        isOnboardingComplete = true
        shouldOfferInitialDataRecovery = false
        hasCompletedPermissionSetup = !UITestingConfiguration.startsPermissionSetup

        if UITestingConfiguration.seedsWorkOrders {
            var entry = WorkOrderEntry(
                area: "4A",
                issueDescription: "Leaking kitchen faucet",
                notes: "Seeded UI test record",
                handymanName: "Alex",
                category: .plumbing,
                priority: .high,
                entryPermitted: true,
                tenantPermission: true,
                entryMethod: .tenantLetIn
            )
            entry.reminderEnabled = false
            var order = WorkOrder(status: .inProgress, entries: [entry])
            record(&order, kind: .created, message: "Seeded for automated UI testing")
            record(&order, kind: .started, message: "Work order opened as in-progress")
            workOrders = [order]
        }
    }
#endif

    @discardableResult
    func save() -> Bool {
        guard !cloud.isCloudErasePending() else {
            lastErrorMessage = "Data deletion is still pending. Connect to the internet and let deletion finish before saving new records or completing setup."
            return false
        }
        guard !restoreRecoveryWriteBlocked else {
            lastErrorMessage = "Local changes are temporarily blocked because an interrupted restore could not be resolved safely. Restart the app to retry recovery before editing data."
            return false
        }
        guard !isBackupOperationInProgress else {
            lastErrorMessage = "Wait for the current backup or restore operation to finish, then try again."
            return false
        }
        guard !isDataCompatibilityBlocked else { return false }
        guard validateCurrentRevisionHistoryForPersistence() else { return false }
        let saveStartedAt = Date()
        let workOrdersBeforeIntegrityRepair = workOrders
        applyPendingRevisionRepairAuditNotices()
        enforceRevisionIdentityIntegrity()
        enforceAuditIntegrity()
        enforceSignedLockIntegrity()

        let originalProfileConfigurationUpdatedAt = profileConfigurationUpdatedAt
        if profile != lastCommittedProfile {
            profileConfigurationUpdatedAt = Date()
        }

        let snapshot = currentSnapshot(incrementSaveRevision: true)
        guard storage.save(snapshot) else {
            workOrders = workOrdersBeforeIntegrityRepair
            profileConfigurationUpdatedAt = originalProfileConfigurationUpdatedAt
            lastErrorMessage = "Local save failed. Check device storage and try again."
            MaintenanceService.record(
                kind: .localSave,
                outcome: .failure,
                durationMilliseconds: Int(Date().timeIntervalSince(saveStartedAt) * 1000),
                itemCount: snapshot.workOrders.count
            )
            return false
        }
        StorageService.commitSaveRevision(snapshot.saveRevision ?? StorageService.currentSaveRevision())
        hasPersistedLocalState = true
        contentModifiedAt = snapshot.snapshotSavedAt
        profileConfigurationUpdatedAt = snapshot.profileConfigurationUpdatedAt
        lastCommittedProfile = snapshot.profile
        pendingRevisionRepairOrderIDs.removeAll()
        MaintenanceService.record(
            kind: .localSave,
            outcome: .success,
            durationMilliseconds: Int(Date().timeIntervalSince(saveStartedAt) * 1000),
            itemCount: snapshot.workOrders.count
        )
        lastErrorMessage = nil

        guard !cloud.isCloudErasePending() else {
            invalidatePendingCloudSync()
            cloudSyncState = .failed(CloudSyncError.cloudErasePending.localizedDescription)
            cloudSyncDetail = CloudSyncError.cloudErasePending.localizedDescription
            return true
        }
        if cloud.isCloudReplacementPending() {
            scheduleCloudReplacement(snapshot)
            return true
        }
        guard !cloudSyncPausedForRecovery else {
            invalidatePendingCloudSync()
            cloudSyncState = .paused
            cloudSyncDetail = "iCloud sync is paused for recovery. This change is saved locally only."
            return true
        }
        guard isOnboardingComplete else {
            invalidatePendingCloudSync()
            cloudSyncState = .idle
            cloudSyncDetail = "Setup is not complete. Changes are saved locally and iCloud upload has not started."
            return true
        }
        guard profile.iCloudEnabled && profile.storageChoice == .iCloud else {
            invalidatePendingCloudSync()
            cloudSyncState = .disabled
            cloudSyncDetail = "Data is saving only on this device."
            return true
        }
        scheduleCloudSync(snapshot)
        return true
    }

    private func validateCurrentRevisionHistoryForPersistence() -> Bool {
        let invalidCount = workOrders.reduce(into: 0) { count, order in
            if order.entries.isEmpty { count += 1 }
        }
        guard invalidCount == 0 else {
            lastErrorMessage = "Data integrity protection stopped this operation because \(invalidCount) work-order record(s) have missing revision history. Existing data was left unchanged."
            return false
        }
        return true
    }

    private func currentSnapshot(incrementSaveRevision: Bool) -> AppSnapshot {
        AppSnapshot(
            profile: profile,
            workOrders: workOrders,
            assets: assets,
            tenants: tenants,
            categories: categories,
            categoryConfigurationUpdatedAt: categoryConfigurationUpdatedAt,
            profileConfigurationUpdatedAt: profileConfigurationUpdatedAt,
            lastSynced: lastSynced,
            snapshotSavedAt: incrementSaveRevision ? Date() : contentModifiedAt,
            deviceID: DeviceIdentity.current,
            saveRevision: incrementSaveRevision ? StorageService.nextSaveRevisionCandidate() : StorageService.currentSaveRevision(),
            dataSchemaVersion: AppDataSchema.currentVersion
        )
    }

    @discardableResult
    private func repairAndPersistLoadedState() -> Bool {
        persistStateForCloudOperation(
            failureMessage: "Data integrity repairs could not be written to protected local storage. The repair remains pending and will be retried."
        ) != nil
    }

    /// Persists the current state for a sync/restore boundary without inventing
    /// a new content-modification timestamp. Integrity repairs are real content
    /// changes, so only those consume a save revision and advance freshness.
    private func persistStateForCloudOperation(failureMessage: String) -> AppSnapshot? {
        guard !cloud.isCloudErasePending() else {
            lastErrorMessage = "Wait for pending data deletion to finish before saving or synchronizing."
            return nil
        }
        guard !restoreRecoveryWriteBlocked else {
            lastErrorMessage = "Cloud operations are paused until interrupted restore recovery is resolved. Restart the app to retry recovery."
            return nil
        }
        guard validateCurrentRevisionHistoryForPersistence() else { return nil }
        let workOrdersBeforeIntegrityRepair = workOrders
        applyPendingRevisionRepairAuditNotices()
        enforceRevisionIdentityIntegrity()
        enforceAuditIntegrity()
        enforceSignedLockIntegrity()

        let repairsChangedData = workOrders != workOrdersBeforeIntegrityRepair
        let profileChanged = profile != lastCommittedProfile
        let originalProfileConfigurationUpdatedAt = profileConfigurationUpdatedAt
        if profileChanged {
            profileConfigurationUpdatedAt = Date()
        }
        let hasCommittedMutation = repairsChangedData || profileChanged
        let snapshot = currentSnapshot(incrementSaveRevision: hasCommittedMutation)
        guard storage.save(snapshot) else {
            workOrders = workOrdersBeforeIntegrityRepair
            profileConfigurationUpdatedAt = originalProfileConfigurationUpdatedAt
            lastErrorMessage = failureMessage
            return nil
        }
        hasPersistedLocalState = true
        if hasCommittedMutation {
            StorageService.commitSaveRevision(snapshot.saveRevision ?? StorageService.currentSaveRevision())
        }
        contentModifiedAt = snapshot.snapshotSavedAt
        profileConfigurationUpdatedAt = snapshot.profileConfigurationUpdatedAt
        lastCommittedProfile = snapshot.profile
        pendingRevisionRepairOrderIDs.removeAll()
        return snapshot
    }

    /// Lifecycle checkpoints protect in-progress onboarding fields without
    /// pretending that merely backgrounding the app is a new cloud conflict.
    func persistLifecycleCheckpoint() {
        guard !restoreRecoveryWriteBlocked, !isBackupOperationInProgress, !isDataCompatibilityBlocked,
              !cloud.isCloudErasePending() else { return }
        guard validateCurrentRevisionHistoryForPersistence() else { return }
        let profileChanged = profile != lastCommittedProfile
        let originalProfileConfigurationUpdatedAt = profileConfigurationUpdatedAt
        if profileChanged {
            profileConfigurationUpdatedAt = Date()
        }
        let snapshot = currentSnapshot(incrementSaveRevision: profileChanged)
        guard storage.save(snapshot) else {
            profileConfigurationUpdatedAt = originalProfileConfigurationUpdatedAt
            return
        }
        hasPersistedLocalState = true
        if profileChanged {
            StorageService.commitSaveRevision(snapshot.saveRevision ?? StorageService.currentSaveRevision())
        }
        contentModifiedAt = snapshot.snapshotSavedAt
        profileConfigurationUpdatedAt = snapshot.profileConfigurationUpdatedAt
        lastCommittedProfile = snapshot.profile
    }

    private func applySnapshotContents(_ snapshot: AppSnapshot) {
        Task { await WorkOrderImageThumbnailCache.shared.removeAll() }
        profile = snapshot.profile
        profileConfigurationUpdatedAt = snapshot.profileConfigurationUpdatedAt
        lastCommittedProfile = snapshot.profile
        workOrders = snapshot.workOrders
        assets = snapshot.assets ?? []
        tenants = snapshot.tenants ?? []
        categories = normalizedCategories(snapshot.categories)
        categoryConfigurationUpdatedAt = snapshot.categoryConfigurationUpdatedAt
        contentModifiedAt = snapshot.snapshotSavedAt
    }

    private struct InMemorySnapshotContents {
        let profile: UserProfile
        let workOrders: [WorkOrder]
        let assets: [AssetRecord]
        let tenants: [TenantContact]
        let categories: [WorkOrderCategory]
        let categoryConfigurationUpdatedAt: Date?
        let profileConfigurationUpdatedAt: Date?
        let lastCommittedProfile: UserProfile
        let lastSynced: Date?
        let contentModifiedAt: Date?
        let hasPersistedLocalState: Bool
        let pendingRevisionRepairOrderIDs: Set<UUID>
    }

    private func captureInMemorySnapshotContents() -> InMemorySnapshotContents {
        InMemorySnapshotContents(
            profile: profile,
            workOrders: workOrders,
            assets: assets,
            tenants: tenants,
            categories: categories,
            categoryConfigurationUpdatedAt: categoryConfigurationUpdatedAt,
            profileConfigurationUpdatedAt: profileConfigurationUpdatedAt,
            lastCommittedProfile: lastCommittedProfile,
            lastSynced: lastSynced,
            contentModifiedAt: contentModifiedAt,
            hasPersistedLocalState: hasPersistedLocalState,
            pendingRevisionRepairOrderIDs: pendingRevisionRepairOrderIDs
        )
    }

    private func restoreInMemorySnapshotContents(_ state: InMemorySnapshotContents) {
        profile = state.profile
        workOrders = state.workOrders
        assets = state.assets
        tenants = state.tenants
        categories = state.categories
        categoryConfigurationUpdatedAt = state.categoryConfigurationUpdatedAt
        profileConfigurationUpdatedAt = state.profileConfigurationUpdatedAt
        lastCommittedProfile = state.lastCommittedProfile
        lastSynced = state.lastSynced
        contentModifiedAt = state.contentModifiedAt
        hasPersistedLocalState = state.hasPersistedLocalState
        pendingRevisionRepairOrderIDs = state.pendingRevisionRepairOrderIDs
    }

    private func mergedSnapshot(_ local: AppSnapshot?, _ cloud: AppSnapshot?) -> AppSnapshot? {
        ConflictMergeService.merge(local: local, cloud: cloud)
    }

    private func normalizedRevisionSnapshot(_ snapshot: AppSnapshot?) -> AppSnapshot? {
        guard let sourceSnapshot = snapshot else { return nil }
        var snapshot: AppSnapshot
        do {
            snapshot = try MaintenanceService.migrate(sourceSnapshot).snapshot
        } catch {
            let message = (error as? LocalizedError)?.errorDescription ?? error.localizedDescription
            dataCompatibilityMessage = message
            lastErrorMessage = message
            invalidatePendingCloudSync()
            MaintenanceService.record(kind: .dataMigration, outcome: .blocked)
            return nil
        }

        var seenWorkOrderIDs = Set<UUID>()
        let duplicateWorkOrderIDs = Set(snapshot.workOrders.compactMap { order in
            seenWorkOrderIDs.insert(order.id).inserted ? nil : order.id
        })
        if !duplicateWorkOrderIDs.isEmpty {
            snapshot.workOrders = ConflictMergeService.coalesceWorkOrders(snapshot.workOrders)
            pendingRevisionRepairOrderIDs.formUnion(duplicateWorkOrderIDs)
        }

        snapshot.workOrders = snapshot.workOrders.map { order in
            var normalizedOrder = order
            var occurrenceCounts: [UUID: Int] = [:]
            var seenIDs = Set<UUID>()
            var previousDate: Date?
            var repaired = false

            for entryIndex in normalizedOrder.entries.indices {
                var entry = normalizedOrder.entries[entryIndex]
                let originalID = entry.id
                let occurrence = occurrenceCounts[originalID, default: 0]
                occurrenceCounts[originalID] = occurrence + 1

                if occurrence > 0 {
                    var collisionIndex = occurrence
                    var replacementID = deterministicRevisionID(orderID: order.id, originalID: originalID, occurrence: collisionIndex)
                    while seenIDs.contains(replacementID) {
                        collisionIndex += 1
                        replacementID = deterministicRevisionID(orderID: order.id, originalID: originalID, occurrence: collisionIndex)
                    }
                    entry.id = replacementID
                    if let previousDate, entry.createdAt <= previousDate {
                        entry.createdAt = previousDate.addingTimeInterval(0.001)
                    }
                    normalizedOrder.entries[entryIndex] = entry
                    repaired = true
                }

                seenIDs.insert(entry.id)
                previousDate = max(previousDate ?? entry.createdAt, entry.createdAt)
            }

            if repaired { pendingRevisionRepairOrderIDs.insert(order.id) }
            return normalizedOrder
        }

        return snapshot
    }

    private func deterministicRevisionID(orderID: UUID, originalID: UUID, occurrence: Int) -> UUID {
        let seedBytes = Array("\(orderID.uuidString)|\(originalID.uuidString)|\(occurrence)".utf8)
        let first = stableHash64(seedBytes, initialValue: 0xcbf29ce484222325)
        let second = stableHash64(seedBytes.reversed(), initialValue: 0x9e3779b185ebca87)
        var bytes: [UInt8] = []
        for value in [first, second] {
            for shift in stride(from: 56, through: 0, by: -8) {
                bytes.append(UInt8((value >> UInt64(shift)) & 0xFF))
            }
        }
        bytes[6] = (bytes[6] & 0x0F) | 0x50
        bytes[8] = (bytes[8] & 0x3F) | 0x80
        let hex = bytes.map { String(format: "%02x", $0) }.joined()
        let uuidString = "\(hex.prefix(8))-\(hex.dropFirst(8).prefix(4))-\(hex.dropFirst(12).prefix(4))-\(hex.dropFirst(16).prefix(4))-\(hex.dropFirst(20).prefix(12))"
        return UUID(uuidString: uuidString) ?? UUID()
    }

    private func stableHash64<S: Sequence>(_ bytes: S, initialValue: UInt64) -> UInt64 where S.Element == UInt8 {
        var hash = initialValue
        for byte in bytes {
            hash ^= UInt64(byte)
            hash &*= 0x100000001b3
        }
        return hash
    }

    private func applyPendingRevisionRepairAuditNotices() {
        let repairMessage = "Record identity metadata repaired to preserve unique work-order and revision identities"
        for orderID in pendingRevisionRepairOrderIDs {
            guard let index = workOrders.firstIndex(where: { $0.id == orderID }) else { continue }
            ensureRecord(&workOrders[index], kind: .integrityNotice, message: repairMessage)
        }
    }


    func acceptCurrentLegalAgreement() {
        let originalProfile = profile
        let acceptedDate = Date()
        profile.legalAccepted = true
        profile.legalAcceptedDate = acceptedDate
        profile.legalAcceptedVersion = LegalContent.currentVersion
        guard save() else {
            profile = originalProfile
            return
        }
        if isOnboardingComplete {
            onboardingPersistence.markCompleted(date: acceptedDate, legalVersion: LegalContent.currentVersion)
        }
    }

    func declineLegalAgreement() {
        let originalProfile = profile
        profile.legalAccepted = false
        profile.legalAcceptedDate = nil
        profile.legalAcceptedVersion = nil
        guard save() else {
            profile = originalProfile
            return
        }
    }

    func completePermissionSetup() {
        permissionSetupPersistence.markCompleted()
        hasCompletedPermissionSetup = true
    }

    func completeOnboarding() {
        guard hasCurrentLegalAcceptance else {
            lastErrorMessage = "Review and accept the current legal agreement before completing setup."
            return
        }
        let originalProfile = profile
        let originalCompletionState = isOnboardingComplete
        profile.iCloudEnabled = profile.storageChoice == .iCloud
        isOnboardingComplete = true
        shouldOfferInitialDataRecovery = false
        guard save() else {
            profile = originalProfile
            isOnboardingComplete = originalCompletionState
            return
        }
        onboardingPersistence.markCompleted(
            date: profile.legalAcceptedDate ?? Date(),
            legalVersion: profile.legalAcceptedVersion
        )
    }

    func beginFreshOnboarding() {
        guard !isOnboardingComplete else { return }
        shouldOfferInitialDataRecovery = false
        lastErrorMessage = nil
        if profile.iCloudEnabled && profile.storageChoice == .iCloud {
            cloudSyncState = isOnline ? .idle : .offline
            cloudSyncDetail = isOnline
                ? "New setup selected. iCloud upload will begin only after setup is complete."
                : "New setup selected. iCloud will remain unavailable until the network returns."
        } else {
            cloudSyncState = .disabled
            cloudSyncDetail = "New setup selected. Data is saving only on this device."
        }
    }

    func restoreFromICloudBeforeOnboarding() async -> Bool {
        guard shouldOfferInitialDataRecovery, !isOnboardingComplete, !hasPersistedLocalState else {
            lastErrorMessage = "iCloud recovery is only available before a new setup has started."
            return false
        }
        guard !cloud.isCloudErasePending() else {
            lastErrorMessage = CloudSyncError.cloudErasePending.localizedDescription
            return false
        }
        guard !cloud.isCloudReplacementPending() else {
            lastErrorMessage = CloudSyncError.cloudReplacementPending.localizedDescription
            return false
        }
        guard !restoreRecoveryWriteBlocked else {
            lastErrorMessage = "A previous restore still needs recovery. Restart the app before restoring from iCloud."
            return false
        }
        guard !isBackupOperationInProgress else {
            lastErrorMessage = "Another backup or restore operation is already running."
            return false
        }

        isBackupOperationInProgress = true
        invalidatePendingCloudSync()
        let generation = cloudSyncGeneration
        cloudSyncState = .checkingAccount
        cloudSyncDetail = "Checking iCloud for an existing iWorkOrder backup."
        defer { isBackupOperationInProgress = false }

        do {
            guard let outcome = try await cloud.downloadFromCloud() else {
                guard generation == cloudSyncGeneration else { return false }
                cloudSyncState = .idle
                cloudSyncDetail = "No existing iWorkOrder backup was found in iCloud."
                lastErrorMessage = nil
                return false
            }
            guard generation == cloudSyncGeneration else { return false }
            guard let recovered = normalizedRevisionSnapshot(outcome.snapshot), !isDataCompatibilityBlocked else {
                if let message = dataCompatibilityMessage {
                    cloudSyncState = .failed(message)
                    cloudSyncDetail = message
                    lastErrorMessage = message
                }
                return false
            }

            let previousState = captureInMemorySnapshotContents()
            let previousLastSynced = lastSynced
            let previousHasPersistedLocalState = hasPersistedLocalState
            applySnapshotContents(recovered)
            lastSynced = outcome.syncedAt

            guard repairAndPersistLoadedState() else {
                restoreInMemorySnapshotContents(previousState)
                lastSynced = previousLastSynced
                hasPersistedLocalState = previousHasPersistedLocalState
                refreshNotifications()
                cloudSyncState = .failed(lastErrorMessage ?? "Existing iCloud data could not be stored locally.")
                cloudSyncDetail = "iCloud recovery stopped because the downloaded backup could not be committed to protected local storage."
                return false
            }

            isOnboardingComplete = true
            shouldOfferInitialDataRecovery = false
            onboardingPersistence.markCompleted(
                date: profile.legalAcceptedDate ?? Date(),
                legalVersion: profile.legalAcceptedVersion
            )
            refreshNotifications()
            if profile.iCloudEnabled && profile.storageChoice == .iCloud {
                cloudSyncState = .synced(outcome.syncedAt)
                cloudSyncDetail = "Existing iCloud data was restored. Setup was skipped."
            } else {
                cloudSyncState = .disabled
                cloudSyncDetail = "Existing iCloud data was restored. Setup was skipped and iCloud Sync remains off."
            }
            lastErrorMessage = nil
            return true
        } catch {
            guard generation == cloudSyncGeneration else { return false }
            updateCloudFailure(error)
            return false
        }
    }

    func resetOnboardingOnly() {
        let originalProfile = profile
        let originalCompletionState = isOnboardingComplete
        isOnboardingComplete = false
        shouldOfferInitialDataRecovery = false
        profile.legalAccepted = false
        profile.legalAcceptedDate = nil
        profile.legalAcceptedVersion = nil
        guard save() else {
            profile = originalProfile
            isOnboardingComplete = originalCompletionState
            return
        }
        onboardingPersistence.clearCompletedFlag()
        permissionSetupPersistence.clearCompletedReview()
        hasCompletedPermissionSetup = false
    }

    func eraseAllData() {
        invalidatePendingCloudSync()
        notifications.cancelAllNotifications()
        notifications.clearPendingRoute()
        deepLinkedOrderID = nil
        cloud.beginCloudErase()
        didLoad = false
        workOrders.removeAll()
        assets.removeAll()
        tenants.removeAll()
        categories = WorkOrderCategory.defaultCategories
        categoryConfigurationUpdatedAt = nil
        profileConfigurationUpdatedAt = nil
        contentModifiedAt = nil
        profile = UserProfile()
        profile.iCloudEnabled = false
        profile.storageChoice = .localOnly
        profile.iCloudDisabledDate = Date()
        lastCommittedProfile = profile
        selectedStatus = .inProgress
        filters = WorkOrderFilters()
        lastSynced = nil
        lastErrorMessage = nil
        dataCompatibilityMessage = nil
        cloudSyncState = isOnline ? .syncing : .offline
        cloudSyncDetail = isOnline
            ? "Deleting the private iCloud dataset."
            : "Local data was erased. Cloud deletion will resume when the network returns."
        isOnboardingComplete = false
        shouldOfferInitialDataRecovery = false
        onboardingPersistence.clearCompletedFlag()
        permissionSetupPersistence.clearCompletedReview()
        hasCompletedPermissionSetup = false
        let localEraseSucceeded = storage.deleteAll()
        Task { await WorkOrderImageThumbnailCache.shared.removeAll() }
        hasPersistedLocalState = false
        RuntimeReliabilityService.deleteAll()
        if !localEraseSucceeded {
            lastErrorMessage = "Some protected local app files could not be deleted yet. Cloud deletion will remain pending and local deletion will be retried."
        }
        cloudSyncPausedForRecovery = false
        restoreRecoveryWriteBlocked = false
        StorageService.resetSaveRevision()
        DeviceIdentity.reset()
        AppTheme.selected = .defaultTheme
        Task { await completePendingCloudErase() }
    }

    private func completePendingCloudErase() async {
        guard cloud.isCloudErasePending(), !isErasingCloudData else { return }
        guard isOnline else {
            cloudSyncState = .offline
            cloudSyncDetail = "Local data was erased. Cloud deletion is pending until the network returns. Sync and restore remain blocked."
            return
        }

        invalidatePendingCloudSync()
        isErasingCloudData = true
        cloudSyncState = .syncing
        cloudSyncDetail = "Deleting protected local app data before clearing the private iCloud dataset."
        defer { isErasingCloudData = false }

        // The cloud pending marker is our last protection against local data
        // resurrection. Never clear it by completing iCloud deletion until the
        // on-device snapshot, attachments, safety backups, and recovery journals
        // have actually been removed.
        guard storage.deleteAll() else {
            cloudSyncState = .failed("Local data deletion is incomplete.")
            cloudSyncDetail = "Some protected local app files could not be deleted. Cloud deletion remains pending and will be retried later."
            lastErrorMessage = cloudSyncDetail
            return
        }
        await WorkOrderImageThumbnailCache.shared.removeAll()
        RuntimeReliabilityService.deleteAll()
        hasPersistedLocalState = false
        cloudSyncDetail = "Deleting the private iCloud zone, records, photos, and signatures."

        do {
            try await cloud.deleteCloudData()
            cloudSyncState = .disabled
            cloudSyncDetail = "Local and iCloud app data were deleted."
            lastErrorMessage = nil
        } catch {
            updateCloudFailure(error)
            cloudSyncDetail += " Sync and restore remain blocked until cloud deletion succeeds."
        }
    }

    func restore(snapshot: AppSnapshot) {
        let originalProfile = profile
        let originalWorkOrders = workOrders
        let originalAssets = assets
        let originalTenants = tenants
        let originalCategories = categories
        let originalCategoryConfigurationUpdatedAt = categoryConfigurationUpdatedAt
        let originalProfileConfigurationUpdatedAt = profileConfigurationUpdatedAt
        let originalLastCommittedProfile = lastCommittedProfile
        let originalContentModifiedAt = contentModifiedAt
        let originalLastSynced = lastSynced
        let originalOnboardingState = isOnboardingComplete
        let originalInitialRecoveryState = shouldOfferInitialDataRecovery
        let originalPendingRepairIDs = pendingRevisionRepairOrderIDs

        guard var compatibleSnapshot = normalizedRevisionSnapshot(snapshot), !isDataCompatibilityBlocked else { return }
        let restoredAt = Date()
        compatibleSnapshot.snapshotSavedAt = restoredAt
        compatibleSnapshot.profileConfigurationUpdatedAt = restoredAt
        applySnapshotContents(compatibleSnapshot)
        lastSynced = compatibleSnapshot.lastSynced
        isOnboardingComplete = true
        shouldOfferInitialDataRecovery = false
        guard save() else {
            profile = originalProfile
            workOrders = originalWorkOrders
            assets = originalAssets
            tenants = originalTenants
            categories = originalCategories
            categoryConfigurationUpdatedAt = originalCategoryConfigurationUpdatedAt
            profileConfigurationUpdatedAt = originalProfileConfigurationUpdatedAt
            lastCommittedProfile = originalLastCommittedProfile
            contentModifiedAt = originalContentModifiedAt
            lastSynced = originalLastSynced
            isOnboardingComplete = originalOnboardingState
            shouldOfferInitialDataRecovery = originalInitialRecoveryState
            pendingRevisionRepairOrderIDs = originalPendingRepairIDs
            refreshNotifications()
            return
        }
        onboardingPersistence.markCompleted(
            date: profile.legalAcceptedDate ?? Date(),
            legalVersion: profile.legalAcceptedVersion
        )
        refreshNotifications()
    }

    @discardableResult
    func addQuick(area: String, description: String) -> Bool {
        var entry = WorkOrderEntry(
            area: area,
            issueDescription: description,
            handymanName: profile.role == .handyman ? profile.personName : "",
            category: .other,
            priority: .normal
        )
        entry.managedCategory = defaultCategory
        entry.normalizeUserEnteredText()
        guard entry.hasRequiredFields else {
            lastErrorMessage = "Enter both an area and an issue description before saving."
            return false
        }
        entry.entryPermitted = tenant(for: entry.area)?.entryPermission ?? false
        entry.tenantPermission = entry.entryPermitted
        var order = WorkOrder(status: .inProgress, entries: [entry])
        record(&order, kind: .created, message: "Ticket created by quick add")
        record(&order, kind: .started, message: "Work order opened as in-progress")

        let originalWorkOrders = workOrders
        workOrders.append(order)
        guard save() else {
            workOrders = originalWorkOrders
            refreshNotifications()
            return false
        }
        return true
    }

    @discardableResult
    func addFull(entry: WorkOrderEntry) -> Bool {
        var entry = entry
        entry.normalizeUserEnteredText()
        guard entry.hasRequiredFields else {
            lastErrorMessage = "Enter both an area and an issue description before saving."
            return false
        }
        entry.createdAt = Date()
        var order = WorkOrder(status: .inProgress, entries: [entry])
        record(&order, kind: .created, message: "Ticket created")
        record(&order, kind: .started, message: "Work order opened as in-progress")
        if entry.reminderEnabled { record(&order, kind: .reminderScheduled, message: "Reminder scheduled") }
        if !entry.images.isEmpty { record(&order, kind: .photoAdded, message: "\(entry.images.count) photo(s) added") }

        let originalWorkOrders = workOrders
        workOrders.append(order)
        guard save() else {
            workOrders = originalWorkOrders
            refreshNotifications()
            return false
        }
        refreshNotifications()
        if entry.priority == .emergency { HapticManager.warning() }
        return true
    }

    @discardableResult
    func update(
        order: WorkOrder,
        expectedLatestEntryID: UUID? = nil,
        newEntry: WorkOrderEntry?,
        status: WorkOrderStatus
    ) -> Bool {
        guard let index = workOrders.firstIndex(where: { $0.id == order.id }) else {
            lastErrorMessage = "This work order is no longer available. Return to the list and open it again."
            return false
        }
        guard !workOrders[index].isDeleted else {
            lastErrorMessage = "This work order was moved to Trash. Recover it before making changes."
            return false
        }
        if let expectedLatestEntryID,
           workOrders[index].latestEntry.id != expectedLatestEntryID {
            lastErrorMessage = "This work order changed while it was open. Your unsaved changes were not applied. Return to the list and reopen the latest revision."
            return false
        }
        if workOrders[index].isSignedAndLocked && newEntry == nil && status != workOrders[index].status {
            lastErrorMessage = "Signed work orders are locked. Use Making Changes to create a new revision."
            return false
        }

        var normalizedEntry = newEntry
        if normalizedEntry != nil {
            normalizedEntry?.normalizeUserEnteredText()
            guard normalizedEntry?.hasRequiredFields == true else {
                lastErrorMessage = "Enter both an area and an issue description before saving."
                return false
            }
        }

        let originalWorkOrders = workOrders
        var shouldWarnEmergency = false
        if let normalizedEntry {
            let previousEntry = workOrders[index].latestEntry
            let oldPriority = previousEntry.priority
            var revision = normalizedEntry
            revision.id = UUID()
            let now = Date()
            revision.createdAt = now > previousEntry.createdAt ? now : previousEntry.createdAt.addingTimeInterval(0.001)
            if revision.signatureFilename == previousEntry.signatureFilename {
                revision.signatureFilename = nil
                revision.signatureSignerName = nil
                revision.signatureCapturedAt = nil
                revision.signatureConsentVersion = nil
            }
            workOrders[index].entries.append(revision)
            shouldWarnEmergency = revision.priority == .emergency && oldPriority != .emergency
            record(&workOrders[index], kind: .edited, message: "New revision added")
            if !revision.images.isEmpty { record(&workOrders[index], kind: .photoAdded, message: "Revision saved with \(revision.images.count) photo(s)") }
            if let signatureFilename = revision.signatureFilename,
               !signatureFilename.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty {
                let signer = revision.signatureSignerName?.trimmingCharacters(in: .whitespacesAndNewlines)
                let message: String
                if let signer, !signer.isEmpty {
                    message = "Electronic signature captured for revision by \(signer)"
                } else {
                    message = "Electronic signature captured for revision"
                }
                record(&workOrders[index], kind: .signed, message: message, date: revision.signatureCapturedAt ?? revision.createdAt)
            }
        }
        if workOrders[index].status != status {
            record(&workOrders[index], kind: .statusChanged, message: "Status changed to \(status.rawValue)")
        }
        workOrders[index].status = status

        guard save() else {
            workOrders = originalWorkOrders
            refreshNotifications()
            return false
        }
        refreshNotifications()
        if shouldWarnEmergency { HapticManager.warning() }
        return true
    }

    func addAudit(to order: WorkOrder, message: String) {
        guard let index = workOrders.firstIndex(where: { $0.id == order.id }) else { return }
        // Signed completed revisions are immutable legal evidence. Merely viewing
        // one must not append or rewrite its embedded audit trail.
        guard !workOrders[index].isSignedAndLocked else { return }
        if message == "Work order opened", workOrders[index].auditLog.last?.message == message { return }
        let originalWorkOrders = workOrders
        record(&workOrders[index], kind: .edited, message: message)
        if !save() {
            workOrders = originalWorkOrders
        }
    }

    private func record(_ order: inout WorkOrder, kind: StatusEventKind, message: String, date: Date = Date()) {
        order.auditLog.append(AuditEvent(date: date, message: message))
        var entries = order.statusEntries ?? []
        entries.append(StatusEntry(kind: kind, date: date, detail: message))
        order.statusEntries = entries
    }

    private func ensureRecord(_ order: inout WorkOrder, kind: StatusEventKind, message: String, date: Date = Date()) {
        var statusEntries = order.statusEntries ?? []
        let existingStatus = statusEntries.first { $0.kind == kind && $0.detail == message }
        let existingAudit = order.auditLog.first { $0.message == message }
        let eventDate = existingStatus?.date ?? existingAudit?.date ?? date

        if existingAudit == nil {
            order.auditLog.append(AuditEvent(date: eventDate, message: message))
        }
        if existingStatus == nil {
            statusEntries.append(StatusEntry(kind: kind, date: eventDate, detail: message))
            order.statusEntries = statusEntries
        }
    }

    private func enforceRevisionIdentityIntegrity() {
        let repairMessage = "Revision identity metadata repaired to preserve unique work-order revisions"

        for orderIndex in workOrders.indices {
            var occurrenceCounts: [UUID: Int] = [:]
            var seenIDs = Set<UUID>()
            var repaired = false
            var previousDate: Date?

            for entryIndex in workOrders[orderIndex].entries.indices {
                var entry = workOrders[orderIndex].entries[entryIndex]
                let originalID = entry.id
                let occurrence = occurrenceCounts[originalID, default: 0]
                occurrenceCounts[originalID] = occurrence + 1

                if occurrence > 0 {
                    var collisionIndex = occurrence
                    var replacementID = deterministicRevisionID(orderID: workOrders[orderIndex].id, originalID: originalID, occurrence: collisionIndex)
                    while seenIDs.contains(replacementID) {
                        collisionIndex += 1
                        replacementID = deterministicRevisionID(orderID: workOrders[orderIndex].id, originalID: originalID, occurrence: collisionIndex)
                    }
                    entry.id = replacementID
                    if let previousDate, entry.createdAt <= previousDate {
                        entry.createdAt = previousDate.addingTimeInterval(0.001)
                    }
                    workOrders[orderIndex].entries[entryIndex] = entry
                    repaired = true
                }

                seenIDs.insert(entry.id)
                previousDate = max(previousDate ?? entry.createdAt, entry.createdAt)
            }

            if repaired {
                ensureRecord(&workOrders[orderIndex], kind: .integrityNotice, message: repairMessage)
            }
        }
    }

    private func enforceAuditIntegrity() {
        for index in workOrders.indices {
            repairLegacyIntegrityEvents(in: &workOrders[index])

            if workOrders[index].auditLog.isEmpty {
                ensureRecord(
                    &workOrders[index],
                    kind: .created,
                    message: "Recovered missing audit trail: original creation date preserved",
                    date: workOrders[index].createdAt
                )
            }

            let statusEntries = workOrders[index].statusEntries ?? []
            if statusEntries.isEmpty {
                ensureRecord(
                    &workOrders[index],
                    kind: .created,
                    message: "Recovered missing status audit entry",
                    date: workOrders[index].createdAt
                )
            }

            deduplicateGeneratedIntegrityEvents(in: &workOrders[index])
        }
    }

    private func enforceSignedLockIntegrity() {
        let completionMessage = "Completed work order locked for legal record"
        let unsignedMessage = "Integrity notice: completed work order has no attached signature file"

        for index in workOrders.indices {
            guard workOrders[index].status == .completed else { continue }
            let signatureReference = workOrders[index].latestEntry.signatureFilename?
                .trimmingCharacters(in: .whitespacesAndNewlines)
            let hasSignatureReference = signatureReference?.isEmpty == false
            let hasAttachedSignature = SignatureStorageService.isReadableImage(filename: signatureReference)

            if hasAttachedSignature {
                let hasSignedEvent = (workOrders[index].statusEntries ?? []).contains { $0.kind == .signed }
                if !hasSignedEvent {
                    let entry = workOrders[index].latestEntry
                    let signer = entry.signatureSignerName?.trimmingCharacters(in: .whitespacesAndNewlines)
                    let message: String
                    if let signer, !signer.isEmpty {
                        message = "Electronic signature attachment verified for completed work order by \(signer)"
                    } else {
                        message = "Electronic signature attachment verified for completed work order"
                    }
                    ensureRecord(
                        &workOrders[index],
                        kind: .signed,
                        message: message,
                        date: entry.signatureCapturedAt ?? entry.createdAt
                    )
                }
            } else {
                let message = hasSignatureReference
                    ? "Integrity notice: completed work order signature attachment is missing or unavailable"
                    : unsignedMessage
                ensureRecord(
                    &workOrders[index],
                    kind: .integrityNotice,
                    message: message,
                    date: workOrders[index].latestEntry.createdAt
                )
            }

            let hasCompletedEvent = (workOrders[index].statusEntries ?? []).contains { $0.kind == .completed }
            if !hasCompletedEvent {
                ensureRecord(
                    &workOrders[index],
                    kind: .completed,
                    message: completionMessage,
                    date: workOrders[index].latestEntry.createdAt
                )
            }

            deduplicateGeneratedIntegrityEvents(in: &workOrders[index])
        }
    }

    private func repairLegacyIntegrityEvents(in order: inout WorkOrder) {
        let legacyUnsignedMessage = "Completed work order verified without attached signature file"
        let legacySyntheticSignedMessage = "Completed work order signature state verified"
        let canonicalUnsignedMessage = "Integrity notice: completed work order has no attached signature file"
        let hasAttachedSignature = SignatureStorageService.isReadableImage(
            filename: order.latestEntry.signatureFilename
        )

        order.auditLog = order.auditLog.map { event in
            guard event.message == legacyUnsignedMessage || (!hasAttachedSignature && event.message == legacySyntheticSignedMessage) else { return event }
            var repaired = event
            repaired.message = canonicalUnsignedMessage
            return repaired
        }

        var statusEntries = order.statusEntries ?? []
        statusEntries = statusEntries.map { entry in
            guard entry.detail == legacyUnsignedMessage || (!hasAttachedSignature && entry.detail == legacySyntheticSignedMessage) else { return entry }
            var repaired = entry
            repaired.kind = .integrityNotice
            repaired.detail = canonicalUnsignedMessage
            return repaired
        }
        order.statusEntries = statusEntries
    }

    private func deduplicateGeneratedIntegrityEvents(in order: inout WorkOrder) {
        let generatedMessages: Set<String> = [
            "Revision identity metadata repaired to preserve unique work-order revisions",
            "Record identity metadata repaired to preserve unique work-order and revision identities",
            "Recovered missing audit trail: original creation date preserved",
            "Recovered missing status audit entry",
            "Integrity notice: completed work order has no attached signature file",
            "Integrity notice: completed work order signature attachment is missing or unavailable",
            "Electronic signature verified for completed work order",
            "Completed work order locked for legal record"
        ]

        var seenAuditMessages = Set<String>()
        order.auditLog = order.auditLog.filter { event in
            guard generatedMessages.contains(event.message) else { return true }
            return seenAuditMessages.insert(event.message).inserted
        }

        var seenStatusMessages = Set<String>()
        let statusEntries = order.statusEntries ?? []
        order.statusEntries = statusEntries.filter { entry in
            guard generatedMessages.contains(entry.detail) else { return true }
            return seenStatusMessages.insert("\(entry.kind.rawValue)|\(entry.detail)").inserted
        }
    }

    @discardableResult
    func moveToTrash(_ order: WorkOrder) -> Bool {
        guard let index = workOrders.firstIndex(where: { $0.id == order.id }) else { return false }
        let originalWorkOrders = workOrders
        workOrders[index].isDeleted = true
        workOrders[index].deletedAt = Date()
        record(&workOrders[index], kind: .deleted, message: "Moved to trash")
        guard save() else {
            workOrders = originalWorkOrders
            refreshNotifications()
            return false
        }
        refreshNotifications()
        return true
    }

    @discardableResult
    func recover(_ order: WorkOrder) -> Bool {
        guard let index = workOrders.firstIndex(where: { $0.id == order.id }) else { return false }
        let originalWorkOrders = workOrders
        workOrders[index].isDeleted = false
        workOrders[index].deletedAt = nil
        record(&workOrders[index], kind: .recovered, message: "Recovered from trash")
        guard save() else {
            workOrders = originalWorkOrders
            refreshNotifications()
            return false
        }
        refreshNotifications()
        return true
    }

    @discardableResult
    func recoverAll() -> Bool {
        let originalWorkOrders = workOrders
        let recoveredIDs = workOrders.indices.compactMap { index -> UUID? in
            guard workOrders[index].isDeleted else { return nil }
            workOrders[index].isDeleted = false
            workOrders[index].deletedAt = nil
            record(&workOrders[index], kind: .recovered, message: "Recovered from trash")
            return workOrders[index].id
        }
        guard !recoveredIDs.isEmpty else { return true }
        guard save() else {
            workOrders = originalWorkOrders
            refreshNotifications()
            return false
        }
        refreshNotifications()
        return true
    }

    @discardableResult
    func addAsset(_ asset: AssetRecord) -> Bool {
        var normalized = asset
        normalized.tag = normalized.tag.trimmingCharacters(in: .whitespacesAndNewlines)
        normalized.name = normalized.name.trimmingCharacters(in: .whitespacesAndNewlines)
        normalized.location = normalized.location.trimmingCharacters(in: .whitespacesAndNewlines)
        guard !normalized.tag.isEmpty else {
            lastErrorMessage = "Enter an asset tag before saving."
            return false
        }
        let originalAssets = assets
        assets.append(normalized)
        guard save() else {
            assets = originalAssets
            return false
        }
        return true
    }

    @discardableResult
    func addTenant(_ tenant: TenantContact) -> Bool {
        var normalized = tenant
        normalized.unit = normalized.unit.trimmingCharacters(in: .whitespacesAndNewlines)
        normalized.name = normalized.name.trimmingCharacters(in: .whitespacesAndNewlines)
        normalized.phone = normalized.phone.trimmingCharacters(in: .whitespacesAndNewlines)
        normalized.email = normalized.email.trimmingCharacters(in: .whitespacesAndNewlines)
        guard !normalized.unit.isEmpty else {
            lastErrorMessage = "Enter a unit before saving the contact."
            return false
        }
        let originalTenants = tenants
        tenants.append(normalized)
        guard save() else {
            tenants = originalTenants
            return false
        }
        return true
    }

    @discardableResult
    func importUnits(_ units: [String]) -> Bool {
        let cleanedUnits = units
            .map { $0.trimmingCharacters(in: .whitespacesAndNewlines) }
            .filter { !$0.isEmpty }
        guard !cleanedUnits.isEmpty else {
            lastErrorMessage = "No valid units or areas were found to import."
            return false
        }
        let originalProfile = profile
        var seenUnitKeys = Set<String>()
        profile.firstBuildingUnits = (profile.firstBuildingUnits + cleanedUnits)
            .compactMap { rawUnit -> String? in
                let unit = rawUnit.trimmingCharacters(in: .whitespacesAndNewlines)
                let key = unitIdentityKey(unit)
                guard !unit.isEmpty, seenUnitKeys.insert(key).inserted else { return nil }
                return unit
            }
            .sorted { unitIdentityKey($0) < unitIdentityKey($1) }
        guard save() else {
            profile = originalProfile
            return false
        }
        return true
    }

    func tenant(for unit: String) -> TenantContact? {
        let key = unitIdentityKey(unit)
        let matches = tenants.filter { unitIdentityKey($0.unit) == key }
        guard matches.count == 1 else { return nil }
        return matches[0]
    }

    func purgeOldData(years: Int) -> Int {
        let cutoff = Calendar.current.date(byAdding: .year, value: -years, to: Date()) ?? .distantPast
        let originalWorkOrders = workOrders

        for index in workOrders.indices where workOrders[index].createdAt < cutoff {
            var orderChanged = false
            for entryIndex in workOrders[index].entries.indices {
                if !workOrders[index].entries[entryIndex].images.isEmpty {
                    workOrders[index].entries[entryIndex].images.removeAll()
                    orderChanged = true
                }
                if workOrders[index].entries[entryIndex].handymanName != "Redacted" {
                    workOrders[index].entries[entryIndex].handymanName = "Redacted"
                    orderChanged = true
                }
            }
            if orderChanged {
                record(&workOrders[index], kind: .redacted, message: "Old photos and names purged after \(years) year retention setting")
            }
        }

        if workOrders != originalWorkOrders {
            guard save() else {
                workOrders = originalWorkOrders
                return 0
            }
        }

        // The database commit happens before physical deletion. A full orphan
        // sweep also retries files left behind by an earlier filesystem error.
        let retainedFilenames = Set(workOrders.flatMap { order in
            order.entries.flatMap { $0.images.map(\.filename) }
        })
        let cleanup = ImageStorageService.deleteUnreferenced(keeping: retainedFilenames)
        if !cleanup.failedFilenames.isEmpty {
            lastErrorMessage = "Some expired photo files could not be deleted yet. They remain unreferenced and will be retried the next time you purge old data."
        }
        return cleanup.removedCount
    }

    func syncNow() async {
        guard !cloud.isCloudErasePending() else {
            cloudSyncState = .failed(CloudSyncError.cloudErasePending.localizedDescription)
            cloudSyncDetail = CloudSyncError.cloudErasePending.localizedDescription
            return
        }
        if cloud.isCloudReplacementPending() {
            guard isOnline else {
                cloudSyncState = .offline
                cloudSyncDetail = "Backup restore is complete locally. Cloud replacement will resume when the network returns."
                return
            }
            invalidatePendingCloudSync()
            cloudSyncGeneration += 1
            let generation = cloudSyncGeneration
            guard let snapshot = persistStateForCloudOperation(
                failureMessage: "Local save failed before cloud replacement."
            ) else { return }
            await performCloudReplacement(snapshot: snapshot, generation: generation, reason: "Manual backup replacement")
            return
        }
        guard !cloudSyncPausedForRecovery else {
            cloudSyncState = .paused
            cloudSyncDetail = "iCloud sync is paused for recovery. Resume it before starting a manual sync."
            return
        }
        guard isOnboardingComplete else {
            cloudSyncState = .idle
            cloudSyncDetail = "Complete setup before uploading data to iCloud."
            return
        }
        guard profile.iCloudEnabled && profile.storageChoice == .iCloud else {
            cloudSyncState = .disabled
            cloudSyncDetail = "Turn on iCloud Sync before syncing."
            return
        }
        guard isOnline else {
            cloudSyncState = .offline
            cloudSyncDetail = "No network connection. Changes remain saved locally."
            return
        }

        invalidatePendingCloudSync()
        cloudSyncGeneration += 1
        let generation = cloudSyncGeneration
        guard let snapshot = persistStateForCloudOperation(
            failureMessage: "Local save failed before iCloud sync."
        ) else { return }
        await performCloudSync(snapshot: snapshot, generation: generation, reason: "Manual sync")
    }

    func resyncFromICloud() async {
        guard !cloud.isCloudErasePending() else {
            cloudSyncState = .failed(CloudSyncError.cloudErasePending.localizedDescription)
            cloudSyncDetail = CloudSyncError.cloudErasePending.localizedDescription
            return
        }
        guard !cloud.isCloudReplacementPending() else {
            cloudSyncState = .failed(CloudSyncError.cloudReplacementPending.localizedDescription)
            cloudSyncDetail = CloudSyncError.cloudReplacementPending.localizedDescription
            return
        }
        guard !cloudSyncPausedForRecovery else {
            cloudSyncState = .paused
            cloudSyncDetail = "iCloud sync is paused for recovery. Resume it before restoring from iCloud."
            return
        }
        guard profile.iCloudEnabled && profile.storageChoice == .iCloud else {
            cloudSyncState = .disabled
            cloudSyncDetail = "Turn on iCloud Sync before restoring from iCloud."
            return
        }
        guard isOnline else {
            cloudSyncState = .offline
            cloudSyncDetail = "No network connection. Local data was not changed."
            return
        }

        invalidatePendingCloudSync()
        cloudSyncGeneration += 1
        let generation = cloudSyncGeneration
        cloudSyncState = .checkingAccount
        cloudSyncDetail = "Checking the private iCloud database."

        do {
            guard let outcome = try await cloud.downloadFromCloud() else {
                guard generation == cloudSyncGeneration else { return }
                cloudSyncState = .idle
                cloudSyncDetail = "No iCloud work-order snapshot exists yet."
                return
            }
            guard generation == cloudSyncGeneration else { return }

            let local = currentSnapshot(incrementSaveRevision: false)
            guard let normalizedCloudSnapshot = normalizedRevisionSnapshot(outcome.snapshot),
                  !isDataCompatibilityBlocked else {
                cloudSyncState = .failed(dataCompatibilityMessage ?? "The iCloud snapshot failed data-integrity validation.")
                cloudSyncDetail = "Cloud restore stopped before local data was changed."
                return
            }
            let merged = mergedSnapshot(local, normalizedCloudSnapshot) ?? normalizedCloudSnapshot
            let previousState = captureInMemorySnapshotContents()
            applySnapshotContents(merged)
            lastSynced = outcome.syncedAt
            guard repairAndPersistLoadedState() else {
                restoreInMemorySnapshotContents(previousState)
                refreshNotifications()
                cloudSyncState = .failed(lastErrorMessage ?? "Cloud data was received, but the merged snapshot could not be saved locally.")
                cloudSyncDetail = "Cloud restore stopped because the merged snapshot could not be committed to protected local storage."
                return
            }
            refreshNotifications()
            cloudSyncState = .synced(outcome.syncedAt)
            cloudSyncDetail = outcome.downloadedAttachmentCount == 0
                ? "Cloud data was checked and merged with this device."
                : "Cloud data was merged and \(outcome.downloadedAttachmentCount) attachment(s) were restored."

            scheduleCloudSync(currentSnapshot(incrementSaveRevision: false))
        } catch {
            guard generation == cloudSyncGeneration else { return }
            updateCloudFailure(error)
        }
    }

    private func bootstrapCloudSync() async {
        guard !cloud.isCloudErasePending(), !isErasingCloudData else { return }
        if cloud.isCloudReplacementPending() {
            await completePendingCloudReplacement()
            return
        }
        guard !cloudSyncPausedForRecovery else {
            cloudSyncState = .paused
            cloudSyncDetail = "iCloud sync is paused for recovery. Local data remains available."
            return
        }
        guard profile.iCloudEnabled && profile.storageChoice == .iCloud else { return }
        guard isOnline else {
            cloudSyncState = .offline
            cloudSyncDetail = "Waiting for a network connection. Changes remain saved locally."
            return
        }

        if !isOnboardingComplete {
            await bootstrapCloudDownloadForOnboarding()
            return
        }

        guard let snapshot = persistStateForCloudOperation(
            failureMessage: "Local state could not be committed before startup iCloud sync."
        ) else {
            cloudSyncState = .failed(lastErrorMessage ?? "Local state could not be committed before startup iCloud sync.")
            cloudSyncDetail = "Startup iCloud sync was stopped because protected local storage could not be updated."
            return
        }
        cloudSyncGeneration += 1
        await performCloudSync(snapshot: snapshot, generation: cloudSyncGeneration, reason: "Startup sync")
    }

    /// Before setup completes, iCloud is read-only. Existing private iCloud
    /// data may be recovered, but a fresh install never uploads a default or
    /// partially completed profile before the user finishes setup.
    private func bootstrapCloudDownloadForOnboarding() async {
        guard !hasPersistedLocalState else {
            cloudSyncState = .idle
            cloudSyncDetail = "Setup is incomplete, but local setup data already exists. iCloud recovery will wait for normal merge sync after setup completes."
            return
        }
        cloudSyncGeneration += 1
        let generation = cloudSyncGeneration
        cloudSyncState = .checkingAccount
        cloudSyncDetail = "Checking iCloud for existing iWorkOrder data before setup completes."

        do {
            guard let outcome = try await cloud.downloadFromCloud() else {
                guard generation == cloudSyncGeneration else { return }
                cloudSyncState = .idle
                cloudSyncDetail = "No existing iCloud data was found. Complete setup before iCloud upload begins."
                return
            }
            guard generation == cloudSyncGeneration else { return }
            guard let recovered = normalizedRevisionSnapshot(outcome.snapshot), !isDataCompatibilityBlocked else { return }

            let previousState = captureInMemorySnapshotContents()
            applySnapshotContents(recovered)
            lastSynced = outcome.syncedAt
            guard repairAndPersistLoadedState() else {
                restoreInMemorySnapshotContents(previousState)
                refreshNotifications()
                cloudSyncState = .failed(lastErrorMessage ?? "Existing iCloud data was received but could not be stored locally.")
                cloudSyncDetail = "iCloud recovery stopped because the downloaded snapshot could not be committed to protected local storage."
                return
            }
            refreshNotifications()
            cloudSyncState = .idle
            cloudSyncDetail = "Existing iCloud data was recovered locally. Complete setup before any iCloud upload occurs."
        } catch {
            guard generation == cloudSyncGeneration else { return }
            updateCloudFailure(error)
        }
    }

    private func scheduleCloudSync(_ snapshot: AppSnapshot) {
        guard !cloud.isCloudErasePending(), !isErasingCloudData else { return }
        guard isOnboardingComplete else {
            cloudSyncState = .idle
            cloudSyncDetail = "Setup is not complete. iCloud upload is waiting."
            return
        }
        if cloud.isCloudReplacementPending() {
            scheduleCloudReplacement(snapshot)
            return
        }
        guard !cloudSyncPausedForRecovery else {
            cloudSyncState = .paused
            cloudSyncDetail = "iCloud sync is paused for recovery. Changes remain saved locally."
            return
        }
        pendingCloudSyncTask?.cancel()
        cloudSyncGeneration += 1
        let generation = cloudSyncGeneration
        pendingCloudSyncTask = Task { [weak self] in
            do { try await Task.sleep(nanoseconds: 700_000_000) } catch { return }
            guard !Task.isCancelled, let self else { return }
            await self.performCloudSync(snapshot: snapshot, generation: generation, reason: "Automatic sync")
        }
    }

    private func performCloudSync(snapshot: AppSnapshot, generation: Int, reason: String) async {
        guard generation == cloudSyncGeneration else { return }
        guard !cloud.isCloudErasePending(), !cloud.isCloudReplacementPending(), !isErasingCloudData else { return }
        guard isOnboardingComplete else {
            cloudSyncState = .idle
            cloudSyncDetail = "Complete setup before uploading data to iCloud."
            return
        }
        guard !cloudSyncPausedForRecovery else {
            cloudSyncState = .paused
            cloudSyncDetail = "iCloud sync is paused for recovery. Changes remain saved locally."
            return
        }
        guard profile.iCloudEnabled && profile.storageChoice == .iCloud else { return }
        guard isOnline else {
            cloudSyncState = .offline
            cloudSyncDetail = "Waiting for a network connection. Changes remain saved locally."
            return
        }

        cloudSyncState = .syncing
        cloudSyncDetail = "\(reason): syncing records, photos, and signatures."
        do {
            let outcome = try await cloud.synchronize(snapshot: snapshot)
            guard generation == cloudSyncGeneration else { return }
            let previousState = captureInMemorySnapshotContents()
            applySnapshotContents(outcome.snapshot)
            lastSynced = outcome.syncedAt
            guard repairAndPersistLoadedState() else {
                restoreInMemorySnapshotContents(previousState)
                refreshNotifications()
                cloudSyncState = .failed(lastErrorMessage ?? "Cloud sync completed remotely, but the merged snapshot could not be saved locally.")
                cloudSyncDetail = "Cloud sync stopped because the merged snapshot could not be committed to protected local storage."
                MaintenanceService.record(kind: .cloudSync, outcome: .failure)
                return
            }
            refreshNotifications()
            cloudSyncState = .synced(outcome.syncedAt)

            let transferred = outcome.uploadedAttachmentCount + outcome.downloadedAttachmentCount
            cloudSyncDetail = transferred == 0
                ? "All iCloud records and attachments are current."
                : "Sync completed. \(outcome.uploadedAttachmentCount) attachment(s) uploaded and \(outcome.downloadedAttachmentCount) restored."
            lastErrorMessage = nil
            MaintenanceService.record(kind: .cloudSync, outcome: .success, itemCount: transferred)
        } catch {
            guard generation == cloudSyncGeneration else { return }
            MaintenanceService.record(kind: .cloudSync, outcome: .failure)
            updateCloudFailure(error)
        }
    }

    private func updateCloudFailure(_ error: Error) {
        let message = (error as? LocalizedError)?.errorDescription ?? error.localizedDescription
        if let syncError = error as? CloudSyncError {
            switch syncError {
            case .noNetwork: cloudSyncState = .offline
            case .accountUnavailable: cloudSyncState = .noAccount
            case .accountRestricted: cloudSyncState = .restricted
            case .incompatibleDataSchema:
                dataCompatibilityMessage = message
                invalidatePendingCloudSync()
                cloudSyncState = .failed(message)
            default: cloudSyncState = .failed(message)
            }
        } else {
            cloudSyncState = .failed(message)
        }
        cloudSyncDetail = message
        lastErrorMessage = message
    }

    private func networkStatusChanged(_ online: Bool) {
        let wasOnline = isOnline
        isOnline = online
        if cloud.isCloudErasePending() {
            if online {
                cloudSyncState = .idle
                cloudSyncDetail = "Network restored. Finishing pending cloud deletion."
                Task { await completePendingCloudErase() }
            } else {
                cloudSyncState = .offline
                cloudSyncDetail = "Cloud deletion is pending. Sync and restore remain blocked until the network returns."
            }
            return
        }
        if cloud.isCloudReplacementPending() {
            if online {
                cloudSyncState = .idle
                cloudSyncDetail = "Network restored. Replacing the private iCloud dataset with the verified backup."
                scheduleCloudReplacement(currentSnapshot(incrementSaveRevision: false))
            } else {
                cloudSyncState = .offline
                cloudSyncDetail = "Backup restore is complete locally. Cloud replacement will resume when the network returns."
            }
            return
        }
        if cloudSyncPausedForRecovery {
            cloudSyncState = .paused
            cloudSyncDetail = online
                ? "iCloud sync is paused for recovery. Local saves remain available."
                : "iCloud sync is paused for recovery and the network is unavailable."
            return
        }
        guard profile.iCloudEnabled && profile.storageChoice == .iCloud else {
            cloudSyncState = .disabled
            return
        }
        guard isOnboardingComplete else {
            cloudSyncState = online ? .idle : .offline
            if shouldOfferInitialDataRecovery {
                cloudSyncDetail = online
                    ? "Choose whether to restore existing data or start a new setup."
                    : "Backup recovery is available, but iCloud requires a network connection."
                return
            }
            cloudSyncDetail = online
                ? "Complete setup before iCloud upload begins."
                : "Setup is incomplete and the network is unavailable."
            return
        }
        if !online {
            cloudSyncState = .offline
            cloudSyncDetail = "No network connection. Changes remain saved locally."
        } else if !wasOnline {
            cloudSyncState = .idle
            cloudSyncDetail = "Network restored. Preparing iCloud sync."
            scheduleCloudSync(currentSnapshot(incrementSaveRevision: false))
        }
    }

    private func completePendingCloudReplacement() async {
        guard cloud.isCloudReplacementPending(), !cloud.isCloudErasePending(), !isErasingCloudData else { return }
        guard isOnline else {
            cloudSyncState = .offline
            cloudSyncDetail = "Backup restore is complete locally. Cloud replacement will resume when the network returns."
            return
        }
        invalidatePendingCloudSync()
        cloudSyncGeneration += 1
        let generation = cloudSyncGeneration
        let snapshot = currentSnapshot(incrementSaveRevision: false)
        await performCloudReplacement(snapshot: snapshot, generation: generation, reason: "Pending backup replacement")
    }

    private func scheduleCloudReplacement(_ snapshot: AppSnapshot) {
        guard cloud.isCloudReplacementPending(), !cloud.isCloudErasePending(), !isErasingCloudData else { return }
        pendingCloudSyncTask?.cancel()
        cloudSyncGeneration += 1
        let generation = cloudSyncGeneration
        pendingCloudSyncTask = Task { [weak self] in
            do { try await Task.sleep(nanoseconds: 700_000_000) } catch { return }
            guard !Task.isCancelled, let self else { return }
            await self.performCloudReplacement(snapshot: snapshot, generation: generation, reason: "Backup replacement")
        }
    }

    private func performCloudReplacement(snapshot: AppSnapshot, generation: Int, reason: String) async {
        guard generation == cloudSyncGeneration else { return }
        guard cloud.isCloudReplacementPending(), !cloud.isCloudErasePending(), !isErasingCloudData else { return }
        guard isOnline else {
            cloudSyncState = .offline
            cloudSyncDetail = "Backup restore is complete locally. Cloud replacement will resume when the network returns."
            return
        }

        cloudSyncState = .syncing
        cloudSyncDetail = "\(reason): replacing iCloud records, photos, and signatures."
        do {
            let outcome = try await cloud.replaceCloudData(with: snapshot)
            guard generation == cloudSyncGeneration else { return }
            let previousState = captureInMemorySnapshotContents()
            applySnapshotContents(outcome.snapshot)
            lastSynced = outcome.syncedAt
            guard repairAndPersistLoadedState() else {
                restoreInMemorySnapshotContents(previousState)
                refreshNotifications()
                cloudSyncState = .failed(lastErrorMessage ?? "Cloud replacement completed remotely, but the snapshot could not be saved locally.")
                cloudSyncDetail = "Cloud replacement requires attention because the resulting snapshot could not be committed to protected local storage."
                return
            }
            refreshNotifications()
            if profile.iCloudEnabled && profile.storageChoice == .iCloud {
                cloudSyncState = .synced(outcome.syncedAt)
                cloudSyncDetail = "Backup replacement completed. iCloud now matches the restored archive."
            } else {
                cloudSyncState = .disabled
                cloudSyncDetail = "Cloud replacement completed. iCloud Sync remains turned off."
            }
            lastErrorMessage = nil
        } catch {
            guard generation == cloudSyncGeneration else { return }
            updateCloudFailure(error)
            cloudSyncDetail += " The restored local data remains protected and cloud replacement will retry later."
        }
    }

    private func invalidatePendingCloudSync() {
        pendingCloudSyncTask?.cancel()
        pendingCloudSyncTask = nil
        cloudSyncGeneration += 1
    }

    private func resumeCloudAfterBackupOperation() {
        guard !cloud.isCloudErasePending(), !isErasingCloudData else { return }
        guard validateCurrentRevisionHistoryForPersistence() else {
            invalidatePendingCloudSync()
            cloudSyncState = .failed(lastErrorMessage ?? "Cloud sync stopped by data-integrity protection.")
            cloudSyncDetail = "Cloud sync was not resumed because local revision history failed validation."
            return
        }
        let snapshot = currentSnapshot(incrementSaveRevision: false)
        if cloud.isCloudReplacementPending() {
            scheduleCloudReplacement(snapshot)
        } else if cloudSyncPausedForRecovery {
            cloudSyncState = .paused
            cloudSyncDetail = "iCloud sync remains paused for recovery after the backup operation."
        } else if profile.iCloudEnabled && profile.storageChoice == .iCloud {
            scheduleCloudSync(snapshot)
        }
    }

    func exportFullBackup() async -> BackupExportResult? {
        let operationStartedAt = Date()
        guard !isBackupOperationInProgress else {
            lastErrorMessage = "Another backup or restore operation is already running."
            return nil
        }
        isBackupOperationInProgress = true
        invalidatePendingCloudSync()
        await cloud.beginExclusiveLocalDataAccess()

        guard validateCurrentRevisionHistoryForPersistence() else {
            await cloud.endExclusiveLocalDataAccess()
            isBackupOperationInProgress = false
            cloudSyncState = .failed(lastErrorMessage ?? "Backup export stopped by data-integrity protection.")
            cloudSyncDetail = "Backup export was stopped before any archive was written."
            MaintenanceService.record(
                kind: .backupExport,
                outcome: .blocked,
                durationMilliseconds: Int(Date().timeIntervalSince(operationStartedAt) * 1000)
            )
            return nil
        }

        let previousState = captureInMemorySnapshotContents()
        applyPendingRevisionRepairAuditNotices()
        enforceRevisionIdentityIntegrity()
        enforceAuditIntegrity()
        enforceSignedLockIntegrity()

        let repairsChangedData = workOrders != previousState.workOrders
        let snapshot = currentSnapshot(incrementSaveRevision: repairsChangedData)
        if repairsChangedData {
            guard storage.save(snapshot) else {
                restoreInMemorySnapshotContents(previousState)
                await cloud.endExclusiveLocalDataAccess()
                isBackupOperationInProgress = false
                resumeCloudAfterBackupOperation()
                lastErrorMessage = "The backup was not created because pending integrity repairs could not be committed to protected local storage."
                MaintenanceService.record(
                    kind: .backupExport,
                    outcome: .failure,
                    durationMilliseconds: Int(Date().timeIntervalSince(operationStartedAt) * 1000)
                )
                return nil
            }
            StorageService.commitSaveRevision(snapshot.saveRevision ?? StorageService.currentSaveRevision())
            hasPersistedLocalState = true
            contentModifiedAt = snapshot.snapshotSavedAt
            profileConfigurationUpdatedAt = snapshot.profileConfigurationUpdatedAt
            lastCommittedProfile = snapshot.profile
            pendingRevisionRepairOrderIDs.removeAll()
        }

        do {
            let result = try await Task.detached(priority: .userInitiated) {
                try BackupArchiveService.createPortableBackup(snapshot: snapshot)
            }.value
            await cloud.endExclusiveLocalDataAccess()
            isBackupOperationInProgress = false
            resumeCloudAfterBackupOperation()
            lastErrorMessage = nil
            MaintenanceService.record(
                kind: .backupExport,
                outcome: .success,
                durationMilliseconds: Int(Date().timeIntervalSince(operationStartedAt) * 1000),
                itemCount: snapshot.workOrders.count
            )
            return result
        } catch {
            await cloud.endExclusiveLocalDataAccess()
            isBackupOperationInProgress = false
            resumeCloudAfterBackupOperation()
            lastErrorMessage = (error as? LocalizedError)?.errorDescription ?? error.localizedDescription
            MaintenanceService.record(
                kind: .backupExport,
                outcome: .failure,
                durationMilliseconds: Int(Date().timeIntervalSince(operationStartedAt) * 1000)
            )
            return nil
        }
    }

    func inspectBackup(at url: URL) async -> BackupRestoreCandidate? {
        do {
            let candidate = try await Task.detached(priority: .userInitiated) {
                try BackupArchiveService.prepareImport(from: url)
            }.value
            lastErrorMessage = nil
            return candidate
        } catch {
            lastErrorMessage = (error as? LocalizedError)?.errorDescription ?? error.localizedDescription
            return nil
        }
    }

    func discardBackupCandidate(_ candidate: BackupRestoreCandidate) {
        Task.detached(priority: .utility) {
            BackupArchiveService.discard(candidate)
        }
    }

    func restoreBackup(_ candidate: BackupRestoreCandidate, mode: BackupRestoreMode) async -> BackupRestoreResult? {
        let operationStartedAt = Date()
        guard !cloud.isCloudErasePending() else {
            lastErrorMessage = CloudSyncError.cloudErasePending.localizedDescription
            return nil
        }
        guard !isBackupOperationInProgress else {
            lastErrorMessage = "Another backup or restore operation is already running."
            return nil
        }
        guard !restoreRecoveryWriteBlocked else {
            lastErrorMessage = "A previous restore still needs recovery. Restart the app before starting another backup restore."
            return nil
        }

        isBackupOperationInProgress = true
        invalidatePendingCloudSync()
        await cloud.beginExclusiveLocalDataAccess()
        enforceRevisionIdentityIntegrity()
        enforceAuditIntegrity()
        enforceSignedLockIntegrity()

        let originalSnapshot = currentSnapshot(incrementSaveRevision: false)
        let originalProfile = profile
        let originalWorkOrders = workOrders
        let originalAssets = assets
        let originalTenants = tenants
        let originalCategories = categories
        let originalCategoryConfigurationUpdatedAt = categoryConfigurationUpdatedAt
        let originalProfileConfigurationUpdatedAt = profileConfigurationUpdatedAt
        let originalLastCommittedProfile = lastCommittedProfile
        let originalLastSynced = lastSynced
        let originalContentModifiedAt = contentModifiedAt
        let originalHasPersistedLocalState = hasPersistedLocalState
        let originalInitialRecoveryState = shouldOfferInitialDataRecovery
        let originalPendingRevisionRepairOrderIDs = pendingRevisionRepairOrderIDs
        let originalDataCompatibilityMessage = dataCompatibilityMessage

        guard var importedSnapshot = normalizedRevisionSnapshot(candidate.snapshot),
              !isDataCompatibilityBlocked else {
            let restoreError = dataCompatibilityMessage ?? "The selected backup failed data-integrity validation."
            dataCompatibilityMessage = originalDataCompatibilityMessage
            pendingRevisionRepairOrderIDs = originalPendingRevisionRepairOrderIDs
            await Task.detached(priority: .utility) {
                BackupArchiveService.discard(candidate)
            }.value
            await cloud.endExclusiveLocalDataAccess()
            isBackupOperationInProgress = false
            resumeCloudAfterBackupOperation()
            lastErrorMessage = restoreError
            MaintenanceService.record(
                kind: .backupRestore,
                outcome: .failure,
                durationMilliseconds: Int(Date().timeIntervalSince(operationStartedAt) * 1000)
            )
            return nil
        }
        importedSnapshot.lastSynced = nil
        importedSnapshot.snapshotSavedAt = Date()
        importedSnapshot.profileConfigurationUpdatedAt = importedSnapshot.snapshotSavedAt
        importedSnapshot.deviceID = DeviceIdentity.current
        importedSnapshot.saveRevision = StorageService.currentSaveRevision()

        var restoredSnapshot: AppSnapshot
        switch mode {
        case .replace:
            restoredSnapshot = importedSnapshot
        case .merge:
            restoredSnapshot = mergedSnapshot(originalSnapshot, importedSnapshot) ?? originalSnapshot
            // Merge imports work-order content without replacing this device's building,
            // legal, security, notification, theme, or storage preferences.
            restoredSnapshot.profile = originalSnapshot.profile
            restoredSnapshot.profileConfigurationUpdatedAt = originalSnapshot.profileConfigurationUpdatedAt
            restoredSnapshot.lastSynced = nil
            restoredSnapshot.snapshotSavedAt = Date()
            restoredSnapshot.deviceID = DeviceIdentity.current
            restoredSnapshot.saveRevision = StorageService.currentSaveRevision()
        }

        let replacementWasAlreadyPending = cloud.isCloudReplacementPending()
        let currentSavedStateUsesICloud = originalHasPersistedLocalState &&
            originalProfile.iCloudEnabled && originalProfile.storageChoice == .iCloud
        let restoredStateUsesICloud = restoredSnapshot.profile.iCloudEnabled &&
            restoredSnapshot.profile.storageChoice == .iCloud
        let shouldReplaceCloud = replacementWasAlreadyPending ||
            (mode == .replace && (currentSavedStateUsesICloud || restoredStateUsesICloud))

        var transaction: BackupAttachmentTransaction?
        var beganCloudReplacement = false
        do {
            let safetyBackup = try await Task.detached(priority: .userInitiated) {
                try BackupArchiveService.createSafetyBackup(snapshot: originalSnapshot)
            }.value

            applySnapshotContents(restoredSnapshot)
            lastSynced = nil
            applyPendingRevisionRepairAuditNotices()
            enforceRevisionIdentityIntegrity()
            enforceAuditIntegrity()

            // Install verified attachment bytes before validating signed records.
            // Otherwise a valid signature that exists only in the incoming backup
            // would be falsely recorded as missing before the transaction copies it.
            let expectedSaveRevision = StorageService.nextSaveRevisionCandidate()
            transaction = try await Task.detached(priority: .userInitiated) {
                try BackupArchiveService.beginAttachmentInstall(
                    candidate: candidate,
                    mode: mode,
                    expectedSaveRevision: expectedSaveRevision
                )
            }.value

            enforceSignedLockIntegrity()
            let savedSnapshot = currentSnapshot(incrementSaveRevision: true)
            guard savedSnapshot.saveRevision == expectedSaveRevision else {
                throw BackupArchiveError.restoreTransactionFailed(
                    "The local save revision changed during restore verification."
                )
            }
            try transaction?.prepareSnapshotCommit(savedSnapshot)

            if shouldReplaceCloud && !replacementWasAlreadyPending {
                cloud.beginCloudReplacement()
                beganCloudReplacement = true
            }

            guard storage.save(savedSnapshot) else {
                throw BackupArchiveError.restoreTransactionFailed("The restored snapshot could not be written to protected local storage.")
            }
            StorageService.commitSaveRevision(savedSnapshot.saveRevision ?? StorageService.currentSaveRevision())
            hasPersistedLocalState = true
            contentModifiedAt = savedSnapshot.snapshotSavedAt
            profileConfigurationUpdatedAt = savedSnapshot.profileConfigurationUpdatedAt
            lastCommittedProfile = savedSnapshot.profile
            pendingRevisionRepairOrderIDs.removeAll()
            let durableRestoreCommitRecorded = transaction?.markSnapshotCommitted() ?? true

            isOnboardingComplete = true
            shouldOfferInitialDataRecovery = false
            onboardingPersistence.markCompleted(
                date: profile.legalAcceptedDate ?? Date(),
                legalVersion: profile.legalAcceptedVersion
            )

            let references = BackupArchiveService.referencedAttachmentFilenames(in: savedSnapshot)
            var finalizationWarningCount = 0
            if let transaction {
                let finalized = await Task.detached(priority: .utility) {
                    transaction.finalize(
                        referencedImages: references.images,
                        referencedSignatures: references.signatures
                    )
                }.value
                if !finalized {
                    finalizationWarningCount = 1
                    if !durableRestoreCommitRecorded {
                        restoreRecoveryWriteBlocked = true
                    }
                }
            }
            await Task.detached(priority: .utility) {
                BackupArchiveService.discard(candidate)
            }.value

            await cloud.endExclusiveLocalDataAccess()
            isBackupOperationInProgress = false
            refreshNotifications()

            if restoreRecoveryWriteBlocked {
                cloudSyncState = .paused
                cloudSyncDetail = "Backup restored locally, but recovery cleanup could not be made durable. Local changes and iCloud sync are paused until restart recovery succeeds."
            } else if shouldReplaceCloud {
                cloudSyncState = isOnline ? .idle : .offline
                cloudSyncDetail = isOnline
                    ? "Backup restored locally. iCloud replacement is queued."
                    : "Backup restored locally. iCloud replacement will resume when the network returns."
                scheduleCloudReplacement(savedSnapshot)
            } else if profile.iCloudEnabled && profile.storageChoice == .iCloud {
                cloudSyncState = isOnline ? .idle : .offline
                cloudSyncDetail = isOnline
                    ? "Backup merged locally. iCloud sync is queued."
                    : "Backup merged locally. iCloud sync will resume when the network returns."
                scheduleCloudSync(savedSnapshot)
            } else {
                cloudSyncState = .disabled
                cloudSyncDetail = "Backup restored. Data is saving only on this device."
            }

            lastErrorMessage = restoreRecoveryWriteBlocked
                ? "Backup restore committed, but recovery cleanup is incomplete. Restart the app before making changes."
                : nil
            MaintenanceService.record(
                kind: .backupRestore,
                outcome: .success,
                durationMilliseconds: Int(Date().timeIntervalSince(operationStartedAt) * 1000),
                itemCount: savedSnapshot.workOrders.count
            )
            return BackupRestoreResult(
                mode: mode,
                restoredCounts: BackupArchiveService.counts(for: savedSnapshot),
                safetyBackupURL: safetyBackup.url,
                warningCount: candidate.warnings.count + safetyBackup.warnings.count + finalizationWarningCount
            )
        } catch {
            var rollbackWarning: String?
            if let backupError = error as? BackupArchiveError,
               case .attachmentRollbackIncomplete = backupError {
                restoreRecoveryWriteBlocked = true
                rollbackWarning = " Attachment recovery is incomplete; local changes and iCloud sync are blocked until restart recovery succeeds."
            }
            if let transaction {
                let rolledBack = await Task.detached(priority: .userInitiated) {
                    transaction.rollback()
                }.value
                if !rolledBack {
                    restoreRecoveryWriteBlocked = true
                    rollbackWarning = " Attachment rollback is still pending; recovery copies were retained. Local changes and iCloud sync are blocked until restart recovery succeeds."
                }
            }
            if beganCloudReplacement {
                cloud.cancelCloudReplacement()
            }
            await cloud.endExclusiveLocalDataAccess()
            isBackupOperationInProgress = false
            profile = originalProfile
            workOrders = originalWorkOrders
            assets = originalAssets
            tenants = originalTenants
            categories = originalCategories
            categoryConfigurationUpdatedAt = originalCategoryConfigurationUpdatedAt
            profileConfigurationUpdatedAt = originalProfileConfigurationUpdatedAt
            lastCommittedProfile = originalLastCommittedProfile
            lastSynced = originalLastSynced
            contentModifiedAt = originalContentModifiedAt
            hasPersistedLocalState = originalHasPersistedLocalState
            shouldOfferInitialDataRecovery = originalInitialRecoveryState
            pendingRevisionRepairOrderIDs = originalPendingRevisionRepairOrderIDs
            refreshNotifications()
            if restoreRecoveryWriteBlocked {
                invalidatePendingCloudSync()
                cloudSyncState = .paused
                cloudSyncDetail = "Restore attachment recovery is incomplete. Local changes and iCloud sync are paused until restart recovery succeeds."
            } else {
                resumeCloudAfterBackupOperation()
            }
            let restoreError = (error as? LocalizedError)?.errorDescription ?? error.localizedDescription
            lastErrorMessage = restoreError + (rollbackWarning ?? "")
            MaintenanceService.record(
                kind: .backupRestore,
                outcome: .failure,
                durationMilliseconds: Int(Date().timeIntervalSince(operationStartedAt) * 1000)
            )
            return nil
        }
    }

    func reportPDFURL(orders: [WorkOrder]? = nil, title: String = "iWorkOrder Report") -> URL? {
        let url = PDFExportService.makeWorkOrderPDF(
            profile: profile,
            orders: orders ?? activeWorkOrders,
            title: title
        )
        if url == nil {
            lastErrorMessage = "The PDF could not be created. Check available storage and try again."
        }
        return url
    }

    func refreshNotificationAuthorization() async {
        guard profile.notificationsEnabled else {
            notificationPermissionNeedsAttention = false
            return
        }
        let status = await notifications.authorizationStatus()
        // The preference can change while iOS is answering. Use current state
        // and never let a stale permission result recreate canceled requests.
        guard profile.notificationsEnabled, !cloud.isCloudErasePending(), !isDataCompatibilityBlocked else {
            notificationPermissionNeedsAttention = false
            notifications.cancelAllNotifications()
            return
        }
        switch status {
        case .authorized, .provisional, .ephemeral:
            notificationPermissionNeedsAttention = false
            refreshNotifications()
        case .notDetermined, .denied:
            // Notification authorization is device-local. Do not persist a local
            // denial/not-determined state into the synced profile or another
            // device could unexpectedly lose its valid notification preference.
            notificationPermissionNeedsAttention = true
            notifications.cancelAllNotifications()
        @unknown default:
            notificationPermissionNeedsAttention = true
            notifications.cancelAllNotifications()
        }
    }

    func refreshNotifications() {
        notifications.reconcile(
            orders: workOrders,
            notificationsEnabled: profile.notificationsEnabled && !isDataCompatibilityBlocked && !cloud.isCloudErasePending(),
            emergencyNotificationsEnabled: profile.emergencyNotificationsEnabled
        )
    }

    @discardableResult
    func applyNotificationPreferences(previousProfile: UserProfile? = nil) -> Bool {
        let rollbackProfile = previousProfile ?? profile
        guard save() else {
            profile = rollbackProfile
            refreshNotifications()
            return false
        }
        // Notification Center changes are applied only after the preference
        // mutation is durably committed, so a failed local save cannot create
        // or cancel user-visible notifications for state that never persisted.
        refreshNotifications()
        return true
    }

    @discardableResult
    func setStorageChoice(_ choice: StorageChoice) -> Bool {
        let originalProfile = profile
        let enabled = choice == .iCloud
        profile.storageChoice = choice
        profile.iCloudEnabled = enabled
        profile.iCloudDisabledDate = enabled ? nil : Date()
        guard save() else {
            profile = originalProfile
            return false
        }
        return true
    }

    @discardableResult
    func setICloudEnabled(_ enabled: Bool) -> Bool {
        setStorageChoice(enabled ? .iCloud : .localOnly)
    }

#if DEBUG
    func setCloudSyncPausedForRecovery(_ paused: Bool) {
        RuntimeReliabilityService.setCloudSyncPaused(paused)
        cloudSyncPausedForRecovery = paused
        invalidatePendingCloudSync()

        // Recovery pause applies only to ordinary synchronization. A previously
        // committed erase or authoritative replacement transaction must be
        // allowed to finish so the app cannot strand a partially recovered state.
        if cloud.isCloudErasePending() {
            cloudSyncState = isOnline ? .idle : .offline
            cloudSyncDetail = isOnline
                ? "Recovery pause updated. Finishing the pending cloud deletion."
                : "Cloud deletion remains pending until the network returns."
            if isOnline {
                Task { await completePendingCloudErase() }
            }
            return
        }
        if cloud.isCloudReplacementPending() {
            cloudSyncState = isOnline ? .idle : .offline
            cloudSyncDetail = isOnline
                ? "Recovery pause updated. Finishing the verified backup replacement."
                : "Verified backup replacement remains pending until the network returns."
            if isOnline {
                scheduleCloudReplacement(currentSnapshot(incrementSaveRevision: false))
            }
            return
        }
        if paused {
            cloudSyncState = .paused
            cloudSyncDetail = "Automatic and manual iCloud sync are paused. Local saves remain available."
        } else if profile.iCloudEnabled && profile.storageChoice == .iCloud {
            cloudSyncState = isOnline ? .idle : .offline
            cloudSyncDetail = isOnline
                ? "Recovery pause ended. Preparing iCloud sync."
                : "Recovery pause ended. Waiting for a network connection."
            if isOnline {
                scheduleCloudSync(currentSnapshot(incrementSaveRevision: false))
            }
        } else {
            cloudSyncState = .disabled
            cloudSyncDetail = "Data is saving only on this device."
        }
    }
#endif

    func writeSupportBundle() throws -> URL {
        try SupportBundleService.writeBundle(for: self)
    }

    func runMaintenanceHealthCheck() -> MaintenanceHealthReport {
        let report = MaintenanceService.healthReport(
            snapshot: currentSnapshot(incrementSaveRevision: false),
            cloudReplacementPending: cloud.isCloudReplacementPending(),
            cloudErasePending: cloud.isCloudErasePending()
        )
        MaintenanceService.record(
            kind: .healthCheck,
            outcome: report.isHealthy ? (report.warningCount == 0 ? .success : .warning) : .failure,
            itemCount: report.criticalIssueCount + report.warningCount
        )
        if report.isHealthy { MaintenanceService.markCurrentBuildHealthy() }
        return report
    }

#if DEBUG
    func writeMaintenanceReport() throws -> URL {
        try MaintenanceService.writeReport(health: runMaintenanceHealthCheck())
    }

    func clearMaintenanceHistory() {
        MaintenanceService.clearHistory()
    }
#endif


}

struct AppSnapshot: Codable, Sendable {
    var profile: UserProfile
    var workOrders: [WorkOrder]
    var assets: [AssetRecord]? = []
    var tenants: [TenantContact]? = []
    var categories: [WorkOrderCategory]?
    var categoryConfigurationUpdatedAt: Date?
    var profileConfigurationUpdatedAt: Date?
    var lastSynced: Date?
    var snapshotSavedAt: Date? = nil
    var deviceID: String? = DeviceIdentity.current
    var saveRevision: Int? = 0
    var dataSchemaVersion: Int? = AppDataSchema.currentVersion
}
