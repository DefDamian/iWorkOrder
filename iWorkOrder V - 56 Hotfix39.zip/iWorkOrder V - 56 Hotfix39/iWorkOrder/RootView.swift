import SwiftUI

@MainActor
struct RootView: View {
    @EnvironmentObject private var store: AppStore
    @AppStorage(AppTheme.storageKey) private var selectedThemeRaw = VisualTheme.defaultTheme.rawValue
    @EnvironmentObject private var appLock: AppLockState
    @Environment(\.accessibilityReduceTransparency) private var reduceTransparency
    private let security = SecurityService()

    var body: some View {
        Group {
            if store.isDataCompatibilityBlocked {
                DataCompatibilityBlockedView(message: store.dataCompatibilityMessage ?? "This local data requires a compatible iWorkOrder version.")
            } else if !store.isOnboardingComplete && store.shouldOfferInitialDataRecovery {
                InitialDataRecoveryView()
            } else if !store.isOnboardingComplete {
                OnboardingView()
            } else if !store.hasCurrentLegalAcceptance {
                LegalUpdateRequiredView()
            } else if !store.hasCompletedPermissionSetup {
                PermissionSetupView()
            } else if appLock.isLocked {
                LockView { await unlock() }
            } else {
                MainTabView()
                    .environmentObject(appLock)
            }
        }
        .preferredColorScheme(preferredScheme)
        .disabled(store.isBackupOperationInProgress)
        .accessibilityHidden(store.isBackupOperationInProgress)
        .overlay {
            if store.isBackupOperationInProgress {
                ZStack {
                    Color.black.opacity(0.28)
                        .ignoresSafeArea()
                    VStack(spacing: 14) {
                        ProgressView()
                            .controlSize(.large)
                        Text("Securing backup data...")
                            .font(.headline)
                        Text("Keep iWorkOrder open until this operation finishes.")
                            .font(.caption)
                            .foregroundStyle(.secondary)
                            .multilineTextAlignment(.center)
                    }
                    .padding(24)
                    .background(
                        reduceTransparency
                            ? AnyShapeStyle(Color(.secondarySystemBackground))
                            : AnyShapeStyle(.regularMaterial),
                        in: RoundedRectangle(cornerRadius: 18, style: .continuous)
                    )
                    .padding()
                }
                .transition(.opacity)
                .zIndex(1000)
                .accessibilityElement(children: .combine)
                .accessibilityLabel("Backup operation in progress")
                .accessibilityHint("Keep iWorkOrder open until the operation finishes")
            }
        }

        .task(id: store.isOnboardingComplete && store.hasCurrentLegalAcceptance && store.hasCompletedPermissionSetup) {
            guard store.isOnboardingComplete, store.hasCurrentLegalAcceptance, store.hasCompletedPermissionSetup else { return }
            if store.profile.faceIDEnabled {
                appLock.requireUnlock()
                await unlock()
            } else {
                appLock.unlock()
            }
        }
        .onChange(of: store.profile.faceIDEnabled) { _, enabled in
            if enabled { appLock.requireUnlock() } else { appLock.unlock() }
        }
        .alert("iWorkOrder", isPresented: Binding(
            get: { store.lastErrorMessage != nil },
            set: { isPresented in
                guard !isPresented else { return }
                Task { @MainActor in
                    await Task.yield()
                    store.lastErrorMessage = nil
                }
            }
        )) {
            Button("OK", role: .cancel) { store.lastErrorMessage = nil }
        } message: {
            Text(store.lastErrorMessage ?? "")
        }
    }

    private var preferredScheme: ColorScheme? {
        switch VisualTheme(rawValue: selectedThemeRaw) ?? .defaultTheme {
        case .defaultTheme: return nil
        case .design2: return .light
        case .design3: return .dark
        }
    }

    private func unlock() async {
        guard store.isOnboardingComplete, store.hasCurrentLegalAcceptance, store.hasCompletedPermissionSetup,
              store.profile.faceIDEnabled,
              let token = appLock.beginAuthentication() else { return }
        let succeeded = await security.authenticate()
        appLock.completeAuthentication(token: token, succeeded: succeeded && !Task.isCancelled)
    }
}

enum MainTab: String, CaseIterable, Identifiable, Hashable {
    case workOrders
    case calendar
    case hub
    case settings

    var id: String { rawValue }

    func title(for theme: VisualTheme) -> String {
        switch self {
        case .workOrders:
            return theme == .defaultTheme ? "Work Order" : (theme == .design3 ? "Field" : "Orders")
        case .calendar:
            return "Calendar"
        case .hub:
            switch theme {
            case .defaultTheme: return "Hub"
            case .design2: return "Dashboard"
            case .design3: return "Field Deck"
            }
        case .settings:
            return "Settings"
        }
    }

    func icon(for theme: VisualTheme) -> String {
        switch self {
        case .workOrders: return theme == .design3 ? "wrench.and.screwdriver.fill" : "list.bullet.rectangle"
        case .calendar: return "calendar"
        case .hub: return theme == .design3 ? "rectangle.3.group.fill" : "chart.bar.doc.horizontal"
        case .settings: return "gearshape"
        }
    }

    var keyboardShortcut: KeyEquivalent {
        switch self {
        case .workOrders: return "1"
        case .calendar: return "2"
        case .hub: return "3"
        case .settings: return "4"
        }
    }

    var keyboardShortcutLabel: String {
        switch self {
        case .workOrders: return "1"
        case .calendar: return "2"
        case .hub: return "3"
        case .settings: return "4"
        }
    }
}

struct MainTabView: View {
    @EnvironmentObject private var store: AppStore
    @Environment(\.horizontalSizeClass) private var horizontalSizeClass
    @AppStorage(AppTheme.storageKey) private var selectedThemeRaw = VisualTheme.defaultTheme.rawValue
    @State private var selectedTab: MainTab = .workOrders

    private var theme: VisualTheme { VisualTheme(rawValue: selectedThemeRaw) ?? .defaultTheme }

    var body: some View {
        Group {
            if horizontalSizeClass == .regular {
                regularWidthContent
            } else {
                compactContent
            }
        }
        .onChange(of: store.deepLinkedOrderID) { _, id in
            if id != nil { selectedTab = .workOrders }
        }
    }

    private var regularWidthContent: some View {
        NavigationSplitView {
            List {
                ForEach(MainTab.allCases) { tab in
                    Button {
                        selectedTab = tab
                    } label: {
                        Label(tab.title(for: theme), systemImage: tab.icon(for: theme))
                            .frame(maxWidth: .infinity, alignment: .leading)
                            .contentShape(Rectangle())
                    }
                    .buttonStyle(.plain)
                    .font(.headline)
                    .foregroundStyle(selectedTab == tab ? AppTheme.accent(for: theme) : .primary)
                    .listRowBackground(selectedTab == tab ? AppTheme.accent(for: theme).opacity(0.12) : Color.clear)
                    .keyboardShortcut(tab.keyboardShortcut, modifiers: [.command])
                    .accessibilityIdentifier(AccessibilityID.mainTab(tab))
                    .accessibilityHint("Press Command \(tab.keyboardShortcutLabel) to open")
                    .accessibilityAddTraits(selectedTab == tab ? .isSelected : [])
                }
            }
            .navigationTitle("iWorkOrder")
            .navigationSplitViewColumnWidth(min: 210, ideal: 250, max: 320)
        } detail: {
            themedContent(for: selectedTab)
        }
        .navigationSplitViewStyle(.balanced)
        .tint(AppTheme.accent(for: theme))
    }

    private var compactContent: some View {
        TabView(selection: $selectedTab) {
            ForEach(MainTab.allCases) { tab in
                themedContent(for: tab)
                    .tabItem {
                        Label(tab.title(for: theme), systemImage: tab.icon(for: theme))
                            .accessibilityIdentifier(AccessibilityID.mainTab(tab))
                    }
                    .tag(tab)
            }
        }
        .tint(AppTheme.accent(for: theme))
    }

    @ViewBuilder
    private func themedContent(for tab: MainTab) -> some View {
        if theme == .defaultTheme {
            content(for: tab)
        } else {
            content(for: tab)
                .environment(\.colorScheme, .light)
                .toolbarColorScheme(.light, for: .navigationBar)
                .toolbarColorScheme(.light, for: .tabBar)
        }
    }

    @ViewBuilder
    private func content(for tab: MainTab) -> some View {
        switch tab {
        case .workOrders: WorkOrderHomeView()
        case .calendar: CalendarWorkOrderView()
        case .hub: HubView()
        case .settings: SettingsView()
        }
    }
}

struct LockView: View {
    let unlock: () async -> Void
    var body: some View {
        VStack(spacing: 18) {
            Image(systemName: "lock.shield")
                .font(.largeTitle)
                .accessibilityHidden(true)
            Text("iWorkOrder Locked")
                .font(.title.bold())
            Button("Unlock with Face ID or Passcode") { Task { await unlock() } }
                .buttonStyle(.borderedProminent)
        }
        .padding()
        .accessibilityIdentifier(AccessibilityID.lockScreen)
    }
}


struct DataCompatibilityBlockedView: View {
    let message: String

    var body: some View {
        NavigationStack {
            VStack(alignment: .leading, spacing: 18) {
                Image(systemName: "externaldrive.badge.exclamationmark")
                    .font(.largeTitle)
                    .foregroundStyle(.orange)
                    .accessibilityHidden(true)
                Text("Data Protection Mode")
                    .font(.title.bold())
                Text(message)
                    .font(.body)
                Text("iWorkOrder has paused saving, synchronization, restore, and editing because the saved data cannot be opened safely. Your existing files are being preserved.")
                    .font(.callout)
                    .foregroundStyle(.secondary)
                Text("Do not delete the app. Install the newer compatible build or contact support with the app version shown below.")
                    .font(.callout.weight(.semibold))
                InfoLine(title: "Installed Version", value: AppBuildInfo.displayVersion)
                Button("Email Support") {
                    EmailHelper.openSupportEmail()
                }
                .buttonStyle(.borderedProminent)
                Spacer()
            }
            .padding()
            .navigationTitle("Protected Data")
        }
        .accessibilityIdentifier(AccessibilityID.dataCompatibilityScreen)
    }
}
