# iWorkOrder v35 Legal and PDF Update

Date: 2026-05-02

## Scope
- Added non-intrusive legal banner system.
- Expanded in-app Privacy Policy, Terms & Conditions, and Data & Liability Disclaimer.
- Added legal baseline date and United States-only language.
- Added export and audit notices to work-order creation, editing, detail, and export flows.
- Upgraded PDF exports with export ID, legal notice, chain-of-custody note, work-order IDs, revision counts, timestamped audit label, and export certification section.
- Preserved existing models, iCloud sync, audit log persistence, theme routing, onboarding, and work-order logic.

## Notes
- Privacy link placeholders are not added because the user will provide the external privacy URL later.
- The legal text is a baseline disclosure and disclaimer, not legal advice.
- App Store Connect privacy answers still need to be completed manually before submission.
