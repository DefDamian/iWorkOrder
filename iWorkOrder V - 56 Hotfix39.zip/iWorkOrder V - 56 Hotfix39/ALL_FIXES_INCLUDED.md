# Hotfix 36 — SwiftUI Type-Check Guard

- Fixes the Xcode `VerticalAlignment` compile error caused by `HStack(alignment: .stretch)` in the rebuilt Theme 3 work-order row.
- Replaces the invalid stack-alignment trick with a valid full-height leading overlay for the priority rail.
- Adds a semantic SwiftUI regression harness that checks stack alignment literals and common alignment-taking modifiers that the portable Swift parser cannot type-check against Apple's SwiftUI SDK.
- Preserves the Hotfix35 onboarding theme-scope fix and Hotfix34 Field Deck rebuild.
- Leaves work-order data, backup format, legal version, bundle identity, and iCloud identity unchanged.

# Hotfix 35 — Onboarding Theme-Scope Compile Correction

- Fixes the Xcode `Cannot find 'selectedTheme' in scope` error in `OnboardingView`.
- Keeps onboarding theme padding reactive by deriving `selectedTheme` from the existing `@AppStorage` value inside the correct view scope.
- Adds a source-scope regression harness that scans shipping Swift structs for `selectedTheme` use without a local declaration.
- Preserves Theme 3 Field Deck, Default, Design 2, work-order data, backup format, legal version, bundle identity, and iCloud identity.

# Hotfix 34 — Theme 3 Rebuild + Full Bug Loop

- Rebuilds Design 3 from scratch as **Field Deck** rather than modifying the prior workflow/control-room appearance.
- Uses a dedicated dark graphite base, mint field accent, compact panel geometry, top rails, square operational markers, and high-contrast typography.
- Replaces the Design 3 Work Orders home with a new Field Deck queue, search, status rail, field filters, actions, and work-order rows while preserving all underlying filtering, deep-link, Quick Add, and creation behavior.
- Gives Design 3 dedicated Calendar, Hub, and Settings structures instead of recoloring shared screens.
- Replaces the old purple Theme 3 preview and identity with the new Field Deck preview, with explicit preview color schemes so the dark theme cannot contaminate the light-theme cards.
- Exposes the Emergency-only filter directly in Field Deck so an inherited filter can never remain hidden.
- Keeps the persisted `.design3` raw value and `selectedVisualTheme` key unchanged so theme preferences migrate without a data conversion.
- Leaves Default Theme, Design 2, work-order schema, backup format, legal version, bundle identity, and iCloud identity unchanged.
- Adds a Hotfix34 regression harness plus native UI coverage for Work Orders, Calendar, Hub, and Settings.
- Runs the full existing regression chain again after the rebuild.

# Hotfix 33 — Distinct Theme Identity

- Corrected the theme system so Default Theme, Design 2, and Design 3 no longer look like duplicated versions of one shared layout.
- Design 2 now uses compact command-console geometry, monospaced operational typography, navy/electric-blue surfaces, and denser cards.
- Design 3 now uses rounded workflow typography, blue-purple gradients, softer large-radius cards, and lavender/blue surfaces.
- Theme picker rows and previews render from the theme they represent instead of inheriting the currently selected card style.
- Calendar, Hub, Settings, shared cards, metrics, headers, and settings rows now preserve the selected theme's distinct visual language.
- Added theme-specific Work Order surface identifiers and Xcode UI coverage for all three actual layouts.
- No work-order schema, backup format, legal version, bundle identity, or iCloud identity change.

# Hotfix 32 — Full Bug Loop

- Makes the Hotfix31 privacy badge fully opaque when Reduce Transparency is enabled instead of leaving a `thinMaterial` sub-surface.
- Removes remaining hidden selected-theme styling reads from retained work-order rows, filter chips, priority cards, date labels, onboarding/recovery, permission, and legal surfaces.
- Pins the Design 2 hero gradient to Design 2 so a live theme switch cannot leak the incoming theme into the outgoing layout.
- Makes the evidence-photo delete button honor Reduce Transparency with an opaque fallback.
- Adds a dedicated Hotfix32 full-loop regression harness and Xcode qualification hook.
- Refreshes current privacy/release documentation without changing legal version, data schema, backup format, or iCloud identity.

# Hotfix 31 — Frosted Privacy Shield

- Replaces the old inactive-scene startup-style screen with a dedicated privacy shield for Notification Center, Control Center, and app-switcher transitions.
- Strongly blurs and desaturates live app content before applying the frost so work-order information is unreadable.
- Uses a compact adaptive `iW` mark instead of a splash-sized logo and product title.
- Honors Reduce Transparency with an opaque fallback and keeps covered controls out of accessibility focus.
- Arms only after the app reaches its first active state so it cannot flash during cold launch.
- Preserves Hotfix30 launch continuity, app-lock behavior, lifecycle persistence, backup format, legal version, and iCloud identity.

# Hotfix 30 — Launch Continuity

- Replaces the low-contrast white startup logo with adaptive light/dark production artwork.
- Gives the native iOS launch screen an adaptive background matched to the logo artwork.
- Uses the same launch background and logo in the SwiftUI splash and privacy shield to prevent white/dark flashes during scene activation.
- Matches native and SwiftUI logo size at 170 points.
- Removes the second-stage splash gradient and duplicate `iWorkOrder` title.
- Shortens the artificial splash hold from 850 ms to 320 ms and preserves Reduce Motion behavior.
- Adds a dedicated Hotfix30 launch-continuity harness and Xcode qualification evidence hook.
- Preserves legal version `2026.09.16.56`, user data, backup format, iCloud identity, and theme selection.

# Hotfix 29 — Live Theme Switching Stabilization

- Makes Work Order, Calendar, Hub, Settings, shared cards, backgrounds, and Form/List chrome directly observe the persisted theme selection.
- Uses explicit per-render theme values for shared styling so one screen cannot mix old and new theme values during a live change.
- Removes the duplicate `UserDefaults` write from the Themes picker and makes the fallback setter idempotent.
- Disables animation across the three structurally different layouts during theme changes.
- Keeps the nested Themes navigation bar visible when Design 2 hides the Settings root navigation bar.
- Adds stable theme accessibility identifiers and Xcode UI coverage for Default -> Design 2 -> Design 3 -> Default without relaunching.
- Preserves legal version `2026.09.16.56`, existing data, backup format, workflow values, and iCloud identity.

# Hotfix 28 — Full Bug Loop Integrity Hardening

- Adds a structural invariant that every persisted work order must contain at least one revision.
- Stops damaged local snapshots in protection mode without overwriting or fabricating work-order history.
- Rejects malformed portable backups with empty work-order revision history before restore changes app data.
- Rejects invalid backup export state before archive work files are created.
- Prevents local save, lifecycle persistence, cloud-operation persistence, backup export, and post-backup cloud resume from persisting zero-revision records.
- Removes raw backup/iCloud snapshot fallbacks after normalization failure.
- Restores the prior local compatibility state if an external backup candidate is rejected and releases/discards restore staging safely.
- Resumes the prior iCloud operation after a rejected backup or a restore failure that rolled back cleanly; sync stays paused when restore recovery is incomplete.
- Adds executable migration/storage regressions plus a dedicated Hotfix28 full bug-loop harness.
- Preserves legal version `2026.09.16.56`, backup format, iCloud identity, and existing valid user data.

# Hotfix 27 — Evidence Photo Removal

- Adds a visible trash control to every Before and After evidence thumbnail.
- Requires explicit destructive confirmation before removing a photo.
- Deletes newly selected unsaved attachment files immediately when they have no remaining references.
- Preserves attachment files that are still referenced by an earlier saved revision, preventing broken audit/revision history.
- Keeps duplicate draft references safe from premature physical deletion.
- Adds accessibility labels/hints and a dedicated Hotfix27 regression harness.
- Preserves schema, backup format, iCloud identity, workflow raw values, and legal version `2026.09.16.56`.

# Hotfix 26 — Work-Order Badge Layout

- Prevents `Normal`, `In-progress`, and other work-order priority/status capsules from wrapping into tall multi-line pills on compact iPhone widths.
- Uses an adaptive one-row/two-row work-order footer so date/edit metadata no longer competes with the badges for the same narrow horizontal space.
- Keeps a secondary vertical badge fallback for large Dynamic Type.
- Preserves workflow raw values, storage/backup formats, iCloud behavior, and legal version `2026.09.16.56`.

# Hotfix 25 — First-Use Permissions and Legal Refresh

- Adds a device-local first-use permission review after onboarding/current legal acceptance, including after a backup restore on a new installation or device.
- Requests only notification authorization and camera authorization used by the optional rear torch.
- Keeps photo attachment selection on Apple PhotosPicker without broad Photo Library authorization.
- Confirms this release does not request device Contacts, Calendar, microphone, precise-location, or App Tracking Transparency authorization.
- Keeps App Lock authentication conditional on the user enabling or restoring App Lock.
- Updates camera and Face ID purpose strings to match actual runtime behavior.
- Advances the legal package to `2026.09.16.56`, effective September 16, 2026, requiring renewed acceptance.
- Keeps permission-review completion device-local so backups and iCloud state cannot incorrectly suppress permission review on a new device.

# Hotfix22 consolidated corrections

See `VERIFICATION_NOTES_v56_HOTFIX22_CONSOLIDATED_STABILITY.md`. Current validation separates executable portable tests, static source checks, and unrun native Apple tests. No blanket zero-defect or release-ready certification is made.

## Historical changes

# All Fixes Included

## Phase 56 Hotfix 21: Real-world beta hardening

- Applies notification side effects only after local work-order/profile persistence succeeds.
- Separates explicit reminder and emergency follow-up request identities and anchors emergency follow-ups to the saved revision time.
- Prevents stale asynchronous notification cleanup from overriding newer reconciliation state.
- Retries pending deep links when matching work-order data arrives after launch/sync.
- Treats iOS notification authorization as device-local so a denied/revoked permission does not get synced back as a global preference change.
- Removes dormant remote-push launch handling and unreachable legacy-theme fake metrics.
- Adds a dedicated Hotfix 21 regression harness to cross-platform and Xcode qualification.

## Phase 56 Hotfix 20: Final release-candidate audit

- Moves large evidence conversion and storage inventory work off ordinary UI rendering.
- Uses lightweight ImageIO attachment validation and permission-aware/lifecycle-safe torch handling.
- Caches Support and backup storage summaries and verifies final-RC compiler-risk patterns.


## Phase 56 Hotfix 19: Release candidate hardening

- Adds an opaque inactive/background privacy shield so task-switcher snapshots do not intentionally expose work-order, tenant, photo, or signature content.
- Removes the unnecessary full Photo Library purpose string; evidence remains selected through SwiftUI `PhotosPicker` only.
- Retains the flashlight camera-hardware purpose string and checks live torch availability/mode support before activation.
- Uses iCloud terminology in public sync/recovery status while retaining CloudKit terminology only where technically appropriate.
- Removes stale sync-status localization and adds Hotfix 19 release-candidate regression checks to cross-platform and Xcode qualification.

## Phase 56 Hotfix 18: Entire app public beta qualification

- Evidence Gallery uses bounded Image I/O thumbnails and an actor-isolated cache rather than repeatedly decoding full attachment images in SwiftUI.
- Attachment deletion, snapshot replacement, restore/sync application, and erase paths invalidate thumbnail cache state.
- Custom work-order animations honor Reduce Motion, while custom card/input/overlay surfaces honor Reduce Transparency.
- Standard tab/navigation bars are left to the system appearance instead of receiving an extra custom material background.
- Legacy theme cloud-status labels come from the live CloudKit state rather than hard-coded success/failure text.
- Monthly report export uses one truthful system share-sheet action rather than buttons that imply dedicated Google Drive or OneDrive integration.
- Adds Hotfix 18 public-beta regression checks to the release and Xcode qualification runners.

## Phase 56 Hotfix 17: Public release surface cleanup

- Public Release builds no longer expose the Maintenance & Recovery / Release Health screen or the manual CloudKit recovery-pause control.
- UI-test launch arguments, seeded UI-test records, and the UI-test state loader are compile-time DEBUG-only and are not present in Release-active source.
- Public support is simplified to app status, a privacy-safe support package, and email support; raw diagnostics export is no longer shown to public users.
- Developer-facing localization strings are removed from the shipped string catalog.
- Release build settings disable previews and testability, while app-bundle resources remain limited to runtime assets, privacy metadata, and localization.
- Added a dedicated public-release harness to prevent internal surfaces from leaking back into the App Store build.

## Phase 56 Hotfix 16: Swift 6 draft-image cleanup compile fix

- Replaces `entry.images.forEach(ImageStorageService.delete)` with an explicit loop because `ImageStorageService.delete(_:)` returns `Bool` while `forEach` requires a `Void` callback.
- Keeps deletion verification behavior intact while intentionally discarding the return value in this best-effort draft cleanup path.
- Adds a regression gate for direct function references passed to `forEach` in app source.
- Hotfix 14 legal content and re-acceptance behavior are unchanged.

## Phase 56 Hotfix 15: Xcode restore access-control compile fix

- `prepareSnapshotCommit(_:)` is no longer `fileprivate`, so the restore flow in `AppStore.swift` compiles when calling the transaction object declared in `BackupArchiveService.swift`.
- The method remains internal to the iWorkOrder module.
- Automated release verification now contains a dedicated cross-file access-control regression gate.
- Hotfix 14 legal content and re-acceptance behavior are unchanged.

## Phase 56 Hotfix 14: Legal refresh and re-acceptance gate

- Refreshed Privacy Policy, Terms & Conditions, and Data & Liability Disclaimer.
- Legal version is `2026.09.13.56`, effective September 13, 2026.
- Added a Legal Terms Updated splash for profiles that accepted an older legal revision.
- Requires successful renewed acceptance before normal app access resumes.
- Keeps public legal copies synchronized with the bundled authoritative text.
- Aligns permission disclosures with the current PhotosPicker and Apple geocoding implementation.

# iWorkOrder cumulative release summary

This v56 package contains the complete project history through Phase 56. The newest phase supersedes older implementation notes where they conflict.

## Core application

- SwiftUI work-order creation, editing, status tracking, search, calendar, dashboard, trash, tenant, asset, photo, signature, audit, PDF, and settings workflows.
- Multiple visual themes with immediate theme switching.
- Optional Face ID, Touch ID, or device-passcode app locking.
- Work-order reminders and emergency-priority notifications.
- Native Mail composition with a share-sheet fallback.
- Registered `iworkorder://workorder/<UUID>` deep links.

## Phase 46: revision and audit integrity

- Repaired the shared Xcode scheme.
- Enforced unique revision identifiers and monotonic revision timestamps.
- Repaired historical duplicate revision IDs before merge.
- Prevented signature inheritance across edited revisions.
- Removed false signed events and duplicate integrity events.

## Phase 47: CloudKit attachment synchronization

- Replaced full-data iCloud key-value syncing with the private CloudKit database.
- Added snapshot, photo, and signature `CKAsset` transfer.
- Added attachment hashes, size checks, corruption repair, missing-file detection, and orphan cleanup.
- Added serialized operations, network-state reporting, custom-zone deletion, migration, and persistent erase protection.

## Phase 48: portable backup and restore

- Added the `.iworkorderbackup` archive format containing snapshot data, photos, and signatures.
- Added per-file and whole-archive SHA-256 validation.
- Added Merge and Replace restore modes, safety backups, rollback journals, low-storage checks, legacy JSON migration, and CloudKit replacement protection.

## Phase 49: runtime security and integrations

- Relocks after backgrounding.
- Reconciles and removes invalid pending and delivered notifications.
- Enforces notification preference switches.
- Removes programmatic app termination.
- Applies themes immediately.
- Hardens erase behavior, email composition, and deep-link routing.

## Phase 50: legal, privacy, signatures, and automated verification

- Replaced remote legal loading with authoritative bundled legal documents.
- Added legal version `2026.08.04.50` and renewed-acceptance gating.
- Separated onboarding completion from legal acceptance.
- Added accurate public legal copies for publication.
- Reconciled local storage, private CloudKit, backups, audit limitations, deletion, and signature disclosures.
- Requires a nonblank signature drawing and signer name.
- Persists signature capture time and legal consent version.
- Adds signature metadata to PDF exports and archive snapshots.
- Audited the privacy manifest and removed unsupported System Boot Time declaration.
- Added an Xcode unit-test target, shared-scheme tests, static checks, a platform-neutral logic harness, macOS CI, and an unsigned release-archive command.

## Release limitation

The Linux verification included with this package cannot perform an iOS SDK compile, simulator run, code signing, TestFlight upload, Xcode privacy report, or physical-device validation. Run `Scripts/run_xcode_ci.sh` and the manual release checklist on macOS before distribution.

## Phase 51: Xcode 26 release qualification

- Advanced the application and test build number to 51.
- Flattened every AppIcon image to RGB to remove App Store alpha-channel risk.
- Added exact icon dimension, PNG encoding, and alpha-channel verification.
- Enabled strict-concurrency diagnostics without forcing an untested Swift 6 language-mode migration.
- Enabled user-script sandboxing, Release dead-code stripping, and product validation.
- Added Xcode 26 and iOS 26 SDK enforcement.
- Added dynamic selection of current iPhone and iPad simulators.
- Added warning-as-error simulator tests, static analysis, unsigned or signed Release archive generation, and archive payload validation.
- Added signed entitlement and code-signature verification when an Apple Team ID is supplied.
- Pinned GitHub Actions to macOS 26 and retained qualification evidence as CI artifacts.
- Added secure signing guidance without embedding developer credentials.


## Phase 52: accessibility, iPad adaptivity, and UI automation

- Added stable accessibility identifiers, VoiceOver labels, values, hints, traits, grouping, and custom actions.
- Hid decorative artwork from assistive technologies.
- Replaced fixed point-size fonts with semantic Dynamic Type styles.
- Added scaled dimensions, `ViewThatFits`, and adaptive grids for large text and narrow windows.
- Added regular-width iPad sidebar navigation while retaining compact tab navigation.
- Enabled all iPad orientations, Split View, Stage Manager, and resizable windows.
- Added Command-1 through Command-4 hardware-keyboard navigation.
- Added Reduce Motion behavior for the splash screen.
- Added an English string-catalog baseline.
- Added an Xcode UI-test target, deterministic launch fixtures, accessibility audits, work-order creation/navigation tests, and a Phase 52 accessibility harness.
- Corrected signed archive mode so code signing is explicitly enabled when a Team ID is supplied.

## Phase 53: TestFlight stabilization and App Store handoff

- Added privacy-safe technical diagnostics and support email attachment flow.
- Added diagnostics privacy and file-generation unit tests.
- Added UI coverage for Support & Diagnostics and named synthetic screenshot capture.
- Added draft App Store metadata, TestFlight instructions, review notes, privacy/export/age-rating guidance, and account-holder confirmation gates.
- Added publish-ready marketing and support pages.
- Added metadata, screenshot, and IPA validators.
- Added repeated unit-test stabilization, iPhone and iPad screenshot evidence, signed App Store Connect export, and validated manual upload handoff.

## Phase 54: Maintenance, migration, and rollback

- Added explicit data schema version 2.
- Added deterministic schema 1 to schema 2 migration.
- Added protected pre-migration recovery copies with retention limits.
- Added Data Protection Mode for unsupported future schemas.
- Blocked saving and CloudKit activity while data compatibility is unresolved.
- Added unreadable-primary quarantine and fallback snapshot reconstruction.
- Added privacy-safe local operational history with fixed fields, 30-day retention, and a 250-event cap.
- Added structured performance timing for local saves, CloudKit sync, backup export, and backup restore.
- Added Maintenance & Recovery health checks and user-controlled report export.
- Added migration, compatibility, report-privacy, and UI automation coverage.
- Added a formal release rollback runbook and migration test matrix.
- Updated legal version and public legal copies for local operational history and migration recovery behavior.

## Phase 55: Field reliability and issue containment

- Added a local runtime lifecycle checkpoint and possible interrupted-session evidence without claiming a crash.
- Added aggregate memory-pressure warning history with the existing 30-day and 250-event limits.
- Added a user-controlled pause for ordinary CloudKit synchronization during recovery.
- Preserved completion of pending cloud erase and authoritative replacement transactions while paused.
- Added a checksum-verified `.iworkordersupport` bundle containing only privacy-safe technical and aggregate evidence.
- Added support-bundle Mail/share handoff, unit tests, UI tests, executable reliability tests, CI gates, and release documentation.
- Updated build number and legal acceptance version to Phase 55.

## Phase 56: Apple release qualification execution and evidence gates

- Advanced app, unit-test, and UI-test build numbers to 56.
- Added a macOS/Xcode 26 qualification runner with simulator testing, five repeated unit-test iterations, static analysis, archive validation, signed IPA export, entitlement capture, and code-signature checks.
- Added optional connected iPhone and iPad test evidence.
- Added a machine-readable evidence matrix and a strict final validator that rejects incomplete, failed, blocked, missing, or unsafe evidence.
- Added SHA-256 indexing for generated qualification artifacts.
- Added physical-device, CloudKit production, privacy-report, accessibility, website, screenshot, App Store Connect, and TestFlight release gates.
- No Apple-only execution result is claimed by the source package itself.


## Phase 56 Hotfix 1: Xcode compile corrections

- Removed all stale references to the deleted `EmailHelper.email(order:)` API.
- Routed row-level email actions through `MailDraft`, `MailComposerView`, and the existing share fallback.
- Corrected optional URL handling in the support-email attachment description.
- Added static release assertions for both defects.
- Left `DEVELOPMENT_TEAM` blank by design so no private Apple Team ID is distributed.


## Phase 56 Hotfix 2: Legal agreement acceptance

- Fixed the onboarding agreement closure being bound to the decline callback by Swift trailing-closure rules.
- Wired the Agree action with the explicit `accept:` argument.
- Prevented silent no-op acceptance buttons.
- Added a UI regression test that verifies acceptance, sheet dismissal, and the accepted state on onboarding.

## v56 Hotfix 3 — Swift 6 Concurrency

Resolved the Xcode 26 strict-concurrency build failures by isolating UI services to the main actor, making callback transfers Sendable, removing unsafe captures, and explicitly configuring Swift 6. See `VERIFICATION_NOTES_v56_HOTFIX3_SWIFT6_CONCURRENCY.md`.

## v56 Hotfix 4

- Removed the ineffective `@preconcurrency` annotation from `UNUserNotificationCenterDelegate` conformance.
- Preserved explicit `@MainActor` service isolation and `nonisolated` delegate callbacks.
- Added a release verification gate that rejects the warning pattern.

## v56 Hotfix 5 - Signature completion controls

Fixed the PencilKit state bridge so drawing a signature immediately enables Clear Signature and Save Signature. Added a delegate coordinator and a UI regression test for the completion flow.

## v56 Hotfix 6 - Defect-only stabilization

- Added required-field validation and text normalization for quick add, full creation, editing, and completion.
- Added revision-conflict protection against stale editors overwriting newer synchronized data.
- Made core work-order creation and revision saves roll back when local persistence fails.
- Made signature completion transactional, removed failed signature files, and blocked duplicate taps.
- Added cleanup for uncommitted draft images and signatures.
- Corrected near-term notification precision by retaining seconds.
- Unified iCloud storage state changes across onboarding and Settings.
- Stabilized share-sheet identity and preserved attachment URLs in fallback sharing.
- Corrected Theme 2 overdue filtering, worker/overdue counts, and New status labeling; removed displayed no-op filter pills.
- Added visible failure reporting for photo import, flashlight activation, and PDF generation.
- Extended UI automation to save the signature and verify the completed locked state.

## v56 Hotfix 7 — Transactional Integrity

- Replaced permanent delete-state merging with newest delete/recovery transition resolution.
- Prevented failed saves from consuming save revision numbers.
- Preserved pending revision-repair evidence until protected persistence succeeds.
- Added rollback boundaries for cloud-applied snapshots that fail local persistence.
- Prevented viewing a signed completed order from mutating its legal audit trail.
- Made trash, recovery, asset, tenant, and unit-import actions transactional.
- Preserved form input when directory or unit-import persistence fails.
- Moved retention file deletion after successful snapshot persistence.
- Protected image files still referenced by another revision.
- Rejected stale address-geocoding callbacks.
- Required backup export to commit integrity repairs before archive generation.
- Made legacy snapshot restore completion conditional on successful persistence.

## v56 Hotfix 8 — Xcode 26 ScrollView initializer

- Made all shorthand vertical SwiftUI scroll-container initializers explicit to prevent Xcode 26 overload ambiguity.

## v56 Hotfix 9 — SwiftUI action result ambiguity

- Explicitly discarded the Boolean result returned by transactional trash persistence inside the swipe-row animation action.
- Removed the `Void` versus `Bool` generic-result conflict reported by Xcode 26.
- Added release verification that prevents the ambiguous closure form from returning.

## v56 Hotfix 10 — Category Manager

- Replaced the read-only fixed category enum list with a persisted ordered category configuration.
- Added transactional category add, delete, and reorder operations with validation and save rollback.
- Updated all category pickers and filters to consume the managed category source.
- Preserved categories already recorded on historical and signed work orders after manager deletion.
- Added schema 3 migration and independent CloudKit conflict resolution for category configuration.
- Added unit and UI regression coverage for category coding, migration, merge, add, and delete behavior.



## v56 Hotfix 20 — Final release-candidate audit

- Moved selected-photo downsampling and JPEG conversion to an ImageIO path that runs away from the SwiftUI actor, preventing large evidence imports from synchronously decoding and redrawing full images in the form.
- Added regression coverage proving picker bytes are converted to a readable bounded JPEG.
- Made the optional flashlight camera-authorization aware and cancellation aware before torch activation.
- Forces the torch off when the evidence form leaves the foreground or disappears, including the case where camera authorization returns after the form is no longer visible.
- Prevents overlapping flashlight hardware requests while permission/configuration work is in progress.
- Moved recursive local-storage size calculation out of normal Support view rendering and onto a utility task.
- Moved Export & Backup storage totals and latest-safety-backup discovery out of SwiftUI body rendering and into the same cached utility refresh path.
- Replaced full signature-image decoding during signed-record integrity checks with a tiny ImageIO pixel-decode validation.
- Updated the descriptive custom-URL identifier to `com.damiancedeno.iWorkOrder` while preserving the existing `iworkorder` scheme, bundle identifier, and iCloud container compatibility identities.
- Added `Scripts/run_final_rc_harness.py` to enforce these release-candidate guarantees.

## Hotfix 23 — Xcode Runtime Warning Cleanup
- Removed completion-handler notification cleanup and nested weak-capture bridge tasks flagged by Xcode.
- Deferred ObservableObject mutations from SwiftUI custom Binding setters to avoid publishing during view updates.
- Added Hotfix 23 regression coverage and Xcode qualification integration.

## v56 Hotfix 31 — Frosted privacy shield

- Replaced the full startup-style privacy cover shown during Notification Center, Control Center, app switching, and other inactive scene states with a dedicated frosted privacy layer.
- Strongly blurs and desaturates the underlying app before the cover appears so work-order details remain unreadable.
- Uses a compact adaptive iWorkOrder mark instead of a second splash screen or large product title.
- Added a Reduce Transparency fallback and preserved accessibility isolation while the cover is active.
- Added a first-activation guard so privacy protection does not interrupt the Hotfix30 launch handoff.
- Added Hotfix31 regression coverage and Phase 56 qualification integration.
