# iWorkOrder v56 Hotfix 18 — Entire App Public Beta Qualification

## Scope

Hotfix 18 is a non-feature public-beta qualification pass over the complete app. It focuses on runtime responsiveness, accessibility behavior, truthful public UI state, current system-navigation behavior, and release verification without changing the legal revision or storage model.

## Changes

- Evidence galleries no longer decode full 1080p attachments synchronously inside SwiftUI rendering. Display-size JPEG thumbnails are generated with Image I/O, cached behind an actor, bounded to 64 entries, and invalidated when attachments are deleted, replaced, restored, synced, or erased.
- Added unit coverage for readable bounded thumbnails and deleted-attachment cache invalidation.
- Custom work-order animations now honor Reduce Motion.
- Shared card/input surfaces and blocking overlays now honor Reduce Transparency with opaque alternatives.
- Removed custom tab-bar material/visibility overrides so standard SwiftUI navigation can use the current system appearance without an extra material layer.
- Legacy theme headers now show the actual `CloudSyncState` instead of hard-coded success/failure text.
- Replaced provider-named report buttons that all opened the same share sheet with one accurate **Share or Save Report** action and matching guidance.
- Updated localization for the corrected public report-sharing language.
- Added `Scripts/run_public_beta_harness.py` and integrated it into both cross-platform verification and the macOS/Xcode qualification runner.

## Verification completed in this environment

- Swift source parsing in both default and `DEBUG` configurations.
- Existing logic, accessibility, submission, migration/maintenance, runtime-reliability, defect, transactional-integrity, core-stability, and public-release harnesses.
- Hotfix 18 public-beta static/regression harness.
- App Store metadata validation.
- Phase 56 template evidence validation.
- Python bytecode and shell syntax checks.

## Required macOS/Xcode verification

This environment does not include Apple's iOS SDK, Simulator, code-signing services, or `xcodebuild`. Before public beta distribution, run the Phase 56 Xcode qualification on macOS and verify:

1. Release build with Swift and Clang warnings treated as errors.
2. iPhone and iPad simulator tests plus the repeated unit-test loop.
3. Evidence Gallery scrolling with many before/after photos and no visible hitching or incorrect thumbnails.
4. Reduce Motion and Reduce Transparency across Default, Design 2, and Design 3 themes.
5. Live cloud-status wording while local-only, syncing, offline, paused, signed out, and failed.
6. Monthly report **Share or Save Report** through Files and installed provider extensions.
7. Signed archive privacy report, entitlements, CloudKit production configuration, and TestFlight smoke test.

## Release/legal note

Legal version remains `2026.09.13.56`. Hotfix 18 changes performance, accessibility presentation, and public UI accuracy; it does not alter the legal terms and therefore does not intentionally trigger another legal re-acceptance.
