# iWorkOrder v56 Hotfix26 — Work-Order Badge Layout

## Purpose

Hotfix26 corrects the compact iPhone work-order card layout where the `Normal` priority and `In-progress` status capsules could become tall and wrap into multiple lines when date/edit metadata consumed the available horizontal width.

## UI correction

- Priority and status capsules now keep their labels on one line.
- The work-order metadata area uses SwiftUI `ViewThatFits` so wider layouts can keep a compact single row while narrower iPhone layouts automatically move the badges onto a clean trailing row.
- The badge group has an additional vertical fallback for very large Dynamic Type sizes or unusually narrow widths.
- Creation-date metadata is capped at two lines and receives layout priority instead of forcing the badges to compress.
- Priority/status model raw values are unchanged, so this is a presentation-only correction with no backup, persistence, iCloud, workflow-state, or legal-version migration.

## Verification

`Scripts/run_hotfix26_work_order_badge_layout_harness.py` checks the responsive layout, one-line badge constraints, Dynamic Type fallback structure, and persistence-safe model values. The harness is included in both cross-platform release verification and the Phase56 Xcode qualification runner.

Native visual verification on an iPhone or Xcode simulator is still required to inspect the final Apple-rendered font metrics and system materials.
