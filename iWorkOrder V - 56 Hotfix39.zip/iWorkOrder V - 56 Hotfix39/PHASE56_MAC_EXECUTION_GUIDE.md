## Hotfix22 runner safety and validation

Run `./Scripts/run_xcode_ci.sh` from the extracted project. The command uses the existing native qualification pipeline; no upload or publication is performed by this command. The initial portable stage now includes executable core-behavior tests.

Custom `PHASE56_ARTIFACTS_DIR` must be a dedicated subdirectory below this project's `Artifacts`; custom `PHASE56_DERIVED_DATA` must be below this project's `build`. Root directories, source directories, escaping symlinks, and manual evidence inside a cleanup destination are refused before deletion. Copy a prior evidence file outside disposable output before using it as manual evidence.

Run the new `ConsolidatedDataRegressionTests` and `PDFExportRegressionTests` in the existing XCTest target. Native PDF output must also be visually inspected. Do not interpret the portable test stand-ins as Apple SDK execution.

# Phase 56 Mac and Apple release qualification

Phase 56 is the first phase that can only be completed with Apple’s real release environment. The repository contains the runner and evidence gates, but the phase is not complete until the signed build, physical-device, CloudKit production, privacy-report, website, screenshot, and TestFlight evidence all pass.

## Automated Mac qualification

For the final native gate, use macOS Tahoe 26.6 or later with stable Xcode 27 build `27A266a`. Xcode 27 includes the iOS 27 SDK and Swift 6.4 compiler while the project remains in Swift 6 language mode:

```bash
PHASE56_MODE=ci ./Scripts/phase56_xcode_qualification.sh
```

The native runner rejects a different Xcode build by default so final evidence cannot accidentally come from an older or beta toolchain. It writes evidence to `Artifacts/Phase56`. As of September 17, 2026, App Store Connect accepts Xcode 27 / iOS 27 SDK builds for App Store and TestFlight submission.

The repository’s hosted workflow runs `./Scripts/run_xcode_ci.sh` on macOS 26 in explicit compatibility mode. That hosted result is useful regression evidence, but it does **not** replace the native Xcode 27 final gate.

## Signed release-candidate qualification

Sign in to the authorized Apple Developer account, then run:

```bash
APPLE_TEAM_ID=YOUR_TEAM_ID \
PHASE56_MODE=signed \
./Scripts/phase56_xcode_qualification.sh
```

Optional connected-device unit-test evidence can be added with:

```bash
APPLE_TEAM_ID=YOUR_TEAM_ID \
PHASE56_MODE=signed \
PHASE56_IPHONE_DEVICE_ID=DEVICE_UDID \
PHASE56_IPAD_DEVICE_ID=DEVICE_UDID \
./Scripts/phase56_xcode_qualification.sh
```

The script does not upload or submit the app automatically.

## Final evidence gate

Copy `ReleaseEvidence/phase56_evidence.template.json` to a controlled evidence location. Mark a gate `pass` only after its evidence exists. Evidence paths must stay under the project or qualification root.

Validate a work-in-progress record:

```bash
python3 Scripts/validate_phase56_evidence.py \
  ReleaseEvidence/phase56_evidence.template.json \
  --root .
```

Require every mandatory gate to pass:

```bash
python3 Scripts/validate_phase56_evidence.py \
  Artifacts/Phase56/phase56_evidence.json \
  --root . \
  --require-complete
```

The full runner can enforce the same final gate:

```bash
APPLE_TEAM_ID=YOUR_TEAM_ID \
PHASE56_MODE=signed \
PHASE56_FINAL_GATE=1 \
PHASE56_MANUAL_EVIDENCE=/path/to/completed_phase56_evidence.json \
./Scripts/phase56_xcode_qualification.sh
```

## Mandatory manual evidence

The final evidence record must cover:

- Signed archive and IPA validation
- Physical iPhone and iPad workflows
- Two-device private CloudKit production testing
- CloudKit schema deployment to production
- Xcode privacy-report review
- Accessibility Inspector and direct assistive-technology testing
- Backup and restore through real Files providers
- Notifications, permissions, biometrics, Mail, the Photos picker, optional flashlight/torch camera-purpose behavior, and deep links
- Large dataset, low-storage, offline, and conflict scenarios
- Public marketing, support, privacy, terms, and disclaimer pages
- Final screenshots
- Account-holder App Store Connect decisions
- TestFlight processing and internal stabilization exit criteria

Do not mark a manual gate complete from source inspection alone.
