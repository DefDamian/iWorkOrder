# iWorkOrder v56 — Hotfix 27 Evidence Photo Removal

## Scope

Hotfix27 adds a safe removal path for Before and After evidence photos while a work-order revision is being edited.

## User-facing behavior

- Every Evidence Gallery thumbnail now has a visible trash control.
- Tapping trash does not remove evidence immediately. A confirmation dialog appears first.
- A newly selected photo that has not yet been saved is removed from the draft and its protected local attachment file is deleted immediately when no other draft reference uses that file.
- A photo that already belongs to a saved revision can be removed from the revision currently being edited, but the attachment is not physically deleted while an earlier saved revision still references it. This preserves the existing revision/audit history instead of corrupting historical evidence.
- The confirmation dialog explains when earlier saved revision history will remain intact.
- Thumbnail-cache invalidation continues through the existing `ImageStorageService.delete(_:)` path.

## Data-integrity boundaries

This change does not alter the work-order schema, backup format, CloudKit record identity, bundle identity, workflow raw values, or legal version. It intentionally does not rewrite or erase historical saved revisions when a current edit removes a photo.

## Automated verification

`Scripts/run_hotfix27_photo_delete_harness.py` checks the confirmation flow, destructive/cancel roles, accessibility labeling, exact image removal, saved-revision preservation, duplicate-draft protection, local-file deletion for unsaved photos, and thumbnail-cache behavior. It is included in both portable verification and the macOS/Xcode qualification path.

Native Xcode build, simulator presentation, and on-device interaction remain required for final Apple-runtime qualification.

## Portable verification result

The complete cross-platform verification suite passed after this change. The release verifier reported 455 checks passed, the dedicated Hotfix27 photo-delete harness passed 18/18 checks, App Store metadata validation passed 44 checks, and Swift parser validation passed for both Release and DEBUG source paths.

The Phase 56 manual Apple evidence template still reports its native/manual gates as pending because this environment does not run Xcode, an iOS simulator, or a physical iPhone/iPad.
