# Phase 56 TestFlight stabilization plan

## Purpose

Use TestFlight to prove that the signed production configuration is stable under realistic work-order use before App Store submission. Test only with synthetic or properly authorized data.

## Internal group 1: release qualification

Participants should include the account holder and users able to verify installation, launch, provisioning, private CloudKit, notifications, app locking, backup and restore, iPhone layouts, and iPad layouts.

Required scenarios:

- Fresh installation and onboarding in Local Only mode.
- Upgrade from an existing v50-v54 dataset.
- Legal acceptance migration.
- Create, revise, complete, sign, delete, recover, and permanently erase records.
- Before-and-after photos with a long Evidence Gallery, PDF export, native Mail, and Share or Save Report through Files and installed share extensions.
- Notification scheduling and cleanup after completion, deletion, disable, and erase.
- Background relocking with Face ID, Touch ID, or passcode.
- Reduce Motion and Reduce Transparency across all three themes.
- Live cloud-state wording in Default, Design 2, and Design 3 while local-only, syncing, offline, paused, and signed out.
- Portable backup export, Merge restore, Replace restore, safety restore, interruption recovery, corruption rejection, and low-storage rejection.
- iPhone and iPad portrait, landscape, Split View, Stage Manager, keyboard, VoiceOver, Dynamic Type, Reduce Motion, and Increased Contrast.
- Privacy-safe diagnostics generation and review before sending.

Exit criteria:

- No launch crash, data-loss defect, unrecoverable onboarding failure, broken restore, missing signed evidence, or cloud resurrection defect.
- No open critical or high-severity defect.
- No stale notification containing deleted work-order information.
- No blocker-level accessibility or iPad layout defect.
- Signed archive, IPA validation, privacy report, and CloudKit production checks pass.

## Internal group 2: operational workflow

Use a small authorized group with synthetic records. Exercise daily creation and completion, long revision histories, repeated backups, multiple photos, offline periods, and two-device edits.

Run for enough real usage to expose delayed notification, storage-growth, conflict, and sync issues. Do not judge stability from launch-only testing.

## External beta

Begin only after internal exit criteria pass. Provide focused What to Test instructions and a monitored support address. The first external build may require TestFlight App Review.

## Defect severity

- Critical: data loss, privacy exposure, wrong-record overwrite, unrecoverable restore, security bypass, or launch failure.
- High: missing attachments, repeated sync failure, broken signing, stale sensitive notification, or inaccessible core workflow.
- Medium: recoverable workflow failure, misleading status, layout clipping, or incomplete export.
- Low: cosmetic defect with no operational impact.

Any critical or high defect resets the affected stabilization scenario after the fix.

## Retained Phase 55 field reliability scenarios

- Relaunch after a clean background transition and confirm no interruption warning is recorded.
- Force-terminate a synthetic test session while active and confirm the next launch reports only a possible interrupted session.
- Exercise a memory-warning test path on a physical device and confirm only aggregate evidence appears.
- Pause ordinary CloudKit synchronization, create and edit local work orders, then confirm no ordinary cloud transfer starts.
- While paused, complete any already-pending cloud erase or authoritative replacement transaction.
- Export a verified support bundle, validate its checksum, and inspect it for prohibited operational content.
- Tamper with a copy of the support bundle and confirm validation rejects it.
- Resume synchronization and verify the expected local dataset is uploaded or merged without resurrecting deleted content.


## Hotfix 20 focus

During the next TestFlight pass, specifically exercise first-use flashlight permission, backgrounding while the torch is active, cancellation/dismissal during the permission prompt, large HEIC/JPEG evidence imports, Support-screen responsiveness with a large dataset, and `iworkorder://` deep-link routing.


## Hotfix 21 focus

During the next TestFlight pass, specifically test reminder persistence under failed/successful saves, independent explicit-reminder and emergency-follow-up delivery, non-resurrection of expired emergency follow-ups after reopen/resync, and deep-link routing when the target order arrives after launch. Verify local notification taps from foreground, background, and terminated states. On two synced devices, deny/revoke notification permission on only one device and confirm that device shows the local permission warning without synchronizing a global disable to the other device.
