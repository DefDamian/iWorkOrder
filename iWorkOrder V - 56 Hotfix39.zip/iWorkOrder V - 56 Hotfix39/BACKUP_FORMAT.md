# iWorkOrder Portable Backup Format

Current archive generation: Phase 48  
File extension: `.iworkorderbackup`  
Format identifier: `com.damiancedeno.iworkorder.backup`  
Container format version: `1`  
Snapshot schema version: `1`

## Binary layout

All integer fields use big-endian byte order.

1. Eight-byte magic value: `IWOBKP48`
2. Four-byte unsigned archive format version
3. Eight-byte unsigned manifest length
4. UTF-8 JSON manifest
5. Raw item payloads in manifest order
6. Thirty-two-byte SHA-256 digest of every preceding archive byte

The payload is streamed rather than loaded into memory as one large object.

## Manifest

The manifest records:

- format identifier and versions
- export UUID and creation date
- app version and build
- source device identity and save revision
- source snapshot timestamp
- work-order, revision, asset, tenant, photo, and signature counts
- total payload bytes
- one descriptor for each payload item

Each item descriptor records its relative path, safe filename, kind, byte count, SHA-256 checksum, and source modification date.

## Required items

Every archive contains exactly one `snapshot.json` item. Referenced attachments are stored under:

- `images/<filename>`
- `signatures/<filename>`

The restore validator rejects absolute paths, path traversal, nested filenames, duplicate paths, unsupported versions, archives larger than 20 GB, unreasonable manifest sizes, unreasonable item counts, invalid checksums, invalid lengths, archive-length mismatches, and snapshot/attachment manifest mismatches. Export, staging, and installation also reserve free storage before writing.

Phase 50 does not change the container format. New optional snapshot fields, including signature signer name, capture time, and legal consent version, remain backward compatible because they are encoded inside `snapshot.json`.

## Restore process

1. Obtain scoped access to the selected Files-provider URL when required.
2. Verify the magic, format version, manifest, calculated archive length, and whole-archive checksum.
3. Stream each payload into a temporary staging directory while verifying its individual length and checksum.
4. Decode and validate the staged snapshot.
5. Compare manifest counts and attachment references with the snapshot.
6. Present Merge or Replace only after validation succeeds.
7. Create and verify a pre-restore safety archive of the current state.
8. Create a persistent restore journal before any final attachment path is changed.
9. Install attachments while recording every created or replaced target.
10. Save the restored snapshot to protected local storage and mark the journal committed.
11. Finalize attachment cleanup and schedule the appropriate CloudKit action.

At launch, any surviving restore journal is compared with the loaded snapshot save revision. If the restored snapshot was committed, cleanup is finalized. Otherwise the journal restores replaced files and removes newly created files before the app presents data.

No current app data is intentionally modified during steps 1 through 6. During export and restore, iWorkOrder also acquires exclusive local-data access from the CloudKit actor and blocks app interaction and background saves so the snapshot and attachment set cannot change mid-transaction.

## Merge semantics

Merge combines work orders, revision entries, audit events, status events, assets, and tenant contacts using existing identity-aware conflict logic. Current device profile and preference values are retained, including legal acceptance, notifications, security, theme, and storage choice. Different files using the same attachment filename cause the merge to stop rather than silently overwrite either file.

## Replace semantics

Replace makes the imported snapshot and attachments authoritative. Unreferenced local attachment files are removed after the new snapshot is saved. If the current or restored profile uses iCloud, a persistent replacement flag blocks ordinary cloud merge and restore. The app deletes and recreates its private custom CloudKit zone, uploads the restored attachments and snapshot, and clears the flag only after the complete cloud transaction succeeds.

## Safety backups

Before every restore, the app creates a verified archive under protected Application Support storage. The three newest safety archives are retained. Settings > Export & Backup can validate and restore the latest safety archive. Erase All Data removes this directory.

## Legacy JSON migration

A raw legacy `AppSnapshot` JSON file can still be selected. It is size-limited and decoded using the supported snapshot date format. Because legacy JSON did not embed files, references to unavailable photos or signatures are removed. The app presents warnings and adds integrity notices to affected work orders before restore.

## Confidentiality

The archive uses integrity checks, not password encryption. Its contents may include resident names, property details, work-order notes, photographs, signatures, and audit records. File-provider encryption and access controls depend on where the user saves the exported archive.
