# v47 CloudKit and Attachment Sync

Scope: Phase 47 cloud-storage replacement and attachment-integrity hardening.

## Changes made

- Replaced the operational `NSUbiquitousKeyValueStore` full snapshot with the user's private CloudKit database.
- Added a custom CloudKit zone so all iWorkOrder cloud records can be erased as one isolated unit.
- Stored the versioned JSON snapshot as `CKAsset` data rather than a key-value payload.
- Stored each photo and signature as an independent `CKAsset` record.
- Added deterministic attachment record identifiers based on attachment kind and filename.
- Added SHA-256 and byte-count verification for attachments.
- Added safe-filename validation before reading or writing restored files.
- Added missing-local and incomplete-cloud attachment failures that prevent false successful-sync status.
- Added automatic repair of corrupted local attachments when a valid immutable cloud asset exists.
- Added cleanup of attachment records no longer referenced by the committed snapshot.
- Added a persistent erase-pending barrier that survives relaunch, clears local remnants, and blocks sync or restore until the custom zone is deleted.
- Serialized startup, automatic, manual, restore, and erase cloud operations.
- Added generation checks so stale asynchronous results cannot overwrite newer UI or app state.
- Added real network reachability through `NWPathMonitor` and fixed the initial callback registration race.
- Added explicit CloudKit account, restriction, quota, network, throttling, and conflict messages.
- Recorded Last Successful Sync only after the full cloud transaction completes.
- Preserved the old key-value snapshot only for one-time migration and cleared it after a successful CloudKit commit.
- Updated onboarding and Cloud settings to describe and display actual record and attachment sync behavior.

## Verification performed

- Parsed every Swift file with the Swift frontend.
- Type-checked the CloudKit service in Swift 6 strict-concurrency mode using isolated test modules.
- Parsed the entitlements, privacy manifest, and shared Xcode scheme as XML.
- Verified the CloudKit service source is included in the target's Compile Sources phase.
- Verified the shared scheme uses the real PBX target identifier.
- Verified the CloudKit container in source matches the entitlement container.
- Verified the former key-value full-snapshot writer is absent.
- Ran an executable in-memory CloudKit harness covering:
  - initial snapshot and attachment upload
  - full photo and signature restore
  - manual corruption repair
  - automatic corruption repair before upload
  - removal of unreferenced attachment records
  - missing cloud attachment detection
  - persistent erase blocking before deletion
  - complete custom-zone erasure and barrier clearing

## Required external verification

A real CloudKit account and Apple runtime are still required to validate:

- development-container schema creation
- production-schema deployment
- provisioning and entitlements
- TestFlight behavior
- two-device propagation
- CloudKit quotas and throttling under real service conditions
- simulator and physical-device UI behavior
- Release archive and code signing

These checks require macOS, Xcode, Apple Developer signing, and access to the configured CloudKit container.
