# v48 Portable Backup and Restore

Scope: Phase 48 portable backup, restore transaction, migration, safety recovery, and CloudKit replacement protection.

## Changes made

- Added `BackupArchiveService.swift` to the application target.
- Added a streamed `.iworkorderbackup` container with a versioned JSON manifest.
- Added per-item SHA-256 and byte-count verification and a whole-archive SHA-256 footer.
- Added strict item-count, manifest-size, legacy-size, path, filename, duplicate, length, checksum, and snapshot/manifest consistency validation.
- Included all referenced photos and signatures with the snapshot.
- Added fully staged validation before the restore confirmation appears.
- Added Merge and Replace restore modes.
- Preserved current profile and preferences during Merge restore.
- Added attachment collision detection for non-destructive Merge restore.
- Added persistent transactional attachment installation and rollback.
- Added launch-time reconciliation for interrupted restores using the committed snapshot save revision.
- Added a 20 GB archive ceiling and free-storage preflight for export, staging, and attachment installation.
- Added exclusive local-data access against CloudKit operations and blocked app interaction and background saves during archive transactions.
- Added a verified pre-restore safety archive and retained the newest three.
- Added Restore Latest Safety Backup to Settings.
- Added legacy JSON migration with unavailable attachment removal, warnings, and integrity audit notices.
- Added a persistent CloudKit replacement transaction for authoritative Replace restore.
- Blocked ordinary CloudKit merge and download while a replacement is pending.
- Added automatic replacement retry after relaunch or network recovery.
- Added safety-backup deletion to Erase All Data.
- Updated embedded legal text and export warnings for portable backup storage.

## Verification performed

- Parsed all Swift files with the Swift frontend.
- Compiled the exact backup service logic in Swift 6 strict-concurrency mode inside an isolated executable harness.
- Executed archive creation and immediate read-back validation.
- Executed full photo and signature staging and restore.
- Executed interrupted-restore journal rollback when the snapshot was not committed.
- Executed interrupted-restore journal finalization when the saved snapshot revision confirmed commit.
- Executed rollback of a committed marker when the matching saved snapshot was unavailable.
- Executed whole-archive corruption rejection.
- Executed per-file collision rejection for Merge restore.
- Executed legacy JSON migration and missing-attachment removal.
- Executed safety-backup pruning and latest-safety discovery.
- Verified the backup service is present in the Xcode group and Compile Sources phase.
- Verified Merge restore explicitly retains the current profile.
- Verified Replace restore sets the persistent CloudKit replacement flag before scheduling upload.
- Verified normal CloudKit synchronize and download paths reject replacement-pending state.
- Verified the replacement path deletes the custom zone, recreates it, uploads attachments and the snapshot, and clears the persistent flag only after success.
- Verified export and restore acquire and release the CloudKit/local-data exclusion barrier on both success and failure paths.
- Parsed the privacy manifest, entitlements, shared scheme, and asset catalog metadata.
- Recalculated the source SHA-256 manifest and verified the final archive after clean extraction.

## External verification required

The following require macOS, Xcode, Apple signing, and real platform services:

- full iOS compile and link
- simulator and physical-device UI behavior
- Files, iCloud Drive, Google Drive, and OneDrive provider import/export behavior
- file-protection behavior on a locked physical device
- low-storage and interrupted-provider behavior
- real CloudKit replacement after offline restore
- two-device verification that stale cloud records do not return
- signed Release archive, TestFlight, and production CloudKit schema
