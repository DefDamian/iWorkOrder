# iWorkOrder v56 — Hotfix 36 SwiftUI Type-Check Guard

## Native Xcode defect

A physical Xcode build of Hotfix35 exposed a SwiftUI semantic type error in `Theme3OrderRow`: `HStack(alignment: .stretch, spacing: 0)` attempted to use a nonexistent `VerticalAlignment.stretch` member. The portable Swift parser accepted the token because parsing does not perform Apple SwiftUI SDK type checking.

## Correction

The Theme 3 priority rail no longer depends on a fictional stack alignment. The row is built from its content `VStack`, and the priority rail is applied as a leading overlay using the valid `Alignment.leading` member. This preserves the intended full-height visual rail without the invalid `HStack` alignment.

## Regression hardening

Hotfix36 adds a semantic SwiftUI source harness in addition to the existing Swift parser. It rejects `.stretch`, validates literal `HStack`, `VStack`, and `ZStack` alignment members against the alignment type each container accepts, checks common `frame`/`overlay`/`background` alignments, and validates common text/navigation alignment enum literals. The harness is part of both portable release verification and the Mac/Xcode qualification workflow.

The Hotfix35 onboarding `selectedTheme` correction and Hotfix34 Field Deck Theme 3 rebuild remain intact.

## Verification boundary

These checks close a class of parser-clean SwiftUI mistakes, but they do not replace Apple SDK type checking. Final native compilation still requires Xcode on macOS. A package with no embedded `DEVELOPMENT_TEAM` also requires the developer to select their Apple development team in Xcode before running on a physical iPhone; that signing configuration is intentionally not hard-coded into the distributable source.
