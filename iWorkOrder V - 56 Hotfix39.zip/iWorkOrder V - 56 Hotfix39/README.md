# iWorkOrder v56 — Hotfix 39 iPadOS 26 Resizable-Scene Cleanup

Hotfix39 removes the deprecated `UIRequiresFullScreen` key that Xcode 27 warns about when building for the iOS/iPadOS 26 baseline. The app now relies on the modern resizable-scene model directly. The iPad target already declares all four interface orientations, uses a configured launch screen, a SwiftUI `WindowGroup`, adaptive navigation/grids, and no `UIScreen.main` layout sizing, so the deprecated compatibility key is no longer needed. iOS/iPadOS 26.0 remains the minimum deployment target.

See `VERIFICATION_NOTES_v56_HOTFIX39_FULLSCREEN_DEPRECATION.md`.

# iWorkOrder v56 — Hotfix 37 Xcode 27 / Swift 6.4 Audit

Hotfix38 raises the minimum supported OS to **iOS/iPadOS 26.0** while keeping the project on Apple's current stable toolchain: **Xcode 27 (27A266a)**, iOS 27 SDK, and the **Swift 6.4 compiler in Swift 6 language mode**. Address verification now uses `MKGeocodingRequest` and `MKAddressRepresentations` directly because the retired iOS 17-25 MapKit compatibility path is no longer needed. The iOS 27 SwiftUI text-field presentation bridge remains availability-safe for iOS 26. Final native qualification still requires the exact stable Xcode 27 build and iOS 27 SDK by default; hosted macOS 26 CI remains compatibility-only.

The project file still records Xcode 26 as the last **native** recommended-settings migration. That metadata is intentionally not spoofed to Xcode 27 in a non-macOS environment, because doing so could suppress migration recommendations that only Xcode can authoritatively apply. Open and save the project in stable Xcode 27, review any offered project-setting migrations, then run the native Xcode 27 qualification gate before distribution.

See `VERIFICATION_NOTES_v56_HOTFIX37_XCODE27_SWIFT64_AUDIT.md`.

# iWorkOrder v56 — Hotfix 36 SwiftUI Type-Check Guard

Hotfix36 fixes the native Xcode `Type 'VerticalAlignment' has no member 'stretch'` error introduced in the rebuilt Theme 3 work-order row. The priority rail now uses a valid leading overlay, and release verification adds a semantic SwiftUI alignment/API scan because `swiftc -parse` alone cannot catch unknown SwiftUI enum members. Hotfix35 onboarding scope correction, Theme 3 Field Deck, Default, Design 2, legal version `2026.09.16.56`, user data, backup format, and iCloud identity are unchanged.

See `VERIFICATION_NOTES_v56_HOTFIX36_SWIFTUI_TYPECHECK_GUARD.md`.

# iWorkOrder v56 — Hotfix 35 Onboarding Theme-Scope Compile Correction

Hotfix35 fixes the native Xcode compile error in `OnboardingView` where adaptive theme padding referenced `selectedTheme` without declaring that derived theme value in the view's lexical scope. It also adds a shipping-source scope regression scan so the same `selectedTheme` mistake is caught before packaging. Theme 3 Field Deck, Default, Design 2, legal version `2026.09.16.56`, user data, backup format, and iCloud identity are unchanged.

See `VERIFICATION_NOTES_v56_HOTFIX35_ONBOARDING_THEME_SCOPE.md`.

# iWorkOrder v56 — Hotfix 34 Theme 3 Rebuild + Full Bug Loop

Hotfix34 rebuilds Design 3 from scratch as **Field Deck**, a dark graphite-and-mint field-operations interface with compact rails, square operational markers, dedicated Work Orders/Calendar/Hub/Settings structures, and a new theme preview. Default Theme and Design 2 keep their existing identities. The persisted Design 3 enum/raw value and `selectedVisualTheme` storage key are unchanged, so existing users who selected Design 3 remain on Design 3 after upgrading. Work-order schema, legal version `2026.09.16.56`, backup format, bundle identity, and iCloud identity are unchanged. The post-rebuild bug loop also caught and fixed a hidden Emergency-only filter state and dark-theme preview contamination in the theme chooser. After those fixes, the complete app-wide regression loop is rerun.

See `VERIFICATION_NOTES_v56_HOTFIX34_THEME3_REBUILD.md`.

# iWorkOrder v56 — Hotfix 33 Distinct Theme Identity

Hotfix33 fixes the three-theme system after Default Theme, Design 2, and Design 3 had become too visually similar across shared app surfaces. The theme picker now previews each represented theme independently, Design 2 uses a compact command-console language, Design 3 uses a softer blue-purple workflow language, and Calendar/Hub/Settings/shared cards no longer collapse back into one generic presentation. The existing theme storage key, legal version `2026.09.16.56`, work-order schema, backup format, bundle identity, and iCloud identity are unchanged.

See `VERIFICATION_NOTES_v56_HOTFIX33_THEME_IDENTITY.md`.

# iWorkOrder v56 — Hotfix 32 Full Bug Loop

Hotfix32 performs another complete bug loop after Hotfix31. It fixes the remaining translucent privacy-badge and evidence-delete surfaces under Reduce Transparency, removes hidden selected-theme styling dependencies from retained work-order and gated/legal views, pins the Design 2 hero to its own gradient during live theme replacement, and refreshes current release/privacy documentation. Legal version `2026.09.16.56`, work-order schema, backup format, bundle identity, iCloud identity, marketing version, and build number are unchanged.

See `VERIFICATION_NOTES_v56_HOTFIX32_FULL_BUG_LOOP.md`.

# iWorkOrder v56 — Hotfix 31 Frosted Privacy Shield

Hotfix31 replaces the inactive-scene startup-style cover with a dedicated privacy shield for Notification Center, Control Center, and app-switcher transitions. Normal operation uses a strongly blurred/desaturated app surface under restrained system frost with a compact adaptive logo; Reduce Transparency uses an opaque fallback. A first-activation guard prevents the privacy cover from flashing during cold launch, preserving Hotfix30 launch continuity. Legal version `2026.09.16.56`, work-order data, backup format, theme selection, and iCloud identity are unchanged.

See `VERIFICATION_NOTES_v56_HOTFIX31_FROSTED_PRIVACY_SHIELD.md`.

# iWorkOrder v56 — Hotfix 30 Launch Continuity

Hotfix30 replaces the mismatched white native launch screen -> dark SwiftUI splash sequence with one continuous adaptive launch appearance. The native iOS launch screen, SwiftUI splash, and inactive-scene privacy shield now share the same `LaunchBackground` and adaptive `LaunchLogo` assets; the old low-contrast white logo is removed, the logo size is consistent across the handoff, the second-stage title/gradient are removed, and the artificial splash hold is reduced to 320 ms. Legal version `2026.09.16.56`, work-order data, backup format, theme selection, and iCloud identity are unchanged.

See `VERIFICATION_NOTES_v56_HOTFIX30_LAUNCH_CONTINUITY.md`.

# iWorkOrder v56 — Hotfix 29 Live Theme Switching Stabilization

Hotfix29 fixes the in-app theme switching path so Default Theme, Design 2, and Design 3 update from one reactive `@AppStorage` source instead of leaving retained SwiftUI views on stale styling. The change removes the duplicate theme write, disables cross-layout interpolation, keeps the Themes navigation controls visible during Design 2 selection, and adds UI automation that switches all three themes without relaunching. Legal version `2026.09.16.56`, work-order data, backup format, and iCloud identity are unchanged.

See `VERIFICATION_NOTES_v56_HOTFIX29_LIVE_THEME_SWITCHING.md`.

# iWorkOrder v56 — Hotfix 28 Full Bug Loop Integrity Hardening

Hotfix28 is a full regression and source-audit pass over Hotfix27. The audit found and fixed revision-history integrity defects: damaged snapshots containing work orders with zero revisions could previously reach model fallback behavior, two restore paths retained raw-snapshot fallbacks after normalization, and failed/rejected backup restores could cancel a pending iCloud sync without resuming it after a safe rollback. Hotfix28 now blocks invalid revision history at migration, persistence, backup import/export, and restore boundaries, preserves the original recovery data, and resumes the prior cloud operation only after a verified safe rollback. Legal version `2026.09.16.56`, backup format, iCloud container identity, and workflow raw values are unchanged.

See `VERIFICATION_NOTES_v56_HOTFIX28_FULL_BUG_LOOP.md`.

# iWorkOrder v56 — Hotfix 27 Evidence Photo Removal

Hotfix27 adds confirmed deletion controls to every Before/After evidence thumbnail. Newly selected unsaved photos are removed from protected local storage immediately when safe, while photos already referenced by a saved revision are removed only from the revision being edited so historical evidence is not silently corrupted. Backup format, iCloud identity, work-order schema, and legal version `2026.09.16.56` are unchanged.

See `VERIFICATION_NOTES_v56_HOTFIX27_PHOTO_DELETE.md`.

# iWorkOrder v56 — Hotfix 26 Work-Order Badge Layout

Hotfix26 fixes the compact iPhone work-order card footer so priority and status capsules remain readable instead of wrapping into tall pills. The card now adapts between a single metadata row and a clean two-row layout using `ViewThatFits`, with an additional fallback for large Dynamic Type. This is a UI-only correction; legal version `2026.09.16.56`, stored data, backups, iCloud identity, and workflow raw values are unchanged.

See `VERIFICATION_NOTES_v56_HOTFIX26_WORK_ORDER_BADGE_LAYOUT.md`.

# iWorkOrder v56 — Hotfix 25 First-Use Permission Review and Legal Refresh

Hotfix25 adds a device-local permission review that runs after onboarding/current legal acceptance and also appears after a backup restore on a new installation or device. It requests only notification authorization and camera authorization used by the optional torch. Photo selection stays on Apple PhotosPicker without broad Photo Library access; the app does not request Contacts, Calendar, microphone, precise-location, or tracking authorization for the current feature set. Legal version `2026.09.16.56`, effective September 16, 2026, requires renewed acceptance before the permission review and normal protected app access.

See `VERIFICATION_NOTES_v56_HOTFIX25_PERMISSIONS_LEGAL.md`.

# iWorkOrder v56 — Hotfix 23 Xcode Runtime Warning Cleanup

Hotfix 23 targets the warnings exposed by the real Xcode/device run: notification cleanup now uses native async UserNotifications APIs, and AppStore mutations from custom SwiftUI Binding setters are deferred beyond the active view-update transaction. No feature, legal-version, storage-format, bundle-ID, or iCloud-container change is introduced.

# iWorkOrder V - 56 Hotfix22

## Current validation status

This is a consolidated correction pass based on Hotfix21, not proof that every feature has passed a device test. It preserves the legal version, production identity, existing data, and feature set. It adds real executable core regressions alongside the existing source checks.

See `VERIFICATION_NOTES_v56_HOTFIX22_CONSOLIDATED_STABILITY.md` for changes, test scope, and remaining stages. See `ReleaseEvidence/hotfix22_portable_results.json` for the recorded portable test results. Native Apple builds and runtime tests are still pending.

Run `./Scripts/verify_release.sh` for portable checks. Run `./Scripts/run_xcode_ci.sh` on a Mac with Xcode for native qualification. No code-only check certifies the shipped binary.

## Historical release notes

Earlier pass counts below describe earlier snapshots and their test scope; they are not current device-release approval.

# iWorkOrder v56

## Phase 56 Hotfix 21 — Real-world beta hardening

- Reconciles reminders/emergency follow-ups only from successfully persisted work-order state.
- Separates explicit reminder and emergency-follow-up identifiers, with emergency follow-ups tied to the current revision timestamp so expired alerts do not resurrect after reopen/resync.
- Generation-guards asynchronous notification cleanup and removes obsolete cancellation/double-removal code.
- Retries pending notification/deep-link routing when work-order data arrives after launch.
- Keeps device-local notification permission separate from the synced app preference so denial on one device cannot disable another device.
- Removes dormant remote-push launch handling and dead legacy UI containing fake metrics.
- Preserves legal version `2026.09.13.56`.

See `VERIFICATION_NOTES_v56_HOTFIX21_REAL_WORLD_BETA.md`.

## Phase 56 Hotfix 20 — Final release-candidate audit

- Moves evidence conversion and storage-directory inventory work off normal SwiftUI rendering paths.
- Uses lightweight ImageIO pixel validation for attachment readability checks.
- Makes flashlight authorization/lifecycle handling explicit and forces the torch off outside the active editor.
- Caches Support/backup storage summaries rather than scanning recursively during body rendering.
- Preserves the existing bundle/iCloud compatibility identity while keeping the public `iworkorder://` route identity current.
- Preserves legal version `2026.09.13.56`.

See `VERIFICATION_NOTES_v56_HOTFIX20_FINAL_RELEASE_CANDIDATE.md`.

## Phase 56 Hotfix 19 — Release candidate hardening

- Obscures operational content with an opaque privacy shield whenever the app becomes inactive or backgrounded so the task-switcher snapshot does not intentionally expose work-order data.
- Removes the unused full Photo Library permission purpose string because evidence selection uses the system `PhotosPicker` user-selected-access model.
- Keeps the flashlight camera-hardware disclosure, while validating live torch availability and supported mode before activation.
- Rewords public sync/recovery status to iCloud instead of exposing CloudKit implementation jargon.
- Removes stale sync-status localization and adds a dedicated Hotfix 19 release-candidate harness to both release-verification paths.
- Preserves legal version `2026.09.13.56`; these release-hardening changes do not require another legal re-acceptance.

See `VERIFICATION_NOTES_v56_HOTFIX19_RELEASE_CANDIDATE_HARDENING.md`.

## Phase 56 Hotfix 18 — Entire app public beta qualification

- Downsamples Evidence Gallery photos off the SwiftUI rendering path and keeps a bounded actor-isolated thumbnail cache instead of repeatedly decoding full 1080p attachments while scrolling.
- Honors Reduce Motion for custom work-order animations and Reduce Transparency for custom cards, input surfaces, and blocking overlays.
- Lets standard SwiftUI tab/navigation components own their current system appearance instead of forcing a custom tab-bar material layer.
- Replaces hard-coded legacy-theme cloud status text with live `CloudSyncState` information.
- Replaces misleading provider-specific report buttons with one accurate system share-sheet action.
- Adds a dedicated Hotfix 18 public-beta qualification harness to the cross-platform and Xcode release runners.
- Preserves legal version `2026.09.13.56`; these performance/accessibility/UI-accuracy changes do not require another legal re-acceptance.

See `VERIFICATION_NOTES_v56_HOTFIX18_PUBLIC_BETA_QUALIFICATION.md`.

## Phase 56 Hotfix 17 — Public release surface cleanup

- Removes public access to internal Maintenance & Recovery / Release Health tooling in Release builds while retaining it for Debug qualification.
- Compile-time excludes UI-test launch arguments, seeded UI-test data, and the UI-test state loader from Release builds.
- Removes the manual recovery-pause control and API from Release builds and clears any legacy persisted manual pause when a public build starts.
- Replaces the public Support & Diagnostics surface with a normal Support screen that offers only app status, a privacy-safe support package, and email support.
- Removes stale developer-facing localization entries from the shipped string catalog and keeps verification scripts, phase reports, and source documentation out of the app Resources build phase.
- Disables Xcode previews and `@testable` access for the app target's Release configuration.
- Preserves legal version `2026.09.13.56`; this public-surface cleanup does not require another legal re-acceptance.

See `VERIFICATION_NOTES_v56_HOTFIX17_PUBLIC_RELEASE_CLEANUP.md`.

## Phase 56 Hotfix 16 — Swift 6 draft-image cleanup compile fix

- Fixes the Xcode compile failure in `WorkOrderViews.swift` where `ImageStorageService.delete(_:) -> Bool` was passed directly to `Array.forEach`, whose callback must return `Void`.
- Replaces the invalid method reference with an explicit loop that intentionally discards the verified deletion result after each cleanup attempt.
- Audits the project for other direct function references passed to `forEach` and adds a regression gate that rejects this Swift 6 type-mismatch pattern.
- Preserves Hotfix 14 legal version `2026.09.13.56`; no additional legal re-acceptance is triggered by this compile-only fix.

See `VERIFICATION_NOTES_v56_HOTFIX16_FOREACH_COMPILE_FIX.md`.

## Phase 56 Hotfix 15 — Xcode restore access-control compile fix

- Fixes the Xcode compile failure where `AppStore.swift` called `BackupAttachmentTransaction.prepareSnapshotCommit(_:)` across files while the method was incorrectly declared `fileprivate`.
- Keeps the restore transaction API module-internal rather than public, so `AppStore` can call it without widening it outside the app module.
- Adds release and core-stability regression gates that reject the broken `fileprivate` declaration if it ever returns.
- Preserves Hotfix 14 legal version `2026.09.13.56`; users who already accepted that exact legal revision are not forced to re-accept only because of this compile fix.

See `VERIFICATION_NOTES_v56_HOTFIX15_XCODE_ACCESS_CONTROL.md`.

## Phase 56 Hotfix 14 — Legal refresh and mandatory re-acceptance

- Updates the bundled Privacy Policy, Terms & Conditions, and Data & Liability Disclaimer to legal version `2026.09.13.56`, effective September 13, 2026.
- Keeps the public privacy, terms, and disclaimer copies aligned with the authoritative in-app text.
- Shows a dedicated Legal Terms Updated splash when an existing profile has an older accepted legal version.
- Blocks normal app access until the user reviews and accepts the current legal package; declining keeps the app gated.
- Adds UI and release regression checks for stale-version gating, renewed acceptance, public-copy parity, and permission/legal alignment.
- Aligns camera/privacy disclosure with actual behavior: photos use the system photo picker, while `AVCaptureDevice` is used only for the optional rear flashlight/torch and does not capture media.

See `VERIFICATION_NOTES_v56_HOTFIX14_LEGAL_REACCEPTANCE.md`.

## Phase 56 Hotfix 13 — Continued core bug loop

- Continues the find, fix, retest loop after Hotfix 12.
- Fixes silent notification scheduling failures, expired-reminder resurrection, orphan attachment cleanup, and incomplete restore rollback write-safety.
- Extends the core-stability harness to 140 checks and completes another independent clean pass with no additional actionable core defect found.

See `VERIFICATION_NOTES_v56_HOTFIX13_CORE_LOOP.md`.

## Phase 56 Hotfix 12 — Core stability loop

- Iterative defect loop across persistence, CloudKit conflict resolution, backup/restore transactions, attachment integrity, privacy cleanup, onboarding recovery, and erase behavior.
- Adds durable restore-recovery safeguards, actual CloudKit attachment orphan cleanup, verified retention deletion, and stricter Data Protection enforcement.
- Extends the integrated Hotfix 12 core-stability harness and release qualification gates.

See `VERIFICATION_NOTES_v56_HOTFIX12_CORE_STABILITY_LOOP.md`.

## Phase 56 Hotfix 10 — Category Manager persistence and propagation

- Replaces the read-only fixed category list with persisted add, delete, and reorder controls.
- Uses the managed category order in new-work-order forms, Quick Add defaults, dashboard filters, and Theme 3 filters.
- Preserves category values already recorded on existing and signed work orders when a category is removed from future selection.
- Synchronizes category configuration through local storage, portable backups, and CloudKit using schema 3.
- Adds transactional rollback and regression tests for category management.

See `VERIFICATION_NOTES_v56_HOTFIX10_CATEGORY_MANAGER.md`.

## Phase 56 Hotfix 9 — SwiftUI action result ambiguity

- Corrects the Xcode 26 `Void` versus `Bool` generic-result conflict in the work-order trash action.
- Explicitly discards the transactional `moveToTrash(_:)` result inside `withAnimation`.
- Adds a release gate that rejects the ambiguous action form.

See `VERIFICATION_NOTES_v56_HOTFIX9_ACTION_RESULT_AMBIGUITY.md`.

Bundle identifier: `com.damiancedeno.SedgwickWorkOrders`

CloudKit container: `iCloud.com.damiancedeno.SedgwickWorkOrders`

Open `iWorkOrder.xcodeproj` in stable Xcode 27 (build `27A266a`) on macOS Tahoe 26.6 or later. Xcode 27 supplies the Swift 6.4 compiler and iOS 27 SDK; keep the project in Swift 6 language mode. Complete the native Xcode 27 qualification gate before distribution.

## Phase 56 Hotfix 6 — Defect stabilization

This package is a bug-fix-only stabilization pass. It does not add a new product feature.

- Rejects whitespace-only work orders and normalizes required text before persistence.
- Prevents an older open editor from saving over a newer CloudKit revision.
- Rolls back core work-order mutations when local persistence fails.
- Commits signatures only after the completed work order saves successfully and blocks duplicate signature submissions.
- Deletes uncommitted draft photos and signatures when creation or editing is cancelled.
- Preserves seconds in notification triggers so near-term reminders are not truncated into the past.
- Keeps onboarding and Settings iCloud controls synchronized.
- Uses stable share-sheet item identity and includes attachments in the Mail fallback.
- Replaces Theme 2 placeholder counts and incorrect overdue/status behavior with live data.
- Reports photo, flashlight, and PDF failures instead of silently doing nothing.
- Extends UI automation through the full signed-completion transition.

See `VERIFICATION_NOTES_v56_HOTFIX6_DEFECT_STABILIZATION.md`.

## Phase 56 Hotfix 2

This package fixes the onboarding legal-agreement stall found during physical Xcode testing:

- Corrected the legal sheet so **I Understand and Agree** invokes the acceptance callback instead of silently doing nothing.
- Dismisses the agreement sheet only after current-version acceptance is confirmed in `AppStore`.
- Disables the Agree button if a future caller omits its callback.
- Added stable automation identifiers and a UI regression test for acceptance and dismissal.

## Phase 56 Hotfix 1

This package includes the first real-Xcode compile corrections discovered during Phase 56 execution:

- Replaced three obsolete `EmailHelper.email(order:)` calls with the native `MailDraft` presentation flow.
- Added Mail composer and share-sheet presentation to swipe, context-menu, and accessibility email actions.
- Safely unwrapped the optional diagnostics URL before reading `pathExtension`.
- Added release checks that prevent these compile regressions from returning.
- Apple signing credentials are intentionally not embedded. Select the authorized Team in Xcode under **Signing & Capabilities** before building on a physical device.

## Phase 56

Build 56 adds the strict Apple release-qualification execution and evidence system. It does not add another speculative app feature.

- Advanced the app, unit-test target, and UI-test target to build `56`.
- Added a Phase 56 Mac/Xcode qualification runner.
- Added five-iteration unit-test stabilization.
- Added optional connected iPhone and iPad test evidence.
- Added signed archive, entitlement, code-signature, IPA, and artifact-index validation.
- Added a machine-readable evidence matrix.
- Added a final gate that refuses pending, blocked, failed, missing, or unsafe evidence.
- Retained all Phase 46 through Phase 55 data-integrity, CloudKit, backup, security, accessibility, App Store, migration, and field-reliability safeguards.

Read:

- `PHASE56_MAC_EXECUTION_GUIDE.md`
- `PHASE56_DEVICE_TEST_MATRIX.md`
- `VERIFICATION_NOTES_v56_APPLE_RELEASE_QUALIFICATION.md`
- `RELEASE_VALIDATION_CHECKLIST.md`
- `APP_STORE_SUBMISSION_HANDOFF.md`
- `TESTFLIGHT_STABILIZATION_PLAN.md`
- `Config/README_SIGNING.md`

## Cross-platform package verification

```bash
./Scripts/verify_release.sh
```

This validates the project structure, source integrity, app logic harnesses, privacy and legal alignment, accessibility, metadata, scripts, and the pending Phase 56 evidence template.

## Mac simulator and unsigned archive qualification

```bash
./Scripts/run_xcode_ci.sh
```

Evidence is written to `Artifacts/Phase56`.

## Signed release-candidate qualification

```bash
APPLE_TEAM_ID=YOUR_TEAM_ID \
PHASE56_MODE=signed \
./Scripts/phase56_xcode_qualification.sh
```

This creates and validates a signed archive and App Store Connect IPA. It intentionally does not upload or submit the app.

## Final release gate

The final gate requires completed physical-device, CloudKit production, privacy-report, accessibility, website, screenshot, App Store Connect, and TestFlight evidence:

```bash
APPLE_TEAM_ID=YOUR_TEAM_ID \
PHASE56_MODE=signed \
PHASE56_FINAL_GATE=1 \
PHASE56_MANUAL_EVIDENCE=/path/to/completed_phase56_evidence.json \
./Scripts/phase56_xcode_qualification.sh
```

The repository must never contain certificates, private keys, provisioning profiles, passwords, App Store Connect API keys, issuer IDs, or other credentials.

## Current release status

The source package is ready for Phase 56 execution. Phase 56 is not complete until the final evidence validator passes on a Mac with an authorized Apple Developer account and the required physical devices and Apple services.

## v56 Hotfix 3 — Swift 6 Concurrency

Resolved the Xcode 26 strict-concurrency build failures by isolating UI services to the main actor, making callback transfers Sendable, removing unsafe captures, and explicitly configuring Swift 6. See `VERIFICATION_NOTES_v56_HOTFIX3_SWIFT6_CONCURRENCY.md`.

## v56 Hotfix 4

- Removed the ineffective `@preconcurrency` annotation from `UNUserNotificationCenterDelegate` conformance.
- Preserved explicit `@MainActor` service isolation and `nonisolated` delegate callbacks.
- Added a release verification gate that rejects the warning pattern.

## v56 Hotfix 5 - Signature completion controls

Fixed the PencilKit state bridge so drawing a signature immediately enables Clear Signature and Save Signature. Added a delegate coordinator and a UI regression test for the completion flow.

### v56 Hotfix 7 transactional-integrity stabilization

Hotfix 7 corrects additional defect paths discovered during the second release audit. It fixes recovery-versus-deletion CloudKit merging, save-revision commit ordering, pending integrity evidence, cloud-result rollback, signed-record audit immutability, transactional trash and directory mutations, retention cleanup ordering, shared-attachment protection, stale address-verification callbacks, and backup export consistency. See `VERIFICATION_NOTES_v56_HOTFIX7_TRANSACTIONAL_INTEGRITY.md`.


## v56 Hotfix 20 — Final release-candidate audit

- Moved selected-photo downsampling and JPEG conversion to an ImageIO path that runs away from the SwiftUI actor, preventing large evidence imports from synchronously decoding and redrawing full images in the form.
- Added regression coverage proving picker bytes are converted to a readable bounded JPEG.
- Made the optional flashlight camera-authorization aware and cancellation aware before torch activation.
- Forces the torch off when the evidence form leaves the foreground or disappears, including the case where camera authorization returns after the form is no longer visible.
- Prevents overlapping flashlight hardware requests while permission/configuration work is in progress.
- Moved recursive local-storage size calculation out of normal Support view rendering and onto a utility task.
- Moved Export & Backup storage totals and latest-safety-backup discovery out of SwiftUI body rendering and into the same cached utility refresh path.
- Replaced full signature-image decoding during signed-record integrity checks with a tiny ImageIO pixel-decode validation.
- Updated the descriptive custom-URL identifier to `com.damiancedeno.iWorkOrder` while preserving the existing `iworkorder` scheme, bundle identifier, and iCloud container compatibility identities.
- Added `Scripts/run_final_rc_harness.py` to enforce these release-candidate guarantees.

## v56 Hotfix 31 — Frosted privacy shield

Hotfix31 redesigns the inactive-scene privacy presentation used when Notification Center, Control Center, or the app switcher covers iWorkOrder. Instead of showing the full startup splash, the app now strongly blurs and desaturates its current content, places a frosted material layer over it, and shows only a small adaptive iWorkOrder mark. Reduce Transparency receives a solid adaptive fallback. A first-activation guard prevents this privacy layer from flashing during cold launch, preserving Hotfix30 startup continuity.

See `VERIFICATION_NOTES_v56_HOTFIX31_FROSTED_PRIVACY_SHIELD.md`.
