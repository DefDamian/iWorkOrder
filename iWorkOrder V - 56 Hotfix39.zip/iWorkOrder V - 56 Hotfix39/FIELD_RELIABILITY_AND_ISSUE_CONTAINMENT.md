# Field reliability and issue containment

Phase 55 adds local-only reliability evidence and recovery controls without developer-operated telemetry.

## Runtime session checkpoint

The app maintains one replaceable JSON checkpoint inside its private app container. It records only the current lifecycle state, session start and update times, build number, data-schema version, and an aggregate memory-warning count.

If a new launch finds that the prior checkpoint was not cleanly marked as backgrounded, the app records a **possible interrupted session**. This is deliberately not labeled a crash because iOS does not guarantee a termination callback and the previous process may have ended for several reasons.

## Memory-pressure evidence

The app records only an aggregate local memory-pressure event and count. It does not capture memory contents, work-order fields, names, addresses, images, signatures, filenames, or device identifiers.

## Recovery cloud-sync pause

A user can pause ordinary CloudKit synchronization while continuing to use and save the app locally. The pause does not cancel or bypass a cloud erase or an authoritative backup-replacement transaction already in progress. This prevents partial recovery operations from being abandoned.

The pause is local, user-controlled, visible in Cloud and Maintenance settings, and removed by Erase All Data.

## Verified support bundle

The `.iworkordersupport` bundle contains:

- the privacy-safe technical diagnostic report;
- the privacy-safe maintenance report;
- aggregate runtime reliability status;
- bounded structured maintenance events; and
- a SHA-256 checksum covering the content payload.

The bundle excludes operational content and is exported only after a user action. It is not uploaded automatically.

## Release use

During TestFlight or production support:

1. Ask the user to enable the recovery sync pause only when containment is necessary.
2. Ask the user to export a verified support bundle.
3. Validate the checksum before reviewing the report.
4. Do not infer a crash solely from a possible interrupted-session event.
5. Resume CloudKit only after the underlying issue is understood and any pending erase or replacement transaction has completed.
