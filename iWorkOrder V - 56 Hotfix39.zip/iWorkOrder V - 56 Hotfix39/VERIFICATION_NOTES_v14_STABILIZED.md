# iWork v14 Stabilized

Baseline: iWork v13.

Scope: stabilization only. No major features were removed or rewritten.

Changes made:
- Removed unused `rect` declaration in `PDFExportService` to clear the PDF export warning.
- Limited iPhone supported orientation declaration to Portrait in the Xcode project settings to clear the orientation warning for the current portrait-only UI.
- Preserved v13 feature set: onboarding persistence, iCloud/local storage, audit log, PDF export, legal screens, haptics, notification routing, image compression, work order filters, trash/reset, and security settings.

Verification performed:
- Swift parse check passed across all `.swift` files.
- `PrivacyInfo.xcprivacy` passed `plutil -lint`.
- `iWorkOrder.entitlements` passed `plutil -lint`.
- Confirmed no remaining `let rect =` unused declaration in Services.swift.
- Confirmed iPhone interface orientation is set to Portrait in project.pbxproj.

Manual device tests still recommended:
- Complete onboarding, force close, reopen, confirm onboarding does not reset.
- Create work order, add photos, sign, reopen, confirm audit log and lock behavior remain intact.
- Export PDF and inspect output.
- Test iCloud sync on another signed-in device.
