# iWorkOrder v56 Hotfix37 — Xcode 27 / Swift 6.4 Audit

Date: September 17, 2026

## Toolchain target

This audit targets Apple’s current stable release toolchain:

- Xcode 27, build `27A266a`
- iOS 27 SDK
- Swift 6.4 compiler
- Swift 6 language mode
- Existing iOS 17.0 deployment target retained

The project remains configured with `SWIFT_VERSION = 6.0`. Xcode uses that setting to select Swift language mode; Swift 6.4 is the compiler version supplied by Xcode 27 and is not a valid replacement value for that project setting.

## Source modernization

`AddressVerifier` in `iWorkOrder/Services.swift` no longer uses the superseded `CLGeocoder`, `CLPlacemark`, or `CNPostalAddressFormatter` path.

- iOS 26 and later use `MKGeocodingRequest`.
- The returned `MKMapItem` uses `MKAddressRepresentations` to obtain the formatted address and city.
- iOS 17 through iOS 25 use a bounded `MKLocalSearch` address-only fallback so the deployment target does not need to be raised solely for the new geocoding API. The fallback now requires the returned street number and meaningful street-name tokens to agree with the typed address before verification succeeds.
- Existing stale-response generation protection and cancellation behavior remain in place.
- Portable behavior fakes were updated so address verification remains executable in the non-Apple regression harness.

SwiftUI text fields were also migrated away from direct `.roundedBorder` usage. On iOS 27 the shared compatibility modifier uses `.bordered` with `textInputBorderShape(.roundedRectangle)`; the legacy `.roundedBorder` call is isolated inside an availability-bounded iOS 17–26 helper so older supported systems retain their existing presentation without exposing the deprecated call in normal Xcode 27 code paths.

## Xcode 27 release gating

`Scripts/phase56_xcode_qualification.sh` now requires the exact stable Xcode 27 build `27A266a` and iOS 27 SDK by default. The hosted macOS 26 CI workflow runs only with the explicit `PHASE56_ALLOW_XCODE26_COMPATIBILITY=1` override and is labeled compatibility-only.

The final native gate therefore cannot silently pass on Xcode 26 or on a different Xcode 27 beta build.

## Xcode project metadata

The project file continues to record Xcode 26 as the last native recommended-settings migration (`LastUpgradeCheck = 2600`, `CreatedOnToolsVersion = 26.0`). This is intentional. The audit environment does not provide Xcode, so stamping those values to 2700 would falsely claim that Xcode 27 had opened the project and applied/reviewed its recommended project-setting migration.

On the Mac that performs release qualification, open the project in stable Xcode 27, review any recommended settings, save the project, and then rerun the full qualification. Any resulting project-file change must be regression-tested before distribution.

## Additional migration checks

The shipping Swift source was scanned for common obsolete or high-risk patterns. The current source contains no `NavigationView`, `UIWebView`, legacy key-window lookup, force cast, forced `try`, or `fatalError` use in the shipping app target. The custom `@State` initialization in `WorkOrderDetailView` was also checked for the Xcode 27 SwiftUI state-macro migration hazard; the three custom-initialized state properties do not also declare competing initial values.

Strict Swift concurrency remains enabled for the app and tests.

## Verification performed in this environment

The post-change portable regression loop completed successfully in bounded batches so one long-running command could not mask later results. The completed loop includes:

- `Scripts/verify_release.py` release/package integrity verification.
- Every executable/source regression harness invoked by `Scripts/verify_release.sh`, from the core logic gates through Hotfix37.
- Hotfix22 executable behavior verification: 83 checks passed.
- Public release, public beta, release-candidate, final-RC, reliability, transactional-integrity, maintenance, accessibility, submission, and dedicated Hotfix21–Hotfix37 gates.
- App Store metadata validation.
- Phase 56 evidence-template validation. The template is valid; its 22 native/device/service gates intentionally remain pending until they are run on Apple hardware/tooling.
- Swift parser validation for both Release and DEBUG source configurations available to the portable Swift compiler.
- Python bytecode compilation for all verification scripts and shell syntax validation for all shell scripts.
- Shipping-source scans for the superseded address APIs and other high-risk patterns covered by this audit.
- Source-manifest regeneration and final SHA-256 integrity verification.

The loop initially exposed stale verification assertions that still expected the old hosted-CI artifact name and the old `CLGeocoder` implementation. Those assertions were updated to validate the Xcode 27 compatibility-CI contract and the modern MapKit cancellation/generation guards, then the affected gates were rerun successfully.

## Required native verification before distribution

This environment is not macOS and does not contain Xcode or Apple’s iOS SDK. Therefore it cannot honestly claim a native Xcode 27 compile, SwiftUI type check against the iOS 27 SDK, simulator run, physical-device test, archive, signing check, CloudKit production test, or TestFlight processing result.

Before public distribution, run `Scripts/phase56_xcode_qualification.sh` on macOS Tahoe 26.6 or later with stable Xcode 27 build `27A266a`, then complete the physical-device and Apple-service evidence gates in `RELEASE_VALIDATION_CHECKLIST.md` and `PHASE56_DEVICE_TEST_MATRIX.md`.
