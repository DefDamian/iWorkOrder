# iWorkOrder V - 56 Hotfix24 First-Launch Recovery

## Change

Fresh installs now stop at a recovery decision before onboarding.

The user can:

1. Restore a verified portable `.iworkorderbackup` file or supported legacy JSON backup.
2. Restore existing private iCloud data.
3. Confirm that no backup exists and continue to normal onboarding.

A successful restore marks onboarding complete and restores the saved profile and application data. If the restored profile accepted an older legal version, the existing legal-update gate remains mandatory, but the full onboarding form is not shown again.

## Safety behavior

- Portable backup files use the existing validation, checksum, staging, safety-backup, attachment-journal, rollback, and protected-storage restore path.
- First-launch file restore uses Replace Current Data so the saved profile is restored rather than retaining an empty default profile.
- A brand-new unsaved default iCloud preference is no longer treated as authoritative existing cloud state when deciding whether a restored archive should replace CloudKit data.
- Automatic pre-onboarding CloudKit recovery is paused while the recovery choice is visible. iCloud recovery occurs only after the user explicitly chooses it.
- Starting a new setup disables the recovery gate for that setup session and does not silently restore cloud data behind the onboarding form.
- Existing local snapshots, data-compatibility blocks, pending cloud deletion, and interrupted-restore protection keep their existing precedence.

## Regression coverage

- Added a deterministic UI-test launch mode for the recovery gate.
- Added UI coverage proving the recovery screen appears before onboarding and that onboarding appears after the explicit no-backup choice.
- Added `run_hotfix24_first_launch_recovery_harness.py` to verify routing, restore semantics, cloud-replacement safeguards, and UI wiring.
- Swift parser validation is run in both Release and Debug parser modes by the cross-platform verification script.
