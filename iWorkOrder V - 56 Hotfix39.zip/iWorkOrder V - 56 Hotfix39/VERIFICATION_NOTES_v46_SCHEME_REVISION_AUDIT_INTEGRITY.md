# v46 Scheme, Revision, and Audit Integrity

Scope: Phase 46 release-integrity hardening.

## Changes made

- Repaired every shared Xcode scheme reference to use the real `iWorkOrder` PBX target identifier.
- Every saved work-order revision now receives a fresh UUID and monotonic save timestamp before it is appended.
- A new revision cannot inherit the prior revision's signature file; only a newly captured signature can certify the new revision.
- Added deterministic pre-merge and load/save migration that repairs duplicate historical revision IDs while preserving revision count and order.
- Added an explicit `Integrity Notice` status-event type.
- Removed the rule that treated every completed work order as signed.
- Completed unsigned work orders now receive one deduplicated integrity notice, not a false signature event.
- Completed signed work orders receive a signature verification event only when the latest revision has an attached signature filename.
- Completion-lock audit events are generated only when absent.
- Legacy false signature events created by older builds are converted into integrity notices.
- Automatically generated integrity events are deduplicated on load and save.

## Verification performed

- Confirmed the scheme target ID exists in `project.pbxproj`.
- Confirmed no obsolete target identifier remains in the package.
- Parsed every Swift source file with the Swift frontend.
- Parsed the shared Xcode scheme and privacy manifest as XML.
- Ran static Phase 46 assertions for fresh revision UUID/timestamp assignment, legacy event conversion, and generated-event deduplication.
- Ran executable Swift logic tests for deterministic duplicate-ID repair, monotonic revision dates, signature separation, unsigned-completion handling, and repeated-save deduplication.

## Xcode limitation

A full iOS build, simulator run, archive, code signing check, and device UI test require macOS with Xcode and cannot be executed in this Linux verification environment.
