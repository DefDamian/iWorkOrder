# Phase 56 Hotfix 14 — Legal refresh and mandatory re-acceptance

Date: September 13, 2026
Legal version: `2026.09.13.56`

## Changes

- Rewrote the authoritative bundled Privacy Policy, Terms & Conditions, and Data & Liability Disclaimer to reflect current app behavior.
- Updated public privacy, terms, and disclaimer files from the same authoritative text.
- Added explicit disclosures for optional private CloudKit sync, Apple geocoding of a user-entered address, user-controlled exports, retention/deletion, local reliability records, electronic signatures, notifications, backups, and recovery.
- Added a dedicated Legal Terms Updated splash for an already-onboarded profile whose accepted legal version is not current.
- Normal app access remains gated until `LegalContent.isCurrentAcceptance` succeeds.
- Declining clears acceptance and leaves normal app access blocked.
- Launch-time biometric authentication waits until onboarding is complete and the current legal version has been accepted, so App Lock cannot obscure the legal-update splash.
- Acceptance is persisted transactionally with the exact current legal version and an acceptance timestamp; a partial acceptance record does not unlock the app.
- Source review confirmed photo attachments use `PhotosPicker`, while `AVCaptureDevice` is used only for the optional rear flashlight/torch. `NSCameraUsageDescription` is retained with an accurate torch-only purpose string; the app does not start a camera capture session or record photos/video through that API.

## Regression coverage

- Added an XCUITest path that starts with a stale accepted legal version, verifies the update splash, verifies decline remains blocked, then verifies renewed acceptance unlocks the seeded app.
- Added release and core-stability assertions for the legal version, effective date, splash stage, stale-version gate, complete acceptance record, transactional accept/decline behavior, torch/photo permission alignment, and public-copy parity.
- Existing current-version acceptance and CloudKit legal-acceptance conflict tests remain in place.

## External compliance references reviewed

- Apple App Review Guidelines 5.1.1 privacy-policy requirements.
- App Store Connect privacy-policy and App Privacy metadata requirements.
- Apple Standard Licensed Application End User License Agreement behavior when no custom EULA is supplied.

These legal documents are compliance-oriented product text, not a substitute for review by qualified legal counsel for the developer's specific business, state, property, employment, or tenant-law obligations.
