# iWorkOrder v56 Hotfix 5 - Signature Completion Controls

## Defect

The PencilKit signature canvas displayed user strokes, but `SignatureCanvas` never assigned a `PKCanvasViewDelegate`. The SwiftUI `PKDrawing` binding therefore remained empty. Because the Save Signature and Clear Signature buttons derive their enabled state from `drawing.strokes.isEmpty`, both controls stayed disabled after the user signed.

## Correction

- Added a `PKCanvasViewDelegate` coordinator.
- Connected the coordinator to `PKCanvasView.delegate`.
- Copies every PencilKit drawing change into the SwiftUI binding.
- Added stable accessibility identifiers for the status picker and Sign and Save action.
- Added UI automation that draws on the signature canvas and verifies that Clear Signature and Save Signature become enabled.

## Expected behavior

After drawing a signature and providing a signer name, Save Signature becomes enabled. Saving the signature completes and locks the current work-order revision.
