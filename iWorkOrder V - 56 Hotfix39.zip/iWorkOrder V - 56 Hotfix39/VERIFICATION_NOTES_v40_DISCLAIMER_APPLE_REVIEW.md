# iWorkOrder v40 - Disclaimer URL + Apple Submission Review

> Historical note: Hotfix 19 supersedes the older photo-library-purpose-string statement below. The current app uses SwiftUI `PhotosPicker` only and no longer ships `NSPhotoLibraryUsageDescription`; `NSCameraUsageDescription` remains for the optional torch.


## Changes made
- Added `Data & Liability Disclaimer` as an in-app Legal web document.
- URL added: `https://github.com/DefDamian/iWorkOrder/blob/main/Data-Liability-Disclaimer`.
- Kept offline fallback text inside the app if the web page fails to load.
- Updated the fallback disclaimer text to match the current legal baseline: iCloud/device storage, no external work-order server, permanent audit logs, PDF export responsibility, no warranty, state-law limitations, electronic signature consent, and emergency disclaimer.
- Updated Terms URL to the current clean GitHub file path: `https://github.com/DefDamian/iWorkOrder/blob/main/terms-of-service`.
- Removed unused `CoreLocation`, `MapKit`, and `Contacts` imports from `Services.swift` to reduce unnecessary privacy surface.

## Apple submission review notes
- Privacy policy link is present in Settings > Legal.
- Terms of Service link is present in Settings > Legal.
- Data & Liability Disclaimer link is present in Settings > Legal.
- Web documents open inside the app using WKWebView, not Safari.
- In-app fallback legal text exists for Privacy, Terms, and Disclaimer.
- Privacy manifest exists and declares no tracking.
- App includes required camera and photo library usage descriptions in the Xcode build settings.
- The app states United States only in the Legal section and fallback legal documents.
- PDF exports include legal notice language and export metadata.

## Manual checks still required in Xcode/App Store Connect
- Build and archive from Xcode on macOS.
- Confirm all three legal web links load on a physical device.
- Confirm GitHub Pages or GitHub file visibility is public before App Review.
- Confirm App Store Connect privacy answers match actual behavior.
- Confirm app icon, screenshots, subtitle, description, and support URL are final.
